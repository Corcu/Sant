

/* Applying Schema Statements - start */


    CREATE TABLE cm_calculation_set (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         name varchar2 (255) NOT NULL,
         official numeric  NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_source (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         source varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_status (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         source varchar2 (255) NOT NULL,
         status varchar2 (255) NOT NULL,
         import_date numeric  NOT NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_status_errors (
        rf_status_id varchar2 (64) NOT NULL,
         errors varchar2 (4000) NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_calc_request (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         account_id varchar2 (64) NOT NULL,
         status varchar2 (255) NOT NULL,
         valuation_date numeric  NULL,
         request_time numeric  NULL,
         time_horizon varchar2 (255) NULL,
         save_results numeric  DEFAULT 1 NOT NULL,
         pricing_env_name varchar2 (255) NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_calc_request_errors (
        request_id varchar2 (64) NOT NULL,
         error_messages varchar2 (4000) NOT NULL,
         error_messages_order numeric  NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_what_if_request (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         status varchar2 (255) NOT NULL,
         valuation_date numeric  NOT NULL,
         pricing_env_name varchar2 (255) NULL 
    ) 
/

    CREATE TABLE cm_simm_what_if_request_errors (
        request_id varchar2 (64) NOT NULL,
         errors varchar2 (4000) NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_what_if_req2calc (
        what_if_request_id varchar2 (64) NOT NULL,
         calc_request_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_what_if (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         what_if_request_id varchar2 (255) NOT NULL,
         valuation_date numeric  NOT NULL,
         trade_id varchar2 (255) NOT NULL,
         trade_sub_id varchar2 (255) NULL,
         uti varchar2 (127) NULL,
         party_id varchar2 (255) NULL,
         counterparty_id varchar2 (255) NULL,
         account_id varchar2 (255) NOT NULL,
         im_model varchar2 (255) NOT NULL,
         risk_type varchar2 (20) NOT NULL,
         product_class varchar2 (64) NOT NULL,
         qualifier varchar2 (255) NULL,
         bucket varchar2 (255) NULL,
         label1 varchar2 (255) NULL,
         label2 varchar2 (255) NULL,
         currency varchar2 (3) NOT NULL,
         amount float  NOT NULL,
         amount_base float  NULL,
         amount_usd float  NULL,
         source varchar2 (255) NULL,
         pricing_env varchar2 (255) NULL,
         end_date varchar2 (64) NULL 
    ) 
/

    CREATE TABLE cm_rf_what_if_collect_reg (
        rf_id varchar2 (64) NOT NULL,
         collect_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_what_if_post_reg (
        rf_id varchar2 (64) NOT NULL,
         post_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_trade (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         valuation_date numeric  NOT NULL,
         trade_id varchar2 (255) NOT NULL,
         trade_sub_id varchar2 (255) NULL,
         uti varchar2 (127) NULL,
         party_id varchar2 (255) NOT NULL,
         counterparty_id varchar2 (255) NOT NULL,
         account_id varchar2 (255) NOT NULL,
         im_model varchar2 (255) NOT NULL,
         risk_type varchar2 (20) NOT NULL,
         product_class varchar2 (64) NOT NULL,
         qualifier varchar2 (255) NULL,
         bucket varchar2 (255) NULL,
         label1 varchar2 (255) NULL,
         label2 varchar2 (255) NULL,
         currency varchar2 (3) NOT NULL,
         amount float  NOT NULL,
         amount_base float  NULL,
         amount_usd float  NULL,
         source varchar2 (255) NULL,
         end_date varchar2 (64) NULL,
         pricing_env varchar2 (255) NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_trade_collect_reg (
        rf_id varchar2 (64) NOT NULL,
         collect_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_trade_post_reg (
        rf_id varchar2 (64) NOT NULL,
         post_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_bucket (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         risk_class varchar2 (32) NOT NULL,
         qualifier varchar2 (64) NOT NULL,
         bucket varchar2 (32) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_status_hist (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         source varchar2 (255) NOT NULL,
         status varchar2 (255) NOT NULL,
         import_date numeric  NOT NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_status_errors_hist (
        rf_status_id varchar2 (64) NOT NULL,
         errors varchar2 (4000) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_status_temp (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         source varchar2 (255) NOT NULL,
         status varchar2 (255) NOT NULL,
         import_date numeric  NOT NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_status_errors_temp (
        rf_status_id varchar2 (64) NOT NULL,
         errors varchar2 (4000) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_trade_hist (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         valuation_date numeric  NOT NULL,
         trade_id varchar2 (255) NOT NULL,
         trade_sub_id varchar2 (255) NULL,
         uti varchar2 (127) NULL,
         party_id varchar2 (255) NOT NULL,
         counterparty_id varchar2 (255) NOT NULL,
         account_id varchar2 (255) NOT NULL,
         im_model varchar2 (255) NOT NULL,
         risk_type varchar2 (20) NOT NULL,
         product_class varchar2 (64) NOT NULL,
         qualifier varchar2 (255) NULL,
         bucket varchar2 (255) NULL,
         label1 varchar2 (255) NULL,
         label2 varchar2 (255) NULL,
         currency varchar2 (3) NOT NULL,
         amount float  NOT NULL,
         amount_base float  NULL,
         amount_usd float  NULL,
         source varchar2 (255) NULL,
         end_date varchar2 (64) NULL,
         pricing_env varchar2 (255) NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_trade_collect_reg_hist (
        rf_id varchar2 (64) NOT NULL,
         collect_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_trade_post_reg_hist (
        rf_id varchar2 (64) NOT NULL,
         post_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_trade_temp (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         valuation_date numeric  NOT NULL,
         trade_id varchar2 (255) NOT NULL,
         trade_sub_id varchar2 (255) NULL,
         uti varchar2 (127) NULL,
         party_id varchar2 (255) NOT NULL,
         counterparty_id varchar2 (255) NOT NULL,
         account_id varchar2 (255) NOT NULL,
         im_model varchar2 (255) NOT NULL,
         risk_type varchar2 (20) NOT NULL,
         product_class varchar2 (64) NOT NULL,
         qualifier varchar2 (255) NULL,
         bucket varchar2 (255) NULL,
         label1 varchar2 (255) NULL,
         label2 varchar2 (255) NULL,
         currency varchar2 (3) NOT NULL,
         amount float  NOT NULL,
         amount_base float  NULL,
         amount_usd float  NULL,
         source varchar2 (255) NULL,
         end_date varchar2 (64) NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_trade_collect_reg_temp (
        rf_id varchar2 (64) NOT NULL,
         collect_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_trade_post_reg_temp (
        rf_id varchar2 (64) NOT NULL,
         post_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_calc_request_hist (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         account_id varchar2 (64) NOT NULL,
         status varchar2 (255) NOT NULL,
         valuation_date numeric  NULL,
         request_time numeric  NULL,
         time_horizon varchar2 (255) NULL,
         save_results numeric  DEFAULT 1 NOT NULL,
         pricing_env_name varchar2 (255) NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_calc_req_errors_hist (
        request_id varchar2 (64) NOT NULL,
         error_messages varchar2 (4000) NOT NULL,
         error_messages_order numeric  NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_calc_request_temp (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         account_id varchar2 (64) NOT NULL,
         status varchar2 (255) NOT NULL,
         valuation_date numeric  NULL,
         request_time numeric  NULL,
         time_horizon varchar2 (255) NULL,
         save_results numeric  DEFAULT 1 NOT NULL,
         pricing_env_name varchar2 (255) NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_calc_req_errors_temp (
        request_id varchar2 (64) NOT NULL,
         error_messages varchar2 (4000) NOT NULL,
         error_messages_order numeric  NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_wif_req_temp (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         status varchar2 (255) NOT NULL,
         valuation_date numeric  NOT NULL,
         pricing_env_name varchar2 (255) NULL 
    ) 
/

    CREATE TABLE cm_simm_wif_req_errors_temp (
        request_id varchar2 (64) NOT NULL,
         errors varchar2 (4000) NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_wif_req2calc_temp (
        what_if_request_id varchar2 (64) NOT NULL,
         calc_request_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_what_if_temp (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         what_if_request_id varchar2 (255) NOT NULL,
         valuation_date numeric  NOT NULL,
         trade_id varchar2 (255) NOT NULL,
         trade_sub_id varchar2 (255) NULL,
         uti varchar2 (127) NULL,
         party_id varchar2 (255) NULL,
         counterparty_id varchar2 (255) NULL,
         account_id varchar2 (255) NOT NULL,
         im_model varchar2 (255) NOT NULL,
         risk_type varchar2 (20) NOT NULL,
         product_class varchar2 (64) NOT NULL,
         qualifier varchar2 (255) NULL,
         bucket varchar2 (255) NULL,
         label1 varchar2 (255) NULL,
         label2 varchar2 (255) NULL,
         currency varchar2 (3) NOT NULL,
         amount float  NOT NULL,
         amount_base float  NULL,
         amount_usd float  NULL,
         source varchar2 (255) NULL,
         pricing_env varchar2 (255) NULL,
         end_date varchar2 (64) NULL 
    ) 
/

    CREATE TABLE cm_rf_wif_collect_reg_temp (
        rf_id varchar2 (64) NOT NULL,
         collect_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_wif_post_reg_temp (
        rf_id varchar2 (64) NOT NULL,
         post_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_im_monitoring_config (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         warning_ccy varchar2 (3) NOT NULL,
         variation numeric  NOT NULL,
         max_total_im float  NOT NULL 
    ) 
/

    CREATE TABLE product_ftp (
        product_id numeric  NOT NULL,
         original_security_id numeric  NOT NULL,
         original_trade_id numeric  NOT NULL,
         original_trade_version numeric  NOT NULL,
         original_trade_model numeric  NOT NULL,
         original_trade_blob blob  NULL,
         product_sub_type varchar2 (32) NOT NULL,
         funding_cost varchar2 (32) NOT NULL,
         is_mirror numeric  NOT NULL,
         maturity_date timestamp  NOT NULL,
         principal float  NULL,
         kpi_ms numeric  NOT NULL,
         kpi_ms_remote numeric  NOT NULL,
         kpi_ms_explode numeric  NOT NULL,
         kpi_ms_generate numeric  NOT NULL,
         kpi_ms_measures numeric  NOT NULL,
         num_legs numeric  NOT NULL,
         num_error numeric  NOT NULL,
         num_reconventions numeric  NOT NULL,
         num_effective_dates numeric  NOT NULL,
         update_time timestamp  NOT NULL,
         update_revision varchar2 (32) NOT NULL 
    ) 
/

    CREATE TABLE product_ftp_leg (
        product_id numeric  NOT NULL,
         trade_date_time timestamp  NOT NULL,
         effective_date timestamp  NOT NULL,
         end_date timestamp  NOT NULL,
         original_trade_version numeric  NOT NULL,
         trade_blob blob  NULL,
         trade_measures blob  NULL,
         trade_status varchar2 (32) NULL,
         trade_error varchar2 (255) NULL,
         update_time timestamp  NOT NULL 
    ) 
/

    CREATE TABLE core_account_attribute (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         account_id varchar2 (36) NOT NULL,
         name varchar2 (255) NOT NULL,
         value varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_account_interest_config (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         currency varchar2 (255) NOT NULL,
         instance varchar2 (255) NULL,
         quote_set_name varchar2 (255) NULL 
    ) 
/

    CREATE TABLE core_bond (
        acc_daycount varchar2 (255) NULL,
         accrual_rounding numeric  NULL,
         acr_rounding_mthd varchar2 (255) NULL,
         active_date numeric  NULL,
         amort_amount FLOAT  NULL,
         amort_rate FLOAT  NULL,
         amort_structure varchar2 (10) NULL,
         announce_date numeric  NULL,
         auction_date numeric  NULL,
         bond_name varchar2 (64) NULL,
         bond_status varchar2 (32) NULL,
         bond_type varchar2 (32) NULL,
         call_date numeric  NULL,
         cap_strike FLOAT  NULL,
         cmp_frequency varchar2 (255) NULL,
         comments varchar2 (512) NULL,
         country varchar2 (32) NULL,
         coupon FLOAT  NULL,
         coupon_currency varchar2 (3) NULL,
         coupon_date_roll varchar2 (255) NULL,
         coupon_date_rule numeric  NULL,
         coupon_frequency varchar2 (255) NULL,
         coupon_holidays varchar2 (128) NULL,
         coupon_offset numeric  NULL,
         coupon_payment_type varchar2 (16) NULL,
         coupon_rounding_mthd varchar2 (255) NULL,
         dated_date numeric  NULL,
         daycount varchar2 (255) NULL,
         default_date numeric  NULL,
         disc_method numeric  NULL,
         face_value FLOAT  NULL,
         first_coupon_date numeric  NULL,
         flip_frequency varchar2 (255) NULL,
         flipper_date numeric  NULL,
         floor_strike FLOAT  NULL,
         fx_rate FLOAT  NULL,
         has_odd_first_coupon numeric  NULL,
         has_odd_last_coupon numeric  NULL,
         inactive_date numeric  NULL,
         ipa_le_id varchar2 (36) NULL,
         is_amortizing numeric  NULL,
         is_cpn_off_bus_day numeric  NULL,
         is_fixed numeric  NULL,
         is_floater numeric  NULL,
         is_reset_bus_lag numeric  NULL,
         is_reset_cutoff_bus_day numeric  NULL,
         is_reset_in_arrears numeric  NULL,
         issue_date numeric  NULL,
         issue_price FLOAT  NULL,
         issue_yield FLOAT  NULL,
         deliverable_lot_size FLOAT  NULL,
         issuer_le_id varchar2 (36) NULL,
         maturity_date numeric  NULL,
         maturity_tenor varchar2 (255) NULL,
         min_purchase_amt FLOAT  NULL,
         nominal_decimals numeric  NULL,
         option_type varchar2 (32) NULL,
         penult_cpn_date numeric  NULL,
         price_decimals numeric  NULL,
         price_rnd_mthd varchar2 (255) NULL,
         quote_type varchar2 (64) NULL,
         quoting_currency varchar2 (3) NULL,
         rate_index varchar2 (128) NULL,
         rate_index_factor FLOAT  NULL,
         rate_index_id varchar2 (36) NULL,
         rate_index_spread FLOAT  NULL,
         record_days numeric  NULL,
         redeem_days numeric  NULL,
         redem_currency varchar2 (3) NULL,
         redem_fx_rate FLOAT  NULL,
         redemption_price FLOAT  NULL,
         reset_avg_method varchar2 (18) NULL,
         reset_cmp_mthd varchar2 (32) NULL,
         reset_cutoff numeric  NULL,
         reset_days numeric  NULL,
         reset_frequency varchar2 (255) NULL,
         reset_holidays varchar2 (128) NULL,
         rolling_day numeric  NULL,
         rounding_unit numeric  NULL,
         sample_weekday numeric  NULL,
         settlement_days numeric  NULL,
         tick_size varchar2 (10) NULL,
         total_issued FLOAT  NULL,
         trustee_le_id varchar2 (36) NULL,
         value_days numeric  NULL,
         withholding_tax FLOAT  NULL,
         yield_decimals numeric  NULL,
         yield_method varchar2 (15) NULL,
         yield_rnd_mthd varchar2 (255) NULL,
         id varchar2 (36) NOT NULL,
         maturity_tenor_days numeric  NULL 
    ) 
/

    CREATE TABLE core_country (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         code varchar2 (255) NOT NULL,
         name varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_currency (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         code varchar2 (255) NOT NULL,
         country varchar2 (255) NULL,
         description varchar2 (255) NULL,
         rounding_decimal numeric  NOT NULL,
         rounding_method varchar2 (255) NOT NULL,
         data_source_id varchar2 (36) NULL 
    ) 
/

    CREATE TABLE core_currencypair (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         primary_currency varchar2 (255) NOT NULL,
         quoting_currency varchar2 (255) NOT NULL,
         data_source_id varchar2 (36) NULL 
    ) 
/

    CREATE TABLE core_data_policy (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         data_type varchar2 (255) NOT NULL,
         policy varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_equity (
        active_date numeric  NULL,
         comments varchar2 (255) NULL,
         corporate varchar2 (64) NULL,
         country varchar2 (32) NULL,
         dividend_currency varchar2 (3) NULL,
         dividend_date_rule numeric  NULL,
         dividend_decimals numeric  NULL,
         dividend_frequency varchar2 (255) NULL,
         equity_name varchar2 (32) NULL,
         equity_status varchar2 (32) NULL,
         exchange_code varchar2 (128) NULL,
         exchange_id varchar2 (36) NULL,
         fixing_type varchar2 (32) NULL,
         inactive_date numeric  NULL,
         is_pay_dividend numeric  NULL,
         nominal_decimals numeric  NULL,
         par_value FLOAT  NULL,
         quote_type varchar2 (64) NULL,
         subtype varchar2 (32) NULL,
         total_issued FLOAT  NULL,
         trading_country varchar2 (255) NULL,
         issuer_le_id varchar2 (36) NULL,
         trading_size FLOAT  NULL,
         id varchar2 (36) NOT NULL 
    ) 
/

    CREATE TABLE core_holiday (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         code varchar2 (255) NOT NULL,
         data_source_id varchar2 (36) NOT NULL,
         name varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_holiday_event (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         hol_date numeric  NOT NULL,
         description varchar2 (255) NULL,
         holiday_id varchar2 (36) NOT NULL 
    ) 
/

    CREATE TABLE core_index (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         currency varchar2 (255) NOT NULL,
         name varchar2 (255) NOT NULL,
         data_source_id varchar2 (36) NULL 
    ) 
/

    CREATE TABLE core_inflation_index (
        publication_lag numeric  NOT NULL,
         reference_day numeric  NOT NULL,
         id varchar2 (36) NOT NULL 
    ) 
/

    CREATE TABLE core_interest_config (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         effective_date numeric  NOT NULL,
         fixed_rate FLOAT  NULL,
         rate_index_id varchar2 (36) NULL,
         rate_type varchar2 (255) NOT NULL,
         spread FLOAT  NULL,
         day_count varchar2 (255) DEFAULT 'DC_30_360' NOT NULL 
    ) 
/

    CREATE TABLE core_junc_interest_config (
        account_interest_config_id0 varchar2 (255) NOT NULL,
         interest_config_id1 varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_le_address (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         address_line varchar2 (255) NULL,
         city varchar2 (255) NULL,
         country varchar2 (255) NOT NULL,
         postal_code varchar2 (255) NULL,
         state varchar2 (255) NULL 
    ) 
/

    CREATE TABLE core_le_contact (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         data_source_id varchar2 (36) NULL,
         email varchar2 (255) NOT NULL,
         first_name varchar2 (255) NOT NULL,
         last_name varchar2 (255) NOT NULL,
         legal_entity_id varchar2 (36) NOT NULL,
         phone_number varchar2 (255) NOT NULL,
         type varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_legal_entity (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         data_source_id varchar2 (36) NULL,
         financial numeric  NULL,
         legal_name varchar2 (255) NOT NULL,
         legal_short_name varchar2 (255) NOT NULL,
         lei varchar2 (255) NULL,
         parent_id varchar2 (255) NULL,
         ultimate_parent_id varchar2 (255) NULL,
         legaladdress_id varchar2 (36) NOT NULL 
    ) 
/

    CREATE TABLE core_legal_entity_roles (
        le_id varchar2 (36) NOT NULL,
         legal_role varchar2 (255) NULL 
    ) 
/

    CREATE TABLE core_pf_from_to (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         exclude_from numeric  NOT NULL,
         exclude_to numeric  NOT NULL,
         from_field varchar2 (255) NULL,
         from_long numeric  NULL,
         from_tenor varchar2 (255) NULL,
         name varchar2 (255) NOT NULL,
         to_field varchar2 (255) NULL,
         to_long numeric  NULL,
         to_tenor varchar2 (255) NULL,
         to_tenor_days numeric  NULL,
         from_tenor_days numeric  NULL 
    ) 
/

    CREATE TABLE core_pf_from_to_map (
        pf_criterion_from_to_id varchar2 (255) NOT NULL,
         pf_id varchar2 (36) NOT NULL 
    ) 
/

    CREATE TABLE core_pf_multi_value (
        pf_multiple_values_id varchar2 (36) NOT NULL,
         multiple_values varchar2 (4000) NULL,
         multiple_values_order numeric  NOT NULL 
    ) 
/

    CREATE TABLE core_pf_multi_values (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         included numeric  NOT NULL,
         name varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_pf_multi_values_map (
        pf_criterion_multi_val_id varchar2 (255) NOT NULL,
         pf_id varchar2 (36) NOT NULL 
    ) 
/

    CREATE TABLE core_product (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         currency varchar2 (3) NULL,
         description varchar2 (255) NULL,
         type varchar2 (64) NOT NULL,
         subtype varchar2 (64) NOT NULL,
         product_type varchar2 (64) NULL,
         quote_name varchar2 (64) NULL,
         source varchar2 (64) NULL,
         data_source_id varchar2 (36) NULL 
    ) 
/

    CREATE TABLE core_product_filter (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         name varchar2 (255) NOT NULL,
         sub_filter_id varchar2 (36) NULL,
         product_type varchar2 (255) NULL 
    ) 
/

    CREATE TABLE core_product_put_call_schedule (
        bond_id0 varchar2 (255) NOT NULL,
         put_call_date_id1 varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_product_sec_attribute (
        product_id2 varchar2 (255) NOT NULL,
         security_attribute_id3 varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_product_sec_id (
        security_id0 varchar2 (255) NOT NULL,
         security_identifier_id1 varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_put_call_date (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         exercise_style varchar2 (255) NOT NULL,
         expiry_date numeric  NOT NULL,
         first_exercise_date numeric  NULL,
         option_type varchar2 (255) NOT NULL,
         strike FLOAT  NOT NULL 
    ) 
/

    CREATE TABLE core_quote_definition (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         market_quote_type varchar2 (255) NOT NULL,
         quote_name varchar2 (255) NOT NULL,
         source_quotable_id varchar2 (36) NOT NULL,
         source_quotable_type varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_quote_set (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         description varchar2 (255) NOT NULL,
         quote_set_name varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_rate_index (
        date_roll varchar2 (255) NOT NULL,
         day_count varchar2 (255) NOT NULL,
         reset_days numeric  NOT NULL,
         source varchar2 (255) NOT NULL,
         tenor varchar2 (255) NOT NULL,
         id varchar2 (36) NOT NULL,
         tenor_days numeric  NULL 
    ) 
/

    CREATE TABLE core_rateindexresetholidays (
        rate_idx_id varchar2 (36) NOT NULL,
         reset_holidays_ids varchar2 (255) NULL 
    ) 
/

    CREATE TABLE core_rating (
        rating_agn_id varchar2 (36) NOT NULL,
         available_ratings varchar2 (255) NULL,
         available_ratings_order numeric  NOT NULL 
    ) 
/

    CREATE TABLE core_rating_agency (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         name varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_rating_le (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         agency_id varchar2 (36) NOT NULL,
         effective_date numeric  NOT NULL,
         legal_entity_id varchar2 (36) NOT NULL,
         seniority varchar2 (255) NOT NULL,
         value varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_security (
        id varchar2 (36) NOT NULL,
         country varchar2 (36) NULL,
         source varchar2 (36) NULL,
         regulatory_id varchar2 (36) NULL 
    ) 
/

    CREATE TABLE core_regulatory (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         esma varchar2 (4) NULL,
         ftc varchar2 (4) NULL,
         jfa varchar2 (4) NULL 
    ) 
/

    CREATE TABLE core_security_attribute (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         name varchar2 (255) NOT NULL,
         value varchar2 (32) NOT NULL 
    ) 
/

    CREATE TABLE core_security_identifier (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         type varchar2 (255) NOT NULL,
         value varchar2 (32) NOT NULL 
    ) 
/

    CREATE TABLE core_settlement_account (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         account_identifier varchar2 (255) NOT NULL,
         agent_id varchar2 (36) NOT NULL,
         currency varchar2 (255) NOT NULL,
         name varchar2 (255) NOT NULL,
         settle_type varchar2 (255) NOT NULL,
         data_source_id varchar2 (36) NULL 
    ) 
/

    CREATE TABLE core_split_currency (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         primary_currency varchar2 (255) NOT NULL,
         quoting_currency varchar2 (255) NOT NULL,
         split_currency varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE incoming_linked_msg_identifier (
        config_id numeric  NOT NULL,
         version_num numeric  NULL,
         template varchar2 (64) NOT NULL,
         msg_attr varchar2 (255) NOT NULL,
         outgoing_templates varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE value_date_control_config (
        value_date_control_config_id numeric  NOT NULL,
         version_num numeric  NULL,
         currency varchar2 (32) NOT NULL,
         method varchar2 (32) NOT NULL,
         holidays varchar2 (32) NOT NULL,
         time numeric  NOT NULL,
         days numeric  DEFAULT 0 NOT NULL,
         business_b numeric  DEFAULT 1 NOT NULL,
         update_settle_date_b numeric  DEFAULT 1 NOT NULL 
    ) 
/

    ALTER TABLE LIQ_LIMIT_CCY_BUCKET ADD bucket_limit float NULL
/

    ALTER TABLE LIQ_LIMIT_CCY_CLASS_LVL ADD class_lvl_limit float NULL
/

    ALTER TABLE LIQ_LIMIT_CCY_CLASS_LVL_BUCKET ADD lvl_bucket_limit float NULL
/

    CREATE TABLE anonymizing_audit (
        entity_id numeric  NOT NULL,
         class_name varchar2 (255) NOT NULL,
         anonymizing_date timestamp  NOT NULL,
         anonymizing_user_name varchar2 (255) NOT NULL,
         approver_user_name varchar2 (255) NULL 
    ) 
/

    ALTER TABLE PRODUCT_ROUNDING_RULE ADD (rounding_decimals numeric NULL,rounding_method numeric NULL)
/

    ALTER TABLE ACC_INTEREST_CONFIG ADD offset_date numeric NULL
/

    ALTER TABLE BALANCE_POSITION ADD total_before_closing float NULL
/

    ALTER TABLE BALANCE_POSITION_HIST ADD total_before_closing float NULL
/

    ALTER TABLE BO_POSTING ADD second_trade_id numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE BO_POSTING_HIST ADD second_trade_id numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE CALYPSO_CACHE ADD cache_limit numeric DEFAULT 100000 NOT NULL
/

    ALTER TABLE PORTFOLIO_SWAP_CONTRACT ADD (status varchar2 (30)  DEFAULT 'Active' NOT NULL,underlyng_type varchar2 (200)  DEFAULT 'All' NOT NULL)
/

    ALTER TABLE PORTFOLIO_SWAP_COUNTRY_REST ADD security_type varchar2 (200)  DEFAULT 'Any' NOT NULL
/

    ALTER TABLE CORR_MAT_DATA_HIST ADD offset_days numeric NULL
/

    ALTER TABLE CORR_MATRIX_DATA ADD offset_days numeric NULL
/

    ALTER TABLE CORR_SURF_BASISADJ ADD offset_days numeric NULL
/

    ALTER TABLE CORR_SURF_DATA ADD offset_days numeric NULL
/

    ALTER TABLE CORR_SURF_PTADJ ADD offset_days numeric NULL
/

    ALTER TABLE CORR_SURF_TIMEAXIS ADD offset_days numeric NULL
/

    ALTER TABLE CORR_TENOR_AX_HIST ADD offset_days numeric NULL
/

    ALTER TABLE CORR_TENOR_AXIS ADD offset_days numeric NULL
/

    ALTER TABLE COV_MAT_DATA_HIST ADD offset_days numeric NULL
/

    ALTER TABLE COV_MATRIX_DATA ADD offset_days numeric NULL
/

    ALTER TABLE CU_CDS ADD start_offset numeric NULL
/

    ALTER TABLE FUNDING_RATE ADD use_reset_days numeric DEFAULT 0 NOT NULL
/

    CREATE TABLE file_document (
        document_id numeric  NOT NULL,
         version numeric  NOT NULL,
         entity_type varchar2 (255) NOT NULL,
         mime_type varchar2 (128) NULL,
         entered_date timestamp  NOT NULL,
         entered_user varchar2 (255) NULL,
         is_binary numeric  DEFAULT 0 NOT NULL,
         charset varchar2 (32) NULL,
         document blob  NULL,
         name varchar2 (255) NULL,
         last_edited timestamp  DEFAULT TIMESTAMP'2000-12-31 00:00:00.0' NOT NULL 
    ) 
/

    ALTER TABLE INV_CASH_MOVEMENT ADD (daily_nfa decimal (38,15)  NULL,daily_brokerage decimal (38,15)  NULL)
/

    ALTER TABLE INV_CASH_BALANCE ADD (total_nfa decimal (38,15)  NULL,total_brokerage decimal (38,15)  NULL)
/

    ALTER TABLE INV_CUST_CASH_MOVEMENT ADD (daily_nfa decimal (38,15)  NULL,daily_brokerage decimal (38,15)  NULL)
/

    ALTER TABLE INV_CUST_CASH_BALANCE ADD (total_nfa decimal (38,15)  NULL,total_brokerage decimal (38,15)  NULL)
/

    ALTER TABLE LE_ATTRIBUTE ADD anonymized numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE LE_CONTACT ADD anonymized numeric DEFAULT 0 NOT NULL
/

    CREATE TABLE sdi_cash_accounts (
        sdi_id numeric  NOT NULL,
         cash_currency varchar2 (255) NOT NULL,
         cash_account_name varchar2 (255) NOT NULL,
         cash_account_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE sdi_cash_accounts_hist (
        sdi_id numeric  NOT NULL,
         cash_currency varchar2 (255) NOT NULL,
         cash_account_name varchar2 (255) NOT NULL,
         cash_account_id numeric  NOT NULL,
         archived_date timestamp  NULL 
    ) 
/

    CREATE TABLE le_settle_delivery_hist (
        sdi_id numeric  NOT NULL,
         sdi_type numeric  NULL,
         name varchar2 (255) NULL,
         agent_le numeric  NULL,
         agent_contact varchar2 (32) NULL,
         agent_account varchar2 (64) NULL,
         message_to_agent numeric  NOT NULL,
         int_le numeric  NULL,
         int_contact varchar2 (32) NULL,
         int_account varchar2 (64) NULL,
         message_to_int numeric  NOT NULL,
         bene_le numeric  NULL,
         bene_contact varchar2 (32) NULL,
         gl_account_id numeric  NULL,
         direct_b numeric  NOT NULL,
         comments varchar2 (255) NULL,
         method varchar2 (32) NULL,
         currency_list varchar2 (255) NULL,
         product_list varchar2 (1024) NULL,
         le_role varchar2 (32) NULL,
         preferred_b numeric  NOT NULL,
         pay_receive numeric  NULL,
         effective_from timestamp  NULL,
         effective_to timestamp  NULL,
         process_org_id numeric  NULL,
         int_gl_acc_id numeric  NULL,
         sd_filter varchar2 (64) NULL,
         priority numeric  NULL,
         link_id numeric  NULL,
         int_le_2 numeric  NULL,
         int_contact_2 varchar2 (32) NULL,
         int_account_2 varchar2 (64) NULL,
         registr_list varchar2 (128) NULL,
         message_to_int2 numeric  NULL,
         trade_cpty_id numeric  NULL,
         bene_name varchar2 (255) NULL,
         agent_name varchar2 (255) NULL,
         int_name varchar2 (255) NULL,
         agent_sub_acc varchar2 (64) NULL,
         int_sub_acc varchar2 (64) NULL,
         int2_sub_acc varchar2 (64) NULL,
         version_num numeric  DEFAULT 0 NOT NULL,
         trade_date_b numeric  NULL,
         bene_iden varchar2 (255) NULL,
         agent_iden varchar2 (255) NULL,
         int_iden varchar2 (255) NULL,
         int2_iden varchar2 (255) NULL,
         addressee_le numeric  NULL,
         reference varchar2 (64) NOT NULL,
         archived_date timestamp  NULL 
    ) 
/

    ALTER TABLE LEGAL_ENTITY ADD anonymized numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE LIQ_POSITION ADD (original_price float NULL,last_average_fx float DEFAULT 1 NULL,first_fx float DEFAULT 1 NULL,second_fx float DEFAULT 1 NULL)
/

    ALTER TABLE LIQ_POSITION_HIST ADD (original_price float NULL,last_average_fx float DEFAULT 1 NULL,first_fx float DEFAULT 1 NULL,second_fx float DEFAULT 1 NULL)
/

    ALTER TABLE LIQ_POSITION_DEL ADD (original_price float NULL,last_average_fx float DEFAULT 1 NULL,first_fx float DEFAULT 1 NULL,second_fx float DEFAULT 1 NULL)
/
CREATE GLOBAL TEMPORARY TABLE liq_product_temp ( product_id numeric  NOT NULL ) ON COMMIT PRESERVE ROWS
/

    CREATE TABLE manual_party_sdi_hist (
        sdi_id numeric  NOT NULL,
         seq_no numeric  NOT NULL,
         pty_id numeric  NULL,
         pty_code varchar2 (255) NULL,
         pty_role varchar2 (32) NULL,
         pty_contact varchar2 (32) NULL,
         pty_acc_name varchar2 (64) NULL,
         pty_long_name varchar2 (255) NULL,
         country_and_city varchar2 (128) NULL,
         code varchar2 (64) NULL,
         code_value varchar2 (128) NULL,
         identifier varchar2 (128) NULL,
         is_financial numeric  NULL,
         msg_to_pty numeric  NULL,
         tag_code varchar2 (64) NULL,
         tag_value varchar2 (255) NULL,
         archived_date timestamp  NULL 
    ) 
/

    CREATE TABLE manual_sdi_hist (
        sdi_id numeric  NOT NULL,
         type varchar2 (32) NULL,
         valid_from timestamp  NULL,
         valid_to timestamp  NULL,
         method varchar2 (32) NULL,
         comments varchar2 (255) NULL,
         entered_date timestamp  NULL,
         classification numeric  NOT NULL,
         bene_le_id numeric  NULL,
         bene_le_code varchar2 (255) NULL,
         version_num numeric  NULL,
         currency_list varchar2 (255) NULL,
         validity_type numeric  DEFAULT 0 NOT NULL,
         reference varchar2 (64) NOT NULL,
         trade_cpty_id numeric  DEFAULT 0 NOT NULL,
         archived_date timestamp  NULL 
    ) 
/

    CREATE TABLE manual_sdi_attr_hist (
        sdi_id numeric  NOT NULL,
         attribute_name varchar2 (128) NOT NULL,
         attribute_value varchar2 (255) NULL,
         archived_date timestamp  NULL 
    ) 
/

    ALTER TABLE OPTION_CONTRACT ADD underlying_date_type varchar2 (32)  NULL
/

    ALTER TABLE PL_POSITION ADD (current_avg_fx float NULL,last_arch_run_date timestamp NULL,last_average_fx float DEFAULT 1 NULL)
/

    ALTER TABLE PL_POSITION_HIST ADD (current_avg_fx float NULL,last_arch_run_date timestamp NULL,last_average_fx float DEFAULT 1 NULL)
/

    ALTER TABLE PL_POSITION_SNAP ADD (current_avg_fx float NULL,last_arch_run_date timestamp NULL,last_average_fx float DEFAULT 1 NULL)
/

    ALTER TABLE PRODUCT_BOND ADD (average_days numeric NULL,cmp_cutoff_lag numeric NULL,cmp_cutoff_lag_b numeric NULL,sample_period_shift_b numeric NULL)
/

    ALTER TABLE PRODUCT_CAP_FLOOR ADD strike_limit float NULL
/

    ALTER TABLE PRODUCT_CASH ADD open_term_bus_day_b numeric DEFAULT 1 NOT NULL
/

    ALTER TABLE PRODUCT_CASH_HIST ADD open_term_bus_day_b numeric DEFAULT 1 NOT NULL
/

    ALTER TABLE PRODUCT_CREDIT_FACILITY ADD credit_limit float NULL
/

    ALTER TABLE PRODUCT_OTCCOM_OPT ADD settlement_offset numeric NULL
/

    ALTER TABLE PRODUCT_OTCEQ_OPT ADD settlement_offset numeric NULL
/

    ALTER TABLE PRODUCT_PM_DEPO_LEASE ADD precious_metal_unit varchar2 (20)  DEFAULT 'Ounces' NOT NULL
/

    ALTER TABLE PRODUCT_SUBSCRIPREDEMP ADD direction varchar2 (128)  NULL
/

    ALTER TABLE PRODUCT_XFERAGENT ADD (from_subacc_sdi_id numeric DEFAULT 0 NULL,to_subacc_sdi_id numeric DEFAULT 0 NULL,is_dap numeric DEFAULT 0 NOT NULL)
/

    ALTER TABLE PRODUCT_STRUCTURED_FLOWS ADD option_method numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE RECON_INVEN_ROW ADD (sub_account_id numeric DEFAULT 0 NOT NULL,base_not_available float NULL,target_not_available float NULL)
/

    ALTER TABLE SEND_COPY_CONFIG ADD (by_jms_b numeric DEFAULT 0 NOT NULL,jms_name varchar2 (32)  NULL)
/

    ALTER TABLE TRADE_OPEN_QTY ADD (fx float DEFAULT 1 NULL,index_rate float DEFAULT 0 NULL)
/

    ALTER TABLE TRADE_OPENQTY_HIST ADD (fx float DEFAULT 1 NULL,index_rate float DEFAULT 0 NULL)
/

    ALTER TABLE TRADE_OPENQTY_SNAP ADD (fx float DEFAULT 1 NULL,index_rate float DEFAULT 0 NULL)
/
CREATE GLOBAL TEMPORARY TABLE toq_product_temp ( product_id numeric  NOT NULL ) ON COMMIT PRESERVE ROWS
/

    ALTER TABLE USER_NAME ADD restricted_le_list varchar2 (4000)  NULL
/

    ALTER TABLE VOL_SURF_UND_COMMOPT ADD underlying_rank numeric DEFAULT 0 NOT NULL
/

    CREATE TABLE arch_partial_trade_ids (
        trade_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE arch_trade_no_sync (
        trade_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE arch_transfer_no_sync (
        transfer_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE arch_quantile (
        trade_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE arch_quantile_no_sync (
        trade_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE pl_mark_temp (
        mark_id numeric  NOT NULL,
         trade_id numeric  NOT NULL,
         pricing_env_name varchar2 (32) NOT NULL,
         valuation_date timestamp  NOT NULL,
         position_or_trade varchar2 (128) NOT NULL,
         position_or_trade_version numeric  NOT NULL,
         entered_datetime timestamp  NOT NULL,
         update_datetime timestamp  NULL,
         version_num numeric  NOT NULL,
         entered_user varchar2 (32) NOT NULL,
         sub_id varchar2 (256) NULL,
         book_id numeric  NOT NULL,
         position_time varchar2 (64) NULL,
         market_time varchar2 (64) NULL,
         comments varchar2 (128) NULL,
         status varchar2 (32) NULL,
         mark_type varchar2 (32) DEFAULT 'PL' NOT NULL 
    ) 
/

    ALTER TABLE OFFICIAL_PL_AGGREGATE ADD strategy_id numeric DEFAULT 0 NOT NULL
/

    CREATE TABLE official_plmark_perm_adj (
        permanent_adj_id numeric  NOT NULL,
         pl_config_id numeric  NOT NULL,
         trade_id numeric  NOT NULL,
         pl_unit_id numeric  NOT NULL,
         pl_bucket_id numeric  NOT NULL,
         book_id numeric  NOT NULL,
         effective_date timestamp  NOT NULL,
         reason varchar2 (64) NOT NULL,
         adj_comment varchar2 (512) NULL,
         adjustor varchar2 (32) NOT NULL,
         is_valid numeric  DEFAULT 0 NOT NULL,
         update_datetime timestamp  NOT NULL,
         version_num numeric  NOT NULL,
         invalidation_datetime timestamp  NULL 
    ) 
/

    CREATE TABLE official_plmark_perm_adj_value (
        permanent_adj_id numeric  NOT NULL,
         measure_name varchar2 (64) NOT NULL,
         adj_value float  NULL,
         total_value float  NULL 
    ) 
/

    CREATE TABLE pl_mark_value_temp (
        mark_id numeric  NOT NULL,
         mark_name varchar2 (32) NOT NULL,
         mark_value float  NULL,
         adj_value float  NULL,
         currency varchar2 (3) NOT NULL,
         display_class varchar2 (128) NULL,
         display_digits numeric  NULL,
         is_adjusted numeric  DEFAULT 0 NOT NULL,
         adj_type varchar2 (512) NULL,
         adj_comment varchar2 (512) NULL,
         is_derived numeric  DEFAULT 0 NOT NULL,
         original_currency varchar2 (3) NOT NULL 
    ) 
/

    ALTER TABLE ACCRUAL_SCHEDULE_PARAMS ADD accrual_offset numeric NULL
/

    ALTER TABLE CORR_SURF_BASISADJ_HIST ADD offset_days numeric NULL
/

    ALTER TABLE CORR_SURF_DATA_HIST ADD offset_days numeric NULL
/

    ALTER TABLE CORR_SURF_PTADJ_HIST ADD offset_days numeric NULL
/

    ALTER TABLE CORR_SURF_TIMEAXIS_HIST ADD offset_days numeric NULL
/

    ALTER TABLE TASK_STATION_TAB ADD (auto_count_b numeric DEFAULT 0 NOT NULL,web_report_b numeric DEFAULT 0 NOT NULL)
/

    ALTER TABLE HA_DESIGNATION_RECORD ADD version_num numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE HA_DESIGNATION_RECORD_TRADE ADD (other_trade_id numeric NULL,other_designation_id numeric NULL,version_num numeric DEFAULT 0 NOT NULL)
/

    ALTER TABLE HA_PORTFOLIO_HEDGE_DEF ADD (participation_rate_calc numeric DEFAULT 0 NOT NULL,prepayment_rate float DEFAULT 0 NOT NULL,hedge_item_type varchar2 (32)  NULL,hedge_item_rate_index_id numeric NULL,hypo_derivative_template varchar2 (64)  NULL)
/

    ALTER TABLE HA_PORTFOLIO_HEDGE_CYCLE ADD end_date timestamp NULL
/

    ALTER TABLE TRADE_GROUPING_BASE ADD am_user varchar2 (256)  NULL
/

    ALTER TABLE ERSC_RULE_GROUP ADD (ref_po numeric NULL,creation_date numeric DEFAULT 0 NOT NULL,creation_user varchar2 (255)  DEFAULT '00112233-4455-6677-8899-aabbccddeeff' NOT NULL,creation_user_type varchar2 (255)  DEFAULT 'urn:calypso:cloud:platform:iam:model:User' NOT NULL,last_update_date numeric DEFAULT 0 NOT NULL,last_update_user varchar2 (255)  DEFAULT '00112233-4455-6677-8899-aabbccddeeff' NOT NULL,last_update_user_type varchar2 (255)  DEFAULT 'urn:calypso:cloud:platform:iam:model:User' NOT NULL)
/

    ALTER TABLE CUSTOM_GROUPING ADD am_user varchar2 (256)  NULL
/

    ALTER TABLE ALLOCATION ADD bm_offset float NULL
/

    ALTER TABLE BENCHMARK_COMP_RECORD_ITEM ADD bm_offset float NULL
/

    CREATE TABLE decsupp_order_hist (
        order_id numeric  NOT NULL,
         product_id numeric  NOT NULL,
         quantity float  NOT NULL,
         remaining_quantity float  NOT NULL,
         book_id numeric  NOT NULL,
         strategy_id numeric  NULL,
         limit_order float  NULL,
         order_type varchar2 (256) NULL,
         breach_info varchar2 (256) NULL,
         is_secondary_market numeric  DEFAULT 1 NOT NULL,
         type varchar2 (20) DEFAULT 'Order' NOT NULL,
         cpty_id numeric  NULL,
         external_ref varchar2 (255) NULL,
         portfolio_manager varchar2 (32) NULL,
         archived_date timestamp  NULL 
    ) 
/

    CREATE TABLE block_order_child_hist (
        block_id numeric  NOT NULL,
         order_id numeric  NOT NULL,
         order_index numeric  DEFAULT -1 NOT NULL,
         archived_date timestamp  NULL 
    ) 
/

    CREATE TABLE am_order_execution_hist (
        id numeric  NOT NULL,
         version numeric  NOT NULL,
         block_order_id numeric  NOT NULL,
         order_type varchar2 (256) NOT NULL,
         trade_id numeric  NULL,
         product_id numeric  NOT NULL,
         action varchar2 (32) NOT NULL,
         cptyId numeric  NULL,
         quantity float  NOT NULL,
         price float  NOT NULL,
         execution_ts timestamp  NOT NULL,
         comments varchar2 (256) NULL,
         status varchar2 (32) NOT NULL,
         external_ref varchar2 (255) NULL,
         archived_date timestamp  NULL 
    ) 
/

    CREATE TABLE am_order_execution_item_hist (
        id numeric  NOT NULL,
         parent_id numeric  NOT NULL,
         parent_version numeric  NOT NULL,
         order_id numeric  NOT NULL,
         trade_id numeric  NOT NULL,
         is_active numeric  NOT NULL,
         archived_date timestamp  NULL 
    ) 
/

    CREATE TABLE ca_fx_mapping (
        id numeric  NOT NULL,
         version_num numeric  NOT NULL,
         product_type varchar2 (32) NOT NULL,
         product_subtype varchar2 (32) NULL,
         ca_type varchar2 (32) NULL,
         ca_sub_type varchar2 (32) NULL,
         fx_position_based varchar2 (32) NULL,
         is_trade_date varchar2 (32) NULL,
         source varchar2 (32) NULL,
         side varchar2 (32) NULL 
    ) 
/

    CREATE TABLE accounting_pl_config (
        id numeric  NOT NULL,
         version numeric  NOT NULL,
         name varchar2 (64) NULL,
         officialplconfig_id numeric  NULL,
         yearend_prorate_termination numeric  NOT NULL,
         positionby_open_trade numeric  NOT NULL,
         additional_values varchar2 (1024) NULL 
    ) 
/

    CREATE TABLE accounting_pl_item (
        id numeric  NOT NULL,
         version numeric  NOT NULL,
         accountingpl_config_id numeric  NOT NULL,
         tradereference_id varchar2 (255) NOT NULL,
         trade_id numeric  NOT NULL,
         trade_version numeric  NOT NULL,
         is_trade numeric  NOT NULL,
         security_id numeric  NULL,
         book_id numeric  NOT NULL,
         val_date timestamp  NOT NULL,
         val_datetime timestamp  NOT NULL,
         run_name varchar2 (64) NULL,
         accountingpl_ccy varchar2 (4) NOT NULL,
         asset_value decimal (38,15) NULL,
         unrealized_mtm decimal (38,15) NULL,
         realized_mtm decimal (38,15) NULL,
         unrealized_accretion decimal (38,15) NULL,
         realized_accretion decimal (38,15) NULL,
         unrealized_accrual decimal (38,15) NULL,
         realized_accrual decimal (38,15) NULL,
         unrealized_otherpl decimal (38,15) NULL,
         realized_otherpl decimal (38,15) NULL,
         unsettled_cash decimal (38,15) NULL,
         settled_cash decimal (38,15) NULL,
         nominal_change decimal (38,15) NULL,
         principal_change decimal (38,15) NULL,
         term_mtm decimal (38,15) NULL,
         term_accrual_real_paid decimal (38,15) NULL,
         term_accrual_real_received decimal (38,15) NULL,
         upfront_mtm decimal (38,15) NULL,
         upfront_accrual_payleg decimal (38,15) NULL,
         upfront_accrual_recleg decimal (38,15) NULL,
         upfront_amort_unreal decimal (38,15) NULL,
         upfront_amort_real decimal (38,15) NULL,
         accrual_bought_sold decimal (38,15) NULL,
         write_down decimal (38,15) NULL,
         bought_sold_inflation decimal (38,15) NULL,
         unrealized_inflation decimal (38,15) NULL,
         realized_inflation decimal (38,15) NULL,
         realized_inflation_mtm decimal (38,15) NULL,
         pay_down decimal (38,15) NULL,
         original_notional decimal (38,15) NULL,
         reported_notional decimal (38,15) NULL,
         current_notional decimal (38,15) NULL,
         reporting_date timestamp  NOT NULL,
         closing_date timestamp  NULL,
         trade_date timestamp  NULL,
         settle_date timestamp  NULL,
         trade_subtype varchar2 (32) NULL,
         sub_type varchar2 (32) NULL,
         open_price decimal (38,15) NULL 
    ) 
/

    CREATE TABLE accounting_pl_item_attr (
        entity_id numeric  NOT NULL,
         entity_type varchar2 (32) NOT NULL,
         attr_name varchar2 (255) NOT NULL,
         attr_type varchar2 (50) DEFAULT 'String' NOT NULL,
         attr_value varchar2 (255) NULL,
         attr_numeric_value float  NULL,
         attr_date_value timestamp  NULL,
         attr_blob blob  NULL 
    ) 
/

    CREATE TABLE activemq_acks (
        container varchar2 (250) NOT NULL,
         sub_dest varchar2 (250) NULL,
         client_id varchar2 (250) NOT NULL,
         sub_name varchar2 (250) NOT NULL,
         selector varchar2 (250) NULL,
         last_acked_id numeric  NULL,
         priority numeric  DEFAULT 5 NOT NULL,
         xid varchar2 (250) NULL 
    ) 
/

    CREATE TABLE activemq_lock (
        id numeric  NOT NULL,
         time numeric  NULL,
         broker_name varchar2 (250) NULL 
    ) 
/

    CREATE TABLE activemq_msgs (
        id numeric  NOT NULL,
         container varchar2 (250) NOT NULL,
         msgid_prod varchar2 (250) NULL,
         msgid_seq numeric  NULL,
         expiration numeric  NULL,
         msg blob  NULL,
         priority numeric  NULL,
         xid varchar2 (250) NULL 
    ) 
/

    CREATE TABLE multi_quote_mapping (
        product_id numeric  NOT NULL,
         source varchar2 (32) NOT NULL,
         currency varchar2 (3) NOT NULL,
         settle_days numeric  NOT NULL,
         entered_datetime timestamp  NOT NULL,
         entered_user varchar2 (32) NOT NULL,
         priority numeric  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE multi_quote_mapping_equity (
        product_id numeric  NOT NULL,
         source varchar2 (32) NOT NULL,
         currency varchar2 (3) NOT NULL,
         settle_days numeric  NOT NULL,
         entered_datetime timestamp  NOT NULL,
         entered_user varchar2 (32) NOT NULL,
         priority numeric  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE platform_core_tenant_init (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  NOT NULL,
         app_name varchar2 (255) NOT NULL,
         status varchar2 (20) NOT NULL,
         version numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_server_configuration (
        server_id numeric  NOT NULL,
         server_name varchar2 (256) NOT NULL,
         am_user varchar2 (256) NOT NULL,
         server_type varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         calypso_version numeric  NOT NULL,
         analysis varchar2 (64) NOT NULL,
         analysis_parameter varchar2 (64) NOT NULL,
         pricing_environment varchar2 (64) NOT NULL,
         trade_filter_template varchar2 (64) NULL,
         market_data_server varchar2 (64) NOT NULL,
         load_balance_policy varchar2 (64) NOT NULL,
         cache_quotes_update numeric  NOT NULL,
         server1 varchar2 (64) NULL,
         server1_dispatcher varchar2 (64) NULL,
         server1_trade_frequency numeric  NULL,
         server1_marketdata_frequency numeric  NULL,
         server2 varchar2 (64) NULL,
         server2_dispatcher varchar2 (64) NULL,
         server2_trade_frequency numeric  NULL,
         server2_marketdata_frequency numeric  NULL,
         server3 varchar2 (64) NULL,
         server3_dispatcher varchar2 (64) NULL,
         server3_trade_frequency numeric  NULL,
         server3_marketdata_frequency numeric  NULL 
    ) 
/

    CREATE TABLE am_column_configuration (
        column_id varchar2 (128) NOT NULL,
         column_name varchar2 (256) NOT NULL,
         am_user varchar2 (256) NULL,
         update_version numeric  DEFAULT 1 NOT NULL,
         aggregation_level varchar2 (64) NOT NULL,
         aggregation_mode varchar2 (64) NOT NULL,
         unit varchar2 (64) NULL,
         alias varchar2 (64) NULL,
         server_configuration varchar2 (64) NOT NULL,
         editable_type varchar2 (64) NOT NULL,
         column_class varchar2 (128) NOT NULL,
         parent_column_id varchar2 (128) NULL,
         audit_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_column_profiles (
        profile_id varchar2 (128) NOT NULL,
         column_id varchar2 (128) NOT NULL,
         group_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_formula_configuration (
        formula_id varchar2 (128) NOT NULL,
         formula_name varchar2 (256) NOT NULL,
         update_version numeric  DEFAULT 1 NOT NULL,
         aggregation_level varchar2 (64) NOT NULL,
         formula_policy varchar2 (64) NOT NULL,
         last_modification_date varchar2 (64) NOT NULL,
         created_by_user varchar2 (64) NOT NULL,
         source_analysis varchar2 (64) NOT NULL,
         formula varchar2 (3968) NOT NULL,
         column_type varchar2 (64) NOT NULL,
         audit_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_formula_profiles (
        formula_id varchar2 (128) NOT NULL,
         group_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_formula_columns (
        formula_id varchar2 (128) NOT NULL,
         column_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_columnset_configuration (
        columnset_id varchar2 (128) NOT NULL,
         columnset_name varchar2 (256) NOT NULL,
         update_version numeric  DEFAULT 1 NOT NULL,
         last_modification_date varchar2 (64) NOT NULL,
         modified_by_user varchar2 (64) NOT NULL,
         trading_ratio_column_id varchar2 (128) NULL,
         audit_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_columnset_profiles (
        columnset_id varchar2 (128) NOT NULL,
         group_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_columnset_widgets (
        columnset_id varchar2 (128) NOT NULL,
         widget_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_columnset_actions (
        columnset_id varchar2 (128) NOT NULL,
         action_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_columnset_main_columns (
        columnset_column_id varchar2 (256) NOT NULL,
         columnset_id varchar2 (128) NULL,
         column_id varchar2 (128) NOT NULL,
         item_index numeric  NULL 
    ) 
/

    CREATE TABLE am_columnset_pivot_columns (
        columnset_column_id varchar2 (256) NOT NULL,
         columnset_id varchar2 (128) NULL,
         column_id varchar2 (128) NOT NULL,
         item_index numeric  NULL 
    ) 
/

    CREATE TABLE am_columnset_group_columns (
        columnset_column_id varchar2 (256) NOT NULL,
         columnset_id varchar2 (128) NULL,
         column_id varchar2 (128) NOT NULL,
         item_index numeric  NULL 
    ) 
/

    CREATE TABLE am_columnset_breakdown_columns (
        columnset_column_id varchar2 (256) NOT NULL,
         columnset_id varchar2 (128) NULL,
         column_id varchar2 (128) NOT NULL,
         item_index numeric  NULL 
    ) 
/

    CREATE TABLE am_unit_configuration (
        unit_id varchar2 (128) NOT NULL,
         unit_name varchar2 (256) NOT NULL,
         update_version numeric  DEFAULT 1 NOT NULL,
         last_modification_date varchar2 (64) NOT NULL,
         modified_by_user varchar2 (64) NOT NULL,
         unit_type varchar2 (64) NOT NULL,
         unit_currency_type varchar2 (64) NOT NULL,
         currency varchar2 (64) NULL,
         unit_level varchar2 (64) NULL,
         multiplier float  NOT NULL,
         denominator_type varchar2 (64) NULL,
         audit_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_unit_profiles (
        unit_id varchar2 (128) NOT NULL,
         group_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_unit_denominator_column (
        unit_denominator_id varchar2 (256) NOT NULL,
         unit_id varchar2 (128) NULL,
         analysis_id varchar2 (256) NOT NULL,
         column_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_grouping_configuration (
        grouping_id varchar2 (128) NOT NULL,
         grouping_name varchar2 (256) NOT NULL,
         update_version numeric  DEFAULT 1 NOT NULL,
         last_modification_date varchar2 (64) NOT NULL,
         created_by_user varchar2 (64) NOT NULL,
         source_analysis varchar2 (64) NOT NULL,
         audit_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_grouping_profiles (
        grouping_id varchar2 (128) NOT NULL,
         group_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_grouping_columns (
        grouping_column_id varchar2 (256) NOT NULL,
         grouping_id varchar2 (128) NULL,
         column_name varchar2 (256) NOT NULL,
         item_index numeric  NULL 
    ) 
/

    CREATE TABLE am_widget_configuration (
        widget_id varchar2 (128) NOT NULL,
         widget_name varchar2 (256) NOT NULL,
         update_version numeric  DEFAULT 1 NOT NULL,
         last_modification_date varchar2 (64) NOT NULL,
         modified_by_user varchar2 (64) NOT NULL,
         widget_type varchar2 (64) NOT NULL,
         audit_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_widget_profiles (
        widget_id varchar2 (128) NOT NULL,
         group_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_widget_columns (
        widget_id varchar2 (128) NOT NULL,
         column_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_chart_widget_configuration (
        chart_widget_id varchar2 (128) NOT NULL,
         widget_id varchar2 (128) NULL,
         chart_widget_name varchar2 (256) NOT NULL,
         chart_type varchar2 (64) NOT NULL,
         columnset_id varchar2 (128) NULL,
         grouping_id varchar2 (128) NULL,
         number_of_segments numeric  NOT NULL,
         display_bar_label numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_order_widget_configuration (
        order_widget_id varchar2 (128) NOT NULL,
         widget_id varchar2 (128) NULL,
         order_widget_name varchar2 (256) NOT NULL,
         template_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_configuration (
        layout_id varchar2 (128) NOT NULL,
         layout_name varchar2 (256) NOT NULL,
         update_version numeric  DEFAULT 1 NOT NULL,
         last_modification_date varchar2 (64) NOT NULL,
         modified_by_user varchar2 (64) NOT NULL,
         default_columnset_id varchar2 (128) NOT NULL,
         default_grouping_id varchar2 (128) NOT NULL,
         default_filtering_id varchar2 (128) NOT NULL,
         default_coloring_id varchar2 (128) NOT NULL,
         audit_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_layout_profiles (
        layout_id varchar2 (128) NOT NULL,
         group_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_columnset (
        layout_id varchar2 (128) NOT NULL,
         columnset_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_fav_columnset (
        layout_id varchar2 (128) NOT NULL,
         columnset_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_grouping (
        layout_id varchar2 (128) NOT NULL,
         grouping_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_fav_grouping (
        layout_id varchar2 (128) NOT NULL,
         grouping_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_filtering (
        layout_id varchar2 (128) NOT NULL,
         filtering_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_fav_filtering (
        layout_id varchar2 (128) NOT NULL,
         filtering_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_widget (
        layout_id varchar2 (128) NOT NULL,
         widget_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_fav_widget (
        layout_id varchar2 (128) NOT NULL,
         widget_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_coloring (
        layout_id varchar2 (128) NOT NULL,
         coloring_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_fav_coloring (
        layout_id varchar2 (128) NOT NULL,
         coloring_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_position (
        layout_id varchar2 (128) NOT NULL,
         display_all numeric  NOT NULL,
         opened_positions numeric  NOT NULL,
         closed_positions numeric  NOT NULL,
         intraday_trades numeric  NOT NULL,
         closed_strategies numeric  NOT NULL,
         cash_instrument numeric  NOT NULL,
         benchmark_instrument numeric  NOT NULL,
         looktrough_adjustment numeric  NOT NULL,
         hide_none_groups numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_layout_display (
        layout_id varchar2 (128) NOT NULL,
         override_decimals_display numeric  NULL 
    ) 
/

    CREATE TABLE am_filtering_configuration (
        filtering_id varchar2 (128) NOT NULL,
         filtering_name varchar2 (256) NOT NULL,
         is_prefiltering numeric  DEFAULT 0 NOT NULL,
         is_and_criteria numeric  DEFAULT 0 NOT NULL,
         update_version numeric  DEFAULT 1 NOT NULL,
         last_modification_date varchar2 (64) NOT NULL,
         modified_by_user varchar2 (64) NOT NULL,
         audit_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_filtering_profiles (
        filtering_id varchar2 (128) NOT NULL,
         group_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_filtering_columns (
        filtering_column_id varchar2 (256) NOT NULL,
         filtering_id varchar2 (128) NULL,
         column_id varchar2 (128) NOT NULL,
         item_index numeric  NULL 
    ) 
/

    CREATE TABLE am_coloring_configuration (
        coloring_id varchar2 (128) NOT NULL,
         coloring_name varchar2 (256) NOT NULL,
         update_version numeric  DEFAULT 1 NOT NULL,
         last_modification_date varchar2 (64) NOT NULL,
         modified_by_user varchar2 (64) NOT NULL,
         source_analysis varchar2 (64) NOT NULL,
         audit_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_coloring_profiles (
        coloring_id varchar2 (128) NOT NULL,
         group_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_coloring_rule_configuration (
        coloring_rule_id varchar2 (128) NOT NULL,
         coloring_id varchar2 (128) NULL,
         coloring_rule_name varchar2 (256) NOT NULL,
         checked_column_id varchar2 (256) NOT NULL,
         operator varchar2 (64) NOT NULL,
         operand varchar2 (64) NOT NULL,
         color numeric  NOT NULL,
         coloring_type varchar2 (64) NOT NULL,
         item_index numeric  NULL 
    ) 
/

    CREATE TABLE am_coloring_colored_columns (
        coloring_rule_id varchar2 (128) NOT NULL,
         column_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE product_triparty_exposure (
        product_id numeric  NOT NULL,
         direction varchar2 (32) NOT NULL,
         start_date timestamp  NULL,
         end_date timestamp  NULL,
         maturity_type varchar2 (10) NULL,
         exposure_type varchar2 (20) NULL,
         exposure_amount float  NULL,
         exposure_currency varchar2 (3) NULL,
         mcc_id numeric  NOT NULL,
         triparty_agent varchar2 (15) NULL,
         eligibility_set varchar2 (20) NULL,
         exposure_amount_matched float  NULL,
         triparty_transaction_reference varchar2 (15) NULL,
         initiation_status varchar2 (15) NULL 
    ) 
/

    CREATE TABLE objstore_files (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) DEFAULT 'user' NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) DEFAULT 'user' NOT NULL,
         file_name varchar2 (1024) NOT NULL,
         file_key varchar2 (64) NOT NULL,
         mime_type varchar2 (64) NOT NULL,
         file_size numeric  NOT NULL,
         app_name VARCHAR(64)  NOT NULL 
    ) 
/

    CREATE TABLE objstore_files_content (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) DEFAULT 'user' NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) DEFAULT 'user' NOT NULL,
         file_name varchar2 (64) NOT NULL,
         file_size varchar2 (64) NOT NULL,
         file_content blob  NOT NULL,
         app_name VARCHAR(64)  NOT NULL 
    ) 
/

    CREATE TABLE audit_record (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) DEFAULT 'user' NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) DEFAULT 'user' NOT NULL,
         capture_time numeric  NOT NULL,
         acting_user_type varchar2 (255) NOT NULL,
         acting_user_id varchar2 (64) NOT NULL,
         app varchar2 (64) NOT NULL,
         type varchar2 (64) NOT NULL,
         class_name varchar2 (255) NOT NULL,
         entity_id varchar2 (64) NOT NULL,
         entity_version_before numeric  NOT NULL,
         property varchar2 (255) NULL,
         before varchar2 (255) NULL,
         after varchar2 (255) NULL,
         group_tag varchar2 (64) NOT NULL,
         recalled numeric  NOT NULL 
    ) 
/

    CREATE TABLE userprefs_preferences (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         preference_type varchar2 (255) NOT NULL,
         preference_key varchar2 (255) NOT NULL,
         preference_value clob  NOT NULL,
         app varchar2 (255) NOT NULL,
         user_id varchar2 (255) NULL,
         default_value clob  NOT NULL,
         regex varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE dashboard_config_layout (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         layout_owner varchar2 (255) NOT NULL,
         layout_type varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE dashboard_config_dashboard (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         description varchar2 (255) NULL,
         dashboard_name varchar2 (255) NOT NULL,
         dashboard_owner varchar2 (255) NOT NULL,
         is_shared numeric  NOT NULL,
         dashboard_type varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE dashboard_config_widget (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         component_name varchar2 (255) NOT NULL,
         dashboard_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE dashboard_config_widget_attr (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         attribute_name varchar2 (255) NOT NULL,
         attribute_type varchar2 (255) NOT NULL,
         attribute_value varchar2 (255) NULL,
         widget_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE dashboard_config_layout_board (
        layout_id varchar2 (64) NOT NULL,
         dashboard_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE userprefs_template (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         template_type varchar2 (255) NOT NULL,
         template_name varchar2 (255) NOT NULL,
         user_id varchar2 (255) NOT NULL,
         app varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE userprefs_template_crit (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         criteria_value clob  NOT NULL,
         criteria_name varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE userprefs_template_2_crit (
        template_id varchar2 (255) NOT NULL,
         criteria_id varchar2 (255) NOT NULL 
    ) 
/

    ALTER TABLE SEND_CONFIG ADD (by_jms_b numeric DEFAULT 0 NOT NULL,jms_name varchar2 (32)  NULL)
/

    CREATE TABLE cm_result (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         account_id varchar2 (64) NOT NULL,
         currency varchar2 (3) NOT NULL,
         direction varchar2 (255) NOT NULL,
         regulator varchar2 (255) NULL,
         valuation_date numeric  NOT NULL,
         status varchar2 (255) DEFAULT 'COMPLETED' NOT NULL,
         additionalim float  NOT NULL,
         scheduleim float  NOT NULL,
         simmim float  NOT NULL,
         totalim float  NOT NULL,
         totalimusd float  NOT NULL,
         maintenance float  NOT NULL,
         etl float  DEFAULT 0 NOT NULL,
         wcl float  DEFAULT 0 NOT NULL,
         calibration_multiplier float  DEFAULT 0.0 NULL,
         calibration_margin float  DEFAULT 0.0 NULL,
         discretionary_margin float  DEFAULT 0 NOT NULL,
         credit_margin float  DEFAULT 0 NOT NULL,
         holiday_margin float  DEFAULT 0 NOT NULL,
         nov float  NOT NULL,
         var float  DEFAULT 0 NOT NULL,
         credit_multiplier float  DEFAULT 0.0 NULL,
         holiday_multiplier float  DEFAULT 0.0 NULL,
         mfm_add_on float  DEFAULT 0.0 NULL,
         liquidity_add_on float  DEFAULT 0.0 NULL,
         calculationsummary_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_result_errors (
        error_messages varchar2 (255) NOT NULL,
         tree_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_calculation_summary (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         status varchar2 (255) NOT NULL,
         service varchar2 (255) NOT NULL,
         calculation_request_id varchar2 (64) NOT NULL,
         calculation_set_id varchar2 (64) NOT NULL,
         time_horizon varchar2 (255) NULL 
    ) 
/

    CREATE TABLE cm_result_node (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         node_name varchar2 (255) NOT NULL,
         currency varchar2 (3) NOT NULL,
         tree_id varchar2 (64) NOT NULL,
         depth numeric  NOT NULL,
         node_index numeric  NOT NULL,
         attribute_key varchar2 (255) NULL,
         string_value varchar2 (255) NULL,
         numeric_value float  NULL 
    ) 
/

    CREATE TABLE cm_result_hist (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         account_id varchar2 (64) NOT NULL,
         currency varchar2 (3) NOT NULL,
         direction varchar2 (255) NOT NULL,
         regulator varchar2 (255) NULL,
         valuation_date numeric  NOT NULL,
         status varchar2 (255) DEFAULT 'COMPLETED' NOT NULL,
         additionalim float  NOT NULL,
         scheduleim float  NOT NULL,
         simmim float  NOT NULL,
         totalim float  NOT NULL,
         totalimusd float  NOT NULL,
         maintenance float  NOT NULL,
         etl float  DEFAULT 0 NOT NULL,
         wcl float  DEFAULT 0 NOT NULL,
         calibration_multiplier float  DEFAULT 0.0 NULL,
         calibration_margin float  DEFAULT 0.0 NULL,
         discretionary_margin float  DEFAULT 0 NOT NULL,
         credit_margin float  DEFAULT 0 NOT NULL,
         holiday_margin float  DEFAULT 0 NOT NULL,
         nov float  NOT NULL,
         var float  DEFAULT 0 NOT NULL,
         credit_multiplier float  DEFAULT 0.0 NULL,
         holiday_multiplier float  DEFAULT 0.0 NULL,
         mfm_add_on float  DEFAULT 0.0 NULL,
         liquidity_add_on float  DEFAULT 0.0 NULL,
         calculationsummary_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_result_temp (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         account_id varchar2 (64) NOT NULL,
         currency varchar2 (3) NOT NULL,
         direction varchar2 (255) NOT NULL,
         regulator varchar2 (255) NULL,
         valuation_date numeric  NOT NULL,
         status varchar2 (255) DEFAULT 'COMPLETED' NOT NULL,
         additionalim float  NOT NULL,
         scheduleim float  NOT NULL,
         simmim float  NOT NULL,
         totalim float  NOT NULL,
         totalimusd float  NOT NULL,
         maintenance float  NOT NULL,
         etl float  DEFAULT 0 NOT NULL,
         wcl float  DEFAULT 0 NOT NULL,
         calibration_multiplier float  DEFAULT 0.0 NULL,
         calibration_margin float  DEFAULT 0.0 NULL,
         discretionary_margin float  DEFAULT 0 NOT NULL,
         credit_margin float  DEFAULT 0 NOT NULL,
         holiday_margin float  DEFAULT 0 NOT NULL,
         nov float  NOT NULL,
         var float  DEFAULT 0 NOT NULL,
         credit_multiplier float  DEFAULT 0.0 NULL,
         holiday_multiplier float  DEFAULT 0.0 NULL,
         mfm_add_on float  DEFAULT 0.0 NULL,
         liquidity_add_on float  DEFAULT 0.0 NULL,
         calculationsummary_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_result_errors_hist (
        error_messages varchar2 (255) NOT NULL,
         tree_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_result_errors_temp (
        error_messages varchar2 (255) NOT NULL,
         tree_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_calculation_summary_hist (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         status varchar2 (255) NOT NULL,
         service varchar2 (255) NOT NULL,
         calculation_request_id varchar2 (64) NOT NULL,
         time_horizon varchar2 (255) NULL,
         calculation_set_id varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_calculation_summary_temp (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         status varchar2 (255) NOT NULL,
         service varchar2 (255) NOT NULL,
         calculation_request_id varchar2 (64) NOT NULL,
         time_horizon varchar2 (255) NULL,
         calculation_set_id varchar2 (255) NULL 
    ) 
/

    CREATE TABLE cm_result_node_hist (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         node_name varchar2 (255) NOT NULL,
         currency varchar2 (3) NOT NULL,
         tree_id varchar2 (64) NOT NULL,
         depth numeric  NOT NULL,
         node_index numeric  NOT NULL,
         attribute_key varchar2 (255) NULL,
         string_value varchar2 (255) NULL,
         numeric_value float  NULL 
    ) 
/

    CREATE TABLE cm_result_node_temp (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         node_name varchar2 (255) NOT NULL,
         currency varchar2 (3) NOT NULL,
         tree_id varchar2 (64) NOT NULL,
         depth numeric  NOT NULL,
         node_index numeric  NOT NULL,
         attribute_key varchar2 (255) NULL,
         string_value varchar2 (255) NULL,
         numeric_value float  NULL 
    ) 
/

    CREATE TABLE cm_simm_regulator (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         name varchar2 (32) NOT NULL 
    ) 
/

    CREATE TABLE cm_account (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         name varchar2 (255) NOT NULL,
         currency varchar2 (3) NOT NULL,
         methodology varchar2 (255) NOT NULL,
         accountdetails_id varchar2 (64) NOT NULL,
         calculator_type varchar2 (255) NULL,
         csadetails_id varchar2 (64) NULL 
    ) 
/

    CREATE TABLE cm_account_details (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL 
    ) 
/

    CREATE TABLE cm_etd_accounts (
        id varchar2 (64) NOT NULL,
         origin varchar2 (255) NULL,
         activity_type varchar2 (255) NULL 
    ) 
/

    CREATE TABLE cm_simm_accounts (
        id varchar2 (64) NOT NULL,
         active_from numeric  NULL,
         active_to numeric  NULL 
    ) 
/

    CREATE TABLE cm_simm_account (
        id varchar2 (64) NOT NULL,
         active_from numeric  NULL,
         active_to numeric  NULL,
         post_currency varchar2 (3) DEFAULT 'XXX' NOT NULL,
         collect_currency varchar2 (3) DEFAULT 'XXX' NOT NULL,
         post_threshold float  DEFAULT 0 NOT NULL,
         collect_threshold float  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_post_regulators (
        post_regulators varchar2 (255) NOT NULL,
         simmmarginaccount_id varchar2 (64) NULL 
    ) 
/

    CREATE TABLE cm_simm_collect_regulators (
        collect_regulators varchar2 (255) NOT NULL,
         simmmarginaccount_id varchar2 (64) NULL 
    ) 
/

    CREATE TABLE cm_simm_regulator_parameters (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         regulator varchar2 (255) NOT NULL,
         simmmarginaccount_id varchar2 (64) NULL 
    ) 
/

    CREATE TABLE cm_simm_parameters (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         parameter_type varchar2 (255) NOT NULL,
         regulatorparameter_id varchar2 (64) NOT NULL,
         value float  NULL,
         criteria varchar2 (255) NULL 
    ) 
/

    CREATE TABLE cm_flat_simm_param (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         regulator varchar2 (32) NOT NULL,
         accountdetails_id varchar2 (64) NULL,
         direction varchar2 (16) NULL,
         parameter_type varchar2 (255) NULL,
         value float  NULL,
         criteria varchar2 (255) NULL 
    ) 
/

    CREATE TABLE cm_whatif_result (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         request_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_whatif_result_detail (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         account_id varchar2 (64) NOT NULL,
         currency varchar2 (3) NOT NULL,
         valuation_date numeric  NOT NULL,
         totalim float  NOT NULL,
         fx_rate float  NOT NULL,
         threshold float  NOT NULL 
    ) 
/

    CREATE TABLE cm_whatif_result_before (
        result_id varchar2 (64) NOT NULL,
         detail_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_whatif_result_after (
        result_id varchar2 (64) NOT NULL,
         detail_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_isda_product_type (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         product_type varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_im_th_monitoring_config (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         csa_trigger float  NOT NULL,
         history_length varchar2 (7) NOT NULL 
    ) 
/

    CREATE TABLE cm_im_th_monitoring_result (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         tree_id varchar2 (64) NOT NULL,
         account_id varchar2 (64) NOT NULL,
         calculation_set_id varchar2 (64) NOT NULL,
         direction varchar2 (255) NOT NULL,
         threshold_status varchar2 (255) NOT NULL,
         csa_status varchar2 (255) NOT NULL,
         currency varchar2 (3) NOT NULL,
         valuation_date numeric  NOT NULL,
         threshold float  NOT NULL,
         threshold_utilization float  NOT NULL,
         totalim float  NOT NULL,
         csa_trigger float  NOT NULL 
    ) 
/

    CREATE TABLE cm_csa_account_details (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         csa_status varchar2 (255) NOT NULL 
    ) 
/

    ALTER TABLE COLLATERAL_CONFIG ADD (po_thresh_appl varchar2 (32)  NULL,le_thresh_appl varchar2 (32)  NULL,mf_application_type varchar2 (32)  NULL,mf_method varchar2 (32)  NULL,mf_linked_confid varchar2 (255)  NULL,mf_exp_linkedid varchar2 (255)  NULL)
/

    ALTER TABLE COLLATERAL_CONFIG_CURRENCY ADD call_cutoff_time timestamp NULL
/

    ALTER TABLE EXPOSURE_GROUP_DEFINITION ADD (po_thresh_appl varchar2 (32)  NULL,le_thresh_appl varchar2 (32)  NULL)
/

    ALTER TABLE MARGIN_CALL_ENTRIES ADD (collateralization_tolerance float DEFAULT 0 NULL,collateralization_status varchar2 (128)  NULL,mf_iapost_threshold float NULL,mf_mfta float NULL,mf_revised_ia float NULL,mf_marginreq_post_mfa float NULL,mf_simm float NULL,mf_schedule float NULL)
/

    ALTER TABLE PENDING_MARGIN_CALL_ENTRIES ADD (collateralization_tolerance float DEFAULT 0 NULL,collateralization_status varchar2 (128)  NULL,mf_iapost_threshold float NULL,mf_mfta float NULL,mf_revised_ia float NULL,mf_marginreq_post_mfa float NULL,mf_simm float NULL,mf_schedule float NULL)
/

    ALTER TABLE MRGCALL_ENTRIES_HIST ADD (collateralization_tolerance float DEFAULT 0 NULL,collateralization_status varchar2 (128)  NULL,mf_iapost_threshold float NULL,mf_mfta float NULL,mf_revised_ia float NULL,mf_marginreq_post_mfa float NULL,mf_simm float NULL,mf_schedule float NULL)
/

    ALTER TABLE COLLATERAL_CONTEXT ADD (le_cash_offset numeric NULL,po_cash_offset numeric NULL,le_security_offset numeric NULL,po_security_offset numeric NULL,override_collateral numeric NULL,collateralization_tolerance float DEFAULT 0 NULL,is_tolerance_percentage numeric DEFAULT 0 NOT NULL,check_tolerance_against varchar2 (128)  NULL)
/

    CREATE TABLE margin_run_info (
        margin_hierarchy varchar2 (64) NOT NULL,
         calculation_set varchar2 (250) NOT NULL,
         eod numeric  DEFAULT 1 NOT NULL,
         margin_data_type varchar2 (64) NOT NULL,
         valuation_date timestamp  NOT NULL,
         valuation_date_time timestamp  NOT NULL,
         time_zone varchar2 (64) NULL 
    ) 
/

    CREATE TABLE margin_mfm_multiplier (
        aggregation_key varchar2 (64) NOT NULL,
         etl_lower_bound float  NOT NULL,
         etl_upper_bound float  NOT NULL,
         value float  NOT NULL 
    ) 
/

    ALTER TABLE MARGIN_ADDON ADD description varchar2 (250)  NULL
/

    ALTER TABLE MARGIN_ADDON_HIST ADD description varchar2 (250)  NULL
/

    CREATE TABLE margin_addon_temp (
        currency varchar2 (3) NOT NULL,
         valuation_date timestamp  NOT NULL,
         margin_agreement_name varchar2 (250) NOT NULL,
         value float  NOT NULL,
         add_on_type varchar2 (250) NOT NULL,
         description varchar2 (250) NULL 
    ) 
/

    ALTER TABLE MARGIN_LIQUIDITY ADD eod numeric DEFAULT 1 NOT NULL
/

    ALTER TABLE MARGIN_TRADE_LIQUIDITY ADD eod numeric DEFAULT 1 NOT NULL
/

    CREATE TABLE margin_unsettled_vm_temp (
        margin_agreement_name varchar2 (250) NOT NULL,
         amount float  NOT NULL,
         valuation_date timestamp  NOT NULL,
         currency varchar2 (3) NOT NULL,
         version numeric  DEFAULT 0 NOT NULL 
    ) 
/

    ALTER TABLE MARGIN_TRADE_VM ADD (po_view numeric DEFAULT 0 NOT NULL,eod numeric DEFAULT 1 NOT NULL,im_portfolio_name varchar2 (250)  NULL,calculation_set varchar2 (250)  NULL,po numeric DEFAULT 0 NOT NULL)
/

    ALTER TABLE MARGIN_TRADE_VM_HIST ADD (po_view numeric DEFAULT 0 NOT NULL,eod numeric DEFAULT 1 NOT NULL,im_portfolio_name varchar2 (250)  NULL,calculation_set varchar2 (250)  NULL,po numeric DEFAULT 0 NOT NULL)
/

    CREATE TABLE margin_trade_vm_temp (
        trade_id varchar2 (60) NOT NULL,
         po_view numeric  DEFAULT 0 NOT NULL,
         valuation_date timestamp  NOT NULL,
         currency varchar2 (3) NULL,
         eod numeric  DEFAULT 1 NOT NULL,
         margin_agreement_name varchar2 (250) NOT NULL,
         im_portfolio_name varchar2 (250) NOT NULL,
         calculation_set varchar2 (250) NOT NULL,
         vm float  NOT NULL,
         vm_collaterized float  DEFAULT 0 NOT NULL,
         vm_cash float  NOT NULL,
         npv float  NOT NULL,
         npv_adj float  NOT NULL,
         pai float  NOT NULL,
         vm_exposure float  NOT NULL,
         leg_direction varchar2 (60) NULL,
         po numeric  DEFAULT 0 NOT NULL,
         additional_measure_1 float  NOT NULL,
         additional_measure_2 float  NOT NULL,
         additional_measure_3 float  NOT NULL,
         additional_measure_4 float  NOT NULL,
         additional_measure_5 float  NOT NULL,
         additional_measure_6 float  NOT NULL,
         additional_measure_7 float  NOT NULL,
         additional_measure_8 float  NOT NULL,
         additional_measure_9 float  NOT NULL,
         additional_measure_10 float  NOT NULL,
         additional_measure_11 float  NOT NULL,
         additional_measure_12 float  NOT NULL,
         additional_measure_13 float  NOT NULL,
         additional_measure_14 float  NOT NULL,
         additional_measure_15 float  NOT NULL 
    ) 
/

    ALTER TABLE MARGIN_PORTFOLIO_VM ADD (eod numeric DEFAULT 1 NOT NULL,im_portfolio_name varchar2 (250)  NULL,calculation_set varchar2 (250)  NULL,po_view numeric DEFAULT 0 NULL)
/

    ALTER TABLE MARGIN_PORTFOLIO_VM_HIST ADD (eod numeric DEFAULT 1 NOT NULL,im_portfolio_name varchar2 (250)  NULL,calculation_set varchar2 (250)  NULL,po_view numeric DEFAULT 0 NULL)
/

    CREATE TABLE margin_portfolio_vm_temp (
        version numeric  DEFAULT 0 NOT NULL,
         valuation_date timestamp  NOT NULL,
         currency varchar2 (3) NULL,
         eod numeric  DEFAULT 1 NOT NULL,
         margin_agreement_name varchar2 (250) NOT NULL,
         im_portfolio_name varchar2 (250) NOT NULL,
         calculation_set varchar2 (250) NOT NULL,
         vm float  NOT NULL,
         vm_collaterized float  DEFAULT 0 NOT NULL,
         vm_cash float  NOT NULL,
         npv float  NOT NULL,
         npv_adj float  NOT NULL,
         pai float  NOT NULL,
         vm_exposure float  NOT NULL,
         additional_measure_1 float  NOT NULL,
         additional_measure_2 float  NOT NULL,
         additional_measure_3 float  NOT NULL,
         additional_measure_4 float  NOT NULL,
         additional_measure_5 float  NOT NULL,
         additional_measure_6 float  NOT NULL,
         additional_measure_7 float  NOT NULL,
         additional_measure_8 float  NOT NULL,
         additional_measure_9 float  NOT NULL,
         additional_measure_10 float  NOT NULL,
         additional_measure_11 float  NOT NULL,
         additional_measure_12 float  NOT NULL,
         additional_measure_13 float  NOT NULL,
         additional_measure_14 float  NOT NULL,
         additional_measure_15 float  NOT NULL,
         po_view numeric  DEFAULT 0 NULL 
    ) 
/

    ALTER TABLE MARGIN_RESULT ADD (eod numeric DEFAULT 1 NOT NULL,wcl float DEFAULT 0.0 NULL,var float DEFAULT 0.0 NULL,credit_multiplier float DEFAULT 0.0 NULL,holiday_multiplier float DEFAULT 0.0 NULL,calibration_margin float DEFAULT 0.0 NULL,calibration_multiplier float DEFAULT 0.0 NULL,mfm_add_on float DEFAULT 0.0 NULL,liquidity_add_on float DEFAULT 0.0 NULL,status varchar2 (255)  DEFAULT 'Unknown' NOT NULL,service varchar2 (255)  DEFAULT 'MARGIN-OTC' NOT NULL,calculation_request_id varchar2 (64)  NULL,calculation_set varchar2 (64)  DEFAULT 'Default' NOT NULL,time_horizon varchar2 (255)  NULL)
/

    ALTER TABLE MARGIN_RESULT_HIST ADD (eod numeric DEFAULT 1 NOT NULL,wcl float DEFAULT 0.0 NULL,var float DEFAULT 0.0 NULL,credit_multiplier float DEFAULT 0.0 NULL,holiday_multiplier float DEFAULT 0.0 NULL,calibration_margin float DEFAULT 0.0 NULL,calibration_multiplier float DEFAULT 0.0 NULL,mfm_add_on float DEFAULT 0.0 NULL,liquidity_add_on float DEFAULT 0.0 NULL,status varchar2 (255)  DEFAULT 'Unknown' NOT NULL,service varchar2 (255)  DEFAULT 'MARGIN-OTC' NOT NULL,calculation_request_id varchar2 (64)  NULL,calculation_set varchar2 (64)  DEFAULT 'Default' NOT NULL,time_horizon varchar2 (255)  NULL)
/

    CREATE TABLE margin_result_temp (
        id varchar2 (64) NOT NULL,
         version numeric  DEFAULT 0 NULL,
         account_id varchar2 (64) NOT NULL,
         eod numeric  DEFAULT 1 NOT NULL,
         currency varchar2 (3) NOT NULL,
         valuation_date timestamp  NOT NULL,
         additionalim float  DEFAULT 0.0 NULL,
         scheduleim float  DEFAULT 0.0 NULL,
         simmim float  DEFAULT 0.0 NULL,
         totalim float  DEFAULT 0.0 NULL,
         maintenance float  DEFAULT 0.0 NULL,
         nov float  DEFAULT 0.0 NULL,
         regulator varchar2 (255) NULL,
         direction varchar2 (255) NOT NULL,
         methodology varchar2 (255) NOT NULL,
         etl float  DEFAULT 0.0 NULL,
         wcl float  DEFAULT 0.0 NULL,
         var float  DEFAULT 0.0 NULL,
         discretionary_margin float  DEFAULT 0.0 NULL,
         credit_margin float  DEFAULT 0.0 NULL,
         holiday_margin float  DEFAULT 0.0 NULL,
         credit_multiplier float  DEFAULT 0.0 NULL,
         holiday_multiplier float  DEFAULT 0.0 NULL,
         calibration_margin float  DEFAULT 0.0 NULL,
         calibration_multiplier float  DEFAULT 0.0 NULL,
         mfm_add_on float  DEFAULT 0.0 NULL,
         liquidity_add_on float  DEFAULT 0.0 NULL,
         status varchar2 (255) DEFAULT 'Unknown' NOT NULL,
         service varchar2 (255) DEFAULT 'MARGIN-OTC' NOT NULL,
         calculation_request_id varchar2 (64) NOT NULL,
         calculation_set varchar2 (64) DEFAULT 'Default' NOT NULL,
         time_horizon varchar2 (255) NULL 
    ) 
/

    CREATE TABLE margin_result_errors_temp (
        error_messages varchar2 (255) NOT NULL,
         tree_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE margin_result_node_temp (
        id varchar2 (64) NOT NULL,
         version numeric  DEFAULT 0 NULL,
         node_name varchar2 (250) NOT NULL,
         currency varchar2 (3) NOT NULL,
         attribute_key varchar2 (255) NULL,
         depth numeric  NOT NULL,
         node_index numeric  NOT NULL,
         numeric_value float  DEFAULT 0.0 NULL,
         string_value varchar2 (255) NULL,
         tree_id varchar2 (64) NOT NULL 
    ) 
/


/* Applying Schema Statements - end */



/* Applying xtra statements - start */



/* Applying xtra statements - end */



/* one time install statements - start */



/* one time install statements - end */

/* Pre Upgrade - Start */
CREATE OR REPLACE PROCEDURE add_column_if_not_exists
    (tab_name IN user_tab_columns.table_name%TYPE,
     col_name IN user_tab_columns.column_name%TYPE,
     data_type IN varchar2)
AS
    x number;
BEGIN
    begin
    select count(*) INTO x FROM user_tab_columns WHERE table_name=UPPER(tab_name) and column_name=upper(col_name);
    exception
        when NO_DATA_FOUND THEN
        x:=0;
        when others then
        null;
    end;
    IF x = 0 THEN
        EXECUTE IMMEDIATE 'alter table ' || tab_name || ' add '||col_name||' '||data_type;
    END IF;
END;
/

CREATE OR REPLACE PROCEDURE drop_function ( proc_name IN user_tab_columns.table_name%TYPE) AS
 x number;
BEGIN
   BEGIN
   SELECT count(*) into x FROM user_objects WHERE object_name=UPPER(proc_name) and object_type= 'FUNCTION';
   exception
        when NO_DATA_FOUND THEN
        x:=0;
        when others then
        null;
    end;
    IF x > 0 THEN
       EXECUTE IMMEDIATE 'drop function '|| proc_name;
    END IF;
END drop_function;
/

CREATE OR REPLACE PROCEDURE drop_column_if_exists
    (tab_name IN user_tab_columns.table_name%TYPE,
     col_name IN user_tab_columns.column_name%TYPE)
AS
    x number;
BEGIN
    begin
    select count(*) INTO x FROM user_tab_columns WHERE table_name=UPPER(tab_name) and column_name=upper(col_name);
    exception
        when NO_DATA_FOUND THEN
        x:=0;
        when others then
        null;
    end;
    IF x > 0 THEN
        EXECUTE IMMEDIATE 'alter table ' || tab_name || ' drop column '||col_name;
    END IF;
END;
/

CREATE OR REPLACE PROCEDURE add_domain_values (dname IN varchar2, dvalue in varchar2, ddescription in varchar2) AS
x number :=0 ;
BEGIN
   BEGIN
   SELECT count(*) INTO x FROM domain_values WHERE name= dname and value= dvalue;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:=0;
      WHEN others THEN
         null;
    END;
        if x = 1 then
                execute immediate 'delete from domain_values where name='||chr(39)||dname||chr(39)||' and value ='||chr(39)||dvalue||chr(39);
                execute immediate 'insert into domain_values ( name, value, description )
                VALUES ('||chr(39)||dname||chr(39)||','||chr(39)||dvalue||chr(39)||','||chr(39)||ddescription||chr(39)||')';
        elsif x=0 THEN
	        execute immediate 'insert into domain_values ( name, value, description ) 
                VALUES ('||chr(39)||dname||chr(39)||','||chr(39)||dvalue||chr(39)||','||chr(39)||ddescription||chr(39)||')';
    END IF;
END add_domain_values;
/

CREATE OR REPLACE PROCEDURE delete_domain_values (dname IN varchar2, dvalue in varchar2) AS
x number :=0 ;
BEGIN
   BEGIN
   SELECT count(*) INTO x FROM domain_values WHERE name= dname and value= dvalue;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:=0;
      WHEN others THEN
         null;
    END;
        if x = 1 then
                execute immediate 'delete from domain_values where name='||chr(39)||dname||chr(39)||' and value ='||chr(39)||dvalue||chr(39);
        
    END IF;
END delete_domain_values;
/

CREATE OR REPLACE PROCEDURE drop_fk_on_table (tab_name IN varchar2) AS
BEGIN
   DECLARE cursor c1 IS 
      SELECT table_name, constraint_name FROM user_constraints WHERE constraint_type = 'R' AND table_name=UPPER(tab_name);
   v_sql varchar2(128);
   BEGIN
      FOR c1_rec IN c1 LOOP 
         v_sql := 'ALTER TABLE '||c1_rec.table_name||' DROP CONSTRAINT '||c1_rec.constraint_name;
         EXECUTE IMMEDIATE v_sql;
      END LOOP;
   END;
END;
/

CREATE OR REPLACE PROCEDURE drop_pk_if_exists (tab_name IN varchar2) AS
x number :=0 ;
BEGIN
   BEGIN
   SELECT count(*) INTO x FROM user_constraints WHERE table_name=UPPER(tab_name) and constraint_type= 'P';
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:=0;
      WHEN others THEN
         null;
    END;
    IF x > 0 THEN
       EXECUTE IMMEDIATE 'ALTER TABLE ' ||tab_name||' DROP PRIMARY KEY DROP INDEX';
    END IF;
END drop_pk_if_exists;
/

CREATE OR REPLACE PROCEDURE drop_uk_if_exists (tab_name IN varchar2) AS
x varchar2(100) ;
BEGIN
   BEGIN
   SELECT  c.constraint_name INTO x FROM user_constraints c, user_tables t WHERE t.table_name=UPPER(tab_name) 
   and c.constraint_type= 'U' and t.table_name=c.table_name;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:='0';
      WHEN others THEN
         null;
    END;
    IF x != '0' THEN
       EXECUTE IMMEDIATE 'ALTER TABLE ' ||tab_name||' DROP constraint '||x;
    END IF;
END drop_uk_if_exists;
/

CREATE OR REPLACE PROCEDURE drop_procedure_if_exists

    (proc_name IN user_objects.object_name%TYPE)

AS

    x number;

BEGIN

    begin

    select count(*) INTO x FROM user_objects WHERE object_name=UPPER(proc_name) and object_type = 'PROCEDURE';

    exception

        when NO_DATA_FOUND THEN

        x:=0;

        when others then

        null;

    end;

    IF x > 0 THEN

        EXECUTE IMMEDIATE 'drop procedure ' || UPPER(proc_name);

    END IF;

END drop_procedure_if_exists;
/

CREATE OR REPLACE PROCEDURE drop_uq_on_table (tab_name IN varchar2) AS
BEGIN
   DECLARE cursor c1 IS 
      SELECT table_name, constraint_name FROM user_constraints WHERE constraint_type = 'U' AND table_name=UPPER(tab_name);
   v_sql varchar2(128);
   BEGIN
      FOR c1_rec IN c1 LOOP 
         v_sql := 'ALTER TABLE '||c1_rec.table_name||' DROP CONSTRAINT '||c1_rec.constraint_name;
         EXECUTE IMMEDIATE v_sql;
      END LOOP;
   END;
END;
/

CREATE OR REPLACE PROCEDURE drop_unique_if_exists (tab_name IN varchar2) AS
constraint_name varchar2(255);
BEGIN
   BEGIN
   SELECT constraint_name INTO constraint_name FROM user_constraints WHERE table_name=UPPER(tab_name) and constraint_type= 'U';
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         constraint_name := NULL;
      WHEN others THEN
         null;
    END;
    IF constraint_name IS NOT NULL THEN
       EXECUTE IMMEDIATE 'ALTER TABLE ' ||tab_name||' DROP CONSTRAINT ' || constraint_name || ' DROP INDEX';
    END IF;
END drop_unique_if_exists;
/

CREATE OR REPLACE PROCEDURE drop_table_if_exists
    (tab_name IN varchar2)
AS
    x number :=0 ;
BEGIN
begin
select count(*) INTO x FROM user_tables WHERE table_name=UPPER(tab_name) ;
exception
when NO_DATA_FOUND THEN
x:=0;
when others then null;
end;
IF x > 0 THEN
EXECUTE IMMEDIATE 'drop table ' ||tab_name;
END IF;
END drop_table_if_exists;
/

CREATE OR REPLACE PROCEDURE add_pk_if_not_exists (tab_name IN varchar2, pk_name in varchar2, c_name in varchar2) AS
x number :=0 ;
BEGIN
   BEGIN
   SELECT count(*) INTO x FROM user_constraints WHERE table_name=UPPER(tab_name) and constraint_type= 'P';
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:=0;
      WHEN others THEN
         null;
    END;
    IF x = 0 THEN
       EXECUTE IMMEDIATE 'ALTER TABLE ' ||tab_name||' add constraint '||pk_name||' primary key ('||c_name||')';
    END IF;
END add_pk_if_not_exists;
/

CREATE OR REPLACE
TYPE list_of_names_t IS  
   TABLE of VARCHAR2(100);
/

CREATE OR REPLACE
PROCEDURE run_query_if_tables_exist
    (tab_names IN list_of_names_t, query IN varchar2)
AS
    x number :=0 ;
    y number :=0 ;
BEGIN
	BEGIN
		select count(*) INTO x FROM table(tab_names);
		select count(*) INTO y FROM user_tables WHERE table_name in (select * from table(tab_names));
	END;
	IF x = y THEN
		EXECUTE IMMEDIATE query;
	END IF;
END run_query_if_tables_exist;
/

CREATE OR REPLACE PROCEDURE rename_column_if_exists
    (tab_name IN user_tab_columns.table_name%TYPE,
     col_name IN user_tab_columns.column_name%TYPE,
     new_col_name IN varchar2)
AS
    x number;
	y number;
BEGIN
    begin 
    select count(*) INTO x FROM user_tab_columns WHERE table_name=UPPER(tab_name) and column_name=upper(col_name);
    exception
        when NO_DATA_FOUND THEN
        x:=0;
        when others then
        null;
    end;
    IF x = 1 THEN
        EXECUTE IMMEDIATE 'alter table ' || tab_name || ' rename  column '||col_name||' to '||new_col_name;
    END IF;
END;
/

/* Pre Upgrade - End */
/* Start of the SQL statements from file:LIQ-7125-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('liquidity','LIQ-7125',1,CURRENT_TIMESTAMP,'started')
/

alter table liq_limit_ccy_bucket rename column bucket_limit to bucket_limit_bck
/

alter table liq_limit_ccy_bucket rename column limit to bucket_limit
/

alter table liq_limit_ccy_class_lvl rename column class_lvl_limit to class_lvl_limit_bck
/

alter table liq_limit_ccy_class_lvl rename column limit to class_lvl_limit
/

alter table liq_limit_ccy_class_lvl_bucket rename column lvl_bucket_limit to lvl_bucket_limit_bck
/

alter table liq_limit_ccy_class_lvl_bucket rename column limit to lvl_bucket_limit
/

alter table liq_limit_ccy_bucket drop column bucket_limit_bck
/

alter table liq_limit_ccy_class_lvl drop column class_lvl_limit_bck
/

alter table liq_limit_ccy_class_lvl_bucket drop column lvl_bucket_limit_bck
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='LIQ-7125' and version=1 and module='liquidity'
/

/* End of the SQL statements from file:LIQ-7125-1.sql */
/* Start of the SQL statements from file:LIQ-7520-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('liquidity','LIQ-7520',1,CURRENT_TIMESTAMP,'started')
/

/* LIQ-7520 : Deprecate Trading book FTP */
delete from domain_values where name = 'FtpCostComponentNames' and value in ( 'SECURITIZED_FUNDING_INTEREST_COST' , 
'SECURITIZED_FUNDING_SECURITY_SWEEP_COST' , 'SECURITIZED_FUNDING_CASH_SWEEP_COST' , 'OVERNIGHT_CASH_SWEEP_COST' , 'OVERNIGHT_CASH_INTEREST_COST' )
/

delete from domain_values where name = 'scheduledTask' and value = 'GEN_FUNDING_FTP_ACCRUALS'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='LIQ-7520' and version=1 and module='liquidity'
/

/* End of the SQL statements from file:LIQ-7520-1.sql */
/* Start of the SQL statements from file:LIQ-7588-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('liquidity','LIQ-7588',1,CURRENT_TIMESTAMP,'started')
/

/* LIQ-7588 : Readding the delete script since there was a regression issue with subsequent versions in liquidity modules */
delete from domain_values where name = 'scheduledTask' and value = 'GEN_FUNDING_FTP_ACCRUALS'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='LIQ-7588' and version=1 and module='liquidity'
/

/* End of the SQL statements from file:LIQ-7588-1.sql */
/* Start of the SQL statements from file:MGNC-776-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-776',1,CURRENT_TIMESTAMP,'started')
/

update pricer_measure set measure_id = 500 where measure_id = 1500
/

update pricer_measure set measure_id = 501 where measure_id = 1501
/

update pricer_measure set measure_id = 502 where measure_id = 1502
/

update pricer_measure set measure_id = 503 where measure_id = 1503
/

update pricer_measure set measure_id = 504 where measure_id = 1504
/

update pricer_measure set measure_id = 505 where measure_id = 1505
/

update pricer_measure set measure_id = 506 where measure_id = 1506
/

update pricer_measure set measure_id = 507 where measure_id = 1507
/

update pricer_measure set measure_id = 508 where measure_id = 1508
/

update pricer_measure set measure_id = 509 where measure_id = 1509
/

update pricer_measure set measure_id = 510 where measure_id = 1510
/

update pricer_measure set measure_id = 511 where measure_id = 1511
/

update pricer_measure set measure_id = 512 where measure_id = 1512
/

update pricer_measure set measure_id = 513 where measure_id = 1513
/

update pricer_measure set measure_id = 514 where measure_id = 1514
/

update pricer_measure set measure_id = 515 where measure_id = 1515
/

update pricer_measure set measure_id = 516 where measure_id = 1516
/

update pricer_measure set measure_id = 517 where measure_id = 1517
/

update pricer_measure set measure_id = 518 where measure_id = 1518
/

update pricer_measure set measure_id = 519 where measure_id = 1519
/

update pricer_measure set measure_id = 520 where measure_id = 1520
/

update pricer_measure set measure_id = 521 where measure_id = 1521
/

update pricer_measure set measure_id = 522 where measure_id = 1522
/

update pricer_measure set measure_id = 523 where measure_id = 1523
/

update pricer_measure set measure_id = 524 where measure_id = 1524
/

update pricer_measure set measure_id = 525 where measure_id = 1525
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-776' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-776-1.sql */
/* Start of the SQL statements from file:MGNC-986-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-986',1,CURRENT_TIMESTAMP,'started')
/

update margin_trade_vm set po_view = (
(select case when count(*) > 0 THEN 1 else 0 end
from quartz_sched_task_attr where attr_name = 'VM View' and attr_value = 'PO' 
and task_id in (select task_id from quartz_sched_task where task_type = 'MARGIN_OTC_VM_CALCULATOR')
and task_id in (select task_id from quartz_sched_task_attr where attr_name = 'Hierarchy Name' and attr_value in (select hierarchy_name from ers_hierarchy where node_name = margin_trade_vm.margin_agreement_name))
)
)
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-986' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-986-1.sql */
/* Start of the SQL statements from file:MGNC-1040-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-1040',1,CURRENT_TIMESTAMP,'started')
/

INSERT INTO domain_values (name, value, description)
	values ('ISDASIMM.treatIRCurveAsXccyBasis.Currencies', 'CNY', '')
/

INSERT INTO domain_values (name, value, description)
	values ('ISDASIMM.treatIRCurveAsXccyBasis.Currencies', 'IDR', '')
/

INSERT INTO domain_values (name, value, description)
	values ('ISDASIMM.treatIRCurveAsXccyBasis.Currencies', 'KRW', '')
/

INSERT INTO domain_values (name, value, description)
	values ('ISDASIMM.flipXccyBasisRisk.Currencies', 'CLP', '')
/

INSERT INTO domain_values (name, value, description)
	values ('ISDASIMM.flipXccyBasisRisk.Currencies', 'COP', '')
/

INSERT INTO domain_values (name, value, description)
	values ('ISDASIMM.flipXccyBasisRisk.Currencies', 'MXN', '')
/

INSERT INTO domain_values (name, value, description)
	values ('ISDASIMM.flipXccyBasisRisk.Currencies', 'PEN', '')
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-1040' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-1040-1.sql */
/* Start of the SQL statements from file:MGNC-451-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-451',1,CURRENT_TIMESTAMP,'started')
/

INSERT INTO scenario_rule (scenario_name,class_name,comments,version_num,owner_name,is_parametric) 
	values ('FXQuotes1pct','com.calypso.tk.risk.ScenarioRuleQuotes',null,0,'',0)
/

INSERT INTO scenario_items (scenario_name, class_name, item_seq, attribute_name, attribute_value)
	values ('FXQuotes1pct','com.calypso.tk.risk.ScenarioRuleQuotes',0,'FXConvertCcy','Delta Display')
/

INSERT INTO scenario_items (scenario_name, class_name, item_seq, attribute_name, attribute_value)
	values ('FXQuotes1pct','com.calypso.tk.risk.ScenarioRuleQuotes',0,'LOAD_QUOTES_NAME','Y')
/

INSERT INTO scenario_items (scenario_name, class_name, item_seq, attribute_name, attribute_value)
	values ('FXQuotes1pct','com.calypso.tk.risk.ScenarioRuleQuotes',0,'LOAD_QUOTE_NAMES','Y')
/

INSERT INTO scenario_items (scenario_name, class_name, item_seq, attribute_name, attribute_value)
	values ('FXQuotes1pct','com.calypso.tk.risk.ScenarioRuleQuotes',0,'SPECIFIC','0 FX. 1 %(rel)')
/

INSERT INTO scenario_items (scenario_name, class_name, item_seq, attribute_name, attribute_value)
	values ('FXQuotes1pct','com.calypso.tk.risk.ScenarioRuleQuotes',0,'Separately','TRUE')
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-451' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-451-1.sql */
/* Start of the SQL statements from file:MGNC-1178-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-1178',1,CURRENT_TIMESTAMP,'started')
/

declare
    vScenarioName varchar2(16) := 'all_fx';
    vCount number;
begin
    select count(*) into vCount from scenario_rule where scenario_name = vScenarioName;
    if vCount < 1 then
        insert into scenario_rule (scenario_name,class_name,comments,version_num,owner_name,is_parametric) values (vScenarioName,'com.calypso.tk.risk.ScenarioMarketData',null,0,'calypso_user',0);
    end if;

    select count(*) into vCount from scenario_items where scenario_name = vScenarioName;
    if vCount < 1 then
        insert into scenario_items (scenario_name,class_name,item_seq,attribute_name,attribute_value) values (vScenarioName,'com.calypso.tk.risk.ScenarioMarketData',0,'SPECIFIC','FX ANY ANY ANY');
        insert into scenario_items (scenario_name,class_name,item_seq,attribute_name,attribute_value) values (vScenarioName,'com.calypso.tk.risk.ScenarioMarketData',1,'SPECIFIC','FXVolatility ANY ANY ANY');
    end if;
end;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-1178' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-1178-1.sql */
/* Start of the SQL statements from file:MGNC-536-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-536',1,CURRENT_TIMESTAMP,'started')
/

update margin_trade_vm set calculation_set = 'Default'
/

update margin_trade_vm_hist set calculation_set = 'Default'
/

update margin_portfolio_vm set calculation_set = 'Default'
/

update margin_portfolio_vm_hist set calculation_set = 'Default'
/

update margin_run_info set calculation_set = 'Default'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-536' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-536-1.sql */
/* Start of the SQL statements from file:MGNC-1338-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-1338',1,CURRENT_TIMESTAMP,'started')
/

update margin_portfolio_vm set po_view = (
(select case when count(*) > 0 THEN 1 else 0 end
from quartz_sched_task_attr where attr_name = 'VM View' and attr_value = 'PO' 
and task_id in (select task_id from quartz_sched_task where task_type = 'MARGIN_OTC_VM_CALCULATOR')
and task_id in (select task_id from quartz_sched_task_attr where attr_name = 'Hierarchy Name' and attr_value in (select hierarchy_name from ers_hierarchy where node_name = margin_portfolio_vm.margin_agreement_name))
)
)
/

delete from quartz_sched_task_attr where attr_name = 'VM View'
and task_id in (select task_id from quartz_sched_task where task_type = 'MARGIN_OTC_VM_CALCULATOR')
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-1338' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-1338-1.sql */
/* Start of the SQL statements from file:MGNC-1432-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-1432',1,CURRENT_TIMESTAMP,'started')
/

INSERT INTO quartz_sched_task_attr (
    task_id,
    attr_name,
    attr_value,
    value_order
)
    SELECT
        task_id,
        'Calculation Set',
        'Default',
        0
    FROM
        quartz_sched_task
    WHERE
        task_type = 'MARGIN_OTC_CALCULATOR'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-1432' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-1432-1.sql */
/* Start of the SQL statements from file:MGNC-1493-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-1493',1,CURRENT_TIMESTAMP,'started')
/

MERGE
INTO    margin_trade_vm v
USING   (
        SELECT DISTINCT tr.trade_id AS trade_id, b.legal_entity_id
            FROM book b, trade tr, margin_trade_vm v
            WHERE v.trade_id = tr.trade_id
            AND tr.book_id = b. book_id
        ) src
ON      (v.trade_id = src.trade_id)
WHEN MATCHED THEN UPDATE
    SET v.po = legal_entity_id
    where v.po = 0
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-1493' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-1493-1.sql */
/* Start of the SQL statements from file:MGNC-1619-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-1619',1,CURRENT_TIMESTAMP,'started')
/

INSERT INTO margin_vm_definition (name,leg,additional_column_index,product_type,measure_name,intraday,cumulative,flip_sign)
        values ('CVM','NEAR',-1,'FXSwap','CVM_NEAR',1,1,1)
/

INSERT INTO margin_vm_definition (name,leg,additional_column_index,product_type,measure_name,intraday,cumulative,flip_sign)
        values ('CVM','FAR',-1,'FXSwap','CVM_FAR',1,1,1)
/

INSERT INTO pricer_measure (measure_name, measure_class_name, measure_id)
        values ('CVM_NEAR','margin.vm.pricer.PricerMeasureVariationMargin', 533)
/

INSERT INTO pricer_measure (measure_name, measure_class_name, measure_id)
        values ('CVM_FAR','margin.vm.pricer.PricerMeasureVariationMargin', 532)
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-1619' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-1619-1.sql */
/* Start of the SQL statements from file:MGNC-1601-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-1601',1,CURRENT_TIMESTAMP,'started')
/

update margin_trade_vm set im_portfolio_name = margin_agreement_name
/

update margin_portfolio_vm set im_portfolio_name = margin_agreement_name
/

update margin_trade_vm_hist set im_portfolio_name = margin_agreement_name
/

update margin_portfolio_vm_hist set im_portfolio_name = margin_agreement_name
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-1601' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-1601-1.sql */
/* Start of the SQL statements from file:CAL-385583-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-385583',1,CURRENT_TIMESTAMP,'started')
/

DELETE
FROM investment_cash_position
WHERE position_id IN
  (SELECT p.position_id
  FROM official_pl_mark m
  RIGHT JOIN investment_cash_position p
  ON m.trade_id = p.position_id
  INNER JOIN
    (SELECT treasury_portfolio_id,
      book_id,
      currency
    FROM investment_cash_position
    GROUP BY treasury_portfolio_id,
      book_id,
      currency
    HAVING COUNT(*) > 1
    ) d
  ON p.treasury_portfolio_id = d.treasury_portfolio_id
  AND p.book_id              =d.book_id
  AND p.currency             =d.currency
  WHERE m.mark_id           IS NULL
  )
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-385583' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-385583-1.sql */
/* Start of the SQL statements from file:CAL-363765-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-363765',1,CURRENT_TIMESTAMP,'started')
/

BEGIN
	DECLARE
		query VARCHAR2(4000);
		tablesToCheck list_of_names_t := list_of_names_t('ERSC_RULE_GROUP','ENTITY_MODIF_METADATA');
	BEGIN
		query := 'UPDATE ersc_rule_group t
		SET
		creation_user =
		CASE WHEN (SELECT m.user_info FROM entity_modif_metadata m WHERE m.id = t.created_meta_data_id) IS NOT NULL
		THEN (SELECT m.user_info FROM entity_modif_metadata m WHERE m.id = t.created_meta_data_id)
		ELSE ''00112233-4455-6677-8899-aabbccddeeff''
		END,
		creation_date =
		CASE WHEN (SELECT m.date_info FROM entity_modif_metadata m WHERE m.id = t.created_meta_data_id) IS NOT NULL
		THEN (SELECT m.date_info FROM entity_modif_metadata m WHERE m.id = t.created_meta_data_id)
		ELSE 0
		END,
		last_update_user =
		CASE WHEN (SELECT m.user_info FROM entity_modif_metadata m WHERE m.id = t.updated_meta_data_id) IS NOT NULL
		THEN (SELECT m.user_info FROM entity_modif_metadata m WHERE m.id = t.updated_meta_data_id)
		ELSE ''00112233-4455-6677-8899-aabbccddeeff''
		END,
		last_update_date =
		CASE WHEN (SELECT m.date_info FROM entity_modif_metadata m WHERE m.id = t.updated_meta_data_id) IS NOT NULL
		THEN (SELECT m.date_info FROM entity_modif_metadata m WHERE m.id = t.updated_meta_data_id)
		ELSE 0
		END
		';
    run_query_if_tables_exist(tablesToCheck, query);
	END;
END;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-363765' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-363765-1.sql */
/* Start of the SQL statements from file:CAL-362799-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-362799',1,CURRENT_TIMESTAMP,'started')
/

update product_seclending set maturity_type = 'TERM' where maturity_type is null and open_term_b = 0
/

update product_seclending set maturity_type = 'OPEN' where maturity_type is null and open_term_b = 1
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-362799' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-362799-1.sql */
/* Start of the SQL statements from file:CAL-359149-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-359149',1,CURRENT_TIMESTAMP,'started')
/

update product_desc set product_sub_type ='Standard' where product_id in (select tlock.product_id from product_tlock tlock,product_bond bond where tlock.ref_product_id = bond.product_id and bond.notional_index is null)
/

update product_desc set product_sub_type ='Inflation' where product_id in (select tlock.product_id from product_tlock tlock,product_bond bond where tlock.ref_product_id = bond.product_id and bond.notional_index is not null)
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-359149' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-359149-1.sql */
/* Start of the SQL statements from file:CAL-364282-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-364282',1,CURRENT_TIMESTAMP,'started')
/

delete from pricer_measure where measure_name = 'PRICE_UNDERLYING_INDEX'
/

INSERT INTO pricer_measure(measure_name,measure_class_name,measure_id) VALUES ('PRICE_UNDERLYING_INDEX','tk.pricer.PricerMeasureCredit',925)
/

delete from pricer_measure where measure_name = 'ACCRUAL_FINANCING'
/

INSERT INTO pricer_measure(measure_name,measure_class_name,measure_id) VALUES ('ACCRUAL_FINANCING','tk.pricer.PricerMeasureCredit',926)
/

delete from pricer_measure where measure_name = 'ACCRUAL_INDEX'
/

INSERT INTO pricer_measure(measure_name,measure_class_name,measure_id) VALUES ('ACCRUAL_INDEX','tk.pricer.PricerMeasureCredit',927)
/

delete from pricer_measure where measure_name = 'MTM_INDEX'
/

INSERT INTO pricer_measure(measure_name,measure_class_name,measure_id) VALUES ('MTM_INDEX','tk.pricer.PricerMeasureCredit',928)
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-364282' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-364282-1.sql */
/* Start of the SQL statements from file:CAL-363666-2.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-363666',2,CURRENT_TIMESTAMP,'started')
/

ALTER TABLE ersc_rule_group MODIFY (ID varchar2(36))
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-363666' and version=2 and module='core'
/

/* End of the SQL statements from file:CAL-363666-2.sql */
/* Start of the SQL statements from file:CAL-363816-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-363816',1,CURRENT_TIMESTAMP,'started')
/

delete pricer_measure where measure_name = 'MTM_CCY' and measure_id = 500
/

delete pricer_measure where measure_name = 'FX_PL' and measure_id = 501
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-363816' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-363816-1.sql */
/* Start of the SQL statements from file:CAL-365914-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-365914',1,CURRENT_TIMESTAMP,'started')
/

DECLARE
   cnt_decimal INT;
   cnt_method INT;
   cnt_rounding_decimal INT;
   cnt_rounding_method INT;
BEGIN
	SELECT COUNT(*) INTO cnt_decimal FROM user_tab_cols WHERE upper(table_name)='PRODUCT_ROUNDING_RULE' AND upper(column_name) = 'DECIMALS';
	SELECT COUNT(*) INTO cnt_method FROM user_tab_cols WHERE upper(table_name)='PRODUCT_ROUNDING_RULE' AND upper(column_name) = 'METHOD';
	SELECT COUNT(*) INTO cnt_rounding_decimal FROM user_tab_cols WHERE upper(table_name)='PRODUCT_ROUNDING_RULE' AND upper(column_name) = 'ROUNDING_DECIMALS';
	SELECT COUNT(*) INTO cnt_rounding_method FROM user_tab_cols WHERE upper(table_name)='PRODUCT_ROUNDING_RULE' AND upper(column_name) = 'ROUNDING_METHOD';
	
	-- While running execute sql, rounding_decimals column will be added if it is not there since we have modified the column name in schema base, 
	-- so we need drop that column and rename the existing column(decimals) to rounding_decimals
	IF(cnt_rounding_decimal = 1 AND cnt_decimal =1) THEN
		execute immediate 'alter table product_rounding_rule rename column rounding_decimals to rounding_decimals_bck';
	END IF;
	IF cnt_decimal = 1 THEN
		execute immediate 'alter table product_rounding_rule rename column decimals to rounding_decimals';
	END IF;
	--Similar to above, do the same thing for rounding_method column
	IF(cnt_rounding_method = 1 AND cnt_method =1) THEN
		execute immediate 'alter table product_rounding_rule rename column rounding_method to rounding_method_bck';
	END IF;
	IF cnt_method = 1 THEN
		execute immediate 'alter table product_rounding_rule rename column method to rounding_method';	
	END IF;
	
	--Finally drop the bck columns	
	IF(cnt_rounding_decimal = 1 AND cnt_rounding_method = 1 AND cnt_method = 1 AND cnt_decimal =1) THEN
		execute immediate 'alter table product_rounding_rule drop (rounding_decimals_bck , rounding_method_bck)';
	END IF;	
END;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-365914' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-365914-1.sql */
/* Start of the SQL statements from file:CAL-363813-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-363813',1,CURRENT_TIMESTAMP,'started')
/

update pricer_measure set measure_id = 924 where measure_name = 'FEES_ALL_AM_EIR'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-363813' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-363813-1.sql */
/* Start of the SQL statements from file:CAL-363986-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-363986',1,CURRENT_TIMESTAMP,'started')
/

update pricer_measure set measure_id = 907 where measure_name = 'NPV_AMF'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-363986' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-363986-1.sql */
/* Start of the SQL statements from file:CAL-366287-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-366287',1,CURRENT_TIMESTAMP,'started')
/

create table missing_plmeasure as select pl_config_id from official_pl_config 
where pl_config_id not in (select pl_config_id from official_pl_config_attr where attr_type='plmeasure' and attr_value='P' || chr(38) || 'L')
/

insert into official_pl_config_attr (pl_config_id, attr_type, attr_value, user_specified_order)
select missing_plmeasure.pl_config_id, 'plmeasure', 'P' || chr(38) || 'L', max_measureid.order_id
from missing_plmeasure, (select pl_config_id, max(user_specified_order)+1 as order_id from official_pl_config_attr where attr_type='plmeasure' group by pl_config_id) max_measureid
where missing_plmeasure.pl_config_id = max_measureid.pl_config_id
/

drop table missing_plmeasure
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-366287' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-366287-1.sql */
/* Start of the SQL statements from file:CAL-367773-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-367773',1,CURRENT_TIMESTAMP,'started')
/

begin 
drop_table_if_exists('inv_cashposition');
drop_table_if_exists('inv_cashpos_hist');
drop_table_if_exists('inv_secposition');
drop_table_if_exists('inv_secpos_hist');
drop_table_if_exists('inv_cash_balance_back152');
drop_table_if_exists('inv_cash_movement_back152');
drop_table_if_exists('inv_sec_balance_back152');
drop_table_if_exists('inv_sec_movement_back152');
drop_table_if_exists('inv_movement_history');
drop_table_if_exists('inv_secposition_new');
end;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-367773' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-367773-1.sql */
/* Start of the SQL statements from file:CAL-365662-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-365662',1,CURRENT_TIMESTAMP,'started')
/

alter table calypso_cache rename column cache_limit to cache_limit_bck
/

alter table calypso_cache rename column limit to cache_limit
/

alter table calypso_cache drop column cache_limit_bck
/

begin
drop_table_if_exists ('tf_temp_table');
end;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-365662' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-365662-1.sql */
/* Start of the SQL statements from file:CAL-365765-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-365765',1,CURRENT_TIMESTAMP,'started')
/

alter table product_credit_facility rename column credit_limit to credit_limit_bck
/

alter table acc_interest_config rename column offset_date to offset_date_bck
/

alter table product_credit_facility rename column limit to credit_limit
/

alter table acc_interest_config rename column offset to offset_date
/

alter table product_credit_facility drop column credit_limit_bck
/

alter table acc_interest_config drop column offset_date_bck
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-365765' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-365765-1.sql */
/* Start of the SQL statements from file:CAL-365777-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-365777',1,CURRENT_TIMESTAMP,'started')
/

alter table product_cap_floor rename column strike_limit to strike_limit_bck
/

alter table product_cap_floor rename column limit to strike_limit
/

alter table corr_surf_basisadj_hist rename column offset_days to offset_days_bck
/

alter table corr_surf_basisadj_hist rename column offset to offset_days
/

alter table corr_surf_data_hist rename column offset_days to offset_days_bck
/

alter table corr_surf_data_hist rename column offset to offset_days
/

alter table corr_surf_ptadj_hist rename column offset_days to offset_days_bck
/

alter table corr_surf_ptadj_hist rename column offset to offset_days
/

alter table corr_surf_timeaxis_hist rename column offset_days to offset_days_bck
/

alter table corr_surf_timeaxis_hist rename column offset to offset_days
/

alter table corr_mat_data_hist rename column offset_days to offset_days_bck
/

alter table corr_mat_data_hist rename column offset to offset_days
/

alter table corr_matrix_data rename column offset_days to offset_days_bck
/

alter table corr_matrix_data rename column offset to offset_days
/

alter table corr_surf_basisadj rename column offset_days to offset_days_bck
/

alter table corr_surf_basisadj rename column offset to offset_days
/

alter table corr_surf_data rename column offset_days to offset_days_bck
/

alter table corr_surf_data rename column offset to offset_days
/

alter table corr_surf_ptadj rename column offset_days to offset_days_bck
/

alter table corr_surf_ptadj rename column offset to offset_days
/

alter table corr_surf_timeaxis rename column offset_days to offset_days_bck
/

alter table corr_surf_timeaxis rename column offset to offset_days
/

alter table corr_tenor_ax_hist rename column offset_days to offset_days_bck
/

alter table corr_tenor_ax_hist rename column offset to offset_days
/

alter table corr_tenor_axis rename column offset_days to offset_days_bck
/

alter table corr_tenor_axis rename column offset to offset_days
/

alter table cov_mat_data_hist rename column offset_days to offset_days_bck
/

alter table cov_mat_data_hist rename column offset to offset_days
/

alter table cov_matrix_data rename column offset_days to offset_days_bck
/

alter table cov_matrix_data rename column offset to offset_days
/

alter table product_cap_floor drop column strike_limit_bck
/

alter table corr_surf_basisadj_hist drop column offset_days_bck
/

alter table corr_surf_data_hist drop column offset_days_bck
/

alter table corr_surf_ptadj_hist drop column offset_days_bck
/

alter table corr_surf_timeaxis_hist drop column offset_days_bck
/

alter table corr_mat_data_hist drop column offset_days_bck
/

alter table corr_matrix_data drop column offset_days_bck
/

alter table corr_surf_basisadj drop column offset_days_bck
/

alter table corr_surf_data drop column offset_days_bck
/

alter table corr_surf_ptadj drop column offset_days_bck
/

alter table corr_surf_timeaxis drop column offset_days_bck
/

alter table corr_tenor_ax_hist drop column offset_days_bck
/

alter table corr_tenor_axis drop column offset_days_bck
/

alter table cov_mat_data_hist drop column offset_days_bck
/

alter table cov_matrix_data drop column offset_days_bck
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-365777' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-365777-1.sql */
/* Start of the SQL statements from file:CAL-365239-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-365239',1,CURRENT_TIMESTAMP,'started')
/

update trade_keyword set keyword_name = 'Trade Average Price' where keyword_name = 'AVG Price Future'
/

update trade_keyword set keyword_name = 'Trade Average Price' where keyword_name = 'AVG Price Future Option'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-365239' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-365239-1.sql */
/* Start of the SQL statements from file:CAL-365972-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-365972',1,CURRENT_TIMESTAMP,'started')
/

begin
rename_column_if_exists ('allocation','bm_offset','bm_offset_bck');
end;
/

begin
rename_column_if_exists ('allocation','offset','bm_offset');
end;
/

begin
rename_column_if_exists ('benchmark_comp_record_item','bm_offset','bm_offset_bck');
end;
/

begin
rename_column_if_exists ('benchmark_comp_record_item','offset','bm_offset');
end;
/

begin 
drop_column_if_exists  ('allocation','bm_offset_bck');
end;
/

begin 
drop_column_if_exists  ('benchmark_comp_record_item','bm_offset_bck');
end;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-365972' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-365972-1.sql */
/* Start of the SQL statements from file:CAL-365961-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-365961',1,CURRENT_TIMESTAMP,'started')
/

alter table cu_cds rename column start_offset to start_offset_bck
/

alter table cu_cds rename column offset to start_offset
/

alter table product_otccom_opt rename column settlement_offset to settlement_offset_bck
/

alter table product_otccom_opt rename column offset to settlement_offset
/

alter table product_otceq_opt rename column settlement_offset to settlement_offset_bck
/

alter table product_otceq_opt rename column offset to settlement_offset
/

alter table accrual_schedule_params rename column accrual_offset to accrual_offset_bck
/

alter table accrual_schedule_params rename column offset to accrual_offset
/

alter table cu_cds drop column start_offset_bck
/

alter table product_otccom_opt drop column settlement_offset_bck
/

alter table product_otceq_opt drop column settlement_offset_bck
/

alter table accrual_schedule_params drop column accrual_offset_bck
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-365961' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-365961-1.sql */
/* Start of the SQL statements from file:CAL-360491-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-360491',1,CURRENT_TIMESTAMP,'started')
/

update option_contract set underlying_date_type='Underlying Add Months' where months_added>0
/

update option_contract set underlying_date_type='Underlying Date Schedule' where underlying_rule>0 AND months_added!=-999
/

update option_contract set underlying_date_type='Add Months on Product' where underlying_rule>0 AND months_added=-999
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-360491' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-360491-1.sql */
/* Start of the SQL statements from file:CAL-367501-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-367501',1,CURRENT_TIMESTAMP,'started')
/

delete from domain_values where name = 'PreciousMetalUnits.XAU'
/

delete from domain_values where name = 'domainName' and value = 'PreciousMetalUnits.XAU'
/

delete from domain_values where name = 'currencyDefaultAttribute' and value = 'PreciousMetalBaseUnit'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-367501' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-367501-1.sql */
/* Start of the SQL statements from file:CAL-300507-3.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-300507',3,CURRENT_TIMESTAMP,'started')
/

create table tempccy as  
(select distinct trade.trade_id  as trade_id , trade.product_id as product_id, decode(cp.pl_display_ccy,'Primary',cp.primary_currency, 'Secondary', cp.quoting_currency) as pl_ccy   
from currency_pair cp, trade t, swap_leg l, product_swap s , trade trade 
where trade.trade_id = t.trade_id and
    l.product_id =  s. product_id 
and t.product_id = s.product_id
and s.swap_type in  ('XCCySwap','SwapNonDeliverable','SwapCrossCurrency','NDS')
and ( (cp.primary_currency = (select l.principal_currency from swap_leg l, product_swap s 
                              where l.product_id =  s. product_id 
                              and t.product_id = s.product_id
                              and s.swap_type in  ('XCCySwap','SwapNonDeliverable','SwapCrossCurrency','NDS')
                              and l.leg_id = 1)--pay leg
	and cp.quoting_currency = (select l.principal_currency from swap_leg l, product_swap s 
                              where l.product_id =  s. product_id
                              and t.product_id = s.product_id
                              and s.swap_type in  ('XCCySwap','SwapNonDeliverable','SwapCrossCurrency','NDS')
                              and l.leg_id = 2) )  
	or (cp.primary_currency = (select l.principal_currency from swap_leg l, product_swap s 
                              where l.product_id =  s. product_id 
                              and t.product_id = s.product_id
                              and s.swap_type in  ('XCCySwap','SwapNonDeliverable','SwapCrossCurrency','NDS')
                              and l.leg_id = 2)--rec leg
	and cp.quoting_currency = (select l.principal_currency from swap_leg l, product_swap s 
                              where l.product_id =  s. product_id
                              and t.product_id = s.product_id
                              and s.swap_type in  ('XCCySwap','SwapNonDeliverable','SwapCrossCurrency','NDS')
                              and l.leg_id = 1) ) ) )
/

merge into trade using tempccy
on (trade.trade_id=tempccy.trade_id)
when matched then update set trade.trade_currency=tempccy.pl_ccy
where trade.trade_id=tempccy.trade_id
/

merge into product_desc using tempccy
on (product_desc.product_id=tempccy.product_id)
when matched then update set product_desc.currency=tempccy.pl_ccy
where product_desc.product_id=tempccy.product_id
/

drop table tempccy
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-300507' and version=3 and module='core'
/

/* End of the SQL statements from file:CAL-300507-3.sql */
/* Start of the SQL statements from file:CAL-374192-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-374192',1,CURRENT_TIMESTAMP,'started')
/

alter table  inv_cash_balance rename to inv_cash_balance_back161
/

alter table inv_cash_movement rename to inv_cash_movement_back161
/

alter table inv_sec_balance rename to inv_sec_balance_back161
/

alter table inv_sec_movement rename to inv_sec_movement_back161
/

create table inv_cash_balance(internal_external varchar2(32) not null,
position_type varchar2(32) not null,
agent_id  number not null,
account_id  number not null,
date_type varchar2(32) not null,
position_date timestamp not null,
currency_code varchar2(3) not null,
book_id  number not null,
config_id  number default 0  not null,
mcc_id  number  default 0 not null  ,
sub_account_id  number default 0 not null,
total_amount  decimal(38,15) null,
total_ote_fut  decimal(38,15) null,
total_ote_opt  decimal(38,15) null,
total_ote_disc  decimal(38,15) null,
total_vm_fut  decimal(38,15) null,
total_vm_opt  decimal(38,15) null,
total_vm_disc  decimal(38,15) null,
total_lov  decimal(38,15) null,
total_sov  decimal(38,15) null,
total_commission  decimal(38,15) null,
total_fees  decimal(38,15) null,
total_futures_pl  decimal(38,15) null,
total_option_premium  decimal(38,15) null,
total_option_cash_settlement  decimal(38,15) null,
total_cash_movements  decimal(38,15) null,
version  number not null,
total_margin_call_in decimal(38,15) null,
total_margin_call_out decimal(38,15) null,
total_mc_rehyp_in decimal(38,15) null,
total_mc_rehyp_out decimal(38,15) null,
total_mc_non_rehyp_in decimal(38,15) null,
total_mc_non_rehyp_out decimal(38,15) null,
total_mc_book_owner_in decimal(38,15) null,
total_mc_book_owner_out decimal(38,15) null)
/

insert /*+ parallel(8) */   into inv_cash_balance select  internal_external ,
 position_type  ,
 agent_id  ,
 account_id  ,
 date_type ,
 position_date ,
 currency_code ,
 book_id  ,
config_id ,
 mcc_id ,
 0,
 total_amount as total_amount   ,
 total_ote_fut as total_ote_fut   ,
 total_ote_opt as total_ote_opt   ,
 total_ote_disc as total_ote_disc   ,
 total_vm_fut as total_vm_fut   ,
 total_vm_opt as total_vm_opt   ,
 total_vm_disc as total_vm_disc   , 
 total_lov as total_lov   ,
 total_sov as total_sov   ,
 total_commission as total_commission   ,
 total_fees as total_fees   ,
 total_futures_pl as total_futures_pl   ,
 total_option_premium as total_option_premium   ,
 total_option_cash_settlement as total_option_cash_settlement   ,
 total_cash_movements as total_cash_movements   ,
 version ,
 total_margin_call_in as total_margin_call_in ,
 total_margin_call_out as total_margin_call_out ,
 total_mc_rehyp_in as total_mc_rehyp_in ,
 total_mc_rehyp_out as total_mc_rehyp_out ,
 total_mc_non_rehyp_in as total_mc_non_rehyp_in ,
 total_mc_non_rehyp_out as total_mc_non_rehyp_out ,
 total_mc_book_owner_in as total_mc_book_owner_in ,
 total_mc_book_owner_out as total_mc_book_owner_out from inv_cash_balance_back161
/

create table inv_cash_movement (internal_external varchar2(32) not null,
position_type varchar2(32) not null,
agent_id  number not null,
account_id  number not null,
date_type varchar2(32) not null,
position_date timestamp not null,
currency_code varchar2(3) not null,
book_id  number not null,
config_id  number  default 0  not null,
mcc_id  number default 0 not null  ,
sub_account_id  number default 0 not null,
daily_change  decimal(38,15) null,
daily_ote_fut  decimal(38,15) null,
daily_ote_opt  decimal(38,15) null,
daily_ote_disc  decimal(38,15) null,
daily_vm_fut  decimal(38,15) null,
daily_vm_opt  decimal(38,15) null,
daily_vm_disc  decimal(38,15) null,
daily_lov  decimal(38,15) null,
daily_sov  decimal(38,15) null,
daily_commission  decimal(38,15) null,
daily_fees  decimal(38,15) null,
daily_futures_pl  decimal(38,15) null,
daily_option_premium  decimal(38,15) null,
daily_option_cash_settlement  decimal(38,15) null,
daily_cash_movements  decimal(38,15) null,
version  number not null,
daily_margin_call_in decimal(38,15) null,
daily_margin_call_out decimal(38,15) null,
daily_mc_rehyp_in decimal(38,15) null,
daily_mc_rehyp_out decimal(38,15) null,
daily_mc_non_rehyp_in decimal(38,15) null,
daily_mc_non_rehyp_out decimal(38,15) null,
daily_mc_book_owner_in decimal(38,15) null,
daily_mc_book_owner_out decimal(38,15) null)
/

insert /*+ parallel(8) */  into inv_cash_movement 
select   
 internal_external,
 position_type,
 agent_id ,
 account_id,
 date_type,
 position_date,
 currency_code,
 book_id ,
 config_id, 
 mcc_id ,
 0,
 daily_change as daily_change, 
daily_ote_fut as daily_ote_fut,
daily_ote_opt as daily_ote_opt,
daily_ote_disc as daily_ote_disc, 
daily_vm_fut as daily_vm_fut,
daily_vm_opt as daily_vm_opt,
daily_vm_disc as daily_vm_disc, 
daily_lov as daily_lov,
daily_sov as daily_sov,
daily_commission as daily_commission,
daily_fees as daily_fees,
daily_futures_pl as daily_futures_pl,
daily_option_premium as daily_option_premium,
daily_option_cash_settlement as daily_option_cash_settlement,
daily_cash_movements as daily_cash_movements,
version ,
daily_margin_call_in as daily_margin_call_in,
daily_margin_call_out as daily_margin_call_out,
daily_mc_rehyp_in as daily_mc_rehyp_in,
daily_mc_rehyp_out as daily_mc_rehyp_out,
daily_mc_non_rehyp_in as daily_mc_non_rehyp_in,
daily_mc_non_rehyp_out as daily_mc_non_rehyp_out,
daily_mc_book_owner_in as daily_mc_book_owner_in,
daily_mc_book_owner_out as daily_mc_book_owner_out from inv_cash_movement_back161
/

create table inv_sec_balance (
internal_external  varchar2(32) not null,
        position_type  varchar2(32) not null,
        date_type  varchar2(32) not null,
        agent_id   number not null,
        account_id   number not null,
        position_date  timestamp not null,
        security_id   number not null,
        book_id   number not null,
        config_id   number  default  0  not null,
        mcc_id   number default  0 not null    ,
		sub_account_id  number default 0 not null,
		total_security   decimal(38,15) null,
        total_borrowed   decimal(38,15) null,
        t_bor_not_avl   decimal(38,15) null,
        total_borrowed_ca   decimal(38,15) null,
        total_loaned   decimal(38,15) null,
        t_loan_not_avl   decimal(38,15) null,
        total_loaned_ca   decimal(38,15) null,
        total_coll_in   decimal(38,15) null,
        t_coll_in_not_avl   decimal(38,15) null,
        total_coll_in_ca   decimal(38,15) null,
        total_coll_out   decimal(38,15) null,
        t_coll_out_not_avl   decimal(38,15) null,
        total_coll_out_ca   decimal(38,15) null,
        total_pledged_in   decimal(38,15) null,
        total_pledged_out   decimal(38,15) null,
        total_unavail   decimal(38,15) null,
        total_repo_track_in   decimal(38,15) null,
        total_repo_track_out   decimal(38,15) null,
        total_borrowed_auto   decimal(38,15) null,
        total_loaned_auto   decimal(38,15) null,
        total_pth_in   decimal(38,15) null,
        total_pth_out   decimal(38,15) null,
        total_hold_in   decimal(38,15) null,
        total_hold_out   decimal(38,15) null,
        total_margin_call_in   decimal(38,15) null,
        total_margin_call_out   decimal(38,15) null,
        total_triparty_mc_in   decimal(38,15) null,
        total_triparty_mc_out   decimal(38,15) null,
        total_simple_transfer_in   decimal(38,15) null,
		total_simple_transfer_out   decimal(38,15) null,
        total_repo_callable_in   decimal(38,15) null,
        total_repo_callable_out   decimal(38,15) null,
        total_seclending_callable_in   decimal(38,15) null,
        total_seclending_callable_out   decimal(38,15) null,
        total_margin_call_rehypo   decimal(38,15) null,        
        total_repo_bsb_in   decimal(38,15) null,        
        total_repo_bsb_out   decimal(38,15) null,               
        total_repo_in   decimal(38,15) null,   
        total_repo_out   decimal(38,15) null,          
        version   number not null,
		total_mc_rehyp_in decimal(38,15) null,
		total_mc_rehyp_out decimal(38,15) null,
		total_mc_non_rehyp_in decimal(38,15) null,
		total_mc_non_rehyp_out decimal(38,15) null,
		total_mc_book_owner_in decimal(38,15) null,
		total_mc_book_owner_out decimal(38,15) null)
/

insert /*+ parallel(8) */  into inv_sec_balance  
select 
internal_external,
position_type,
date_type,
agent_id,
account_id,
position_date,
security_id,
book_id,
config_id,
mcc_id,
0,
total_security  as total_security,
total_borrowed  as total_borrowed,
t_bor_not_avl  as t_bor_not_avl,
total_borrowed_ca  as total_borrowed_ca,
total_loaned  as total_loaned,
t_loan_not_avl  as t_loan_not_avl,
total_loaned_ca  as total_loaned_ca,
total_coll_in  as total_coll_in,
t_coll_in_not_avl  as t_coll_in_not_avl,
total_coll_in_ca  as total_coll_in_ca,
total_coll_out  as total_coll_out,
t_coll_out_not_avl  as t_coll_out_not_avl,
total_coll_out_ca  as total_coll_out_ca,
total_pledged_in  as total_pledged_in,
total_pledged_out  as total_pledged_out,
total_unavail  as total_unavail,
total_repo_track_in  as total_repo_track_in,
total_repo_track_out  as total_repo_track_out,
total_borrowed_auto  as total_borrowed_auto,
total_loaned_auto  as total_loaned_auto,
total_pth_in  as total_pth_in,
total_pth_out  as total_pth_out,
total_hold_in  as total_hold_in,
total_hold_out  as total_hold_out,
total_margin_call_in  as total_margin_call_in,
total_margin_call_out  as total_margin_call_out,
total_triparty_mc_in  as total_triparty_mc_in,
total_triparty_mc_out  as total_triparty_mc_out,
total_simple_transfer_in  as total_simple_transfer_in,
total_simple_transfer_out  as total_simple_transfer_out,
total_repo_callable_in  as total_repo_callable_in,
total_repo_callable_out  as total_repo_callable_out,
total_seclending_callable_in  as total_seclending_callable_in,
total_seclending_callable_out as total_seclending_callable_out,
total_margin_call_rehypo  as total_margin_call_rehypo,
total_repo_bsb_in  as total_repo_bsb_in,
total_repo_bsb_out  as total_repo_bsb_out,
total_repo_in  as total_repo_in,
total_repo_out  as total_repo_out ,
version ,
total_mc_rehyp_in as total_mc_rehyp_in,
total_mc_rehyp_out as total_mc_rehyp_out,
total_mc_non_rehyp_in as total_mc_non_rehyp_in,
total_mc_non_rehyp_out  as total_mc_non_rehyp_out,
total_mc_book_owner_in as total_mc_book_owner_in,
total_mc_book_owner_out as total_mc_book_owner_out from inv_sec_balance_back161
/

create table inv_sec_movement (
        internal_external varchar2(32) not null,
        position_type varchar2(32) not null,
        date_type varchar2(32) not null,
        agent_id  number not null,
        account_id  number not null,
        position_date timestamp not null,
        security_id  number not null,
        book_id  number not null,
        config_id  number default 0 not null,
        mcc_id  number default 0  not null ,
		sub_account_id  number default 0 not null,
		daily_security  decimal(38,15) null,
        daily_borrowed  decimal(38,15) null,
        d_bor_not_avl  decimal(38,15) null,
        daily_borrowed_ca  decimal(38,15) null,
        daily_loaned  decimal(38,15) null,
        d_loan_not_avl  decimal(38,15) null,
        daily_loaned_ca  decimal(38,15) null,
        daily_coll_in  decimal(38,15) null,
        d_coll_in_not_avl  decimal(38,15) null,
        daily_coll_in_ca  decimal(38,15) null,
        daily_coll_out  decimal(38,15) null,
        d_coll_out_not_avl  decimal(38,15) null,
        daily_coll_out_ca  decimal(38,15) null,
        daily_pledged_in  decimal(38,15) null,
        daily_pledged_out  decimal(38,15) null,
        daily_unavail  decimal(38,15) null,
        daily_repo_track_in  decimal(38,15) null,
        daily_repo_track_out  decimal(38,15) null,
        daily_borrowed_auto  decimal(38,15) null,
        daily_loaned_auto  decimal(38,15) null,
        daily_pth_in  decimal(38,15) null,
        daily_pth_out  decimal(38,15) null,
		daily_hold_in  decimal(38,15) null,
        daily_hold_out  decimal(38,15) null,
        daily_margin_call_in  decimal(38,15) null,
		daily_margin_call_out  decimal(38,15) null,
		daily_triparty_mc_in  decimal(38,15) null,
		daily_triparty_mc_out  decimal(38,15) null,
		daily_simple_transfer_in  decimal(38,15) null,
		daily_simple_transfer_out  decimal(38,15) null,
        daily_repo_callable_in  decimal(38,15) null,
		daily_repo_callable_out  decimal(38,15) null,
		daily_seclending_callable_in  decimal(38,15) null,
		daily_seclending_callable_out  decimal(38,15) null,
		daily_margin_call_rehypo  decimal(38,15) null,
		daily_repo_bsb_in  decimal(38,15) null,        
        daily_repo_bsb_out  decimal(38,15) null, 
        daily_repo_in  decimal(38,15) null,   
        daily_repo_out  decimal(38,15) null,      
        version  number not null,
		daily_mc_rehyp_in decimal(38,15) null, 
		daily_mc_rehyp_out decimal(38,15) null, 
		daily_mc_non_rehyp_in decimal(38,15) null, 
		daily_mc_non_rehyp_out decimal(38,15) null, 
		daily_mc_book_owner_in decimal(38,15) null, 
		daily_mc_book_owner_out decimal(38,15) null)
/

insert /*+ parallel(8) */  into  inv_sec_movement  select  
internal_external,
position_type,
date_type,
agent_id,
account_id,
position_date,
security_id,
book_id,
config_id,
mcc_id,
0,
daily_security  as daily_security,
daily_borrowed  as daily_borrowed,
d_bor_not_avl  as d_bor_not_avl,
daily_borrowed_ca  as daily_borrowed_ca,
daily_loaned  as daily_loaned,
d_loan_not_avl  as d_loan_not_avl,
daily_loaned_ca  as daily_loaned_ca,
daily_coll_in  as daily_coll_in,
d_coll_in_not_avl  as d_coll_in_not_avl,
daily_coll_in_ca  as daily_coll_in_ca,
daily_coll_out  as daily_coll_out,
d_coll_out_not_avl  as d_coll_out_not_avl,
daily_coll_out_ca  as daily_coll_out_ca,
daily_pledged_in  as daily_pledged_in,
daily_pledged_out  as daily_pledged_out,
daily_unavail  as daily_unavail,
daily_repo_track_in  as daily_repo_track_in,
daily_repo_track_out  as daily_repo_track_out,
daily_borrowed_auto  as daily_borrowed_auto,
daily_loaned_auto  as daily_loaned_auto,
daily_pth_in  as daily_pth_in,
daily_pth_out  as daily_pth_out,
daily_hold_in  as daily_hold_in,
daily_hold_out  as daily_hold_out,
daily_margin_call_in  as daily_margin_call_in,
daily_margin_call_out  as daily_margin_call_out,
daily_triparty_mc_in  as daily_triparty_mc_in,
daily_triparty_mc_out  as daily_triparty_mc_out,
daily_simple_transfer_in  as daily_simple_transfer_in,
daily_simple_transfer_out  as daily_simple_transfer_out,
daily_repo_callable_in  as daily_repo_callable_in,
daily_repo_callable_out  as daily_repo_callable_out,
daily_seclending_callable_in as daily_seclending_callable_in,
daily_seclending_callable_out as daily_seclending_callable_out,
daily_margin_call_rehypo  as daily_margin_call_rehypo,
daily_repo_bsb_in  as daily_repo_bsb_in,
daily_repo_bsb_out  as daily_repo_bsb_out,
daily_repo_in  as daily_repo_in,
daily_repo_out  as daily_repo_out,
version ,
daily_mc_rehyp_in as daily_mc_rehyp_in, 
daily_mc_rehyp_out as daily_mc_rehyp_out,
daily_mc_non_rehyp_in as daily_mc_non_rehyp_in, 
daily_mc_non_rehyp_out as daily_mc_non_rehyp_out,
daily_mc_book_owner_in as daily_mc_book_owner_in,
daily_mc_book_owner_out as daily_mc_book_owner_out from inv_sec_movement_back161
/

alter table inv_sec_movement noparallel logging
/

alter table inv_sec_balance noparallel logging
/

alter table inv_cash_movement noparallel logging
/

alter table inv_cash_balance noparallel logging
/

drop table inv_cash_balance_back161
/

drop table inv_cash_movement_back161
/

drop table inv_sec_balance_back161
/

drop table inv_sec_movement_back161
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-374192' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-374192-1.sql */
/* Start of the SQL statements from file:CAL-376349-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-376349',1,CURRENT_TIMESTAMP,'started')
/

UPDATE curve_parameter SET value = REPLACE(VALUE, ',', '.') WHERE parameter_name IN ('January','February','March','April','May','June','July','August','September','October','November','December')
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-376349' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-376349-1.sql */
/* Start of the SQL statements from file:CAL-371591-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-371591',1,CURRENT_TIMESTAMP,'started')
/

/*
CAL-371591
Sets pl methodology to 'transfer' only for SimpleTransfer products if it was 'CASH_PL' or was changed to 'AmortizedCost'
because of script provided for CAL-305182.
*/ 
UPDATE pl_methodology_config_items m
SET m.methodology_name = 'Transfer' 
WHERE m.product_type = 'SimpleTransfer' 
AND (m.methodology_name = 'CASH_PL' OR m.methodology_name = 'AmortizedCost')
/

UPDATE official_pl_mark m 
SET m.methodology = 'Transfer'
WHERE m.effective_product_type = 'SimpleTransfer' 
AND (m.methodology = 'CASH_PL' OR m.methodology = 'AmortizedCost')
/

UPDATE official_pl_mark_hist m 
SET m.methodology = 'Transfer'
WHERE m.effective_product_type = 'SimpleTransfer' 
AND (m.methodology = 'CASH_PL' OR m.methodology = 'AmortizedCost')
/

UPDATE official_pl_aggregate_item m 
SET m.methodology = 'Transfer'
WHERE m.effective_product_type = 'SimpleTransfer' 
AND (m.methodology = 'CASH_PL' OR m.methodology = 'AmortizedCost')
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-371591' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-371591-1.sql */
/* Start of the SQL statements from file:CAL-371321-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-371321',1,CURRENT_TIMESTAMP,'started')
/

update acc_rule set version_num = 0 where version_num is NULL
/

update acc_rule set po_id = 0 where po_id is NULL
/

update acc_rule set liq_agg_conf_id = 0 where liq_agg_conf_id is NULL
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-371321' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-371321-1.sql */
/* Start of the SQL statements from file:CAL-378859-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-378859',1,CURRENT_TIMESTAMP,'started')
/

/*CURVE_POINT_ADJ  & CURVE_QUOTE_ADJ grows with zero values - getPricingEnv() call performance issue*/

create table curve_point_adj_new as (select * from curve_point_adj where adj_value !=0)
/

alter table curve_point_adj rename to curve_point_adj_back
/

alter table curve_point_adj_new rename to curve_point_adj
/

drop table curve_point_adj_back
/

create table curve_quote_adj_new as (select * from curve_quote_adj where adj_value !=0)
/

alter table curve_quote_adj rename to curve_quote_adj_back
/

alter table curve_quote_adj_new rename to curve_quote_adj
/

drop table curve_quote_adj_back
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-378859' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-378859-1.sql */
/* Start of the SQL statements from file:CAL-379875-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-379875',1,CURRENT_TIMESTAMP,'started')
/

DELETE FROM domain_values WHERE name = 'engineName' AND value ='CollateralServiceIntegrationEngine'
/

DELETE FROM domain_values WHERE name = 'eventFilter' AND value ='CollateralServiceIntegrationEventFilter'
/

DELETE FROM engine_config WHERE ENGINE_NAME = 'CollateralServiceIntegrationEngine'
/

DELETE from engine_param where ENGINE_NAME = 'CollateralServiceIntegrationEngine'
/

DELETE from ps_event_config WHERE ENGINE_NAME = 'CollateralServiceIntegrationEngine'
/

DELETE from ps_event_filter WHERE ENGINE_NAME = 'CollateralServiceIntegrationEngine'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-379875' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-379875-1.sql */
/* Start of the SQL statements from file:CAL-377334-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-377334',1,CURRENT_TIMESTAMP,'started')
/

/* move official_pl_temp_id to temp table -- need to drop the table so it can be created again as temp table and to remove request_id which is not needed anymore */
begin 
drop_table_if_exists('official_pl_temp_id');
end;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-377334' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-377334-1.sql */
/* Start of the SQL statements from file:CAL-377359-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-377359',1,CURRENT_TIMESTAMP,'started')
/

declare 
y int;
x int;
BEGIN
	select max(vsize(CURRENCY_LIST)) into x from fee_config;
	select count(*) into y from fee_config;
	exception WHEN NO_DATA_FOUND THEN
	x:=0;
	y:=0;
	if (y = 0 or x <= 400) then
		execute immediate 'alter table fee_config modify (CURRENCY_LIST varchar2(400))';
	end if;
END;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-377359' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-377359-1.sql */
/* Start of the SQL statements from file:CAL-359075-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-359075',1,CURRENT_TIMESTAMP,'started')
/

create or replace procedure sp_pl_methodology_driver as
  x integer := 0;
  y integer := 0;
  z integer := 0;
  pl_meth_driver VARCHAR2(32); 
  book_attr_name VARCHAR2(32); 
  begin      
		SELECT COUNT(DISTINCT pl_methodology_driver) INTO x FROM pl_methodology_config;
		DBMS_OUTPUT.PUT_LINE('checking the methodology driver(s) in pl_methodology_config. '|| x);
		SELECT count(*) INTO y FROM book_attribute WHERE is_pl_methodology_driver = 1;
		DBMS_OUTPUT.PUT_LINE('checking pl methodology driver book attribute exist. '|| y );	
	
  IF x > 1 THEN
      DBMS_OUTPUT.PUT_LINE('Error occured - Found multiple methodology drivers in pl_methodology_config table');
  END IF;	
  
  IF y > 1 THEN
        DBMS_OUTPUT.PUT_LINE('Error occured - there should be only one book attribute set to pl methodology driver in book_attribute table');
  END IF;
  
  IF x = 1 THEN
  	SELECT DISTINCT pl_methodology_driver INTO pl_meth_driver FROM pl_methodology_config;
  	DBMS_OUTPUT.PUT_LINE('Methodology driver in pl_methodology_config - '|| pl_meth_driver);
  	
  	IF y = 0 THEN
  		SELECT count(*) INTO z FROM book_attribute WHERE attribute_name = pl_meth_driver;
  		IF z = 0 THEN
  			execute immediate 'INSERT INTO book_attribute(attribute_name,is_pl_methodology_driver) VALUES (' ||chr(39)||pl_meth_driver||chr(39)|| ', 1)';  
  		ELSIF z = 1 THEN
			execute immediate 'UPDATE book_attribute SET is_pl_methodology_driver = 1 WHERE attribute_name = ' ||chr(39)||pl_meth_driver||chr(39);
  		END IF;
  	ELSIF y = 1 THEN
  	  SELECT attribute_name INTO book_attr_name FROM book_attribute WHERE is_pl_methodology_driver = 1;
	  DBMS_OUTPUT.PUT_LINE('Pl methodology driver book attribute - '|| book_attr_name);	
  	
	  IF (pl_meth_driver != book_attr_name) THEN
	  	DBMS_OUTPUT.PUT_LINE('Error occured - Pl methodology driver in pl_methodology_config table do not match Pl methodology driver book attribute');
	  ELSE
	  	DBMS_OUTPUT.PUT_LINE('Pl methodology driver in pl_methodology_config table match Pl methodology driver book attribute');
	  END IF;
  	END IF;  
  END IF;  
END;
/

begin
sp_pl_methodology_driver;
end;
/

drop procedure sp_pl_methodology_driver
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-359075' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-359075-1.sql */
/* Start of the SQL statements from file:CAL-357588-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-357588',1,CURRENT_TIMESTAMP,'started')
/

/* initialize the new original price column on all liquidations to the first trade price */
/* then update specific liquidation types, only when average price methodologies are in use */
/* for Buy/Sell (type=0) and CA REDEMPTION (type=9), set original price to the first TOQ's price (signed), as it would be when not using average price */
/* for REALIZED liquidations (type=2), first price is a constant 0 (CA CASH) or 1 (Fees) and not related to a trade or position price; it can stay as first price */
/* for the other CA types - AMORTIZATION (3), PAYDOWN (7), REFERENTIAL (8) - set original price to the first TOQ's price (unsigned), as it would be when not using average price */
update liq_position set original_price = first_price
/

declare using_avgprice integer := 0;
begin
	select count(*) into using_avgprice from liq_info where liq_method in ('TDWAC','WAC','WACSL','AvgCost','AvgPrice');
    if using_avgprice > 0 then
    begin
		update liq_position set original_price = (select
			case
				when lp2.type in (0,9) 
				then trade_open_qty.price * SIGN(trade_open_qty.quantity) 
				when lp2.type in (3,7,8) 
				then trade_open_qty.price 
			end
			from trade_open_qty, liq_position lp2
			where trade_open_qty.book_id = lp2.book_id
			and trade_open_qty.product_id = lp2.product_id
			and trade_open_qty.liq_agg_id = lp2.liq_agg_id
			and trade_open_qty.liq_config_id = lp2.liq_config_id
			and trade_open_qty.sign = lp2.first_rel_id
			and trade_open_qty.linked_id = lp2.first_linked_id
			and trade_open_qty.settle_date = lp2.first_settle_date
			and trade_open_qty.trade_id = lp2.first_trade
			and liq_position.order_id = lp2.order_id
		)
		where liq_position.type in (0,9,3,7,8);
    end;	
    end if;
end;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-357588' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-357588-1.sql */
/* Start of the SQL statements from file:CAL-384964-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-384964',1,CURRENT_TIMESTAMP,'started')
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-384964' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-384964-1.sql */
/* Start of the SQL statements from file:CAL-385090-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-385090',1,CURRENT_TIMESTAMP,'started')
/

UPDATE credit_rating
SET debt_seniority = 'ANY'
WHERE upper(debt_seniority) = 'ANY'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-385090' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-385090-1.sql */
/* Start of the SQL statements from file:CAL-385399-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-385399',1,CURRENT_TIMESTAMP,'started')
/

DELETE FROM auth_class_config WHERE full_class_name = 'com.calypso.engine.risk.util.mcc.MCCBagTol '
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-385399' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-385399-1.sql */
/* Start of the SQL statements from file:CAL-387866-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-387866',1,CURRENT_TIMESTAMP,'started')
/

CREATE OR REPLACE
PROCEDURE rename_pws_items_columns
AS
BEGIN
  EXECUTE immediate 'CREATE TABLE am_grouping_columns_bk as (select * from am_grouping_columns)';
  EXECUTE immediate 'CREATE TABLE am_filtering_columns_bk  as (select * from am_filtering_columns)';
  EXECUTE immediate 'CREATE TABLE am_columnset_main_columns_bk as (select * from  am_columnset_main_columns)';
  EXECUTE immediate 'CREATE TABLE am_columnset_pivot_columns_bk as (select * from   am_columnset_pivot_columns)';
  EXECUTE immediate 'CREATE TABLE am_columnset_group_columns_bk as (select * from  am_columnset_group_columns)';
  EXECUTE immediate 'CREATE TABLE am_columnset_break_columns_bk as (select * from  am_columnset_breakdown_columns)';
  EXECUTE immediate 'CREATE TABLE am_coloring_colord_columns_bk as (select * from am_coloring_colored_columns)';
  EXECUTE immediate 'CREATE TABLE am_unit_denominator_column_bk as (select * from  am_unit_denominator_column)';
  EXECUTE immediate 'CREATE TABLE am_columnset_config_bk as (select * from am_columnset_configuration)';
  EXECUTE immediate 'CREATE TABLE am_columnset_profiles_bk as (select * from am_columnset_profiles)';
  EXECUTE immediate 'CREATE TABLE am_columnset_widgets_bk as (select * from am_columnset_widgets)';
  EXECUTE immediate 'CREATE TABLE am_columnset_actions_bk as (select * from am_columnset_actions)';
  EXECUTE immediate 'CREATE TABLE am_unit_configuration_bk as (select * from am_unit_configuration)';
  EXECUTE immediate 'CREATE TABLE am_unit_profiles_bk as (select * from am_unit_profiles)';
  EXECUTE immediate 'CREATE TABLE am_grouping_configuration_bk as (select * from am_grouping_configuration)';
  EXECUTE immediate 'CREATE TABLE am_grouping_profiles_bk as (select * from am_grouping_profiles)';
  EXECUTE immediate 'CREATE TABLE am_filtering_configuration_bk as (select * from am_filtering_configuration)';
  EXECUTE immediate 'CREATE TABLE am_filtering_profiles_bk as (select * from am_filtering_profiles)';
  EXECUTE immediate 'CREATE TABLE am_coloring_configuration_bk as (select * from am_coloring_configuration)';
  EXECUTE immediate 'CREATE TABLE am_coloring_profiles_bk as (select * from am_coloring_profiles)';
  EXECUTE immediate 'CREATE TABLE am_coloring_rule_config_bk as (select * from am_coloring_rule_configuration)';
  EXECUTE immediate 'truncate table am_grouping_columns';
  EXECUTE immediate 'truncate table am_filtering_columns';
  EXECUTE immediate 'truncate table am_columnset_main_columns';
  EXECUTE immediate 'truncate table am_columnset_pivot_columns';
  EXECUTE immediate 'truncate table am_columnset_group_columns';
  EXECUTE immediate 'truncate table am_columnset_breakdown_columns';
  EXECUTE immediate 'truncate table am_unit_denominator_column';
  EXECUTE immediate 'truncate table am_columnset_configuration';
  EXECUTE immediate 'truncate table am_columnset_profiles';
  EXECUTE immediate 'truncate table am_columnset_widgets';
  EXECUTE immediate 'truncate table am_columnset_actions';
  EXECUTE immediate 'truncate table am_unit_configuration';
  EXECUTE immediate 'truncate table am_unit_profiles';
  EXECUTE immediate 'truncate table am_grouping_configuration';
  EXECUTE immediate 'truncate table am_grouping_profiles';
  EXECUTE immediate 'truncate table am_filtering_configuration';
  EXECUTE immediate 'truncate table am_filtering_profiles';
  EXECUTE immediate 'truncate table am_coloring_configuration';
  EXECUTE immediate 'truncate table am_coloring_profiles';
  EXECUTE immediate 'truncate table am_coloring_rule_configuration';

EXCEPTION
WHEN OTHERS THEN
  NULL;
END rename_pws_items_columns;
/

begin 
	rename_pws_items_columns;
end;
/

DROP PROCEDURE rename_pws_items_columns
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-387866' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-387866-1.sql */
/* Start of the SQL statements from file:CAL-389341-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-389341',1,CURRENT_TIMESTAMP,'started')
/

update quartz_sched_task_attr sta set sta.attr_name = 'Save Results' where sta.attr_name = 'Save Results ? ' and exists (select NULL from quartz_sched_task st where st.task_id = sta.task_id and st.task_type = 'ERS_ANALYSIS')
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-389341' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-389341-1.sql */
/* Start of the SQL statements from file:CAL-380148-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('middleofficeam','CAL-380148',1,CURRENT_TIMESTAMP,'started')
/

update product_desc set und_security_id = product_id where product_type = 'UnitizedFund' and und_security_id = 0
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-380148' and version=1 and module='middleofficeam'
/

/* End of the SQL statements from file:CAL-380148-1.sql */
/* Start of the SQL statements from file:COLT-12800-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('collateral','COLT-12800',1,CURRENT_TIMESTAMP,'started')
/

DECLARE        
        v_rows_exists number := 0;
		v_table_exists number := 0;
 
BEGIN	
		select count(*) into v_table_exists from user_tables where table_name = 'COLLATERAL_CONFIG_FIELD_DUMMY';
		
		if (v_table_exists > 0) then
		execute immediate 'drop table COLLATERAL_CONFIG_FIELD_DUMMY';
		end if;
		
		select count(*) into v_rows_exists from collateral_config_field where mcc_field='ACADIA_AUTO_DISPUTE';
        
		if (v_rows_exists > 0) then
		
				execute immediate 'create table COLLATERAL_CONFIG_FIELD_DUMMY AS (
				select * from collateral_config_field where mcc_field=''ACADIA_AUTO_DISPUTE'')';
				
				execute immediate 'insert into collateral_config_field (mcc_id, mcc_field, mcc_value) (
				select distinct mcc_id,''ACADIA_CALL_ABOVE_TOLERANCE'' Col1, ''false'' col2 from COLLATERAL_CONFIG_FIELD_DUMMY where mcc_field in (''ACADIA_AUTO_DISPUTE'') and lower(mcc_value)=''false'')';
				
				execute immediate 'insert into collateral_config_field (mcc_id, mcc_field, mcc_value) (
				select distinct mcc_id,''ACADIA_CALL_ABOVE_TOLERANCE'' Col1, ''true'' col2 from COLLATERAL_CONFIG_FIELD_DUMMY where mcc_field in (''ACADIA_AUTO_DISPUTE'') and lower(mcc_value)=''true'')';
				
				execute immediate 'insert into collateral_config_field (mcc_id, mcc_field, mcc_value) (
				select distinct mcc_id,''ACADIA_CALL_NOTIFICATION_TIME'' Col1, ''No STP'' col2 from COLLATERAL_CONFIG_FIELD_DUMMY where mcc_field in (''ACADIA_AUTO_DISPUTE''))';
		
		end if;
		select count(*) into v_table_exists from user_tables where table_name = 'COLLATERAL_CONFIG_FIELD_DUMMY';
		
		if (v_table_exists > 0) then
		execute immediate 'drop table COLLATERAL_CONFIG_FIELD_DUMMY';
		end if;
END;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='COLT-12800' and version=1 and module='collateral'
/

/* End of the SQL statements from file:COLT-12800-1.sql */
/* Start of the SQL statements from file:COLT-13175-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('collateral','COLT-13175',1,CURRENT_TIMESTAMP,'started')
/

update collateral_config set LE_THRESH_APPL = 'IA + MTM',PO_THRESH_APPL = 'IA + MTM' where PO_THRESH_APPL is null and LE_THRESH_APPL is null
/

update exposure_group_definition set LE_THRESH_APPL = 'IA + MTM',PO_THRESH_APPL = 'IA + MTM' where PO_THRESH_APPL is null and LE_THRESH_APPL is null
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='COLT-13175' and version=1 and module='collateral'
/

/* End of the SQL statements from file:COLT-13175-1.sql */
/* Post Upgrade - Start */
drop procedure add_column_if_not_exists
/

drop procedure drop_column_if_exists
/

drop procedure add_domain_values
/

drop procedure drop_fk_on_table
/

drop procedure drop_pk_if_exists
/

drop procedure drop_uk_if_exists
/

drop procedure drop_procedure_if_exists
/

drop procedure drop_uq_on_table
/

drop procedure drop_unique_if_exists
/

drop procedure drop_table_if_exists
/

drop procedure add_pk_if_not_exists
/

drop procedure run_query_if_tables_exist
/

drop type list_of_names_t
/

drop procedure rename_column_if_exists
/

/* Post Upgrade - End */
