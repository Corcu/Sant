DELETE FROM CALYPSO.ENGINE_CONFIG WHERE ENGINE_NAME='MatchableBuilderEngine';
Insert into CALYPSO.ENGINE_CONFIG (ENGINE_ID,ENGINE_NAME,ENGINE_COMMENT,VERSION_NUM) values ((select max(ENGINE_ID)+1 from CALYPSO.ENGINE_CONFIG),'MatchableBuilderEngine','Starts and stops MatchableBuilderEngine','500');

-- Cargando engine params
DELETE FROM ENGINE_PARAM WHERE ENGINE_NAME='MatchableBuilderEngine';
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MatchableBuilderEngine','DISPLAY_NAME','MatchableBuilderEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MatchableBuilderEngine','CLASS_NAME','com.calypso.engine.matching.MatchableBuilderEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MatchableBuilderEngine','STARTUP','true');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MatchableBuilderEngine','INSTANCE_NAME','gen_engineserver');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MatchableBuilderEngine','EVENT_POOL_POLICY','FIFO');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MatchableBuilderEngine','PricingEnv','OFFICIAL');

DELETE FROM PS_EVENT_CONFIG WHERE ENGINE_NAME='MatchableBuilderEngine';
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventProcessMessage','MatchableBuilderEngine');
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventProcessTransfer','MatchableBuilderEngine');
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventTransfer','MatchableBuilderEngine');
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventMessage','MatchableBuilderEngine');


DELETE FROM CALYPSO.ENGINE_CONFIG WHERE ENGINE_NAME='MatchingEngine';
Insert into CALYPSO.ENGINE_CONFIG (ENGINE_ID,ENGINE_NAME,ENGINE_COMMENT,VERSION_NUM) values ((select max(ENGINE_ID)+1 from CALYPSO.ENGINE_CONFIG),'MatchingEngine','Starts and stops MatchingEngine','500');


-- Cargando engine params
DELETE FROM ENGINE_PARAM WHERE ENGINE_NAME='MatchingEngine';
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MatchingEngine','DISPLAY_NAME','MatchingEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MatchingEngine','CLASS_NAME','com.calypso.engine.matching.MatchingEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MatchingEngine','STARTUP','true');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MatchingEngine','INSTANCE_NAME','gen_engineserver');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MatchingEngine','EVENT_POOL_POLICY','FIFO');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MatchingEngine','PricingEnv','OFFICIAL');

DELETE FROM PS_EVENT_CONFIG WHERE ENGINE_NAME='MatchingEngine';
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventDomainChange','MatchingEngine');
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventMatchable','MatchingEngine');
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventMatchingGroup','MatchingEngine');



DELETE FROM PS_EVENT_FILTER WHERE ENGINE_NAME='MatchingEngine';
Insert into CALYPSO.PS_EVENT_FILTER (EVENT_CONFIG_NAME,ENGINE_NAME,EVENT_FILTER) values ('Back-Office','MatchingEngine','MatchingEventFilter');

