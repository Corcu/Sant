WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK;

declare
    v_count integer := 0;
begin
    select count(*) into v_count from calypso_info where major_version = 16 and minor_version = 1 and patch_version = '85';
    
    IF (v_count=0) THEN
       RAISE_APPLICATION_ERROR(-20000, 'Test failed'); 
    END IF;
END;
/

WHENEVER SQLERROR CONTINUE NONE;

set define off;



-- Remove new PricerMeasures
DELETE FROM pricer_measure WHERE measure_name= 'ACCRUAL_REAL_TD';
DELETE FROM pricer_measure WHERE measure_name= 'ACCRUAL_REAL_TD_PAY';
DELETE FROM pricer_measure WHERE measure_name= 'ACCRUAL_REAL_TD_REC';
DELETE FROM pricer_measure WHERE measure_name= 'ACCRUAL_TERM_REAL';
DELETE FROM pricer_measure WHERE measure_name= 'ACCRUAL_TERM_REAL_PAY';
DELETE FROM pricer_measure WHERE measure_name= 'ACCRUAL_TERM_REAL_REC';
DELETE FROM pricer_measure WHERE measure_name= 'CA_PV_NET_COST';
DELETE FROM pricer_measure WHERE measure_name= 'CA_PV_NET_COST_AM';
DELETE FROM pricer_measure WHERE measure_name= 'DIRTY_PRICE_SCALED';
DELETE FROM pricer_measure WHERE measure_name= 'FX_PL';
DELETE FROM pricer_measure WHERE measure_name= 'MTM_BASE';
DELETE FROM pricer_measure WHERE measure_name= 'MTM_CCY';
DELETE FROM pricer_measure WHERE measure_name= 'PM_SCHEDULE';
DELETE FROM pricer_measure WHERE measure_name= 'PM_SIMM';
DELETE FROM pricer_measure WHERE measure_name= 'PV01_DISC';
DELETE FROM pricer_measure WHERE measure_name= 'SEC_FIN_DELAYED_COUPON';
DELETE FROM pricer_measure WHERE measure_name= 'SEC_FIN_FUTURE_PRINCIPAL_FLOWS';
DELETE FROM pricer_measure WHERE measure_name= 'SEC_FIN_LIABILITY_ACCRUAL';
DELETE FROM pricer_measure WHERE measure_name= 'SEC_FIN_LIABILITY_PRINCIPAL';
DELETE FROM pricer_measure WHERE measure_name= 'TAX_LN_AM';
DELETE FROM pricer_measure WHERE measure_name= 'TAX_LN_REMAIN';
DELETE FROM pricer_measure WHERE measure_name= 'TET_COLLATERAL_VALUE';
DELETE FROM pricer_measure WHERE measure_name= 'TET_EXPOSURE_AMOUNT';
DELETE FROM pricer_measure WHERE measure_name= 'TRADE_DIRTY_PRICE_SCALED';


--Remove Collateral Context Product Definition Pricer Measures
DELETE FROM collateral_product_definition WHERE data='PRICE' AND data_type='Measure' AND product_type='Collateral';
DELETE FROM collateral_product_definition WHERE data='PRICE' AND data_type='Measure' AND product_type='Repo';
DELETE FROM collateral_product_definition WHERE data='PRICE' AND data_type='Measure' AND product_type='SecLending';

DELETE FROM collateral_product_definition WHERE data='SEC_FIN_SECURITY_ACCRUAL' AND data_type='Measure' AND product_type='Collateral';
DELETE FROM collateral_product_definition WHERE data='SEC_FIN_SECURITY_ACCRUAL' AND data_type='Measure' AND product_type='Repo';
DELETE FROM collateral_product_definition WHERE data='SEC_FIN_SECURITY_ACCRUAL' AND data_type='Measure' AND product_type='SecLending';

DELETE FROM collateral_product_definition WHERE data='SEC_FIN_SECURITY_VALUE' AND data_type='Measure' AND product_type='Collateral';
DELETE FROM collateral_product_definition WHERE data='SEC_FIN_SECURITY_VALUE' AND data_type='Measure' AND product_type='Repo';
DELETE FROM collateral_product_definition WHERE data='SEC_FIN_SECURITY_VALUE' AND data_type='Measure' AND product_type='SecLending';

DELETE FROM collateral_product_definition WHERE data='SEC_FIN_SECURITY_CLEAN_VALUE' AND data_type='Measure' AND product_type='Collateral';
DELETE FROM collateral_product_definition WHERE data='SEC_FIN_SECURITY_CLEAN_VALUE' AND data_type='Measure' AND product_type='Repo';
DELETE FROM collateral_product_definition WHERE data='SEC_FIN_SECURITY_CLEAN_VALUE' AND data_type='Measure' AND product_type='SecLending';

DELETE FROM collateral_product_definition WHERE data='SEC_FIN_LIABILITY' AND data_type='Measure' AND product_type='Repo';
DELETE FROM collateral_product_definition WHERE data='SEC_FIN_LIABILITY' AND data_type='Measure' AND product_type='SecLending';

DELETE FROM collateral_product_definition WHERE data='DIRTY_PRICE' AND data_type='Measure' AND product_type='Repo';
DELETE FROM collateral_product_definition WHERE data='DIRTY_PRICE' AND data_type='Measure' AND product_type='SecLending';

DELETE FROM collateral_product_definition WHERE data='ACCRUAL' AND data_type='Measure' AND product_type='Repo';
DELETE FROM collateral_product_definition WHERE data='ACCRUAL' AND data_type='Measure' AND product_type='SecLending';

-- Remove allocation validator
DELETE FROM allocation_validator WHERE collateral_context_id=1 AND dto_id=1 AND name='AllocationPriceValidator';
DELETE FROM allocation_validator WHERE collateral_context_id=1 AND dto_id=3 AND name='EligibilityAllocationValidator';

--Remove LocaleForBondQuotes DV
DELETE FROM domain_values WHERE name='LocaleForBondQuotes' AND value='English';


-- Should update 2 rows
UPDATE allocation_validator_kv set value = 'SOFT' WHERE name = 'Warning-Type';

-- Remove new ClassAuthModes
DELETE FROM domain_values where name = 'classAuthMode' AND value in ('CollateralInventoryPool', 'CollateralSource', 'CollateralConfig', 'MarginCallCreditRatingConfiguration');

-- Remove MCC Additional Fields
DELETE FROM domain_values where name = 'mccAdditionalField' AND value in ('RISK_CCY', 'SLM');
DELETE FROM domain_values where name = 'domainName' AND value = 'mccAdditionalField.SLM';
DELETE FROM domain_values where name = 'mccAdditionalField.SLM';

-- Remove LocaleForBondQuotes in English
DELETE FROM domain_values where name = 'LocaleForBondQuotes' AND value = 'English';

-- Remove new Engines
delete from ps_event_filter where engine_name in ('DataExportServiceEngine','KPIEngine','UpdateManagerEngine','DataUploaderEngine','FIXEngine','MatchingEngine','MatchableBuilderEngine');
delete from ps_event_config where engine_name in ('DataExportServiceEngine','KPIEngine','UpdateManagerEngine','DataUploaderEngine','FIXEngine','MatchingEngine','MatchableBuilderEngine');
delete from engine_param where engine_name in ('DataExportServiceEngine','KPIEngine','UpdateManagerEngine','DataUploaderEngine','FIXEngine','MatchingEngine','MatchableBuilderEngine');
delete from engine_config where engine_name in ('DataExportServiceEngine','KPIEngine','UpdateManagerEngine','DataUploaderEngine','FIXEngine','MatchingEngine','MatchableBuilderEngine');
