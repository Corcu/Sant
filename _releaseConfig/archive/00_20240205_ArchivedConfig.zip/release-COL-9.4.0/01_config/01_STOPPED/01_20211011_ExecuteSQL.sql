WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK;

declare
    v_count integer := 0;
begin
    select count(*) into v_count from calypso_info where major_version = 16 and minor_version = 1 and patch_version = '71';
    
    IF (v_count=0) THEN
       RAISE_APPLICATION_ERROR(-20000, 'Test failed'); 
    END IF;
END;
/

WHENEVER SQLERROR CONTINUE NONE;

set define off;


/* Applying Schema Statements - start */


    ALTER TABLE iso_20022_external_code ADD (jurisdiction varchar2 (255)  NULL,code_type varchar2 (255)  NULL)
/

    CREATE TABLE mifid2_transaction_event (
        event_id numeric  NOT NULL,
         trn numeric  NOT NULL,
         trade_id numeric  NOT NULL,
         status varchar2 (4) NOT NULL,
         creation_date timestamp  NOT NULL,
         sent_date timestamp  NULL,
         venue_trans_id varchar2 (255) NULL,
         executing_entity_id varchar2 (255) NULL,
         submitting_entity_id varchar2 (255) NOT NULL,
         invest_firm_ind numeric  NULL,
         buyer_id varchar2 (255) NULL,
         buyer_id_type varchar2 (1) NULL,
         buyer_country varchar2 (2) NULL,
         buyer_dm_id varchar2 (255) NULL,
         buyer_dm_id_type varchar2 (1) NULL,
         seller_id varchar2 (255) NULL,
         seller_id_type varchar2 (1) NULL,
         seller_country varchar2 (2) NULL,
         seller_dm_id varchar2 (255) NULL,
         seller_dm_id_type varchar2 (1) NULL,
         order_transmission_ind varchar2 (1) NULL,
         buyer_transmitter_id varchar2 (255) NULL,
         seller_transmitter_id varchar2 (255) NULL,
         trading_date_time timestamp  NOT NULL,
         trading_capacity varchar2 (4) NULL,
         quantity float  NULL,
         quantity_type varchar2 (20) NULL,
         quantity_ccy varchar2 (3) NULL,
         derivative_notional_change varchar2 (4) NULL,
         price float  NULL,
         price_type varchar2 (11) NULL,
         price_ccy varchar2 (3) NULL,
         net_amount float  NULL,
         venue varchar2 (4) NULL,
         country_of_branch varchar2 (2) NULL,
         up_front_payment float  NULL,
         up_front_payment_ccy varchar2 (3) NULL,
         complex_trade_component_id varchar2 (255) NULL,
         instrument_id varchar2 (12) NULL,
         instrument_id_type varchar2 (15) NULL,
         instrument_name varchar2 (255) NULL,
         instrument_classification varchar2 (255) NULL,
         notional_ccy1 varchar2 (3) NULL,
         notional_ccy2_type varchar2 (6) NULL,
         notional_ccy2 varchar2 (3) NULL,
         price_multiplier float  NULL,
         uv_instrument_classification varchar2 (512) NULL,
         underlying_instrument_id varchar2 (255) NULL,
         uv_index_classification varchar2 (255) NULL,
         underlying_index_id varchar2 (512) NULL,
         underlying_index_name varchar2 (255) NULL,
         underlying_index_term varchar2 (25) NULL,
         option_type varchar2 (12) NULL,
         strike_price float  NULL,
         strike_price_type varchar2 (12) NULL,
         strike_price_ccy varchar2 (3) NULL,
         option_style varchar2 (25) NULL,
         maturity_date timestamp  NULL,
         expiry_date timestamp  NULL,
         delivery_type varchar2 (4) NULL,
         invest_decision_name varchar2 (255) NULL,
         firm_execution_name varchar2 (255) NULL,
         waiver_ind varchar2 (4) NULL,
         short_selling_ind varchar2 (4) NULL,
         otc_post_trade_ind varchar2 (255) NULL,
         commodity_derivative_ind varchar2 (1) NULL,
         sft_ind varchar2 (1) NULL 
    ) 
/

    CREATE TABLE mifid2_party_national_id (
        event_id numeric  NOT NULL,
         party_id varchar2 (255) NOT NULL,
         party_id_sub_type varchar2 (6) NULL,
         party_first_name varchar2 (255) NULL,
         party_last_name varchar2 (255) NULL,
         party_dob timestamp  NULL 
    ) 
/

    CREATE TABLE mifid2_trader (
        trader_id numeric  NOT NULL,
         trader_short_name varchar2 (128) NOT NULL,
         trader_first_name varchar2 (255) NULL,
         trader_last_name varchar2 (255) NULL,
         trader_dob timestamp  NULL,
         trader_country varchar2 (2) NULL,
         trader_country_of_branch varchar2 (2) NULL,
         trader_nat_id_type varchar2 (255) NULL,
         trader_nat_id varchar2 (255) NULL 
    ) 
/

    CREATE TABLE mifid2_product_eligibility (
        product_eligibility_id numeric  NOT NULL,
         legal_entity_id numeric  NOT NULL,
         processing_org_id numeric  NOT NULL,
         product_type varchar2 (32) NOT NULL,
         product_subtype varchar2 (32) NOT NULL,
         instrument_id numeric  NULL,
         leg1_currency varchar2 (3) NULL,
         leg1_rate_index varchar2 (128) NULL,
         leg2_currency varchar2 (3) NULL,
         leg2_rate_index varchar2 (128) NULL,
         underlying_id numeric  NULL,
         obligation_id numeric  NULL 
    ) 
/

    CREATE TABLE ers_hedge_portfolio_report (
        value_date timestamp  NOT NULL,
         account varchar2 (32) NULL,
         currency varchar2 (32) NULL,
         risk_type varchar2 (32) NULL,
         maturity varchar2 (32) NULL,
         value_type varchar2 (32) NULL,
         bucket_sensitivity varchar2 (32) NULL,
         value float  NULL 
    ) 
/

    CREATE TABLE ers_liquidity_table (
        value_date timestamp  NOT NULL,
         product_type varchar2 (32) NULL,
         currency varchar2 (32) NULL,
         maturity varchar2 (32) NULL,
         net_position_size float  NULL,
         liquidity_factor float  NULL,
         bid_ask_spread float  NULL,
         liquidity_set_id numeric  NULL 
    ) 
/

    ALTER TABLE collateral_config ADD (po_haircut_ineligibility numeric NULL,le_haircut_ineligibility numeric NULL)
/

    ALTER TABLE exposure_group_definition ADD (po_haircut_ineligibility numeric NULL,le_haircut_ineligibility numeric NULL)
/

    ALTER TABLE margin_call_entries ADD (is_ineligible_collateral numeric NULL,is_concentration_breach numeric NULL,total_collateral_pre_haircut float DEFAULT 0 NULL)
/

    ALTER TABLE pending_margin_call_entries ADD (is_ineligible_collateral numeric NULL,is_concentration_breach numeric NULL,total_collateral_pre_haircut float DEFAULT 0 NULL)
/

    ALTER TABLE mrgcall_entries_hist ADD (is_ineligible_collateral numeric NULL,is_concentration_breach numeric NULL,total_collateral_pre_haircut float DEFAULT 0 NULL)
/

    ALTER TABLE concentration_limit ADD collateral_value varchar2 (64)  NULL
/

    ALTER TABLE collateral_acadia_definition ADD is_coll_tolerance numeric DEFAULT 0 NULL
/

    CREATE TABLE ib_reconciliation_master (
        reconciliation_id numeric  NOT NULL,
         trade_id numeric  NOT NULL,
         mcc_id numeric  NULL,
         create_date timestamp  NULL,
         status varchar2 (64) NULL,
         action varchar2 (64) NULL,
         reference_source varchar2 (32) NULL,
         receiving_party varchar2 (64) NULL,
         agreement_type varchar2 (64) NULL,
         call_type varchar2 (64) NULL,
         delivery_type varchar2 (64) NULL,
         currency varchar2 (3) NULL,
         start_date timestamp  NULL,
         end_date timestamp  NULL,
         reference_trade_id varchar2 (64) NULL,
         reference_mcc_id varchar2 (64) NULL,
         last_update timestamp  NULL 
    ) 
/

    CREATE TABLE ib_reconciliation_details (
        reconciliation_id numeric  NOT NULL,
         reference_source varchar2 (32) NOT NULL,
         payment_amt float  DEFAULT 0 NULL,
         value_date timestamp  NULL,
         contractual_date timestamp  NULL,
         collateral_amt float  DEFAULT 0 NULL,
         interest_amt float  DEFAULT 0 NULL,
         rollover_amt float  DEFAULT 0 NULL,
         benc_hmark varchar2 (64) NULL,
         calculation_type varchar2 (32) NULL,
         day_convention varchar2 (32) NULL,
         is_tax_exemption varchar2 (32) NULL,
         tax_with_holding varchar2 (32) NULL,
         attributes blob  NULL 
    ) 
/

    ALTER TABLE matching_criteria ADD version_num numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE cm_calculation_summary ADD request_type varchar2 (64)  DEFAULT 'STANDARD' NULL
/

    ALTER TABLE cm_account ADD threshold_group_id varchar2 (64)  NULL
/

    ALTER TABLE cm_im_th_monitoring_result ADD threshold_group_id varchar2 (64)  NULL
/

    CREATE TABLE cm_im_th_mon_result_hist (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         tree_id varchar2 (64) NULL,
         account_id varchar2 (64) NULL,
         calculation_set_id varchar2 (64) NULL,
         direction varchar2 (255) NOT NULL,
         threshold_status varchar2 (255) NOT NULL,
         csa_status varchar2 (255) NOT NULL,
         currency varchar2 (3) NOT NULL,
         valuation_date numeric  NOT NULL,
         threshold float  NOT NULL,
         threshold_utilization float  NOT NULL,
         totalim float  NOT NULL,
         csa_trigger float  NOT NULL,
         threshold_group_id varchar2 (64) NULL 
    ) 
/

    CREATE TABLE cm_im_th_mon_result_temp (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         tree_id varchar2 (64) NULL,
         account_id varchar2 (64) NULL,
         calculation_set_id varchar2 (64) NULL,
         direction varchar2 (255) NOT NULL,
         threshold_status varchar2 (255) NOT NULL,
         csa_status varchar2 (255) NOT NULL,
         currency varchar2 (3) NOT NULL,
         valuation_date numeric  NOT NULL,
         threshold float  NOT NULL,
         threshold_utilization float  NOT NULL,
         totalim float  NOT NULL,
         csa_trigger float  NOT NULL,
         threshold_group_id varchar2 (64) NULL 
    ) 
/

    CREATE TABLE cm_im_th_result_errors (
        im_th_monitoring_result_id varchar2 (64) NOT NULL,
         errors varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_im_th_result_errors_hist (
        im_th_monitoring_result_id varchar2 (64) NOT NULL,
         errors varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_im_th_result_errors_temp (
        im_th_monitoring_result_id varchar2 (64) NOT NULL,
         errors varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_threshold_group (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         name varchar2 (255) NOT NULL,
         currency varchar2 (3) DEFAULT 'XXX' NOT NULL,
         post_threshold float  DEFAULT 0 NOT NULL,
         collect_threshold float  DEFAULT 0 NOT NULL,
         trigger_percentage float  DEFAULT 0 NOT NULL 
    ) 
/

    ALTER TABLE cm_simm_calc_request ADD request_type varchar2 (64)  NULL
/

    ALTER TABLE cm_rf_trade ADD request_type varchar2 (64)  DEFAULT 'STANDARD' NULL
/

    CREATE TABLE cm_rf_trade_attrib_link (
        rf_trade_id varchar2 (36) NOT NULL,
         rf_trade_attribs_id varchar2 (36) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_trade_attribs (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         name varchar2 (255) NOT NULL,
         value varchar2 (255) NOT NULL 
    ) 
/

    ALTER TABLE cm_calc_request_simm ADD request_type varchar2 (64)  NULL
/

    ALTER TABLE cm_account_calc_request_simm ADD request_type varchar2 (64)  NULL
/

    CREATE TABLE cm_csv_column_config (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         file_format varchar2 (255) NOT NULL,
         name varchar2 (255) NOT NULL,
         value varchar2 (255) NULL,
         type varchar2 (255) NOT NULL 
    ) 
/

    ALTER TABLE acc_statement_cfg ADD interim_generation numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE portfolio_swap_contract ADD date_calc_method numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE portfolio_swap_contract_fund ADD (compound_freq_style varchar2 (32)  DEFAULT 'Original' NOT NULL,obs_shift numeric DEFAULT 0 NOT NULL,rounding_decimals numeric DEFAULT 0 NOT NULL,rounding_method varchar2 (64)  NULL,cmp_cutoff_days numeric DEFAULT 0 NOT NULL,cmp_cutoff_bus numeric DEFAULT 0 NOT NULL,cmp_cutoff_holiday varchar2 (100)  NULL,diff_resetdate_cpn numeric DEFAULT 0 NOT NULL,spread_calc_method varchar2 (100)  DEFAULT 'SPRD_ADDITIVE' NULL)
/

    ALTER TABLE pfs_lifecycle ADD term_ro_avg_price_b numeric DEFAULT 0 NULL
/

    CREATE TABLE rate_fallback_data (
        currency_code varchar2 (3) NOT NULL,
         rate_index_code varchar2 (32) NOT NULL,
         rate_index_tenor numeric  NOT NULL,
         effective_date timestamp  NOT NULL,
         rfr_spread float  NOT NULL 
    ) 
/

    ALTER TABLE inv_cash_movement ADD (daily_bucket0 decimal (38,15)  NULL,daily_bucket1 decimal (38,15)  NULL,daily_bucket2 decimal (38,15)  NULL,daily_bucket3 decimal (38,15)  NULL,daily_bucket4 decimal (38,15)  NULL,daily_bucket5 decimal (38,15)  NULL,daily_bucket6 decimal (38,15)  NULL,daily_bucket7 decimal (38,15)  NULL,daily_bucket8 decimal (38,15)  NULL,daily_bucket9 decimal (38,15)  NULL)
/

    ALTER TABLE inv_cash_balance ADD (total_bucket0 decimal (38,15)  NULL,total_bucket1 decimal (38,15)  NULL,total_bucket2 decimal (38,15)  NULL,total_bucket3 decimal (38,15)  NULL,total_bucket4 decimal (38,15)  NULL,total_bucket5 decimal (38,15)  NULL,total_bucket6 decimal (38,15)  NULL,total_bucket7 decimal (38,15)  NULL,total_bucket8 decimal (38,15)  NULL,total_bucket9 decimal (38,15)  NULL)
/

    ALTER TABLE inv_cust_cash_movement ADD (daily_bucket0 decimal (38,15)  NULL,daily_bucket1 decimal (38,15)  NULL,daily_bucket2 decimal (38,15)  NULL,daily_bucket3 decimal (38,15)  NULL,daily_bucket4 decimal (38,15)  NULL,daily_bucket5 decimal (38,15)  NULL,daily_bucket6 decimal (38,15)  NULL,daily_bucket7 decimal (38,15)  NULL,daily_bucket8 decimal (38,15)  NULL,daily_bucket9 decimal (38,15)  NULL)
/

    ALTER TABLE inv_cust_cash_balance ADD (total_bucket0 decimal (38,15)  NULL,total_bucket1 decimal (38,15)  NULL,total_bucket2 decimal (38,15)  NULL,total_bucket3 decimal (38,15)  NULL,total_bucket4 decimal (38,15)  NULL,total_bucket5 decimal (38,15)  NULL,total_bucket6 decimal (38,15)  NULL,total_bucket7 decimal (38,15)  NULL,total_bucket8 decimal (38,15)  NULL,total_bucket9 decimal (38,15)  NULL)
/

    CREATE TABLE realized_pl_config (
        realized_pl_config_id numeric  NOT NULL,
         book_id numeric  NOT NULL,
         product_type varchar2 (32) NOT NULL,
         liq_config_id numeric  NOT NULL,
         pos_aggreg_config_id numeric  NULL,
         closing_trade_b numeric  DEFAULT 0 NOT NULL,
         version_num numeric  DEFAULT 0 NOT NULL 
    ) 
/

    ALTER TABLE product_bond ADD (current_coupon varchar2 (32)  NULL,effective_spread_b numeric NULL)
/

    ALTER TABLE fx_fixing_reset_dates ADD fx_reset2 numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE product_fx_swap ADD (swap_principal_rate float NULL,swap_quoting_rate float NULL)
/

    ALTER TABLE product_advance ADD fps_b numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE trade_role_alloc ADD fixed_amount float DEFAULT 0.0 NULL
/

    ALTER TABLE trd_rolealloc_hist ADD fixed_amount float DEFAULT 0.0 NULL
/

    ALTER TABLE vol_surf_und_cap ADD (compound_b numeric NULL,compound_freq varchar2 (12)  DEFAULT 'NON' NOT NULL,cmp_with_spread varchar2 (32)  DEFAULT 'NoCompound' NOT NULL,underlying_payment_offset numeric NULL,underlying_payment_busdayb numeric DEFAULT 1 NOT NULL)
/

    ALTER TABLE vol_surf_und_swpt ADD (compound_b numeric DEFAULT 0 NOT NULL,compound_freq varchar2 (12)  DEFAULT 'NON' NOT NULL,cmp_with_spread varchar2 (32)  DEFAULT 'NoCompound' NOT NULL,float_und_payment_offset numeric DEFAULT 0 NOT NULL,float_und_payment_busdayb numeric DEFAULT 1 NOT NULL,fixed_und_payment_offset numeric DEFAULT 0 NOT NULL,fixed_und_payment_busdayb numeric DEFAULT 1 NOT NULL)
/

    ALTER TABLE psp_interest_base_calc ADD (interest_amt_d float DEFAULT 0 NOT NULL,interest_amt float DEFAULT 0 NOT NULL)
/

    CREATE TABLE pkserver_processing_info_hist (
        trade_id numeric  NOT NULL,
         trade_version numeric  NOT NULL,
         processing_info_name varchar2 (128) NOT NULL,
         processing_info_value varchar2 (255) NULL,
         archived_date timestamp  NULL 
    ) 
/

    ALTER TABLE quartz_sched_task ADD access_permission numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE decsupp_order ADD (validity varchar2 (32)  DEFAULT 'GTC' NOT NULL,validity_date timestamp NULL,idle_quantity float NULL,version numeric DEFAULT 0 NOT NULL)
/

    ALTER TABLE decsupp_order_hist ADD (validity varchar2 (32)  DEFAULT 'GTC' NOT NULL,validity_date timestamp NULL,idle_quantity float NULL)
/

    ALTER TABLE payment_setup ADD setup_comment varchar2 (256)  NULL
/

    ALTER TABLE accounting_pl_config ADD fxbased_item_level numeric NULL
/

    ALTER TABLE accounting_pl_item ADD (bucket0 decimal (38,15)  NULL,bucket1 decimal (38,15)  NULL,bucket2 decimal (38,15)  NULL,bucket3 decimal (38,15)  NULL,bucket4 decimal (38,15)  NULL,bucket5 decimal (38,15)  NULL,bucket6 decimal (38,15)  NULL,bucket7 decimal (38,15)  NULL,bucket8 decimal (38,15)  NULL,bucket9 decimal (38,15)  NULL)
/

    ALTER TABLE accounting_pl_item_hist ADD (bucket0 decimal (38,15)  NULL,bucket1 decimal (38,15)  NULL,bucket2 decimal (38,15)  NULL,bucket3 decimal (38,15)  NULL,bucket4 decimal (38,15)  NULL,bucket5 decimal (38,15)  NULL,bucket6 decimal (38,15)  NULL,bucket7 decimal (38,15)  NULL,bucket8 decimal (38,15)  NULL,bucket9 decimal (38,15)  NULL)
/

    CREATE TABLE am_report_hierarchy (
        hierarchy_id numeric  DEFAULT 0 NOT NULL,
         hierarchy_name varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE am_report_tree_node (
        hierarchy_id numeric  DEFAULT 0 NOT NULL,
         node_id numeric  DEFAULT 0 NOT NULL,
         node_type varchar2 (8) NOT NULL,
         node_order numeric  DEFAULT 0 NOT NULL,
         parent_id numeric  DEFAULT 0 NOT NULL,
         report_title varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE ha_reconvention_processed (
        reconvention_id numeric  NOT NULL,
         trade_id numeric  NOT NULL,
         reconvention_key varchar2 (64) NOT NULL,
         reconvention_date timestamp  NOT NULL 
    ) 
/

    CREATE TABLE routed_order_mapping (
        route_id numeric  NOT NULL,
         routed_order_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE pros_yield_accretion (
        pros_yield_method varchar2 (64) NOT NULL,
         pricing_env varchar2 (64) NOT NULL,
         trade_id numeric  NOT NULL,
         period_date timestamp  NOT NULL,
         initial_credit_spread float  NOT NULL,
         initial_yield float  NOT NULL,
         reset_date timestamp  NOT NULL,
         period_eir float  NOT NULL,
         period_yield float  NOT NULL,
         dirty_price float  NOT NULL,
         clean_price float  NOT NULL,
         cum_accretion float  NOT NULL 
    ) 
/


/* Applying Schema Statements - end */



/* Applying xtra statements - start */



/* Applying xtra statements - end */



/* one time install statements - start */



/* one time install statements - end */

/* Pre Upgrade - Start */
CREATE OR REPLACE PROCEDURE add_column_if_not_exists
    (tab_name IN user_tab_columns.table_name%TYPE,
     col_name IN user_tab_columns.column_name%TYPE,
     data_type IN varchar2)
AS
    x number;
BEGIN
    begin
    select count(*) INTO x FROM user_tab_columns WHERE table_name=UPPER(tab_name) and column_name=upper(col_name);
    exception
        when NO_DATA_FOUND THEN
        x:=0;
        when others then
        null;
    end;
    IF x = 0 THEN
        EXECUTE IMMEDIATE 'alter table ' || tab_name || ' add '||col_name||' '||data_type;
    END IF;
END;
/

CREATE OR REPLACE PROCEDURE drop_function ( proc_name IN user_tab_columns.table_name%TYPE) AS
 x number;
BEGIN
   BEGIN
   SELECT count(*) into x FROM user_objects WHERE object_name=UPPER(proc_name) and object_type= 'FUNCTION';
   exception
        when NO_DATA_FOUND THEN
        x:=0;
        when others then
        null;
    end;
    IF x > 0 THEN
       EXECUTE IMMEDIATE 'drop function '|| proc_name;
    END IF;
END drop_function;
/

CREATE OR REPLACE PROCEDURE drop_column_if_exists
    (tab_name IN user_tab_columns.table_name%TYPE,
     col_name IN user_tab_columns.column_name%TYPE)
AS
    x number;
BEGIN
    begin
    select count(*) INTO x FROM user_tab_columns WHERE table_name=UPPER(tab_name) and column_name=upper(col_name);
    exception
        when NO_DATA_FOUND THEN
        x:=0;
        when others then
        null;
    end;
    IF x > 0 THEN
        EXECUTE IMMEDIATE 'alter table ' || tab_name || ' drop column '||col_name;
    END IF;
END;
/

CREATE OR REPLACE PROCEDURE add_domain_values (dname IN varchar2, dvalue in varchar2, ddescription in varchar2) AS
x number :=0 ;
BEGIN
   BEGIN
   SELECT count(*) INTO x FROM domain_values WHERE name= dname and value= dvalue;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:=0;
      WHEN others THEN
         null;
    END;
        if x = 1 then
                execute immediate 'delete from domain_values where name='||chr(39)||dname||chr(39)||' and value ='||chr(39)||dvalue||chr(39);
                execute immediate 'insert into domain_values ( name, value, description )
                VALUES ('||chr(39)||dname||chr(39)||','||chr(39)||dvalue||chr(39)||','||chr(39)||ddescription||chr(39)||')';
        elsif x=0 THEN
	        execute immediate 'insert into domain_values ( name, value, description ) 
                VALUES ('||chr(39)||dname||chr(39)||','||chr(39)||dvalue||chr(39)||','||chr(39)||ddescription||chr(39)||')';
    END IF;
END add_domain_values;
/

CREATE OR REPLACE PROCEDURE delete_domain_values (dname IN varchar2, dvalue in varchar2) AS
x number :=0 ;
BEGIN
   BEGIN
   SELECT count(*) INTO x FROM domain_values WHERE name= dname and value= dvalue;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:=0;
      WHEN others THEN
         null;
    END;
        if x = 1 then
                execute immediate 'delete from domain_values where name='||chr(39)||dname||chr(39)||' and value ='||chr(39)||dvalue||chr(39);
        
    END IF;
END delete_domain_values;
/

CREATE OR REPLACE PROCEDURE drop_fk_on_table (tab_name IN varchar2) AS
BEGIN
   DECLARE cursor c1 IS 
      SELECT table_name, constraint_name FROM user_constraints WHERE constraint_type = 'R' AND table_name=UPPER(tab_name);
   v_sql varchar2(128);
   BEGIN
      FOR c1_rec IN c1 LOOP 
         v_sql := 'ALTER TABLE '||c1_rec.table_name||' DROP CONSTRAINT '||c1_rec.constraint_name;
         EXECUTE IMMEDIATE v_sql;
      END LOOP;
   END;
END;
/

CREATE OR REPLACE PROCEDURE drop_pk_if_exists (tab_name IN varchar2) AS
x number :=0 ;
BEGIN
   BEGIN
   SELECT count(*) INTO x FROM user_constraints WHERE table_name=UPPER(tab_name) and constraint_type= 'P';
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:=0;
      WHEN others THEN
         null;
    END;
    IF x > 0 THEN
       EXECUTE IMMEDIATE 'ALTER TABLE ' ||tab_name||' DROP PRIMARY KEY DROP INDEX';
    END IF;
END drop_pk_if_exists;
/

CREATE OR REPLACE PROCEDURE drop_uk_if_exists (tab_name IN varchar2) AS
x varchar2(100) ;
BEGIN
   BEGIN
   SELECT  c.constraint_name INTO x FROM user_constraints c, user_tables t WHERE t.table_name=UPPER(tab_name) 
   and c.constraint_type= 'U' and t.table_name=c.table_name;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:='0';
      WHEN others THEN
         null;
    END;
    IF x != '0' THEN
       EXECUTE IMMEDIATE 'ALTER TABLE ' ||tab_name||' DROP constraint '||x;
    END IF;
END drop_uk_if_exists;
/

CREATE OR REPLACE PROCEDURE drop_procedure_if_exists

    (proc_name IN user_objects.object_name%TYPE)

AS

    x number;

BEGIN

    begin

    select count(*) INTO x FROM user_objects WHERE object_name=UPPER(proc_name) and object_type = 'PROCEDURE';

    exception

        when NO_DATA_FOUND THEN

        x:=0;

        when others then

        null;

    end;

    IF x > 0 THEN

        EXECUTE IMMEDIATE 'drop procedure ' || UPPER(proc_name);

    END IF;

END drop_procedure_if_exists;
/

CREATE OR REPLACE PROCEDURE drop_uq_on_table (tab_name IN varchar2) AS
BEGIN
   DECLARE cursor c1 IS 
      SELECT table_name, constraint_name FROM user_constraints WHERE constraint_type = 'U' AND table_name=UPPER(tab_name);
   v_sql varchar2(128);
   BEGIN
      FOR c1_rec IN c1 LOOP 
         v_sql := 'ALTER TABLE '||c1_rec.table_name||' DROP CONSTRAINT '||c1_rec.constraint_name;
         EXECUTE IMMEDIATE v_sql;
      END LOOP;
   END;
END;
/

CREATE OR REPLACE PROCEDURE drop_unique_if_exists (tab_name IN varchar2) AS
constraint_name varchar2(255);
BEGIN
   BEGIN
   SELECT constraint_name INTO constraint_name FROM user_constraints WHERE table_name=UPPER(tab_name) and constraint_type= 'U';
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         constraint_name := NULL;
      WHEN others THEN
         null;
    END;
    IF constraint_name IS NOT NULL THEN
       EXECUTE IMMEDIATE 'ALTER TABLE ' ||tab_name||' DROP CONSTRAINT ' || constraint_name || ' DROP INDEX';
    END IF;
END drop_unique_if_exists;
/

CREATE OR REPLACE PROCEDURE drop_table_if_exists
    (tab_name IN varchar2)
AS
    x number :=0 ;
BEGIN
begin
select count(*) INTO x FROM user_tables WHERE table_name=UPPER(tab_name) ;
exception
when NO_DATA_FOUND THEN
x:=0;
when others then null;
end;
IF x > 0 THEN
EXECUTE IMMEDIATE 'drop table ' ||tab_name;
END IF;
END drop_table_if_exists;
/

CREATE OR REPLACE PROCEDURE add_pk_if_not_exists (tab_name IN varchar2, pk_name in varchar2, c_name in varchar2) AS
x number :=0 ;
BEGIN
   BEGIN
   SELECT count(*) INTO x FROM user_constraints WHERE table_name=UPPER(tab_name) and constraint_type= 'P';
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:=0;
      WHEN others THEN
         null;
    END;
    IF x = 0 THEN
       EXECUTE IMMEDIATE 'ALTER TABLE ' ||tab_name||' add constraint '||pk_name||' primary key ('||c_name||')';
    END IF;
END add_pk_if_not_exists;
/

CREATE OR REPLACE
TYPE list_of_names_t IS  
   TABLE of VARCHAR2(100);
/

CREATE OR REPLACE
PROCEDURE run_query_if_tables_exist
    (tab_names IN list_of_names_t, query IN varchar2)
AS
    x number :=0 ;
    y number :=0 ;
BEGIN
	BEGIN
		select count(*) INTO x FROM table(tab_names);
		select count(*) INTO y FROM user_tables WHERE table_name in (select * from table(tab_names));
	END;
	IF x = y THEN
		EXECUTE IMMEDIATE query;
	END IF;
END run_query_if_tables_exist;
/

CREATE OR REPLACE PROCEDURE rename_column_if_exists
    (tab_name IN user_tab_columns.table_name%TYPE,
     col_name IN user_tab_columns.column_name%TYPE,
     new_col_name IN varchar2)
AS
    x number;
	y number;
BEGIN
    begin 
    select count(*) INTO x FROM user_tab_columns WHERE table_name=UPPER(tab_name) and column_name=upper(col_name);
    exception
        when NO_DATA_FOUND THEN
        x:=0;
        when others then
        null;
    end;
    IF x = 1 THEN
        EXECUTE IMMEDIATE 'alter table ' || tab_name || ' rename  column '||col_name||' to '||new_col_name;
    END IF;
END;
/

/* Pre Upgrade - End */
/* Start of the SQL statements from file:MGNC-2169-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-2169',1,CURRENT_TIMESTAMP,'started')
/

/*  Insert values from ers_liquidity_period to margin_liquidity_factor table*/
-- MANUAL MODIFICATION - Gives ERROR and No Data in Table
/*
INSERT INTO margin_liquidity_factor 
(product_type, 
 product_name, 
 threshold, 
 liquidity_period, 
 liquidity_set_id, 
 bidask_spread
)
SELECT 
product_type, 
product_name, 
threshold, 
liquidity_period, 
liquidity_set_id, 
bidask_spread 
FROM ers_liquidity_period
/
*/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-2169' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-2169-1.sql */
/* Start of the SQL statements from file:BOMSG-1008-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('bo-messaging-mx-cash','BOMSG-1008',1,CURRENT_TIMESTAMP,'started')
/

UPDATE domain_values SET description = '02' WHERE name='MX.BAH.Versions' and value='pacs.008.001.CHAPS'
/

UPDATE domain_values SET description = '02' WHERE name='MX.BAH.Versions' and value='pacs.009.001.CHAPS'
/

UPDATE domain_values SET description = '02' WHERE name='MX.BAH.Versions' and value='pacs.004.001.CHAPS'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='BOMSG-1008' and version=1 and module='bo-messaging-mx-cash'
/

/* End of the SQL statements from file:BOMSG-1008-1.sql */
/* Start of the SQL statements from file:BOMSG-1027-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('bo-messaging-mx-cash','BOMSG-1027',1,CURRENT_TIMESTAMP,'started')
/

UPDATE domain_values SET value = 'pacs.008.001.MEPS' WHERE name='SWIFT.Templates.GPI' and value='pacs.008.001.COV.MEPS'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='BOMSG-1027' and version=1 and module='bo-messaging-mx-cash'
/

/* End of the SQL statements from file:BOMSG-1027-1.sql */
/* Start of the SQL statements from file:BOMSG-1045-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('bo-messaging-mx-cash','BOMSG-1045',1,CURRENT_TIMESTAMP,'started')
/

UPDATE domain_values SET description = '03.ch.03' WHERE name='MX.Versions' and value='camt.029.001.SIX'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='BOMSG-1045' and version=1 and module='bo-messaging-mx-cash'
/

/* End of the SQL statements from file:BOMSG-1045-1.sql */
/* Start of the SQL statements from file:CAL-300507-4.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-300507',4,CURRENT_TIMESTAMP,'started')
/

create table tempccy as  
(select distinct trade.trade_id  as trade_id , trade.product_id as product_id, decode(cp.pl_display_ccy,'Primary',cp.primary_currency, 'Secondary', cp.quoting_currency) as pl_ccy   
from currency_pair cp, trade t, swap_leg l, product_swap s , trade trade 
where trade.trade_id = t.trade_id and
    l.product_id =  s. product_id 
and t.product_id = s.product_id
and s.swap_type in  ('XCCySwap','SwapNonDeliverable','SwapCrossCurrency','NDS')
and ( (cp.primary_currency = (select l.principal_currency from swap_leg l, product_swap s 
                              where l.product_id =  s. product_id 
                              and t.product_id = s.product_id
                              and s.swap_type in  ('XCCySwap','SwapNonDeliverable','SwapCrossCurrency','NDS')
                              and l.leg_id = 1)--pay leg
	and cp.quoting_currency = (select l.principal_currency from swap_leg l, product_swap s 
                              where l.product_id =  s. product_id
                              and t.product_id = s.product_id
                              and s.swap_type in  ('XCCySwap','SwapNonDeliverable','SwapCrossCurrency','NDS')
                              and l.leg_id = 2) )  
	or (cp.primary_currency = (select l.principal_currency from swap_leg l, product_swap s 
                              where l.product_id =  s. product_id 
                              and t.product_id = s.product_id
                              and s.swap_type in  ('XCCySwap','SwapNonDeliverable','SwapCrossCurrency','NDS')
                              and l.leg_id = 2)--rec leg
	and cp.quoting_currency = (select l.principal_currency from swap_leg l, product_swap s 
                              where l.product_id =  s. product_id
                              and t.product_id = s.product_id
                              and s.swap_type in  ('XCCySwap','SwapNonDeliverable','SwapCrossCurrency','NDS')
                              and l.leg_id = 1) ) ) )
/

merge into trade using tempccy
on (trade.trade_id=tempccy.trade_id)
when matched then update set trade.trade_currency=tempccy.pl_ccy
where trade.trade_id=tempccy.trade_id
/

merge into product_desc using tempccy
on (product_desc.product_id=tempccy.product_id)
when matched then update set product_desc.currency=tempccy.pl_ccy
where product_desc.product_id=tempccy.product_id
/

drop table tempccy
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-300507' and version=4 and module='core'
/

/* End of the SQL statements from file:CAL-300507-4.sql */
/* Start of the SQL statements from file:CAL-403515-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-403515',1,CURRENT_TIMESTAMP,'started')
/

update portfolio_swap_contract_fund set sample_timing = 'BEG_PER', reset_timing = 'END_PER' where id in (select funding_leg_id from portfolio_swap_contract) and reset_freq = 'DLY'
/

update portfolio_swap_contract_fund set compound_b = 0 where id in (select funding_leg_id from portfolio_swap_contract) and (reset_freq = 'DLY' or reset_freq = 'NON')
/

update portfolio_swap_contract_fund set cmp_with_spread = 'NO_COMPOUND' where id in (select funding_leg_id from portfolio_swap_contract)
/

update portfolio_swap_contract_fund ps set (ps.rounding_method, ps.rounding_decimals) = (select currency_default.rounding_method, currency_default.rate_decimals from portfolio_swap_contract, portfolio_swap_contract_fund, currency_default where portfolio_swap_contract_fund.id = portfolio_swap_contract.funding_leg_id and currency_default.currency_code = portfolio_swap_contract.settlement_curr and portfolio_swap_contract_fund.id = ps.id)
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-403515' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-403515-1.sql */
/* Start of the SQL statements from file:CAL-401038-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-401038',1,CURRENT_TIMESTAMP,'started')
/

create or replace procedure CREATE_TABLE_CONFIG_ID_MAP 
    (name IN user_tables.table_NAME%TYPE) 
as
    x number :=0 ;
begin
    begin
    select count(*) into x from user_tables where table_name=upper(name);
    exception
        when no_data_found then
        x:=0;
        when others then null;
    end;
    if x = 0 then
        execute immediate 'create table am_server_config_id_map (config_id number(*,0) not null, config_name varchar2(256) not null, config_user varchar2(256) not null)';
    end if;
end CREATE_TABLE_CONFIG_ID_MAP;
/

begin
CREATE_TABLE_CONFIG_ID_MAP('am_server_config_id_map');
end;
/

create or replace procedure CREATE_TABLE_STARTUP_GROUPING
    (name IN user_tables.table_NAME%TYPE) 
as
    x number :=0 ;
begin
    begin
    select count(*) into x from user_tables where table_name=upper(name);
    exception
        when no_data_found then
        x:=0;
        when others then null;
    end;
    if x = 0 then
        execute immediate 'create table am_analysis_startup_grouping (config_id number(*,0) not null, grouping_id number(*,0) not null)';
    end if;
end CREATE_TABLE_STARTUP_GROUPING;
/

begin
CREATE_TABLE_STARTUP_GROUPING('am_analysis_startup_grouping');
end;
/

create or replace procedure SP_INSERT_CONFIG_GROUPING_MAP as 
begin
	declare
	configuration_name varchar(255);
	exist_config_grouping number;
begin
  for startup_grouping_record in (select config_id, grouping_id from am_analysis_startup_grouping) 
  loop
  select config_name into configuration_name from am_server_config_id_map where config_id = startup_grouping_record.config_id;
  select count(*) into exist_config_grouping from am_server_config_grouping_map where config_name = configuration_name and grouping_id = startup_grouping_record.grouping_id;
  if exist_config_grouping = 0
    then
        insert into am_server_config_grouping_map(config_name,grouping_id) values(configuration_name, startup_grouping_record.grouping_id);
  end if;
  end loop;
end;
end SP_INSERT_CONFIG_GROUPING_MAP;
/

begin
SP_INSERT_CONFIG_GROUPING_MAP;
end;
/

drop procedure CREATE_TABLE_CONFIG_ID_MAP
/

drop procedure CREATE_TABLE_STARTUP_GROUPING
/

drop procedure SP_INSERT_CONFIG_GROUPING_MAP
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-401038' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-401038-1.sql */
/* Start of the SQL statements from file:CAL-408541-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-408541',1,CURRENT_TIMESTAMP,'started')
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-408541' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-408541-1.sql */
/* Start of the SQL statements from file:CAL-403515-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-403515',1,CURRENT_TIMESTAMP,'started')
/

update portfolio_swap_contract_fund set sample_timing = 'BEG_PER', reset_timing = 'END_PER' where id in (select funding_leg_id from portfolio_swap_contract) and reset_freq = 'DLY'
/

update portfolio_swap_contract_fund set compound_b = 0 where id in (select funding_leg_id from portfolio_swap_contract) and (reset_freq = 'DLY' or reset_freq = 'NON')
/

update portfolio_swap_contract_fund set cmp_with_spread = 'NO_COMPOUND' where id in (select funding_leg_id from portfolio_swap_contract)
/

update portfolio_swap_contract_fund ps set (ps.rounding_method, ps.rounding_decimals) = (select currency_default.rounding_method, currency_default.rate_decimals from portfolio_swap_contract, portfolio_swap_contract_fund, currency_default where portfolio_swap_contract_fund.id = portfolio_swap_contract.funding_leg_id and currency_default.currency_code = portfolio_swap_contract.settlement_curr and portfolio_swap_contract_fund.id = ps.id)
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-403515' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-403515-1.sql */
/* Start of the SQL statements from file:CAL-409888-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-409888',1,CURRENT_TIMESTAMP,'started')
/

insert 
into
product_sec_code
( product_id,
  sec_code,
  code_value,
  code_value_ucase
) 
select
ps.product_id,
'SWAPLEG_TerminationDate',
tk.keyword_value,
tk.keyword_value
from 
product_structured_flows ps,
trade tr,
( 
 select 
 tk1.trade_id,
 tk1.keyword_value
 from 
 trade_keyword tk1
 where 
 tk1.keyword_name = 'TransferDate' 
 and tk1.trade_id
 in
   (
     select
 	 trade_id
	 from 
	 trade_keyword
	 where keyword_name = 'TransferType' 
	 and keyword_value='PartialTermination'
	)
) tk 
where
tr.product_id = ps.product_id
and 
tr.trade_id =tk.trade_id
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-409888' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-409888-1.sql */
/* Start of the SQL statements from file:CAL-409801-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-409801',1,CURRENT_TIMESTAMP,'started')
/

update sched_task_attr set attr_value =replace(attr_value, ';', '|') where attr_name IN('Include Quote Names Like','Exclude Quote Names Like')
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-409801' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-409801-1.sql */
/* Start of the SQL statements from file:CAL-411307-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-411307',1,CURRENT_TIMESTAMP,'started')
/

update product_cap_floor set cmp_cutoff_lag =0 where cmp_cutoff_lag = -1
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-411307' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-411307-1.sql */
/* Start of the SQL statements from file:CAL-408114-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-408114',1,CURRENT_TIMESTAMP,'started')
/

/* If Pay leg is floating and p_type is null , update it with 'None' */
update cap_swap_ext_info  set  p_type = 'None' WHERE EXISTS (select 1 from swap_leg, product_swap where cap_swap_ext_info.product_id = swap_leg.product_id and product_swap.product_id = swap_leg.product_id and swap_leg.leg_id=product_swap.pay_leg_id and  swap_leg.leg_type='Float' and cap_swap_ext_info.p_type is  null)
/

/* If Receive leg is floating and r_type is null , update it with 'None' */
update cap_swap_ext_info  set  r_type = 'None' WHERE EXISTS (select 1 from swap_leg, product_swap where cap_swap_ext_info.product_id = swap_leg.product_id and product_swap.product_id = swap_leg.product_id and swap_leg.leg_id=product_swap.receive_leg_id  and  swap_leg.leg_type='Float' and cap_swap_ext_info.r_type is  null)
/

/* Creating a temp table paylegtemp and copying  the columns product_id from swap_leg , pay_leg_id from swap and p_type from cap_swap_ext_info 
   if the product_id's from cap_swap_ext_info  and swap_leg matches
   and if  product_id's from swap and swap_leg matches
   and if p_type is not null and either embed_option_type from swap_leg is not equal to p_type or embed_option_type from swap_leg is null
*/
CREATE TABLE paylegtemp as (
select leg.product_id,swap.pay_leg_id,info.p_type from cap_swap_ext_info info, product_swap swap, swap_leg leg
where info.product_id=leg.product_id and
swap.product_id = leg.product_id and 
swap.pay_leg_id=leg.leg_id  and 
info.p_type is not null and 
(leg.embed_option_type <> info.p_type  or leg.embed_option_type is null))
/

/* Creating a temp table rcvlegtemp and copying  the columns product_id from swap_leg , receive_leg_id from swap and r_type from cap_swap_ext_info 
   if the product_id's from cap_swap_ext_info  and swap_leg matches
   and if  product_id's from swap and swap_leg matches
   and if r_type is not null and either embed_option_type from swap_leg is not equal to r_type  or embed_option_type from swap_leg is null
*/

CREATE TABLE rcvlegtemp as (
select leg.product_id,swap.receive_leg_id,info.r_type from cap_swap_ext_info info, product_swap swap, swap_leg leg
where info.product_id=leg.product_id and
swap.product_id = leg.product_id and 
swap.receive_leg_id=leg.leg_id  and 
info.r_type is not null and 
(leg.embed_option_type <> info.r_type  or leg.embed_option_type is null)
)
/

/* Update embed_option_type with p_type 
   if product_id from swap_leg and paylegtemp matches and 
   Leg_id from swap and pay_leg_id from paylegtemp matches
*/
 
update swap_leg set embed_option_type = (select p_type from paylegtemp pt where swap_leg.product_id = pt.product_id and swap_leg.leg_id = pt.pay_leg_id)
WHERE EXISTS
(select 1 from paylegtemp pt where  swap_leg.product_id = pt.product_id and swap_leg.leg_id = pt.pay_leg_id)
/

/* Update embed_option_type with r_type 
   if product_id from swap_leg and receivelegtemp matches and 
   Leg_id from swap and receive_leg_id from pcvlegtemp matches
*/

update swap_leg set embed_option_type = (select r_type from rcvlegtemp rt where swap_leg.product_id = rt.product_id and swap_leg.leg_id = rt.receive_leg_id) 
WHERE EXISTS 
(select 1 from rcvlegtemp rt where swap_leg.product_id = rt.product_id and  swap_leg.leg_id=rt.receive_leg_id)
/

/* Dropping the temp tables*/
drop table paylegtemp
/

drop table rcvlegtemp
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-408114' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-408114-1.sql */
/* Start of the SQL statements from file:CAL-413138-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-413138',1,CURRENT_TIMESTAMP,'started')
/

INSERT INTO sched_task_attr (task_id, attr_name, attr_value) 
SELECT task_id, 
'SEND REPORT BY EMAIL CC', 
SUBSTR(attr_value, INSTR(attr_value, ',')+1)
FROM Sched_task_attr 
WHERE attr_name ='SEND REPORT BY EMAIL TO' AND SUBSTR(attr_value, INSTR(attr_value, ',')+1) <> attr_value
/

UPDATE sched_task_attr 
SET attr_value = SUBSTR(attr_value, 0, INSTR(attr_value, ',')-1)
WHERE attr_name ='SEND REPORT BY EMAIL TO' AND SUBSTR(attr_value, 0, INSTR(attr_value, ',')-1) <> attr_value
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-413138' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-413138-1.sql */
/* Start of the SQL statements from file:CAL-405622-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-405622',1,CURRENT_TIMESTAMP,'started')
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-405622' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-405622-1.sql */
/* Start of the SQL statements from file:CAL-410822-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-410822',1,CURRENT_TIMESTAMP,'started')
/

delete from calypso_seed where seed_name = 'MarginCallConfigID'
/

insert into calypso_seed (last_id,seed_name,seed_alloc_size)
values ((select last_id from calypso_seed where seed_name = 'product'), 'MarginCallConfigID', 500)
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-410822' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-410822-1.sql */
/* Start of the SQL statements from file:CAL-410906-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-410906',1,CURRENT_TIMESTAMP,'started')
/

delete from calypso_seed where seed_name = 'ExposureGroupID'
/

insert into calypso_seed (last_id,seed_name,seed_alloc_size)
values ((select last_id from calypso_seed where seed_name = 'product'), 'ExposureGroupID', 500)
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-410906' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-410906-1.sql */
/* Start of the SQL statements from file:CAL-410770-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-410770',1,CURRENT_TIMESTAMP,'started')
/

delete from calypso_seed where seed_name = 'DividendID'
/

insert into calypso_seed (last_id,seed_name,seed_alloc_size)
values ((select last_id from calypso_seed where seed_name = 'product'), 'DividendID', 500)
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-410770' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-410770-1.sql */
/* Start of the SQL statements from file:CAL-415037-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-415037',1,CURRENT_TIMESTAMP,'started')
/

update portfolio_swap_contract_fund set spread_calc_method = 'SPRD_ADDITIVE'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-415037' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-415037-1.sql */
/* Start of the SQL statements from file:CAL-414266-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-414266',1,CURRENT_TIMESTAMP,'started')
/

declare
x number :=0 ;
begin
    select count(*) into x from calypso_seed where seed_name='eventtypeaction';
    if x=0 then
     	INSERT INTO calypso_seed ( last_id, seed_name, seed_alloc_size ) values ((select last_id from calypso_seed where seed_name = 'product'), 'eventtypeaction', 500);
   	end if;
end;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-414266' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-414266-1.sql */
/* Start of the SQL statements from file:CAL-410754-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-410754',1,CURRENT_TIMESTAMP,'started')
/

declare
x number :=0 ;
begin
    select count(*) into x from calypso_seed where seed_name='tradebundle';
    if x=0 then
     	INSERT INTO calypso_seed ( last_id, seed_name, seed_alloc_size ) values ((select last_id from calypso_seed where seed_name = 'product'), 'tradebundle', 500);
   	end if;
end;
/

declare
x number :=0 ;
begin
    select count(*) into x from calypso_seed where seed_name='externaltradeeventaction';
    if x=0 then
     	INSERT INTO calypso_seed ( last_id, seed_name, seed_alloc_size ) values ((select last_id from calypso_seed where seed_name = 'product'), 'externaltradeeventaction', 500);
   	end if;
end;
/

declare
x number :=0 ;
begin
    select count(*) into x from calypso_seed where seed_name='cadefaults';
    if x=0 then
     	INSERT INTO calypso_seed ( last_id, seed_name, seed_alloc_size ) values ((select last_id from calypso_seed where seed_name = 'product'), 'cadefaults', 500);
   	end if;
end;
/

declare
x number :=0 ;
begin
    select count(*) into x from calypso_seed where seed_name='caelection';
    if x=0 then
     	INSERT INTO calypso_seed ( last_id, seed_name, seed_alloc_size ) values ((select last_id from calypso_seed where seed_name = 'product'), 'caelection', 500);
   	end if;
end;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-410754' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-410754-1.sql */
/* Start of the SQL statements from file:CAL-410879-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-410879',1,CURRENT_TIMESTAMP,'started')
/

declare
x number :=0 ;
begin
    select count(*) into x from calypso_seed where seed_name='NotionalAdjustment';
    if x=0 then
     	INSERT INTO calypso_seed ( last_id, seed_name, seed_alloc_size ) values ((select last_id from calypso_seed where seed_name = 'product'), 'NotionalAdjustment', 500);
   	end if;
end;
/

declare
x number :=0 ;
begin
    select count(*) into x from calypso_seed where seed_name='Deliverable';
    if x=0 then
     	INSERT INTO calypso_seed ( last_id, seed_name, seed_alloc_size ) values ((select last_id from calypso_seed where seed_name = 'product'), 'Deliverable', 500);
   	end if;
end;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-410879' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-410879-1.sql */
/* Start of the SQL statements from file:CAL-416064-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-416064',1,CURRENT_TIMESTAMP,'started')
/

update pricer_measure set measure_id='538' where measure_name='TAX_LN_AM'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-416064' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-416064-1.sql */
/* Start of the SQL statements from file:ACADIA-1095-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('acadia','ACADIA-1095',1,CURRENT_TIMESTAMP,'started')
/

BEGIN
execute immediate 'update collateral_config set accept_undisputed_amt=1 where acadia_b=1 and triparty_b=1';		
execute immediate 'update collateral_config set accept_undisputed_amt=1 where mcc_id in (select distinct mrg_call_def from exposure_group_definition where acadia_b=1 and triparty_b=1)';	
END;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='ACADIA-1095' and version=1 and module='acadia'
/

/* End of the SQL statements from file:ACADIA-1095-1.sql */
/* Start of the SQL statements from file:CAL-415189-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('collateral','CAL-415189',1,CURRENT_TIMESTAMP,'started')
/

update concentration_limit set collateral_value = 'Post Haircut Value' where collateral_value is null and (percentage_basis = 'Total Collateral Value' or percentage_basis = 'Category Collateral Value' or percentage_basis = 'Net Asset Value' or percentage_basis = 'Total Net Balance')
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-415189' and version=1 and module='collateral'
/

/* End of the SQL statements from file:CAL-415189-1.sql */
/* Post Upgrade - Start */
drop procedure add_column_if_not_exists
/

drop procedure drop_column_if_exists
/

drop procedure add_domain_values
/

drop procedure drop_fk_on_table
/

drop procedure drop_pk_if_exists
/

drop procedure drop_uk_if_exists
/

drop procedure drop_procedure_if_exists
/

drop procedure drop_uq_on_table
/

drop procedure drop_unique_if_exists
/

drop procedure drop_table_if_exists
/

drop procedure add_pk_if_not_exists
/

drop procedure run_query_if_tables_exist
/

drop type list_of_names_t
/

drop procedure rename_column_if_exists
/

/* Post Upgrade - End */


/* Applying Schema Statements - start */


-- MANUAL MODIFICATION - Do NOT Remove these, rename to custom some of them
ALTER INDEX idx_margin_call_entr2 RENAME TO san_custom_idx_mgrcall_entr;
ALTER INDEX idx_trade9 RENAME TO san_custom_idx_trade;
ALTER INDEX idx_pl_markx RENAME TO san_custom_idx_pl_mark;
/*
    DROP INDEX idx_margin_call_entr2
/

    DROP INDEX san_custom_idx_prod_col_exp
/

    DROP INDEX san_custom_idx_bo_cre
/

    DROP INDEX san_custom_idx_bo_msg
/

    DROP INDEX san_custom_idx_prod_desc
/

    DROP INDEX san_custom_idx_prod_sxfer
/

    DROP INDEX idx_trade9
/

    DROP INDEX idx_pl_markx
/
*/

-- DROP this index on empty table
    DROP INDEX idx_margin_liquidity2
/

-- DROP this index on empty table
    DROP INDEX idx_margin_trade_liq1
/

-- DROP this index on empty table
    DROP INDEX idx_margin_portfolio1
/

-- DROP this index on empty table
    DROP INDEX idx_recon_inven_row4
/

-- DROP this index on empty table
    DROP INDEX idx_official_pl_aggr2
/

    ALTER TABLE objstore_files MODIFY (app_name VARCHAR(64))
/

    ALTER TABLE objstore_files_content MODIFY (app_name VARCHAR(64))
/

    ALTER TABLE CM_IM_TH_MONITORING_RESULT MODIFY TREE_ID NULL
/

    ALTER TABLE CM_IM_TH_MONITORING_RESULT MODIFY ACCOUNT_ID NULL
/

    ALTER TABLE CM_IM_TH_MONITORING_RESULT MODIFY CALCULATION_SET_ID NULL
/

    ALTER TABLE ACC_EVENT_CONFIG MODIFY RETRO_ACTIVITY varchar2 (32)
/

    ALTER TABLE DISP_PARAMS MODIFY PARAM_VALUE varchar2 (4000)
/

    ALTER TABLE fx_fixing_reset_dates MODIFY (FX_RESET DEFAULT 0)
/

    ALTER TABLE TEMPLATE_DATES MODIFY TEMPLATE_NAME varchar2 (128)
/

    ALTER TABLE TEMPLATE_PRODUCT MODIFY TEMPLATE_NAME varchar2 (128)
/

    ALTER TABLE TRADE_TMPL_KEYWORD MODIFY TEMPLATE_NAME varchar2 (128)
/

    UPDATE
        VOL_SURF_UND_CAP 
    SET
        COMPOUND_B = 0 
    WHERE
        COMPOUND_B IS NULL
/

    ALTER TABLE VOL_SURF_UND_CAP MODIFY COMPOUND_B NOT NULL
/

    UPDATE
        VOL_SURF_UND_CAP 
    SET
        UNDERLYING_PAYMENT_OFFSET = 0 
    WHERE
        UNDERLYING_PAYMENT_OFFSET IS NULL
/

    ALTER TABLE VOL_SURF_UND_CAP MODIFY UNDERLYING_PAYMENT_OFFSET NOT NULL
/

    ALTER TABLE DECSUPP_ORDER MODIFY PORTFOLIO_MANAGER varchar2 (256)
/

    UPDATE
        ACCOUNTING_PL_CONFIG 
    SET
        FXBASED_ITEM_LEVEL = 0 
    WHERE
        FXBASED_ITEM_LEVEL IS NULL
/

    ALTER TABLE ACCOUNTING_PL_CONFIG MODIFY FXBASED_ITEM_LEVEL NOT NULL
/
CREATE UNIQUE INDEX pk_mifid2_transactio1 ON MIFID2_TRANSACTION_EVENT ( event_id ) nologging parallel 8
/

    ALTER TABLE MIFID2_TRANSACTION_EVENT ADD CONSTRAINT pk_mifid2_transactio1 PRIMARY KEY ( event_id ) USING INDEX
/

    ALTER INDEX pk_mifid2_transactio1 noparallel logging
/
CREATE UNIQUE INDEX pk_mifid2_party_nati1 ON MIFID2_PARTY_NATIONAL_ID ( event_id, party_id ) nologging parallel 8
/

    ALTER TABLE MIFID2_PARTY_NATIONAL_ID ADD CONSTRAINT pk_mifid2_party_nati1 PRIMARY KEY ( event_id, party_id ) USING INDEX
/

    ALTER INDEX pk_mifid2_party_nati1 noparallel logging
/
CREATE UNIQUE INDEX pk_mifid2_trader1 ON MIFID2_TRADER ( trader_id ) nologging parallel 8
/

    ALTER TABLE MIFID2_TRADER ADD CONSTRAINT pk_mifid2_trader1 PRIMARY KEY ( trader_id ) USING INDEX
/

    ALTER INDEX pk_mifid2_trader1 noparallel logging
/
CREATE UNIQUE INDEX pk_mifid2_product_el1 ON MIFID2_PRODUCT_ELIGIBILITY ( product_eligibility_id ) nologging parallel 8
/

    ALTER TABLE MIFID2_PRODUCT_ELIGIBILITY ADD CONSTRAINT pk_mifid2_product_el1 PRIMARY KEY ( product_eligibility_id ) USING INDEX
/

    ALTER INDEX pk_mifid2_product_el1 noparallel logging
/
CREATE UNIQUE INDEX pk_ib_reconciliation1 ON IB_RECONCILIATION_MASTER ( reconciliation_id ) nologging parallel 8
/

    ALTER TABLE IB_RECONCILIATION_MASTER ADD CONSTRAINT pk_ib_reconciliation1 PRIMARY KEY ( reconciliation_id ) USING INDEX
/

    ALTER INDEX pk_ib_reconciliation1 noparallel logging
/
CREATE UNIQUE INDEX pk_ib_reconciliation3 ON IB_RECONCILIATION_DETAILS ( reconciliation_id, reference_source ) nologging parallel 8
/

    ALTER TABLE IB_RECONCILIATION_DETAILS ADD CONSTRAINT pk_ib_reconciliation3 PRIMARY KEY ( reconciliation_id, reference_source ) USING INDEX
/

    ALTER INDEX pk_ib_reconciliation3 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_im_th_mon_resu1 ON CM_IM_TH_MON_RESULT_HIST ( id ) nologging parallel 8
/

    ALTER TABLE CM_IM_TH_MON_RESULT_HIST ADD CONSTRAINT pk_cm_im_th_mon_resu1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_im_th_mon_resu1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_threshold_grou1 ON CM_THRESHOLD_GROUP ( id ) nologging parallel 8
/

    ALTER TABLE CM_THRESHOLD_GROUP ADD CONSTRAINT pk_cm_threshold_grou1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_threshold_grou1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_csv_column_con2 ON CM_CSV_COLUMN_CONFIG ( id ) nologging parallel 8
/

    ALTER TABLE CM_CSV_COLUMN_CONFIG ADD CONSTRAINT pk_cm_csv_column_con2 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_csv_column_con2 noparallel logging
/
CREATE UNIQUE INDEX pk_rate_fallback_dat1 ON RATE_FALLBACK_DATA ( currency_code, rate_index_code, rate_index_tenor ) nologging parallel 8
/

    ALTER TABLE RATE_FALLBACK_DATA ADD CONSTRAINT pk_rate_fallback_dat1 PRIMARY KEY ( currency_code, rate_index_code, rate_index_tenor ) USING INDEX
/

    ALTER INDEX pk_rate_fallback_dat1 noparallel logging
/
CREATE UNIQUE INDEX pk_inv_sec_query1 ON INV_SEC_QUERY ( internal_external, position_type, date_type, agent_id, account_id, security_id, book_id, config_id, mcc_id, sub_account_id, query_id )
/

    ALTER TABLE INV_SEC_QUERY ADD CONSTRAINT pk_inv_sec_query1 PRIMARY KEY ( internal_external, position_type, date_type, agent_id, account_id, security_id, book_id, config_id, mcc_id, sub_account_id, query_id ) USING INDEX
/
CREATE UNIQUE INDEX pk_inv_cash_query1 ON INV_CASH_QUERY ( internal_external, position_type, date_type, agent_id, account_id, currency_code, book_id, config_id, mcc_id, sub_account_id, query_id )
/

    ALTER TABLE INV_CASH_QUERY ADD CONSTRAINT pk_inv_cash_query1 PRIMARY KEY ( internal_external, position_type, date_type, agent_id, account_id, currency_code, book_id, config_id, mcc_id, sub_account_id, query_id ) USING INDEX
/
CREATE UNIQUE INDEX pk_realized_pl_confi2 ON REALIZED_PL_CONFIG ( realized_pl_config_id ) nologging parallel 8
/

    ALTER TABLE REALIZED_PL_CONFIG ADD CONSTRAINT pk_realized_pl_confi2 PRIMARY KEY ( realized_pl_config_id ) USING INDEX
/

    ALTER INDEX pk_realized_pl_confi2 noparallel logging
/
CREATE UNIQUE INDEX pk_pkserver_processi3 ON PKSERVER_PROCESSING_INFO_HIST ( trade_id, trade_version, processing_info_name ) nologging parallel 8
/

    ALTER TABLE PKSERVER_PROCESSING_INFO_HIST ADD CONSTRAINT pk_pkserver_processi3 PRIMARY KEY ( trade_id, trade_version, processing_info_name ) USING INDEX
/

    ALTER INDEX pk_pkserver_processi3 noparallel logging
/
CREATE UNIQUE INDEX pk_am_report_hierarc1 ON AM_REPORT_HIERARCHY ( hierarchy_id ) nologging parallel 8
/

    ALTER TABLE AM_REPORT_HIERARCHY ADD CONSTRAINT pk_am_report_hierarc1 PRIMARY KEY ( hierarchy_id ) USING INDEX
/

    ALTER INDEX pk_am_report_hierarc1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_report_tree_no1 ON AM_REPORT_TREE_NODE ( hierarchy_id, parent_id, node_order, node_id ) nologging parallel 8
/

    ALTER TABLE AM_REPORT_TREE_NODE ADD CONSTRAINT pk_am_report_tree_no1 PRIMARY KEY ( hierarchy_id, parent_id, node_order, node_id ) USING INDEX
/

    ALTER INDEX pk_am_report_tree_no1 noparallel logging
/
CREATE UNIQUE INDEX pk_ha_reconvention_p1 ON HA_RECONVENTION_PROCESSED ( reconvention_id ) nologging parallel 8
/

    ALTER TABLE HA_RECONVENTION_PROCESSED ADD CONSTRAINT pk_ha_reconvention_p1 PRIMARY KEY ( reconvention_id ) USING INDEX
/

    ALTER INDEX pk_ha_reconvention_p1 noparallel logging
/
CREATE UNIQUE INDEX pk_routed_order_mapp1 ON ROUTED_ORDER_MAPPING ( route_id, routed_order_id ) nologging parallel 8
/

    ALTER TABLE ROUTED_ORDER_MAPPING ADD CONSTRAINT pk_routed_order_mapp1 PRIMARY KEY ( route_id, routed_order_id ) USING INDEX
/

    ALTER INDEX pk_routed_order_mapp1 noparallel logging
/
CREATE UNIQUE INDEX pk_pros_yield_accret1 ON PROS_YIELD_ACCRETION ( pros_yield_method, pricing_env, trade_id, period_date ) nologging parallel 8
/

    ALTER TABLE PROS_YIELD_ACCRETION ADD CONSTRAINT pk_pros_yield_accret1 PRIMARY KEY ( pros_yield_method, pricing_env, trade_id, period_date ) USING INDEX
/

    ALTER INDEX pk_pros_yield_accret1 noparallel logging
/
CREATE UNIQUE INDEX idx_cm_threshold_gro2 ON CM_THRESHOLD_GROUP ( name, tenant_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_threshold_gro2 noparallel logging
/
CREATE UNIQUE INDEX idx_cm_csv_column_co1 ON CM_CSV_COLUMN_CONFIG ( name ) nologging parallel 8
/

    ALTER INDEX idx_cm_csv_column_co1 noparallel logging
/
CREATE UNIQUE INDEX idx_realized_pl_conf1 ON REALIZED_PL_CONFIG ( book_id, product_type ) nologging parallel 8
/

    ALTER INDEX idx_realized_pl_conf1 noparallel logging
/
CREATE UNIQUE INDEX idx_am_report_tree_n2 ON AM_REPORT_TREE_NODE ( node_id ) nologging parallel 8
/

    ALTER INDEX idx_am_report_tree_n2 noparallel logging
/
CREATE UNIQUE INDEX idx_ha_reconvention_2 ON HA_RECONVENTION_PROCESSED ( trade_id, reconvention_key ) nologging parallel 8
/

    ALTER INDEX idx_ha_reconvention_2 noparallel logging
/
CREATE INDEX idx_mifid2_transacti2 ON MIFID2_TRANSACTION_EVENT ( trade_id ) nologging parallel 8
/

    ALTER INDEX idx_mifid2_transacti2 noparallel logging
/
CREATE INDEX idx_mifid2_trader2 ON MIFID2_TRADER ( trader_short_name ) nologging parallel 8
/

    ALTER INDEX idx_mifid2_trader2 noparallel logging
/
CREATE INDEX idx_ib_reconciliatio2 ON IB_RECONCILIATION_MASTER ( mcc_id, receiving_party, agreement_type, call_type, delivery_type, currency, start_date, end_date ) nologging parallel 8
/

    ALTER INDEX idx_ib_reconciliatio2 noparallel logging
/
CREATE INDEX idx_cm_im_th_result_1 ON CM_IM_TH_RESULT_ERRORS ( im_th_monitoring_result_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_im_th_result_1 noparallel logging
/
CREATE INDEX idx_cm_im_th_result_2 ON CM_IM_TH_RESULT_ERRORS_HIST ( im_th_monitoring_result_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_im_th_result_2 noparallel logging
/
CREATE INDEX idx_fx_flexi_forward2 ON FX_FLEXI_FORWARD_TAKEUP_SCH ( take_up_schedule_id ) nologging parallel 8
/

    ALTER INDEX idx_fx_flexi_forward2 noparallel logging
/
CREATE INDEX idx_fx_flexi_forward4 ON FX_FLEXI_FORWARD_TAKEUP_SCH_H ( take_up_schedule_id ) nologging parallel 8
/

    ALTER INDEX idx_fx_flexi_forward4 noparallel logging
/
CREATE INDEX idx_fx_flexi_forward28 ON FX_FLEXI_FORWARD_MERCHANTFX ( merchantfx_id ) nologging parallel 8
/

    ALTER INDEX idx_fx_flexi_forward28 noparallel logging
/
CREATE INDEX idx_fx_flexi_forward30 ON FX_FLEXI_FORWARD_MERCHANTFX_H ( merchantfx_id ) nologging parallel 8
/

    ALTER INDEX idx_fx_flexi_forward30 noparallel logging
/
CREATE INDEX idx_product_temp1 ON PRODUCT_TEMP ( id ) nologging parallel 8
/

    ALTER INDEX idx_product_temp1 noparallel logging
/
CREATE INDEX idx_trade_filter_pag1 ON TRADE_FILTER_PAGE ( page_id, page_index ) nologging parallel 8
/

    ALTER INDEX idx_trade_filter_pag1 noparallel logging
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'PRICE','Measure','Collateral',1 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_SECURITY_ACCRUAL','Measure','Collateral',2 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_SECURITY_VALUE','Measure','Collateral',3 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_SECURITY_CLEAN_VALUE','Measure','Collateral',4 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'PRICE','Measure','Repo',1 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_SECURITY_ACCRUAL','Measure','Repo',2 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_SECURITY_VALUE','Measure','Repo',3 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_SECURITY_CLEAN_VALUE','Measure','Repo',4 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_LIABILITY','Measure','Repo',5 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'DIRTY_PRICE','Measure','Repo',6 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'ACCRUAL','Measure','Repo',7 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'PRICE','Measure','SecLending',1 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_SECURITY_ACCRUAL','Measure','SecLending',2 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_SECURITY_VALUE','Measure','SecLending',3 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_SECURITY_CLEAN_VALUE','Measure','SecLending',4 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_LIABILITY','Measure','SecLending',5 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'DIRTY_PRICE','Measure','SecLending',6 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'ACCRUAL','Measure','SecLending',7 )
/

    INSERT 
    INTO
        allocation_validator
        ( collateral_context_id, dto_id, name, type ) 
    VALUES
        (1,1,'AllocationPriceValidator','AllocationPriceValidator' )
/

    INSERT 
    INTO
        allocation_validator
        ( collateral_context_id, dto_id, name, type ) 
    VALUES
        (1,3,'EligibilityAllocationValidator','EligibilityAllocationValidator' )
/

    INSERT 
    INTO
        arch_registry
        ( table_size, table_type ) 
    VALUES
        (0,'entry' )
/

    INSERT 
    INTO
        arch_registry
        ( table_size, table_type ) 
    VALUES
        (0,'concentration' )
/

    INSERT 
    INTO
        arch_registry
        ( table_size, table_type ) 
    VALUES
        (0,'position' )
/

    INSERT 
    INTO
        arch_registry
        ( table_size, table_type ) 
    VALUES
        (0,'detailEntry' )
/

    INSERT 
    INTO
        arch_registry
        ( table_size, table_type ) 
    VALUES
        (0,'allocation' )
/

    INSERT 
    INTO
        cm_calculation_set
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, name, official, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','00632a8a-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','MARGIN_SIMULATION_CS_00632a8a-40d3-11eb-b378-0242ac130002',0,0,0 )
/

    INSERT 
    INTO
        advice_config
        ( address_method, advice_config_id, always_send, default_language, event_type, format_type, gateway, inactive, matching, message_type, po_id, product_type, rec_contact_type, receiver_id, receiver_role, sd_filter, send_contact_type, template_name ) 
    VALUES
        ('ACADIA',14000,0,'English','VERIFIED_INTEREST','ACADIA','ACADIA',0,0,'INTEREST_NOTIFICATION',0,'InterestBearing','Default',0,'CounterParty','NONE','Default','CreateInterest' )
/

    INSERT 
    INTO
        advice_config
        ( address_method, advice_config_id, always_send, default_language, event_type, format_type, gateway, inactive, matching, message_type, po_id, product_type, rec_contact_type, receiver_id, receiver_role, sd_filter, send_contact_type, template_name ) 
    VALUES
        ('ACADIA',14001,0,'English','MISMATCHED_INTEREST','ACADIA','ACADIA',0,0,'INTEREST_NOTIFICATION',0,'InterestBearing','Default',0,'CounterParty','NONE','Default','AmendInterest' )
/

    INSERT 
    INTO
        advice_config
        ( address_method, advice_config_id, always_send, default_language, event_type, format_type, gateway, inactive, matching, message_type, po_id, product_type, rec_contact_type, receiver_id, receiver_role, sd_filter, send_contact_type, template_name ) 
    VALUES
        ('ACADIA',14002,0,'English','FINALIZED_INTEREST','ACADIA','ACADIA',0,0,'INTEREST_NOTIFICATION',0,'InterestBearing','Default',0,'CounterParty','NONE','Default','FinalizeInterest' )
/

    INSERT 
    INTO
        advice_config
        ( address_method, advice_config_id, always_send, default_language, event_type, format_type, gateway, inactive, matching, message_type, po_id, product_type, rec_contact_type, receiver_id, receiver_role, sd_filter, send_contact_type, template_name ) 
    VALUES
        ('ACADIA',14003,0,'English','CANCELLED_INTEREST','ACADIA','ACADIA',0,0,'INTEREST_NOTIFICATION',0,'InterestBearing','Default',0,'CounterParty','NONE','Default','CancelInterest' )
/

    INSERT 
    INTO
        advice_config
        ( address_method, advice_config_id, always_send, default_language, event_type, format_type, gateway, inactive, matching, message_type, po_id, product_type, rec_contact_type, receiver_id, receiver_role, sd_filter, send_contact_type, template_name ) 
    VALUES
        ('ACADIA',14004,0,'English','DISPUTED_INTEREST','ACADIA','ACADIA',0,0,'INTEREST_NOTIFICATION',0,'InterestBearing','Default',0,'CounterParty','NONE','Default','DisputeInterest' )
/

    INSERT 
    INTO
        advice_config
        ( address_method, advice_config_id, always_send, default_language, event_type, format_type, gateway, inactive, matching, message_type, po_id, product_type, rec_contact_type, receiver_id, receiver_role, sd_filter, send_contact_type, template_name ) 
    VALUES
        ('ACADIA',14005,0,'English','UNPAIRED_INTEREST','ACADIA','ACADIA',0,0,'INTEREST_NOTIFICATION',0,'InterestBearing','Default',0,'CounterParty','NONE','Default','AmendInterest' )
/

    INSERT 
    INTO
        bo_workflow_rule
        ( id, rule_name ) 
    VALUES
        (15005,'InterestStatementDispute' )
/

    INSERT 
    INTO
        calypso_cache
        ( app_name, cache_limit, eviction, expiration, implementation, limit_name ) 
    VALUES
        ('DefaultServer',100000,'LFU',0,'Calypso','SecondaryMarketTrade' )
/

    INSERT 
    INTO
        calypso_cache
        ( app_name, cache_limit, eviction, expiration, implementation, limit_name ) 
    VALUES
        ('DefaultServer',50000,'LFU',0,'Calypso','OTCTrade' )
/

    delete 
    FROM
        calypso_info
/

    INSERT 
    INTO
        calypso_info
        ( major_version, minor_version, patch_version, ref_time_zone, sub_version, version_date ) 
    VALUES
        (16,1,'85','GMT',0,TIMESTAMP'2021-09-02 00:00:00.0' )
/

    UPDATE
        calypso_info 
    SET
        ref_time_zone = 'GMT'
/

    INSERT 
    INTO
        calypso_seed
        ( last_id, seed_alloc_size, seed_name ) 
    VALUES
        (1,1,'mifid2_event' )
/

    INSERT 
    INTO
        calypso_seed
        ( last_id, seed_alloc_size, seed_name ) 
    VALUES
        (1,1,'mifid2_product_criteria' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Margin Config','domainName','Margin' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'Margin','MATCH_ID.TradeKeyword' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'scheduledTask','ERS_LIQUIDITY_IMPORT' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Registers the MiFID2 Handler in the Lifcycle Engine','lifeCycleEntityType','Mifid2Reporting' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('List the statuses that will be processed for MiFID2 transaction reporting.','domainName','MiFID2EligibleTradeStatus' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MiFID2EligibleTradeStatus','VERIFIED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MiFID2EligibleTradeStatus','TERMINATED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MiFID2EligibleTradeStatus','CANCELED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('List the product types that will be processed for MiFID2 transaction reporting.','domainName','MiFID2EligibleProducts' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Boolean that indicates whether an entity is a MiFID2 Investment Firm','leAttributeType','MiFID-InvestFirm' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MiFID classification of LEs. Used to determine eligibility.','leAttributeType','MiFID-Role' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Date of Birth of the contact. Format is yyyy-MM-dd','addressMethod','Date of Birth' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The value will be used in the Venue Transaction ID field. If absent, the External Reference will be used.','tradeKeyword','MiFID2VenueTransactionID' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('LE Short Name. Identifies the person who makes the decision to acquire the financial instrument.','tradeKeyword','BuyerDecisionMakerName' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('LE Short Name. Identifies the person who makes the decision to acquire the financial instrument.','tradeKeyword','SellerDecisionMakerName' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Venue MIC code','tradeKeyword','MiFID-Venue' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Instrument Name that will be sent to the MiFID2 Transaction reporting. If empty the product description will be sent.','tradeKeyword','MiFID-InstrumentName' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The trader name or the algorithm. The trader name must correspond to an id in the trader window','tradeKeyword','Mifid2InvestmentDecisionName' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','Mifid2ProductEligibility.Swap' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','Mifid2ProductEligibility.Equity' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','Mifid2ProductEligibility.Credit' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'Mifid2ProductEligibility.Credit','CreditDefaultSwap' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'Mifid2ProductEligibility.Credit','CDSIndexOption' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'Mifid2ProductEligibility.Swap','Swap' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'Mifid2ProductEligibility.Equity','EquityLinkedSwap' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'Mifid2ProductEligibility.Equity','EquityForward' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'Mifid2ProductEligibility.Equity','EquityStructuredOption' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If left blank the InvestmentDecision will be used','tradeKeyword','Mifid2FirmExecutionName' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','Mifid2WaiverIndicator' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','keyword.Mifid2WaiverIndicator' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Reference Price','keyword.Mifid2WaiverIndicator','RFPT' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Negotiated (liquid)','keyword.Mifid2WaiverIndicator','NLIQ' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Negotiated (illiquid)','keyword.Mifid2WaiverIndicator','OILQ' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Negotiated (conditions)','keyword.Mifid2WaiverIndicator','PRIC' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Above specified size','keyword.Mifid2WaiverIndicator','SIZE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Illiquid instrument','keyword.Mifid2WaiverIndicator','ILQD' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','Mifid2ShortSellingIndicator' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','keyword.Mifid2ShortSellingIndicator' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Short sale with no exemption','keyword.Mifid2ShortSellingIndicator','SESH' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Short sale with exemption','keyword.Mifid2ShortSellingIndicator','SSEX' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('No short sale','keyword.Mifid2ShortSellingIndicator','SELL' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Information not available','keyword.Mifid2ShortSellingIndicator','UNDI' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('List of indicators: BENC, ACTX, LRGS, ILQD, SIZE, CANC, AMND, SDIV, RPRI, DUPL, TNCP, TPAC, XFPH','tradeKeyword','Mifid2OTCPostTradeIndicator' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','Mifid2CommodityDerivativeIndicator' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','keyword.Mifid2CommodityDerivativeIndicator' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'keyword.Mifid2CommodityDerivativeIndicator','TRUE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'keyword.Mifid2CommodityDerivativeIndicator','FALSE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','Mifid2SFTIndicator' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','keyword.Mifid2SFTIndicator' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'keyword.Mifid2SFTIndicator','TRUE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'keyword.Mifid2SFTIndicator','FALSE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','Mifid2TradingCapacity' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','keyword.Mifid2TradingCapacity' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Dealing on own account','keyword.Mifid2TradingCapacity','DEAL' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Matched principal','keyword.Mifid2TradingCapacity','MTCH' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Any other capacity','keyword.Mifid2TradingCapacity','AOTC' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','Mifid2InstrumentName' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'REPORT.Types','Mifid2Transaction' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'scheduledTask','MIFID2_TRANSACTION_REPORTING' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','SkipBookValidationForAmend' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'SkipBookValidationForAmend','EurexETD' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','SkipCounterPartyValidationForAmend' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'SkipCounterPartyValidationForAmend','EurexETD' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleTrade','PlatformDraftAllege' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleTrade','PlatformTransfer' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleTrade','PlatformAcceptAffirm' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'UploaderCalypsoMapping.Types','EurexETDFieldMapping' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If true, it''ll propagate start leg assigned sdis to end leg sdis.','SECFINANCE_RETURN_SDI','false' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'eventType','EX_ACADIA_INTEREST_ERROR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'exceptionType','ACADIA_INTEREST_ERROR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ACADIA.Templates','CreateInterest' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ACADIA.Templates','AmendInterest' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ACADIA.Templates','CancelInterest' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ACADIA.Templates','DisputeInterest' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ACADIA.Templates','FinalizeInterest' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('This domain values is used to check the present status with acadia state','domainName','acadiaInterestBearingValidStatus' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'acadiaInterestBearingValidStatus','CANCELLED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'acadiaInterestBearingValidStatus','PAYMENT_INTEREST_AMENDED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'acadiaInterestBearingValidStatus','PAYMENT_INTEREST_NOTIFIED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'acadiaInterestBearingValidStatus','PAYMENT_MISMATCHED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'acadiaInterestBearingValidStatus','PAYMENT_PENDING_VALUE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'acadiaInterestBearingValidStatus','PAYMENT_UNPAIRED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'acadiaInterestBearingValidStatus','PAYMENT_DISPUTED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'acadiaInterestBearingValidStatus','VERIFIED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'acadiaInterestBearingValidStatus','PAYMENT_FINALIZED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleMessage','InterestStatementDispute' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'messageAction','IB_DISPUTE' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('mccAdditionalField','ACADIA_INTEREST_RECEIVING_PARTY' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('domainName','MX.T2' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('SWHTBEB3XXX','MX.T2','SAA.Receiver' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.Templates.GPI','pacs.009.001.CHAPS' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.Templates.GPI','pacs.008.001.CHAPS' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.Templates.GPI','pacs.009.001.COV.CHAPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleMessage','HandleMXRsltnOfInvstgtn' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('iso20022Type','PaymentCancellationRejection' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('iso20022Type','InvestigationExecutionConf' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('iso20022Type','ReturnReason' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('XferAttributes','MXJurisdiction' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('XferAttributes','ConfirmationStatus' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('XferAttributes','CancellationReason' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('XferAttributes','CancellationReasonProp' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('XferAttributes','CancelAdditionalInformation' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'transferAction','REJECT_REQUEST' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','camt.029.001.SIX' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('03.ch.03','MX.Versions','camt.029.001.SIX' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','camt.029.001.MEPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('09','MX.Versions','camt.029.001.MEPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('02','MX.BAH.Versions','camt.029.001.MEPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Used to populate Juridisction drop down in ISO20022 window','domainName','jurisdiction' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Used to customize action while handling incoming camt 029','domainName','MXRsltnOfInvstgtn.Action' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MXRsltnOfInvstgtn.Action','CNCL' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MXRsltnOfInvstgtn.Action','RJCR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'transferAction','RECALL' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('iso20022Type','CancelReason' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('iso20022Type','CancelReasonProp' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('iso20022Type','CancellationReason' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('iso20022Type','CancellationReasonProp' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','camt.056.001.MEPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('08','MX.Versions','camt.056.001.MEPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('02','MX.BAH.Versions','camt.056.001.MEPS' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','camt.056.001.SIX' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('01.ch.01','MX.Versions','camt.056.001.SIX' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('01','MX.BAH.Versions','camt.056.001.SIX' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('messageType','INC_CAMT056' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('INC_CAMT056','incomingType','CAMT056' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('ExternalMessageField.MessageMapper','CAMT056' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Used to customize action while handling incoming camt 056','domainName','MXPmtCancellationMessage.Action' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MXPmtCancellationMessage.Action','REQUEST' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','camt.056.001.T2' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('08','MX.Versions','camt.056.001.T2' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.Templates.GPI','pacs.008.001.SIX' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.Templates.GPI','pacs.009.001.SIX' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','pacs.002.001.SIX' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('08','MX.Versions','camt.054.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('02','MX.BAH.Versions','camt.054.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'messageType','DEBIT_CREDIT_NOTIF' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','pacs.010.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('03','MX.Versions','pacs.010.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('02','MX.BAH.Versions','pacs.010.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.Templates.GPI','pacs.010.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('08','MX.Versions','camt.052.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('02','MX.BAH.Versions','camt.052.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','camt.052.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('08','MX.Versions','camt.053.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('02','MX.BAH.Versions','camt.053.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','camt.053.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('domainName','SWIFT.LEAddressChange' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.LEAddressChange','MT101' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.LEAddressChange','MT101SAP' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.LEAddressChange','MT101Switch' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.LEAddressChange','MT102' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.LEAddressChange','MT102Plus' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.LEAddressChange','MT103' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.LEAddressChange','MT103INDEVAL' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.LEAddressChange','MT103XferAgent' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.LEAddressChange','MT110' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.LEAddressChange','MT202COV' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.LEAddressChange','MT205COV' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.LEAddressChange','MT210' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.LEAddressChange','MT210EUROCLEAR' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.LEAddressChange','MT210Grouped' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.LEAddressChange','MT210INDEVAL' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.LEAddressChange','MT210Switch' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','Counterparty_Ref' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'measuresForAdjustment','PM_SIMM' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'measuresForAdjustment','PM_SCHEDULE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'classAuthMode','CollateralInventoryPool' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'classAuthMode','CollateralSource' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('tk.marketdata','classAuthMode','MarginCallCreditRatingConfiguration' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'classAuthMode','CollateralConfig' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Archive Triparty allocations for Closed and TERMINATED contracts','scheduledTask','COLLATERAL_ARCHIVE_TRIPARTY_ALLOCATIONS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Risk Currency','mccAdditionalField','RISK_CCY' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Stress Loss Margin','mccAdditionalField','SLM' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('domainName','mccAdditionalField.SLM' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('mccAdditionalField.SLM','True' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('mccAdditionalField.SLM','False' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('List of Triparty Agents','domainName','MT527PriceAdjustmentForZeroRQV' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MT527PriceAdjustmentForZeroRQV','CLEARSTREAM' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('SR2021: contains all available values for this option attribute','domainName','CAAttribute.blockingPeriod' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Blocking Till Response Deadline','CAAttribute.blockingPeriod','RDDT' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Blocking Till Record Date','CAAttribute.blockingPeriod','RDTE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Blocking Till Meeting Date','CAAttribute.blockingPeriod','MEET' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Blocking Till Market Deadline','CAAttribute.blockingPeriod','MKDT' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Narrative Unblocking Date','CAAttribute.blockingPeriod','NARR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Blocking Till Payment Date','CAAttribute.blockingPeriod','PAYD' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Blocking Till End of Election Period','CAAttribute.blockingPeriod','PWAL' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Unblocking Date Unknown','CAAttribute.blockingPeriod','UKWN' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Collapses the samples for cutofflag period','domainName','SimpleAvgPreventCutoffPeriodCollapse' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('RISKDEV','ProcessingConfig','ETDWorkstationRiskserver.Name' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','MonthlyConfirmedAmount' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Locale for Bond quotes','LocaleForBondQuotes','English' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Product code FallBacktype can either be null or ISDA','securityCode','FallBackType' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('List of immutable task fields and task enrichments','domainName','tsImmutableFields' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('This domain contains available DataSourceScheme that should use original trade date','domainName','DSS_MT54x_TRAD' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Kickoff Date Calculator based on Validity Date of order or block order','kickoffDateCalculator','ValidityDate' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('PFS Contract Underlying Product Type','domainName','ELSTerminationBeforeFixing' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Risk alternate curve Interpolate As value, aligned with the riskAlternateCurveInterpolator domain value.','domainName','riskAlternateCurveInterpolateAs' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Keyword to retain the product specific view on Structured Flows Trade Window','tradeTmplKeywords','ProductView' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Used by the rule UnSetXferMessageRef to remove Msg Attributes from Transfer','domainName','UnsetXferMessageRef' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','CSDR_DataSourceScheme_ACOW' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'CSDR_DataSourceScheme_ACOW','BPSS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'CSDR_DataSourceScheme_ACOW','CEDE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'CSDR_DataSourceScheme_ACOW','ECLR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'CSDR_DataSourceScheme_ACOW','IBRC' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'rateIndexAttributes','FallbackCalculatorAsOfDate' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'rateIndexAttributes','NominalIndexSource' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'rateIndexAttributes','Index Type' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'rateIndexAttributes','Index Convention' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Scheduled Task to populate fallback type','scheduledTask','POPULATE_FALLBACKTYPE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','FallBackTypeValues' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Max number of PaymentSetup configurations allowed','userAccessPermAttributes','Max.PaymentSetup' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'accEventProperty','NO_CLEANUP' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'accEventType','INTEREST_NTLRECONV' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'accEventType','INTEREST_SHORTFALL_TD' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'accEventType','INTEREST_REIMBURSE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'accEventType','INTEREST_REIMBURSE_TD' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'accEventType','PRINCIPAL_SHORTFALL_TD' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'accEventType','PRINCIPAL_REIMBURSE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'accEventType','PRINCIPAL_REIMBURSE_TD' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('TDWAC unsettled unrealized accretion straight line','accEventType','TDWAC_ACCRETION_SL_UNSETTLED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('TDWAC unsettled unrealized accretion yield','accEventType','TDWAC_ACCRETION_YIELD_UNSETTLED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Provides the Permission to View the Model Calibration Window if it is Configured','function','ViewMarketData' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to Add/Modify the config managing the generation of RealizedPL Transfers','function','AddModifyRealizedPLConfig' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to Remove the config managing the generation of RealizedPL Transfers','function','RemoveRealizedPLConfig' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to view PostingPositionCriteria','function','ViewPostingPositionCriteria' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to modify PostingPositionCriteria','function','ModifyPostingPositionCriteria' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to authorize PositingPositionCriteria','function','AuthorizePostingPositionCriteria' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('USAGE FOR FALL BACK CURVES','marketDataUsage','FB_FOR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'PFSContractUnderlying','ADR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ELSTerminationBeforeFixing','false' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('New Yield method to not consider leap year for price-yield discounting','yieldMethod','Exp_NL365' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Remove the list of keywords while copying the trade','domainName','FXKeywordsToRemoveOnCopyNew' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'Bond.RoundingRuleAttributes','Nominal DTF Rate' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'Bond.RoundingRuleAttributes','NPV' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to set audit flag','function','AllowAudit' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to set authorization flag','function','AllowAuth' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to set workflow flag','function','AllowWorkflow' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to allow login','function','AllowLogin' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If true, there are a specific set of hardcoded columns that will be hidden','domainName','PositionKeepingBlotterHideColumns' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Default value is false. If set to true explicitly, Window Forward Takeups Remaining Amount will be Considered','domainName','WindowForwardTakeupRemainingAmount' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('PKS failure polling interval in milli seconds (Integer). Minimum and default value will be 2000 and maximum can be anything','domainName','PKSFailureStatusPollingInterval' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Update interval in ms for position monitors to update the views for the update in positions.','domainName','PositionMonitorUpdateInterval' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleMessage','SetMT537MonthlyAmount' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleMessage','ReprocessMT537Monthly' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','NonSettlementMessage' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'NonSettlementMessage','SESE024' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'NonSettlementMessage','SESE027' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'NonSettlementMessage','SESE031' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'scheduledTask','HEDGE_RECONVENTION_PROCESSING' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'AMOrderAction','ROUTE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'AMOrderStatus','ROUTED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleAMBlockOrder','CheckKickOff' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to authorize transfer creation and amendment','function','CreateModifyTransfer' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to authorize to delete transfers','function','RemoveTransfer' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to authorize message creation and amendment','function','CreateModifyMessage' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to authorize to delete messages','function','RemoveMessage' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','XferAttributes.RemoveForSPLIT' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleAMOrder','CheckKickOff' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleAMOrder','RouteAndUpdateIdleQty' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleAMOrder','ExecuteRoutedOrderAndUpdateRemainingQty' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleAMOrder','UpdateIdleQtyWhenClosingRoute' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleAMOrder','CheckNoExecutionsAndNoActiveRoutes' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleAMOrder','UpdateFullyExecutedOrderQty' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Used to close FOWS QTE Window','userAttributes','Close FOWS QTE After Position Split Transfer' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Used to compute the interset value for broken compound periods','PartialPeriodCompRateEnrichmentMethods','NCCR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Domain to specify MCC configurations','domainName','Market.Conformity.Check' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'Market.Conformity.Check','MCC' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Configuration for Import Engine MultiJurisdiction support','engineParam','MODULE_NAME' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Configuration for Import Engine MultiJurisdiction support','engineParam','SFTP_FEED_DOMAIN_KEY' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MarginAccount-_-ACCOUNTGROUP-_-VALDATE','Margin','ExportTemplate.MarginAccount' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('List all eligible Element the MatchableBuilderEventFilter will use to check PSEvent eligibility. Please note that only element that are fixed other the time should be listed','domainName','MatchingContext.SDFilter.EligibleElement' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MatchingContext.SDFilter.EligibleElement','Message Template' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MatchingContext.SDFilter.EligibleElement','Message Gateway' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Role function','function','MARGIN_READERRole' )
/

    INSERT 
    INTO
        engine_config
        ( engine_comment, engine_id, engine_name ) SELECT
            null,
            coalesce(max(engine_id)+1,
            100),
            'DataExportServiceEngine' 
        FROM
            engine_config 
        WHERE
            1=1
/

    INSERT 
    INTO
        engine_config
        ( engine_comment, engine_id, engine_name ) SELECT
            null,
            max(engine_id)+1,
            'UpdateManagerEngine' 
        FROM
            engine_config 
        WHERE
            1=1
/

    INSERT 
    INTO
        engine_config
        ( engine_comment, engine_id, engine_name ) SELECT
            null,
            max(engine_id)+1,
            'DataUploaderEngine' 
        FROM
            engine_config 
        WHERE
            1=1
/

    INSERT 
    INTO
        engine_config
        ( engine_comment, engine_id, engine_name ) SELECT
            null,
            coalesce(max(engine_id)+1,
            100),
            'KPIEngine' 
        FROM
            engine_config 
        WHERE
            1=1
/

    INSERT 
    INTO
        engine_config
        ( engine_comment, engine_id, engine_name ) SELECT
            null,
            coalesce(max(engine_id)+1,
            100),
            'FIXEngine' 
        FROM
            engine_config 
        WHERE
            1=1
/

    INSERT 
    INTO
        engine_config
        ( engine_comment, engine_id, engine_name ) SELECT
            'MatchingEngine',
            coalesce(max(engine_id)+1,
            100),
            'MatchingEngine' 
        FROM
            engine_config 
        WHERE
            1=1
/

    INSERT 
    INTO
        engine_config
        ( engine_comment, engine_id, engine_name ) SELECT
            'MatchableBuilderEngine',
            coalesce(max(engine_id)+1,
            100),
            'MatchableBuilderEngine' 
        FROM
            engine_config 
        WHERE
            1=1
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('DataExportServiceEngine','CLASS_NAME','com.calypso.tk.engine.DataExportServiceEngine' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('DataExportServiceEngine','DISPLAY_NAME','DataExporterServiceEngine' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('DataExportServiceEngine','INSTANCE_NAME','engineserver' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('DataExportServiceEngine','STARTUP','false' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('DataExportServiceEngine','config','dataexporter.properties' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('UpdateManagerEngine','CLASS_NAME','com.calypso.tk.engine.UpdateManagerEngine' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('UpdateManagerEngine','DISPLAY_NAME','Update Manager Engine' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('UpdateManagerEngine','INSTANCE_NAME','engineserver' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('UpdateManagerEngine','STARTUP','false' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('DataUploaderEngine','CLASS_NAME','com.calypso.tk.engine.DataUploaderEngine' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('DataUploaderEngine','DISPLAY_NAME','DataUploaderEngine' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('DataUploaderEngine','INSTANCE_NAME','engineserver' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('DataUploaderEngine','STARTUP','false' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('DataUploaderEngine','config','datauploader' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('KPIEngine','CLASS_NAME','com.calypso.kpi.KPIEngine' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('KPIEngine','DISPLAY_NAME','KPI Engine' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('KPIEngine','INSTANCE_NAME','kpiserver' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('KPIEngine','STARTUP','false' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('FIXEngine','CLASS_NAME','com.calypso.tk.engine.FIXEngine' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('FIXEngine','DISPLAY_NAME','FIX Engine' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('FIXEngine','INSTANCE_NAME','engineserver' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('FIXEngine','STARTUP','false' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('FIXEngine','config','fix.properties' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('FIXEngine','EVENT_POOL_POLICY','FIXEngine' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('MatchingEngine','TIMEOUT_RESTART','5' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('MatchableBuilderEngine','TIMEOUT_RESTART','5' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_comment, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.SecFinancePricerMeasure','Bond Coupon Delayed payment at Repo Maturity.',606,'SEC_FIN_DELAYED_COUPON' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_comment, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.SecFinancePricerMeasure',null,607,'SEC_FIN_LIABILITY_PRINCIPAL' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_comment, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.SecFinancePricerMeasure',null,608,'SEC_FIN_LIABILITY_ACCRUAL' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_comment, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.SecFinancePricerMeasure','Sum of all future Cash Flows (type Principal)',534,'SEC_FIN_FUTURE_PRINCIPAL_FLOWS' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureTAX_LN_AM',538,'TAX_LN_AM' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureTAX_LN_REMAIN',537,'TAX_LN_REMAIN' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.core.PricerMeasure',536,'PV01_DISC' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureTripartyExposure',538,'TET_EXPOSURE_AMOUNT' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureTripartyExposure',539,'TET_COLLATERAL_VALUE' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureMTM_BASE',497,'MTM_BASE' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureMTM_CCY',498,'MTM_CCY' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureFX_PL',535,'FX_PL' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.calculators.PricerMeasureBond',920,'DIRTY_PRICE_SCALED' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.calculators.PricerMeasureBond',921,'TRADE_DIRTY_PRICE_SCALED' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureACCRUAL_TERM_REAL',526,'ACCRUAL_TERM_REAL' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureACCRUAL_TERM_REAL_PAY',527,'ACCRUAL_TERM_REAL_PAY' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureACCRUAL_TERM_REAL_REC',528,'ACCRUAL_TERM_REAL_REC' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureACCRUAL_REAL_TD',529,'ACCRUAL_REAL_TD' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureACCRUAL_REAL_TD_PAY',530,'ACCRUAL_REAL_TD_PAY' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureACCRUAL_REAL_TD_REC',531,'ACCRUAL_REAL_TD_REC' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureCA_PV_NET_COST',929,'CA_PV_NET_COST' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureCA_PV_NET_COST_AM',930,'CA_PV_NET_COST_AM' )
/

    INSERT 
    INTO
        pricing_param_name
        ( default_value, is_global_b, param_comment, param_domain, param_name, param_type ) 
    VALUES
        ('false',1,'If true compute PV01 for bond settling on the Forward Settle Date','true,false','PV01_FROM_FWD_BOND','java.lang.Boolean' )
/

    INSERT 
    INTO
        product_code
        ( code_type, mandatory_b, otc_b, product_code, product_list, searchable_b, unique_b ) 
    VALUES
        ('string',0,1,'FallBackType',null,1,0 )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('DataExportServiceEngine','PSEventProcessOrder','Back-Office' )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('FIXEngine','PSEventFIXMessage','Back-Office' )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('MatchableBuilderEngine','PSEventMessage','Back-Office' )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('MatchableBuilderEngine','PSEventProcessMessage','Back-Office' )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('MatchableBuilderEngine','PSEventProcessTransfer','Back-Office' )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('MatchableBuilderEngine','PSEventProcessTrade','Back-Office' )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('MatchableBuilderEngine','PSEventTrade','Back-Office' )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('MatchableBuilderEngine','PSEventTransfer','Back-Office' )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('MatchingEngine','PSEventMatchable','Back-Office' )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('MatchingEngine','PSEventDomainChange','Back-Office' )
/

    INSERT 
    INTO
        ps_event_filter
        ( engine_name, event_config_name, event_filter ) 
    VALUES
        ('DataExportServiceEngine','Back-Office','DataExportServiceEngineEventFilter' )
/

    INSERT 
    INTO
        ps_event_filter
        ( engine_name, event_config_name, event_filter ) 
    VALUES
        ('FIXEngine','Back-Office','FIXEngineEventFilter' )
/

    INSERT 
    INTO
        ps_event_filter
        ( engine_name, event_config_name, event_filter ) 
    VALUES
        ('MatchableBuilderEngine','Back-Office','MatchableBuilderEventFilter' )
/

    INSERT 
    INTO
        ps_event_filter
        ( engine_name, event_config_name, event_filter ) 
    VALUES
        ('MatchingEngine','Back-Office','MatchingEventFilter' )
/

    INSERT 
    INTO
        send_config
        ( address_method, advice_status, advice_type, by_gateway_b, by_method_b, gateway, product_type, publish_b, save_b, send_b, send_config_id ) 
    VALUES
        ('ACADIA','VERIFIED','INTEREST_NOTIFICATION',1,0,'ACADIA','ALL',0,1,1,14006 )
/

    INSERT 
    INTO
        wfw_transition
        ( create_task_b, event_class, gen_int_event_b, kick_cutoff_b, log_completed_b, msg_type, possible_action, product_type, resulting_status, same_user_b, status, update_only_b, use_stp_b, workflow_id ) 
    VALUES
        (0,'PSEventMessage',0,0,0,'ACADIA_INCOMING','IB_DISPUTE','ALL','DISPUTED',1,'PROCESSED',0,0,15005 )
/


/* Applying Schema Statements - end */



/* Applying xtra statements - start */


    update
        calypso_database_module_audit 
    set
        version='4.7.00' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='acadia'
/

    update
        calypso_database_module_audit 
    set
        version='16.1.0.85' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='acc-pl-reconciliation'
/

    update
        calypso_database_module_audit 
    set
        version='1.0.4' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='audit-service'
/

    update
        calypso_database_module_audit 
    set
        version='1.22.00' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='bo-messaging-core'
/

    update
        calypso_database_module_audit 
    set
        version='1.22.00' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='bo-messaging-mx-cash'
/

    update
        calypso_database_module_audit 
    set
        version='1.22.00' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='bo-messaging-mx-colr'
/

    update
        calypso_database_module_audit 
    set
        version='1.22.00' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='bo-messaging-mx-core'
/

    update
        calypso_database_module_audit 
    set
        version='1.22.00' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='bo-messaging-mx-fxtr'
/

    update
        calypso_database_module_audit 
    set
        version='1.22.00' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='bo-messaging-mx-jd'
/

    update
        calypso_database_module_audit 
    set
        version='1.22.00' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='bo-messaging-mx-sese'
/

    insert 
    into
        calypso_database_module_audit
        (name,version,createdts) 
    values
        ('calypso-fix','1.1.0',CURRENT_TIMESTAMP)
/

    insert 
    into
        calypso_database_module_audit
        (name,version,createdts) 
    values
        ('calypso-fpml','1.1.0',CURRENT_TIMESTAMP)
/

    update
        calypso_database_module_audit 
    set
        version='16.1.0.85' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='collateral'
/

    update
        calypso_database_module_audit 
    set
        version='4.7.1' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='core-data-srvc'
/

    update
        calypso_database_module_audit 
    set
        version='16.1.0.85' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='core'
/

    update
        calypso_database_module_audit 
    set
        version='16.1.0.85' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='datauploader'
/

    update
        calypso_database_module_audit 
    set
        version='16.1.0.85' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='integration-services'
/

    update
        calypso_database_module_audit 
    set
        version='16.1.0.85' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='liquidity'
/

    update
        calypso_database_module_audit 
    set
        version='8.10.0' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='margin-calculator-unrestricted'
/

    update
        calypso_database_module_audit 
    set
        version='5.4.0' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='margin-manager'
/

    update
        calypso_database_module_audit 
    set
        version='7.4.0' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='margin-simm'
/

    update
        calypso_database_module_audit 
    set
        version='2.9.48' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='matching'
/

    update
        calypso_database_module_audit 
    set
        version='16.1.0.85' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='middleofficeam'
/

    insert 
    into
        calypso_database_module_audit
        (name,version,createdts) 
    values
        ('mifid2-reporting','16.1.0.85',CURRENT_TIMESTAMP)
/

    update
        calypso_database_module_audit 
    set
        version='2.6.0' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='objectstorage-service'
/

    insert 
    into
        calypso_database_module_audit
        (name,version,createdts) 
    values
        ('security-finance-triparty','16.1.0.85',CURRENT_TIMESTAMP)
/

    update
        calypso_database_module_audit 
    set
        version='16.1.0.85' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='security-finance'
/

    update
        calypso_database_module_audit 
    set
        version='1.5.1' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='swift-mt-core'
/

    update
        calypso_database_module_audit 
    set
        version='16.1.0.85' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='treasury'
/

    update
        calypso_database_module_audit 
    set
        version='1.5.16' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='user-preferences-service'
/


/* Applying xtra statements - end */



/* one time install statements - start */



/* one time install statements - end */



/* Applying Stored Procedures - start */

CREATE OR REPLACE FUNCTION custom_rule_discriminator (name IN varchar2) RETURN varchar2
IS
BEGIN
IF instr(name,'MessageRule') <> 0 THEN
RETURN 'MessageRule';
ELSIF instr(name,'TradeRule') <> 0 THEN
RETURN 'TradeRule';
ELSIF instr(name,'TransferRule') <> 0 THEN
RETURN 'TransferRule';
ELSIF instr(name,'WorkflowRule') <> 0 THEN
RETURN 'WorkflowRule';
ELSE
RETURN 'error';
END IF;
END custom_rule_discriminator;
/
CREATE OR REPLACE PROCEDURE drop_function ( proc_name IN user_tab_columns.table_name%TYPE) AS
 x number;
BEGIN
   BEGIN
   SELECT count(*) into x FROM user_objects WHERE object_name=UPPER(proc_name) and object_type= 'FUNCTION';
   exception
        when NO_DATA_FOUND THEN
        x:=0;
        when others then
        null;
    end;
    IF x > 0 THEN
       EXECUTE IMMEDIATE 'drop function '|| proc_name;
    END IF;
END drop_function;
/
begin
 drop_function ('rate_index_string_value');
end;
/
create or replace view rate_index_string_value as select rate_index_id,
replace(substr(quote_name, instr(quote_name, '.', 1, 1) + 1), '.', '/') string_value
from rate_index
/
create or replace procedure sp_trunc_temp_tables
as
begin
execute immediate 'truncate table TRADE_FILTER_PAGE' ;
execute immediate 'truncate table TF_TEMP_TABLE' ;
end;
/
CREATE OR REPLACE PROCEDURE sp_analysis_out_permp (arg_id   IN NUMBER )
AS BEGIN
UPDATE analysis_output_perm_pages p1 
SET page_number = ( SELECT rnum FROM ( SELECT page_id, row_number() 
OVER (ORDER BY page_id) -1 rnum 
FROM analysis_output_perm_pages 
WHERE id = arg_id AND page_number<>-1) 
p2 WHERE p1.page_id = p2.page_id ) 
where p1.id = arg_id AND p1.page_number <> -1;
END;
/
CREATE OR REPLACE PROCEDURE SP_INSERT_OFFICIAL_PL_BUCKET
     ( 
        p_PL_BUCKET_ID        IN  OFFICIAL_PL_BUCKET.PL_BUCKET_ID%TYPE,                
        p_LEG                 IN  OFFICIAL_PL_BUCKET.LEG%TYPE,                  
        p_LOCATION            IN  OFFICIAL_PL_BUCKET.LOCATION%TYPE, 
        p_STRIP_DATE          IN  OFFICIAL_PL_BUCKET.STRIP_DATE%TYPE, 
        p_SUBPRODUCT_ID       IN  OFFICIAL_PL_BUCKET.SUBPRODUCT_ID%TYPE, 
        p_SUBPRODUCT_TYPE     IN  OFFICIAL_PL_BUCKET.SUBPRODUCT_TYPE%TYPE,                
        p_SUBPRODUCT_SUB_TYPE IN  OFFICIAL_PL_BUCKET.SUBPRODUCT_SUB_TYPE%TYPE,                
        p_SUBPRODUCT_EXTENDED_TYPE IN  OFFICIAL_PL_BUCKET.SUBPRODUCT_EXTENDED_TYPE%TYPE,
        p_EXISTING_PL_BUCKET_ID OUT OFFICIAL_PL_BUCKET.PL_BUCKET_ID%TYPE
     )
AS 
BEGIN  
	
	INSERT INTO OFFICIAL_PL_BUCKET 
		(PL_BUCKET_ID,LEG,LOCATION,STRIP_DATE,
		SUBPRODUCT_ID,SUBPRODUCT_TYPE,SUBPRODUCT_SUB_TYPE,SUBPRODUCT_EXTENDED_TYPE) 
	VALUES 
		(p_PL_BUCKET_ID,p_LEG,p_LOCATION,p_STRIP_DATE,
		p_SUBPRODUCT_ID,p_SUBPRODUCT_TYPE,p_SUBPRODUCT_SUB_TYPE,p_SUBPRODUCT_EXTENDED_TYPE) ;
	
	COMMIT;
	
	p_EXISTING_PL_BUCKET_ID := p_PL_BUCKET_ID;
	RETURN;
	
EXCEPTION 
        WHEN DUP_VAL_ON_INDEX THEN
			SELECT  
			      PL_BUCKET_ID
			INTO
			      p_EXISTING_PL_BUCKET_ID
			FROM   	OFFICIAL_PL_BUCKET
			WHERE (LEG = p_LEG OR ((LEG IS NULL) AND (p_LEG IS NULL)))
			AND		(LOCATION = p_LOCATION OR ((LOCATION IS NULL) AND (p_LOCATION IS NULL)))
			AND		(STRIP_DATE = p_STRIP_DATE OR ((STRIP_DATE IS NULL) AND (p_STRIP_DATE IS NULL)))
			AND		(SUBPRODUCT_ID = p_SUBPRODUCT_ID OR ((SUBPRODUCT_ID IS NULL) AND (p_SUBPRODUCT_ID IS NULL)))
			AND		(SUBPRODUCT_TYPE = p_SUBPRODUCT_TYPE OR ((SUBPRODUCT_TYPE IS NULL) AND (p_SUBPRODUCT_TYPE IS NULL)))
			AND		(SUBPRODUCT_SUB_TYPE = p_SUBPRODUCT_SUB_TYPE OR ((SUBPRODUCT_SUB_TYPE IS NULL) AND (p_SUBPRODUCT_SUB_TYPE IS NULL)))
			AND		(SUBPRODUCT_EXTENDED_TYPE = p_SUBPRODUCT_EXTENDED_TYPE OR ((SUBPRODUCT_EXTENDED_TYPE IS NULL) AND (p_SUBPRODUCT_EXTENDED_TYPE IS NULL)));
  
			RETURN;
        WHEN OTHERS THEN
             RAISE_APPLICATION_ERROR (-20001, 
                                     'Error while inserting new plBucket.  PL_BUCKET_ID=' 
                                     || p_PL_BUCKET_ID || ':$:' || SQLERRM, TRUE) ; 
END SP_INSERT_OFFICIAL_PL_BUCKET ;
/
CREATE OR REPLACE PROCEDURE SP_INSERT_OFFICIAL_PL_UNIT
     ( 
        p_PL_UNIT_ID          IN  OFFICIAL_PL_UNIT.PL_UNIT_ID%TYPE,                
        p_BOOK_ID             IN  OFFICIAL_PL_UNIT.BOOK_ID%TYPE,                  
        p_STRATEGY            IN  OFFICIAL_PL_UNIT.STRATEGY%TYPE, 
        p_TRADER              IN  OFFICIAL_PL_UNIT.TRADER%TYPE, 
        p_DESK                IN  OFFICIAL_PL_UNIT.DESK%TYPE, 
        p_CURRENCY            IN  OFFICIAL_PL_UNIT.CURRENCY%TYPE,                
        p_CURRENCY_PAIR       IN  OFFICIAL_PL_UNIT.CURRENCY_PAIR%TYPE,                
        p_PO_ID               IN  OFFICIAL_PL_UNIT.PO_ID%TYPE,                
        p_IS_BY_TRADE         IN  OFFICIAL_PL_UNIT.IS_BY_TRADE%TYPE,
        p_EXISTING_PL_UNIT_ID OUT OFFICIAL_PL_UNIT.PL_UNIT_ID%TYPE
     )
AS 
BEGIN  
	
	INSERT INTO OFFICIAL_PL_UNIT 
		(PL_UNIT_ID,BOOK_ID,STRATEGY,TRADER,DESK,
		CURRENCY,CURRENCY_PAIR,PO_ID,IS_BY_TRADE) 
	VALUES 
		(p_PL_UNIT_ID,p_BOOK_ID,p_STRATEGY,p_TRADER,p_DESK,
		p_CURRENCY,p_CURRENCY_PAIR,p_PO_ID,p_IS_BY_TRADE);
	
	COMMIT;
	
	p_EXISTING_PL_UNIT_ID := p_PL_UNIT_ID;
	RETURN ;
EXCEPTION 
        WHEN DUP_VAL_ON_INDEX THEN
          SELECT  
              PL_UNIT_ID
          INTO
                p_EXISTING_PL_UNIT_ID
          FROM   	OFFICIAL_PL_UNIT
          WHERE 	(BOOK_ID = p_BOOK_ID OR ((BOOK_ID IS NULL) AND (p_BOOK_ID IS NULL)))
          AND		(STRATEGY = p_STRATEGY OR ((STRATEGY IS NULL) AND (p_STRATEGY IS NULL)))
          AND		(TRADER = p_TRADER OR ((TRADER IS NULL) AND (p_TRADER IS NULL)))
          AND		(DESK = p_DESK OR ((DESK IS NULL) AND (p_DESK IS NULL)))
          AND  		CURRENCY = p_CURRENCY
          AND		(CURRENCY_PAIR = p_CURRENCY_PAIR OR ((CURRENCY_PAIR IS NULL) AND (p_CURRENCY_PAIR IS NULL)))
          AND		PO_ID = p_PO_ID
          AND		IS_BY_TRADE = p_IS_BY_TRADE;
          
          RETURN;
        WHEN OTHERS THEN
             RAISE_APPLICATION_ERROR (-20001, 
                                     'Error while inserting new plUnit.  PL_UNIT_ID=' 
                                     || p_PL_UNIT_ID || ':$:' || SQLERRM, TRUE) ; 
END SP_INSERT_OFFICIAL_PL_UNIT ;
/
CREATE OR REPLACE PROCEDURE SP_INS_OFFICIAL_PL_AGGREGATE
     ( 
        p_AGG_ID              IN  OFFICIAL_PL_AGGREGATE.AGG_ID%TYPE,                
        p_PL_CONFIG_ID        IN  OFFICIAL_PL_AGGREGATE.PL_CONFIG_ID%TYPE, 
        p_BOOK_ID             IN  OFFICIAL_PL_AGGREGATE.BOOK_ID%TYPE,                  
        p_PL_UNIT_ID          IN  OFFICIAL_PL_AGGREGATE.PL_UNIT_ID%TYPE, 
        p_ACTION_DATETIME     IN  OFFICIAL_PL_AGGREGATE.ACTION_DATETIME%TYPE, 
        p_EFFECTIVE_PRODUCT_TYPE  IN  OFFICIAL_PL_AGGREGATE.EFFECTIVE_PRODUCT_TYPE%TYPE,
        p_STRATEGY_ID         IN  OFFICIAL_PL_AGGREGATE.STRATEGY_ID%TYPE, 
        p_EXISTING_AGG_ID OUT OFFICIAL_PL_AGGREGATE.AGG_ID%TYPE
     )
AS 
BEGIN  
	
	INSERT INTO OFFICIAL_PL_AGGREGATE 
		(AGG_ID,PL_CONFIG_ID,BOOK_ID,PL_UNIT_ID,ACTION_DATETIME,
		EFFECTIVE_PRODUCT_TYPE,STRATEGY_ID) 
	VALUES 
		(p_AGG_ID,p_PL_CONFIG_ID,p_BOOK_ID,p_PL_UNIT_ID,p_ACTION_DATETIME,
		p_EFFECTIVE_PRODUCT_TYPE,p_STRATEGY_ID);
	
	COMMIT;
	
	p_EXISTING_AGG_ID := p_AGG_ID;
	RETURN ;
EXCEPTION 
        WHEN DUP_VAL_ON_INDEX THEN
          SELECT  
              AGG_ID
          INTO
                p_EXISTING_AGG_ID
          FROM   	OFFICIAL_PL_AGGREGATE
          WHERE PL_CONFIG_ID = p_PL_CONFIG_ID 	
          AND		BOOK_ID = p_BOOK_ID
          AND		PL_UNIT_ID = p_PL_UNIT_ID
          AND  	EFFECTIVE_PRODUCT_TYPE = p_EFFECTIVE_PRODUCT_TYPE
          AND	STRATEGY_ID = p_STRATEGY_ID;
          
          RETURN;
        WHEN OTHERS THEN
             RAISE_APPLICATION_ERROR (-20001, 
                                     'Error while inserting new opl aggregate.  AGG_ID=' 
                                     || p_AGG_ID || ':$:' || SQLERRM, TRUE) ; 
END SP_INS_OFFICIAL_PL_AGGREGATE ;
/
/* add all new stored procs above this line. The following will compile all invalid objects */

DECLARE
begin
  FOR c1_rec IN (SELECT 'ALTER ' || decode(a.object_type,   'PACKAGE BODY',   'PACKAGE',   'TYPE BODY',   'TYPE', a.object_type) 
  || ' ' || a.object_name || decode(a.object_type,   'JAVA CLASS',   ' RESOLVE',   ' COMPILE') 
  || decode(a.object_type, 'PACKAGE BODY',' BODY', 'TYPE BODY','BODY') FullSql
          FROM user_objects a,(SELECT MAX(LEVEL) mylevel, object_id
             FROM public_dependency START WITH object_id IN
				(SELECT object_id FROM user_objects WHERE status = 'INVALID' and    object_type <> 'SYNONYM' )
				CONNECT BY object_id = PRIOR referenced_object_id
				GROUP BY object_id)b
			WHERE a.object_id = b.object_id(+) 
			AND a.status = 'INVALID'
			AND object_type <> 'SYNONYM' ORDER BY b.mylevel DESC,a.object_name ASC )
  LOOP
  begin
    execute immediate c1_rec.FullSql;
    exception
		when others then
					null;
  end;    
  end LOOP;
end;
/
begin
   execute immediate 'drop procedure sp_mcc_housekeeping';
exception when others then
   if sqlcode != -4043 then
      raise;
   end if;
end;
/


/* Applying Stored Procedures - end */

