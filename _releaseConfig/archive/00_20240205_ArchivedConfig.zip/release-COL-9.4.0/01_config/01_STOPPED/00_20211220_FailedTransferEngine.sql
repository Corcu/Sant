DELETE FROM CALYPSO.ENGINE_CONFIG WHERE ENGINE_NAME='FailedTransferEngine';
Insert into CALYPSO.ENGINE_CONFIG (ENGINE_ID,ENGINE_NAME,ENGINE_COMMENT,VERSION_NUM) values ((select max(ENGINE_ID)+1 from CALYPSO.ENGINE_CONFIG),'FailedTransferEngine','Starts and stops FailedTransferEngine','500');


-- DV. Engine Params
delete from domain_values where name = 'engineParam' and value='ReportTypeName';
Insert into DOMAIN_VALUES (NAME,VALUE,DESCRIPTION) values ('engineParam','ReportTypeName','CustomFallidas');
delete from domain_values where name = 'engineParam' and value='ReportTemplateName';
Insert into DOMAIN_VALUES (NAME,VALUE,DESCRIPTION) values ('engineParam','ReportTemplateName','fallidasReport');
-- DV. Engine instances
delete from domain_values where name = 'EngineServer.instances' and value='cws_engineserver';
Insert into DOMAIN_VALUES (NAME,VALUE,DESCRIPTION) values ('EngineServer.instances','cws_engineserver',null);


-- Cargando engine params
DELETE FROM ENGINE_PARAM WHERE ENGINE_NAME='FailedTransferEngine';
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('FailedTransferEngine','DISPLAY_NAME','FailedTransferEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('FailedTransferEngine','CLASS_NAME','calypsox.engine.failedXfer.FailedTransferEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('FailedTransferEngine','STARTUP','true');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('FailedTransferEngine','INSTANCE_NAME','cws_engineserver');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('FailedTransferEngine','ReportTypeName','CustomFallidas');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('FailedTransferEngine','ReportTemplateName','fallidasReport');

DELETE FROM PS_EVENT_CONFIG WHERE ENGINE_NAME='FailedTransferEngine';
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventTrade','FailedTransferEngine');
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventTransfer','FailedTransferEngine');
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventMessage','FailedTransferEngine');
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventInventorySecPosition','FailedTransferEngine');



