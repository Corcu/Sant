

/* Applying Schema Statements - start */


    CREATE TABLE cm_calculation_set (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         name varchar2 (255) NOT NULL,
         official numeric  NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_source (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         source varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_status (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         source varchar2 (255) NOT NULL,
         status varchar2 (255) NOT NULL,
         import_date numeric  NOT NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_status_errors (
        rf_status_id varchar2 (64) NOT NULL,
         errors varchar2 (4000) NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_calc_request (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         account_id varchar2 (64) NOT NULL,
         status varchar2 (255) NOT NULL,
         valuation_date numeric  NULL,
         request_time numeric  NULL,
         time_horizon varchar2 (255) NULL,
         save_results numeric  DEFAULT 1 NOT NULL,
         pricing_env_name varchar2 (255) NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_calc_request_errors (
        request_id varchar2 (64) NOT NULL,
         error_messages varchar2 (4000) NOT NULL,
         error_messages_order numeric  NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_what_if_request (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         status varchar2 (255) NOT NULL,
         valuation_date numeric  NOT NULL,
         pricing_env_name varchar2 (255) NULL 
    ) 
/

    CREATE TABLE cm_simm_what_if_request_errors (
        request_id varchar2 (64) NOT NULL,
         errors varchar2 (4000) NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_what_if_req2calc (
        what_if_request_id varchar2 (64) NOT NULL,
         calc_request_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_what_if (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         what_if_request_id varchar2 (255) NOT NULL,
         valuation_date numeric  NOT NULL,
         trade_id varchar2 (255) NOT NULL,
         trade_sub_id varchar2 (255) NULL,
         uti varchar2 (127) NULL,
         party_id varchar2 (255) NULL,
         counterparty_id varchar2 (255) NULL,
         account_id varchar2 (255) NOT NULL,
         im_model varchar2 (255) NOT NULL,
         risk_type varchar2 (20) NOT NULL,
         product_class varchar2 (64) NOT NULL,
         qualifier varchar2 (255) NULL,
         bucket varchar2 (255) NULL,
         label1 varchar2 (255) NULL,
         label2 varchar2 (255) NULL,
         currency varchar2 (3) NOT NULL,
         amount float  NOT NULL,
         amount_base float  NULL,
         amount_usd float  NULL,
         source varchar2 (255) NULL,
         pricing_env varchar2 (255) NULL,
         end_date varchar2 (64) NULL 
    ) 
/

    CREATE TABLE cm_rf_what_if_collect_reg (
        rf_id varchar2 (64) NOT NULL,
         collect_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_what_if_post_reg (
        rf_id varchar2 (64) NOT NULL,
         post_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_trade (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         valuation_date numeric  NOT NULL,
         trade_id varchar2 (255) NOT NULL,
         trade_sub_id varchar2 (255) NULL,
         uti varchar2 (127) NULL,
         party_id varchar2 (255) NOT NULL,
         counterparty_id varchar2 (255) NOT NULL,
         account_id varchar2 (255) NOT NULL,
         im_model varchar2 (255) NOT NULL,
         risk_type varchar2 (20) NOT NULL,
         product_class varchar2 (64) NOT NULL,
         qualifier varchar2 (255) NULL,
         bucket varchar2 (255) NULL,
         label1 varchar2 (255) NULL,
         label2 varchar2 (255) NULL,
         currency varchar2 (3) NOT NULL,
         amount float  NOT NULL,
         amount_base float  NULL,
         amount_usd float  NULL,
         source varchar2 (255) NULL,
         end_date varchar2 (64) NULL,
         pricing_env varchar2 (255) NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_trade_collect_reg (
        rf_id varchar2 (64) NOT NULL,
         collect_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_trade_post_reg (
        rf_id varchar2 (64) NOT NULL,
         post_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_bucket (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         risk_class varchar2 (32) NOT NULL,
         qualifier varchar2 (64) NOT NULL,
         bucket varchar2 (32) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_status_hist (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         source varchar2 (255) NOT NULL,
         status varchar2 (255) NOT NULL,
         import_date numeric  NOT NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_status_errors_hist (
        rf_status_id varchar2 (64) NOT NULL,
         errors varchar2 (4000) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_status_temp (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         source varchar2 (255) NOT NULL,
         status varchar2 (255) NOT NULL,
         import_date numeric  NOT NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_status_errors_temp (
        rf_status_id varchar2 (64) NOT NULL,
         errors varchar2 (4000) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_trade_hist (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         valuation_date numeric  NOT NULL,
         trade_id varchar2 (255) NOT NULL,
         trade_sub_id varchar2 (255) NULL,
         uti varchar2 (127) NULL,
         party_id varchar2 (255) NOT NULL,
         counterparty_id varchar2 (255) NOT NULL,
         account_id varchar2 (255) NOT NULL,
         im_model varchar2 (255) NOT NULL,
         risk_type varchar2 (20) NOT NULL,
         product_class varchar2 (64) NOT NULL,
         qualifier varchar2 (255) NULL,
         bucket varchar2 (255) NULL,
         label1 varchar2 (255) NULL,
         label2 varchar2 (255) NULL,
         currency varchar2 (3) NOT NULL,
         amount float  NOT NULL,
         amount_base float  NULL,
         amount_usd float  NULL,
         source varchar2 (255) NULL,
         end_date varchar2 (64) NULL,
         pricing_env varchar2 (255) NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_trade_collect_reg_hist (
        rf_id varchar2 (64) NOT NULL,
         collect_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_trade_post_reg_hist (
        rf_id varchar2 (64) NOT NULL,
         post_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_trade_temp (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         valuation_date numeric  NOT NULL,
         trade_id varchar2 (255) NOT NULL,
         trade_sub_id varchar2 (255) NULL,
         uti varchar2 (127) NULL,
         party_id varchar2 (255) NOT NULL,
         counterparty_id varchar2 (255) NOT NULL,
         account_id varchar2 (255) NOT NULL,
         im_model varchar2 (255) NOT NULL,
         risk_type varchar2 (20) NOT NULL,
         product_class varchar2 (64) NOT NULL,
         qualifier varchar2 (255) NULL,
         bucket varchar2 (255) NULL,
         label1 varchar2 (255) NULL,
         label2 varchar2 (255) NULL,
         currency varchar2 (3) NOT NULL,
         amount float  NOT NULL,
         amount_base float  NULL,
         amount_usd float  NULL,
         source varchar2 (255) NULL,
         end_date varchar2 (64) NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_trade_collect_reg_temp (
        rf_id varchar2 (64) NOT NULL,
         collect_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_trade_post_reg_temp (
        rf_id varchar2 (64) NOT NULL,
         post_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_calc_request_hist (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         account_id varchar2 (64) NOT NULL,
         status varchar2 (255) NOT NULL,
         valuation_date numeric  NULL,
         request_time numeric  NULL,
         time_horizon varchar2 (255) NULL,
         save_results numeric  DEFAULT 1 NOT NULL,
         pricing_env_name varchar2 (255) NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_calc_req_errors_hist (
        request_id varchar2 (64) NOT NULL,
         error_messages varchar2 (4000) NOT NULL,
         error_messages_order numeric  NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_calc_request_temp (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         account_id varchar2 (64) NOT NULL,
         status varchar2 (255) NOT NULL,
         valuation_date numeric  NULL,
         request_time numeric  NULL,
         time_horizon varchar2 (255) NULL,
         save_results numeric  DEFAULT 1 NOT NULL,
         pricing_env_name varchar2 (255) NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_calc_req_errors_temp (
        request_id varchar2 (64) NOT NULL,
         error_messages varchar2 (4000) NOT NULL,
         error_messages_order numeric  NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_wif_req_temp (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         status varchar2 (255) NOT NULL,
         valuation_date numeric  NOT NULL,
         pricing_env_name varchar2 (255) NULL 
    ) 
/

    CREATE TABLE cm_simm_wif_req_errors_temp (
        request_id varchar2 (64) NOT NULL,
         errors varchar2 (4000) NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_wif_req2calc_temp (
        what_if_request_id varchar2 (64) NOT NULL,
         calc_request_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_what_if_temp (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         what_if_request_id varchar2 (255) NOT NULL,
         valuation_date numeric  NOT NULL,
         trade_id varchar2 (255) NOT NULL,
         trade_sub_id varchar2 (255) NULL,
         uti varchar2 (127) NULL,
         party_id varchar2 (255) NULL,
         counterparty_id varchar2 (255) NULL,
         account_id varchar2 (255) NOT NULL,
         im_model varchar2 (255) NOT NULL,
         risk_type varchar2 (20) NOT NULL,
         product_class varchar2 (64) NOT NULL,
         qualifier varchar2 (255) NULL,
         bucket varchar2 (255) NULL,
         label1 varchar2 (255) NULL,
         label2 varchar2 (255) NULL,
         currency varchar2 (3) NOT NULL,
         amount float  NOT NULL,
         amount_base float  NULL,
         amount_usd float  NULL,
         source varchar2 (255) NULL,
         pricing_env varchar2 (255) NULL,
         end_date varchar2 (64) NULL 
    ) 
/

    CREATE TABLE cm_rf_wif_collect_reg_temp (
        rf_id varchar2 (64) NOT NULL,
         collect_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_rf_wif_post_reg_temp (
        rf_id varchar2 (64) NOT NULL,
         post_regulators varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_im_monitoring_config (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         warning_ccy varchar2 (3) NOT NULL,
         variation numeric  NOT NULL,
         max_total_im float  NOT NULL 
    ) 
/

    ALTER TABLE COLLATERAL_CONFIG ADD (po_thresh_appl varchar2 (32)  NULL,le_thresh_appl varchar2 (32)  NULL,mf_application_type varchar2 (32)  NULL,mf_method varchar2 (32)  NULL,mf_linked_confid varchar2 (255)  NULL,mf_exp_linkedid varchar2 (255)  NULL)
/

    ALTER TABLE COLLATERAL_CONFIG_CURRENCY ADD call_cutoff_time timestamp NULL
/

    ALTER TABLE EXPOSURE_GROUP_DEFINITION ADD (po_thresh_appl varchar2 (32)  NULL,le_thresh_appl varchar2 (32)  NULL)
/

    ALTER TABLE MARGIN_CALL_ENTRIES ADD (collateralization_tolerance float DEFAULT 0 NULL,collateralization_status varchar2 (128)  NULL,mf_iapost_threshold float NULL,mf_mfta float NULL,mf_revised_ia float NULL,mf_marginreq_post_mfa float NULL,mf_simm float NULL,mf_schedule float NULL)
/

    ALTER TABLE PENDING_MARGIN_CALL_ENTRIES ADD (collateralization_tolerance float DEFAULT 0 NULL,collateralization_status varchar2 (128)  NULL,mf_iapost_threshold float NULL,mf_mfta float NULL,mf_revised_ia float NULL,mf_marginreq_post_mfa float NULL,mf_simm float NULL,mf_schedule float NULL)
/

    ALTER TABLE MRGCALL_ENTRIES_HIST ADD (collateralization_tolerance float DEFAULT 0 NULL,collateralization_status varchar2 (128)  NULL,mf_iapost_threshold float NULL,mf_mfta float NULL,mf_revised_ia float NULL,mf_marginreq_post_mfa float NULL,mf_simm float NULL,mf_schedule float NULL)
/

    ALTER TABLE COLLATERAL_CONTEXT ADD (le_cash_offset numeric NULL,po_cash_offset numeric NULL,le_security_offset numeric NULL,po_security_offset numeric NULL,override_collateral numeric NULL,collateralization_tolerance float DEFAULT 0 NULL,is_tolerance_percentage numeric DEFAULT 0 NOT NULL,check_tolerance_against varchar2 (128)  NULL)
/

    CREATE TABLE anonymizing_audit (
        entity_id numeric  NOT NULL,
         class_name varchar2 (255) NOT NULL,
         anonymizing_date timestamp  NOT NULL,
         anonymizing_user_name varchar2 (255) NOT NULL,
         approver_user_name varchar2 (255) NULL 
    ) 
/

    ALTER TABLE PRODUCT_ROUNDING_RULE ADD (rounding_decimals numeric NULL,rounding_method numeric NULL)
/

    ALTER TABLE ACC_INTEREST_CONFIG ADD offset_date numeric NULL
/

    ALTER TABLE BALANCE_POSITION ADD total_before_closing float NULL
/

    ALTER TABLE BALANCE_POSITION_HIST ADD total_before_closing float NULL
/

    ALTER TABLE BO_POSTING ADD second_trade_id numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE BO_POSTING_HIST ADD second_trade_id numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE PORTFOLIO_SWAP_CONTRACT ADD (status varchar2 (30)  DEFAULT 'Active' NOT NULL,underlyng_type varchar2 (200)  DEFAULT 'All' NOT NULL)
/

    ALTER TABLE PORTFOLIO_SWAP_COUNTRY_REST ADD security_type varchar2 (200)  DEFAULT 'Any' NOT NULL
/

    ALTER TABLE CORR_MAT_DATA_HIST ADD offset_days numeric NULL
/

    ALTER TABLE CORR_MATRIX_DATA ADD offset_days numeric NULL
/

    ALTER TABLE CORR_SURF_BASISADJ ADD offset_days numeric NULL
/

    ALTER TABLE CORR_SURF_DATA ADD offset_days numeric NULL
/

    ALTER TABLE CORR_SURF_PTADJ ADD offset_days numeric NULL
/

    ALTER TABLE CORR_SURF_TIMEAXIS ADD offset_days numeric NULL
/

    ALTER TABLE CORR_TENOR_AX_HIST ADD offset_days numeric NULL
/

    ALTER TABLE CORR_TENOR_AXIS ADD offset_days numeric NULL
/

    ALTER TABLE COV_MAT_DATA_HIST ADD offset_days numeric NULL
/

    ALTER TABLE COV_MATRIX_DATA ADD offset_days numeric NULL
/

    ALTER TABLE CU_CDS ADD start_offset numeric NULL
/

    ALTER TABLE FUNDING_RATE ADD use_reset_days numeric DEFAULT 0 NOT NULL
/

    CREATE TABLE file_document (
        document_id numeric  NOT NULL,
         version numeric  NOT NULL,
         entity_type varchar2 (255) NOT NULL,
         mime_type varchar2 (128) NULL,
         entered_date timestamp  NOT NULL,
         entered_user varchar2 (255) NULL,
         is_binary numeric  DEFAULT 0 NOT NULL,
         charset varchar2 (32) NULL,
         document blob  NULL,
         name varchar2 (255) NULL,
         last_edited timestamp  DEFAULT TIMESTAMP'2000-12-31 00:00:00.0' NOT NULL 
    ) 
/

    ALTER TABLE INV_CASH_MOVEMENT ADD (daily_nfa decimal (38,15)  NULL,daily_brokerage decimal (38,15)  NULL)
/

    ALTER TABLE INV_CASH_BALANCE ADD (total_nfa decimal (38,15)  NULL,total_brokerage decimal (38,15)  NULL)
/

    ALTER TABLE INV_CUST_CASH_MOVEMENT ADD (daily_nfa decimal (38,15)  NULL,daily_brokerage decimal (38,15)  NULL)
/

    ALTER TABLE INV_CUST_CASH_BALANCE ADD (total_nfa decimal (38,15)  NULL,total_brokerage decimal (38,15)  NULL)
/

    ALTER TABLE LE_ATTRIBUTE ADD anonymized numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE LE_CONTACT ADD anonymized numeric DEFAULT 0 NOT NULL
/

    CREATE TABLE sdi_cash_accounts (
        sdi_id numeric  NOT NULL,
         cash_currency varchar2 (255) NOT NULL,
         cash_account_name varchar2 (255) NOT NULL,
         cash_account_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE sdi_cash_accounts_hist (
        sdi_id numeric  NOT NULL,
         cash_currency varchar2 (255) NOT NULL,
         cash_account_name varchar2 (255) NOT NULL,
         cash_account_id numeric  NOT NULL,
         archived_date timestamp  NULL 
    ) 
/

    CREATE TABLE le_settle_delivery_hist (
        sdi_id numeric  NOT NULL,
         sdi_type numeric  NULL,
         name varchar2 (255) NULL,
         agent_le numeric  NULL,
         agent_contact varchar2 (32) NULL,
         agent_account varchar2 (64) NULL,
         message_to_agent numeric  NOT NULL,
         int_le numeric  NULL,
         int_contact varchar2 (32) NULL,
         int_account varchar2 (64) NULL,
         message_to_int numeric  NOT NULL,
         bene_le numeric  NULL,
         bene_contact varchar2 (32) NULL,
         gl_account_id numeric  NULL,
         direct_b numeric  NOT NULL,
         comments varchar2 (255) NULL,
         method varchar2 (32) NULL,
         currency_list varchar2 (255) NULL,
         product_list varchar2 (1024) NULL,
         le_role varchar2 (32) NULL,
         preferred_b numeric  NOT NULL,
         pay_receive numeric  NULL,
         effective_from timestamp  NULL,
         effective_to timestamp  NULL,
         process_org_id numeric  NULL,
         int_gl_acc_id numeric  NULL,
         sd_filter varchar2 (64) NULL,
         priority numeric  NULL,
         link_id numeric  NULL,
         int_le_2 numeric  NULL,
         int_contact_2 varchar2 (32) NULL,
         int_account_2 varchar2 (64) NULL,
         registr_list varchar2 (128) NULL,
         message_to_int2 numeric  NULL,
         trade_cpty_id numeric  NULL,
         bene_name varchar2 (255) NULL,
         agent_name varchar2 (255) NULL,
         int_name varchar2 (255) NULL,
         agent_sub_acc varchar2 (64) NULL,
         int_sub_acc varchar2 (64) NULL,
         int2_sub_acc varchar2 (64) NULL,
         version_num numeric  DEFAULT 0 NOT NULL,
         trade_date_b numeric  NULL,
         bene_iden varchar2 (255) NULL,
         agent_iden varchar2 (255) NULL,
         int_iden varchar2 (255) NULL,
         int2_iden varchar2 (255) NULL,
         addressee_le numeric  NULL,
         reference varchar2 (64) NOT NULL,
         archived_date timestamp  NULL 
    ) 
/

    ALTER TABLE LIQ_POSITION ADD (original_price float NULL,last_average_fx float DEFAULT 1 NULL,first_fx float DEFAULT 1 NULL,second_fx float DEFAULT 1 NULL)
/

    ALTER TABLE LIQ_POSITION_HIST ADD (original_price float NULL,last_average_fx float DEFAULT 1 NULL,first_fx float DEFAULT 1 NULL,second_fx float DEFAULT 1 NULL)
/

    ALTER TABLE LIQ_POSITION_DEL ADD (original_price float NULL,last_average_fx float DEFAULT 1 NULL,first_fx float DEFAULT 1 NULL,second_fx float DEFAULT 1 NULL)
/
CREATE GLOBAL TEMPORARY TABLE liq_product_temp ( product_id numeric  NOT NULL ) ON COMMIT PRESERVE ROWS
/

    CREATE TABLE manual_party_sdi_hist (
        sdi_id numeric  NOT NULL,
         seq_no numeric  NOT NULL,
         pty_id numeric  NULL,
         pty_code varchar2 (255) NULL,
         pty_role varchar2 (32) NULL,
         pty_contact varchar2 (32) NULL,
         pty_acc_name varchar2 (64) NULL,
         pty_long_name varchar2 (255) NULL,
         country_and_city varchar2 (128) NULL,
         code varchar2 (64) NULL,
         code_value varchar2 (128) NULL,
         identifier varchar2 (128) NULL,
         is_financial numeric  NULL,
         msg_to_pty numeric  NULL,
         tag_code varchar2 (64) NULL,
         tag_value varchar2 (255) NULL,
         archived_date timestamp  NULL 
    ) 
/

    CREATE TABLE manual_sdi_hist (
        sdi_id numeric  NOT NULL,
         type varchar2 (32) NULL,
         valid_from timestamp  NULL,
         valid_to timestamp  NULL,
         method varchar2 (32) NULL,
         comments varchar2 (255) NULL,
         entered_date timestamp  NULL,
         classification numeric  NOT NULL,
         bene_le_id numeric  NULL,
         bene_le_code varchar2 (255) NULL,
         version_num numeric  NULL,
         currency_list varchar2 (255) NULL,
         validity_type numeric  DEFAULT 0 NOT NULL,
         reference varchar2 (64) NOT NULL,
         trade_cpty_id numeric  DEFAULT 0 NOT NULL,
         archived_date timestamp  NULL 
    ) 
/

    CREATE TABLE manual_sdi_attr_hist (
        sdi_id numeric  NOT NULL,
         attribute_name varchar2 (128) NOT NULL,
         attribute_value varchar2 (255) NULL,
         archived_date timestamp  NULL 
    ) 
/

    ALTER TABLE OPTION_CONTRACT ADD underlying_date_type varchar2 (32)  NULL
/

    ALTER TABLE PL_POSITION ADD (current_avg_fx float NULL,last_arch_run_date timestamp NULL,last_average_fx float DEFAULT 1 NULL)
/

    ALTER TABLE PL_POSITION_HIST ADD (current_avg_fx float NULL,last_arch_run_date timestamp NULL,last_average_fx float DEFAULT 1 NULL)
/

    ALTER TABLE PL_POSITION_SNAP ADD (current_avg_fx float NULL,last_arch_run_date timestamp NULL,last_average_fx float DEFAULT 1 NULL)
/

    ALTER TABLE PRODUCT_BOND ADD (average_days numeric NULL,cmp_cutoff_lag numeric NULL,cmp_cutoff_lag_b numeric NULL,sample_period_shift_b numeric NULL)
/

    ALTER TABLE PRODUCT_CAP_FLOOR ADD strike_limit float NULL
/

    ALTER TABLE PRODUCT_CASH ADD open_term_bus_day_b numeric DEFAULT 1 NOT NULL
/

    ALTER TABLE PRODUCT_CASH_HIST ADD open_term_bus_day_b numeric DEFAULT 1 NOT NULL
/

    ALTER TABLE PRODUCT_CREDIT_FACILITY ADD credit_limit float NULL
/

    ALTER TABLE PRODUCT_OTCCOM_OPT ADD settlement_offset numeric NULL
/

    ALTER TABLE PRODUCT_OTCEQ_OPT ADD settlement_offset numeric NULL
/

    ALTER TABLE PRODUCT_PM_DEPO_LEASE ADD precious_metal_unit varchar2 (20)  DEFAULT 'Ounces' NOT NULL
/

    ALTER TABLE PRODUCT_SUBSCRIPREDEMP ADD direction varchar2 (128)  NULL
/

    ALTER TABLE PRODUCT_XFERAGENT ADD (from_subacc_sdi_id numeric DEFAULT 0 NULL,to_subacc_sdi_id numeric DEFAULT 0 NULL,is_dap numeric DEFAULT 0 NOT NULL)
/

    ALTER TABLE PRODUCT_STRUCTURED_FLOWS ADD option_method numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE RECON_INVEN_ROW ADD (sub_account_id numeric DEFAULT 0 NOT NULL,base_not_available float NULL,target_not_available float NULL)
/

    ALTER TABLE SEND_COPY_CONFIG ADD (by_jms_b numeric DEFAULT 0 NOT NULL,jms_name varchar2 (32)  NULL)
/

    ALTER TABLE TRADE_OPEN_QTY ADD (fx float DEFAULT 1 NULL,index_rate float DEFAULT 0 NULL)
/

    ALTER TABLE TRADE_OPENQTY_HIST ADD (fx float DEFAULT 1 NULL,index_rate float DEFAULT 0 NULL)
/

    ALTER TABLE TRADE_OPENQTY_SNAP ADD (fx float DEFAULT 1 NULL,index_rate float DEFAULT 0 NULL)
/
CREATE GLOBAL TEMPORARY TABLE toq_product_temp ( product_id numeric  NOT NULL ) ON COMMIT PRESERVE ROWS
/

    ALTER TABLE USER_NAME ADD restricted_le_list varchar2 (4000)  NULL
/

    ALTER TABLE VOL_SURF_UND_COMMOPT ADD underlying_rank numeric DEFAULT 0 NOT NULL
/

    CREATE TABLE arch_partial_trade_ids (
        trade_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE arch_trade_no_sync (
        trade_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE arch_transfer_no_sync (
        transfer_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE arch_quantile (
        trade_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE arch_quantile_no_sync (
        trade_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE pl_mark_temp (
        mark_id numeric  NOT NULL,
         trade_id numeric  NOT NULL,
         pricing_env_name varchar2 (32) NOT NULL,
         valuation_date timestamp  NOT NULL,
         position_or_trade varchar2 (128) NOT NULL,
         position_or_trade_version numeric  NOT NULL,
         entered_datetime timestamp  NOT NULL,
         update_datetime timestamp  NULL,
         version_num numeric  NOT NULL,
         entered_user varchar2 (32) NOT NULL,
         sub_id varchar2 (256) NULL,
         book_id numeric  NOT NULL,
         position_time varchar2 (64) NULL,
         market_time varchar2 (64) NULL,
         comments varchar2 (128) NULL,
         status varchar2 (32) NULL,
         mark_type varchar2 (32) DEFAULT 'PL' NOT NULL 
    ) 
/

    ALTER TABLE OFFICIAL_PL_AGGREGATE ADD strategy_id numeric DEFAULT 0 NOT NULL
/

    CREATE TABLE official_plmark_perm_adj (
        permanent_adj_id numeric  NOT NULL,
         pl_config_id numeric  NOT NULL,
         trade_id numeric  NOT NULL,
         pl_unit_id numeric  NOT NULL,
         pl_bucket_id numeric  NOT NULL,
         book_id numeric  NOT NULL,
         effective_date timestamp  NOT NULL,
         reason varchar2 (64) NOT NULL,
         adj_comment varchar2 (512) NULL,
         adjustor varchar2 (32) NOT NULL,
         is_valid numeric  DEFAULT 0 NOT NULL,
         update_datetime timestamp  NOT NULL,
         version_num numeric  NOT NULL,
         invalidation_datetime timestamp  NULL 
    ) 
/

    CREATE TABLE official_plmark_perm_adj_value (
        permanent_adj_id numeric  NOT NULL,
         measure_name varchar2 (64) NOT NULL,
         adj_value float  NULL,
         total_value float  NULL 
    ) 
/

    CREATE TABLE pl_mark_value_temp (
        mark_id numeric  NOT NULL,
         mark_name varchar2 (32) NOT NULL,
         mark_value float  NULL,
         adj_value float  NULL,
         currency varchar2 (3) NOT NULL,
         display_class varchar2 (128) NULL,
         display_digits numeric  NULL,
         is_adjusted numeric  DEFAULT 0 NOT NULL,
         adj_type varchar2 (512) NULL,
         adj_comment varchar2 (512) NULL,
         is_derived numeric  DEFAULT 0 NOT NULL,
         original_currency varchar2 (3) NOT NULL 
    ) 
/

    ALTER TABLE ACCRUAL_SCHEDULE_PARAMS ADD accrual_offset numeric NULL
/

    ALTER TABLE CORR_SURF_BASISADJ_HIST ADD offset_days numeric NULL
/

    ALTER TABLE CORR_SURF_DATA_HIST ADD offset_days numeric NULL
/

    ALTER TABLE CORR_SURF_PTADJ_HIST ADD offset_days numeric NULL
/

    ALTER TABLE CORR_SURF_TIMEAXIS_HIST ADD offset_days numeric NULL
/

    ALTER TABLE TASK_STATION_TAB ADD (auto_count_b numeric DEFAULT 0 NOT NULL,web_report_b numeric DEFAULT 0 NOT NULL)
/

    ALTER TABLE HA_DESIGNATION_RECORD ADD version_num numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE HA_DESIGNATION_RECORD_TRADE ADD (other_trade_id numeric NULL,other_designation_id numeric NULL,version_num numeric DEFAULT 0 NOT NULL)
/

    ALTER TABLE HA_PORTFOLIO_HEDGE_DEF ADD (participation_rate_calc numeric DEFAULT 0 NOT NULL,prepayment_rate float DEFAULT 0 NOT NULL,hedge_item_type varchar2 (32)  NULL,hedge_item_rate_index_id numeric NULL,hypo_derivative_template varchar2 (64)  NULL)
/

    ALTER TABLE HA_PORTFOLIO_HEDGE_CYCLE ADD end_date timestamp NULL
/

    ALTER TABLE TRADE_GROUPING_BASE ADD am_user varchar2 (256)  NULL
/

    ALTER TABLE ERSC_RULE_GROUP ADD (ref_po numeric NULL,creation_date numeric DEFAULT 0 NOT NULL,creation_user varchar2 (255)  DEFAULT '00112233-4455-6677-8899-aabbccddeeff' NOT NULL,creation_user_type varchar2 (255)  DEFAULT 'urn:calypso:cloud:platform:iam:model:User' NOT NULL,last_update_date numeric DEFAULT 0 NOT NULL,last_update_user varchar2 (255)  DEFAULT '00112233-4455-6677-8899-aabbccddeeff' NOT NULL,last_update_user_type varchar2 (255)  DEFAULT 'urn:calypso:cloud:platform:iam:model:User' NOT NULL)
/

    ALTER TABLE CUSTOM_GROUPING ADD am_user varchar2 (256)  NULL
/

    ALTER TABLE ALLOCATION ADD bm_offset float NULL
/

    ALTER TABLE BENCHMARK_COMP_RECORD_ITEM ADD bm_offset float NULL
/

    CREATE TABLE decsupp_order_hist (
        order_id numeric  NOT NULL,
         product_id numeric  NOT NULL,
         quantity float  NOT NULL,
         remaining_quantity float  NOT NULL,
         book_id numeric  NOT NULL,
         strategy_id numeric  NULL,
         limit_order float  NULL,
         order_type varchar2 (256) NULL,
         breach_info varchar2 (256) NULL,
         is_secondary_market numeric  DEFAULT 1 NOT NULL,
         type varchar2 (20) DEFAULT 'Order' NOT NULL,
         cpty_id numeric  NULL,
         external_ref varchar2 (255) NULL,
         portfolio_manager varchar2 (32) NULL,
         archived_date timestamp  NULL 
    ) 
/

    CREATE TABLE block_order_child_hist (
        block_id numeric  NOT NULL,
         order_id numeric  NOT NULL,
         order_index numeric  DEFAULT -1 NOT NULL,
         archived_date timestamp  NULL 
    ) 
/

    CREATE TABLE am_order_execution_hist (
        id numeric  NOT NULL,
         version numeric  NOT NULL,
         block_order_id numeric  NOT NULL,
         order_type varchar2 (256) NOT NULL,
         trade_id numeric  NULL,
         product_id numeric  NOT NULL,
         action varchar2 (32) NOT NULL,
         cptyId numeric  NULL,
         quantity float  NOT NULL,
         price float  NOT NULL,
         execution_ts timestamp  NOT NULL,
         comments varchar2 (256) NULL,
         status varchar2 (32) NOT NULL,
         external_ref varchar2 (255) NULL,
         archived_date timestamp  NULL 
    ) 
/

    CREATE TABLE am_order_execution_item_hist (
        id numeric  NOT NULL,
         parent_id numeric  NOT NULL,
         parent_version numeric  NOT NULL,
         order_id numeric  NOT NULL,
         trade_id numeric  NOT NULL,
         is_active numeric  NOT NULL,
         archived_date timestamp  NULL 
    ) 
/

    CREATE TABLE ca_fx_mapping (
        id numeric  NOT NULL,
         version_num numeric  NOT NULL,
         product_type varchar2 (32) NOT NULL,
         product_subtype varchar2 (32) NULL,
         ca_type varchar2 (32) NULL,
         ca_sub_type varchar2 (32) NULL,
         fx_position_based varchar2 (32) NULL,
         is_trade_date varchar2 (32) NULL,
         source varchar2 (32) NULL,
         side varchar2 (32) NULL 
    ) 
/

    CREATE TABLE accounting_pl_config (
        id numeric  NOT NULL,
         version numeric  NOT NULL,
         name varchar2 (64) NULL,
         officialplconfig_id numeric  NULL,
         yearend_prorate_termination numeric  NOT NULL,
         positionby_open_trade numeric  NOT NULL,
         additional_values varchar2 (1024) NULL 
    ) 
/

    CREATE TABLE accounting_pl_item (
        id numeric  NOT NULL,
         version numeric  NOT NULL,
         accountingpl_config_id numeric  NOT NULL,
         tradereference_id varchar2 (255) NOT NULL,
         trade_id numeric  NOT NULL,
         trade_version numeric  NOT NULL,
         is_trade numeric  NOT NULL,
         security_id numeric  NULL,
         book_id numeric  NOT NULL,
         val_date timestamp  NOT NULL,
         val_datetime timestamp  NOT NULL,
         run_name varchar2 (64) NULL,
         accountingpl_ccy varchar2 (4) NOT NULL,
         asset_value decimal (38,15) NULL,
         unrealized_mtm decimal (38,15) NULL,
         realized_mtm decimal (38,15) NULL,
         unrealized_accretion decimal (38,15) NULL,
         realized_accretion decimal (38,15) NULL,
         unrealized_accrual decimal (38,15) NULL,
         realized_accrual decimal (38,15) NULL,
         unrealized_otherpl decimal (38,15) NULL,
         realized_otherpl decimal (38,15) NULL,
         unsettled_cash decimal (38,15) NULL,
         settled_cash decimal (38,15) NULL,
         nominal_change decimal (38,15) NULL,
         principal_change decimal (38,15) NULL,
         term_mtm decimal (38,15) NULL,
         term_accrual_real_paid decimal (38,15) NULL,
         term_accrual_real_received decimal (38,15) NULL,
         upfront_mtm decimal (38,15) NULL,
         upfront_accrual_payleg decimal (38,15) NULL,
         upfront_accrual_recleg decimal (38,15) NULL,
         upfront_amort_unreal decimal (38,15) NULL,
         upfront_amort_real decimal (38,15) NULL,
         accrual_bought_sold decimal (38,15) NULL,
         write_down decimal (38,15) NULL,
         bought_sold_inflation decimal (38,15) NULL,
         unrealized_inflation decimal (38,15) NULL,
         realized_inflation decimal (38,15) NULL,
         realized_inflation_mtm decimal (38,15) NULL,
         pay_down decimal (38,15) NULL,
         original_notional decimal (38,15) NULL,
         reported_notional decimal (38,15) NULL,
         current_notional decimal (38,15) NULL,
         reporting_date timestamp  NOT NULL,
         closing_date timestamp  NULL,
         trade_date timestamp  NULL,
         settle_date timestamp  NULL,
         trade_subtype varchar2 (32) NULL,
         sub_type varchar2 (32) NULL,
         open_price decimal (38,15) NULL 
    ) 
/

    CREATE TABLE accounting_pl_item_attr (
        entity_id numeric  NOT NULL,
         entity_type varchar2 (32) NOT NULL,
         attr_name varchar2 (255) NOT NULL,
         attr_type varchar2 (50) DEFAULT 'String' NOT NULL,
         attr_value varchar2 (255) NULL,
         attr_numeric_value float  NULL,
         attr_date_value timestamp  NULL,
         attr_blob blob  NULL 
    ) 
/

    CREATE TABLE activemq_acks (
        container varchar2 (250) NOT NULL,
         sub_dest varchar2 (250) NULL,
         client_id varchar2 (250) NOT NULL,
         sub_name varchar2 (250) NOT NULL,
         selector varchar2 (250) NULL,
         last_acked_id numeric  NULL,
         priority numeric  DEFAULT 5 NOT NULL,
         xid varchar2 (250) NULL 
    ) 
/

    CREATE TABLE activemq_lock (
        id numeric  NOT NULL,
         time numeric  NULL,
         broker_name varchar2 (250) NULL 
    ) 
/

    CREATE TABLE activemq_msgs (
        id numeric  NOT NULL,
         container varchar2 (250) NOT NULL,
         msgid_prod varchar2 (250) NULL,
         msgid_seq numeric  NULL,
         expiration numeric  NULL,
         msg blob  NULL,
         priority numeric  NULL,
         xid varchar2 (250) NULL 
    ) 
/

    CREATE TABLE multi_quote_mapping (
        product_id numeric  NOT NULL,
         source varchar2 (32) NOT NULL,
         currency varchar2 (3) NOT NULL,
         settle_days numeric  NOT NULL,
         entered_datetime timestamp  NOT NULL,
         entered_user varchar2 (32) NOT NULL,
         priority numeric  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE multi_quote_mapping_equity (
        product_id numeric  NOT NULL,
         source varchar2 (32) NOT NULL,
         currency varchar2 (3) NOT NULL,
         settle_days numeric  NOT NULL,
         entered_datetime timestamp  NOT NULL,
         entered_user varchar2 (32) NOT NULL,
         priority numeric  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE platform_core_tenant_init (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  NOT NULL,
         app_name varchar2 (255) NOT NULL,
         status varchar2 (20) NOT NULL,
         version numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_server_configuration (
        server_id numeric  NOT NULL,
         server_name varchar2 (256) NOT NULL,
         am_user varchar2 (256) NOT NULL,
         server_type varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         calypso_version numeric  NOT NULL,
         analysis varchar2 (64) NOT NULL,
         analysis_parameter varchar2 (64) NOT NULL,
         pricing_environment varchar2 (64) NOT NULL,
         trade_filter_template varchar2 (64) NULL,
         market_data_server varchar2 (64) NOT NULL,
         load_balance_policy varchar2 (64) NOT NULL,
         cache_quotes_update numeric  NOT NULL,
         server1 varchar2 (64) NULL,
         server1_dispatcher varchar2 (64) NULL,
         server1_trade_frequency numeric  NULL,
         server1_marketdata_frequency numeric  NULL,
         server2 varchar2 (64) NULL,
         server2_dispatcher varchar2 (64) NULL,
         server2_trade_frequency numeric  NULL,
         server2_marketdata_frequency numeric  NULL,
         server3 varchar2 (64) NULL,
         server3_dispatcher varchar2 (64) NULL,
         server3_trade_frequency numeric  NULL,
         server3_marketdata_frequency numeric  NULL 
    ) 
/

    CREATE TABLE am_column_configuration (
        column_id varchar2 (128) NOT NULL,
         column_name varchar2 (256) NOT NULL,
         am_user varchar2 (256) NULL,
         update_version numeric  DEFAULT 1 NOT NULL,
         aggregation_level varchar2 (64) NOT NULL,
         aggregation_mode varchar2 (64) NOT NULL,
         unit varchar2 (64) NULL,
         alias varchar2 (64) NULL,
         server_configuration varchar2 (64) NOT NULL,
         editable_type varchar2 (64) NOT NULL,
         column_class varchar2 (128) NOT NULL,
         parent_column_id varchar2 (128) NULL,
         audit_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_column_profiles (
        profile_id varchar2 (128) NOT NULL,
         column_id varchar2 (128) NOT NULL,
         group_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_formula_configuration (
        formula_id varchar2 (128) NOT NULL,
         formula_name varchar2 (256) NOT NULL,
         update_version numeric  DEFAULT 1 NOT NULL,
         aggregation_level varchar2 (64) NOT NULL,
         formula_policy varchar2 (64) NOT NULL,
         last_modification_date varchar2 (64) NOT NULL,
         created_by_user varchar2 (64) NOT NULL,
         source_analysis varchar2 (64) NOT NULL,
         formula varchar2 (3968) NOT NULL,
         column_type varchar2 (64) NOT NULL,
         audit_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_formula_profiles (
        formula_id varchar2 (128) NOT NULL,
         group_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_formula_columns (
        formula_id varchar2 (128) NOT NULL,
         column_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_columnset_configuration (
        columnset_id varchar2 (128) NOT NULL,
         columnset_name varchar2 (256) NOT NULL,
         update_version numeric  DEFAULT 1 NOT NULL,
         last_modification_date varchar2 (64) NOT NULL,
         modified_by_user varchar2 (64) NOT NULL,
         trading_ratio_column_id varchar2 (128) NULL,
         audit_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_columnset_profiles (
        columnset_id varchar2 (128) NOT NULL,
         group_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_columnset_widgets (
        columnset_id varchar2 (128) NOT NULL,
         widget_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_columnset_actions (
        columnset_id varchar2 (128) NOT NULL,
         action_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_columnset_main_columns (
        columnset_column_id varchar2 (256) NOT NULL,
         columnset_id varchar2 (128) NULL,
         column_id varchar2 (128) NOT NULL,
         item_index numeric  NULL 
    ) 
/

    CREATE TABLE am_columnset_pivot_columns (
        columnset_column_id varchar2 (256) NOT NULL,
         columnset_id varchar2 (128) NULL,
         column_id varchar2 (128) NOT NULL,
         item_index numeric  NULL 
    ) 
/

    CREATE TABLE am_columnset_group_columns (
        columnset_column_id varchar2 (256) NOT NULL,
         columnset_id varchar2 (128) NULL,
         column_id varchar2 (128) NOT NULL,
         item_index numeric  NULL 
    ) 
/

    CREATE TABLE am_columnset_breakdown_columns (
        columnset_column_id varchar2 (256) NOT NULL,
         columnset_id varchar2 (128) NULL,
         column_id varchar2 (128) NOT NULL,
         item_index numeric  NULL 
    ) 
/

    CREATE TABLE am_unit_configuration (
        unit_id varchar2 (128) NOT NULL,
         unit_name varchar2 (256) NOT NULL,
         update_version numeric  DEFAULT 1 NOT NULL,
         last_modification_date varchar2 (64) NOT NULL,
         modified_by_user varchar2 (64) NOT NULL,
         unit_type varchar2 (64) NOT NULL,
         unit_currency_type varchar2 (64) NOT NULL,
         currency varchar2 (64) NULL,
         unit_level varchar2 (64) NULL,
         multiplier float  NOT NULL,
         denominator_type varchar2 (64) NULL,
         audit_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_unit_profiles (
        unit_id varchar2 (128) NOT NULL,
         group_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_unit_denominator_column (
        unit_denominator_id varchar2 (256) NOT NULL,
         unit_id varchar2 (128) NULL,
         analysis_id varchar2 (256) NOT NULL,
         column_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_grouping_configuration (
        grouping_id varchar2 (128) NOT NULL,
         grouping_name varchar2 (256) NOT NULL,
         update_version numeric  DEFAULT 1 NOT NULL,
         last_modification_date varchar2 (64) NOT NULL,
         created_by_user varchar2 (64) NOT NULL,
         source_analysis varchar2 (64) NOT NULL,
         audit_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_grouping_profiles (
        grouping_id varchar2 (128) NOT NULL,
         group_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_grouping_columns (
        grouping_column_id varchar2 (256) NOT NULL,
         grouping_id varchar2 (128) NULL,
         column_name varchar2 (256) NOT NULL,
         item_index numeric  NULL 
    ) 
/

    CREATE TABLE am_widget_configuration (
        widget_id varchar2 (128) NOT NULL,
         widget_name varchar2 (256) NOT NULL,
         update_version numeric  DEFAULT 1 NOT NULL,
         last_modification_date varchar2 (64) NOT NULL,
         modified_by_user varchar2 (64) NOT NULL,
         widget_type varchar2 (64) NOT NULL,
         audit_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_widget_profiles (
        widget_id varchar2 (128) NOT NULL,
         group_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_widget_columns (
        widget_id varchar2 (128) NOT NULL,
         column_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_chart_widget_configuration (
        chart_widget_id varchar2 (128) NOT NULL,
         widget_id varchar2 (128) NULL,
         chart_widget_name varchar2 (256) NOT NULL,
         chart_type varchar2 (64) NOT NULL,
         columnset_id varchar2 (128) NULL,
         grouping_id varchar2 (128) NULL,
         number_of_segments numeric  NOT NULL,
         display_bar_label numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_order_widget_configuration (
        order_widget_id varchar2 (128) NOT NULL,
         widget_id varchar2 (128) NULL,
         order_widget_name varchar2 (256) NOT NULL,
         template_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_configuration (
        layout_id varchar2 (128) NOT NULL,
         layout_name varchar2 (256) NOT NULL,
         update_version numeric  DEFAULT 1 NOT NULL,
         last_modification_date varchar2 (64) NOT NULL,
         modified_by_user varchar2 (64) NOT NULL,
         default_columnset_id varchar2 (128) NOT NULL,
         default_grouping_id varchar2 (128) NOT NULL,
         default_filtering_id varchar2 (128) NOT NULL,
         default_coloring_id varchar2 (128) NOT NULL,
         audit_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_layout_profiles (
        layout_id varchar2 (128) NOT NULL,
         group_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_columnset (
        layout_id varchar2 (128) NOT NULL,
         columnset_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_fav_columnset (
        layout_id varchar2 (128) NOT NULL,
         columnset_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_grouping (
        layout_id varchar2 (128) NOT NULL,
         grouping_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_fav_grouping (
        layout_id varchar2 (128) NOT NULL,
         grouping_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_filtering (
        layout_id varchar2 (128) NOT NULL,
         filtering_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_fav_filtering (
        layout_id varchar2 (128) NOT NULL,
         filtering_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_widget (
        layout_id varchar2 (128) NOT NULL,
         widget_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_fav_widget (
        layout_id varchar2 (128) NOT NULL,
         widget_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_coloring (
        layout_id varchar2 (128) NOT NULL,
         coloring_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_fav_coloring (
        layout_id varchar2 (128) NOT NULL,
         coloring_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE am_layout_position (
        layout_id varchar2 (128) NOT NULL,
         display_all numeric  NOT NULL,
         opened_positions numeric  NOT NULL,
         closed_positions numeric  NOT NULL,
         intraday_trades numeric  NOT NULL,
         closed_strategies numeric  NOT NULL,
         cash_instrument numeric  NOT NULL,
         benchmark_instrument numeric  NOT NULL,
         looktrough_adjustment numeric  NOT NULL,
         hide_none_groups numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_layout_display (
        layout_id varchar2 (128) NOT NULL,
         override_decimals_display numeric  NULL 
    ) 
/

    CREATE TABLE am_filtering_configuration (
        filtering_id varchar2 (128) NOT NULL,
         filtering_name varchar2 (256) NOT NULL,
         is_prefiltering numeric  DEFAULT 0 NOT NULL,
         is_and_criteria numeric  DEFAULT 0 NOT NULL,
         update_version numeric  DEFAULT 1 NOT NULL,
         last_modification_date varchar2 (64) NOT NULL,
         modified_by_user varchar2 (64) NOT NULL,
         audit_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_filtering_profiles (
        filtering_id varchar2 (128) NOT NULL,
         group_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_filtering_columns (
        filtering_column_id varchar2 (256) NOT NULL,
         filtering_id varchar2 (128) NULL,
         column_id varchar2 (128) NOT NULL,
         item_index numeric  NULL 
    ) 
/

    CREATE TABLE am_coloring_configuration (
        coloring_id varchar2 (128) NOT NULL,
         coloring_name varchar2 (256) NOT NULL,
         update_version numeric  DEFAULT 1 NOT NULL,
         last_modification_date varchar2 (64) NOT NULL,
         modified_by_user varchar2 (64) NOT NULL,
         source_analysis varchar2 (64) NOT NULL,
         audit_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE am_coloring_profiles (
        coloring_id varchar2 (128) NOT NULL,
         group_name varchar2 (256) NOT NULL 
    ) 
/

    CREATE TABLE am_coloring_rule_configuration (
        coloring_rule_id varchar2 (128) NOT NULL,
         coloring_id varchar2 (128) NULL,
         coloring_rule_name varchar2 (256) NOT NULL,
         checked_column_id varchar2 (256) NOT NULL,
         operator varchar2 (64) NOT NULL,
         operand varchar2 (64) NOT NULL,
         color numeric  NOT NULL,
         coloring_type varchar2 (64) NOT NULL,
         item_index numeric  NULL 
    ) 
/

    CREATE TABLE am_coloring_colored_columns (
        coloring_rule_id varchar2 (128) NOT NULL,
         column_id varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE product_triparty_exposure (
        product_id numeric  NOT NULL,
         direction varchar2 (32) NOT NULL,
         start_date timestamp  NULL,
         end_date timestamp  NULL,
         maturity_type varchar2 (10) NULL,
         exposure_type varchar2 (20) NULL,
         exposure_amount float  NULL,
         exposure_currency varchar2 (3) NULL,
         mcc_id numeric  NOT NULL,
         triparty_agent varchar2 (15) NULL,
         eligibility_set varchar2 (20) NULL,
         exposure_amount_matched float  NULL,
         triparty_transaction_reference varchar2 (15) NULL,
         initiation_status varchar2 (15) NULL 
    ) 
/

    CREATE TABLE userprefs_preferences (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         preference_type varchar2 (255) NOT NULL,
         preference_key varchar2 (255) NOT NULL,
         preference_value clob  NOT NULL,
         app varchar2 (255) NOT NULL,
         user_id varchar2 (255) NULL,
         default_value clob  NOT NULL,
         regex varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE dashboard_config_layout (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         layout_owner varchar2 (255) NOT NULL,
         layout_type varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE dashboard_config_dashboard (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         description varchar2 (255) NULL,
         dashboard_name varchar2 (255) NOT NULL,
         dashboard_owner varchar2 (255) NOT NULL,
         is_shared numeric  NOT NULL,
         dashboard_type varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE dashboard_config_widget (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         component_name varchar2 (255) NOT NULL,
         dashboard_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE dashboard_config_widget_attr (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         attribute_name varchar2 (255) NOT NULL,
         attribute_type varchar2 (255) NOT NULL,
         attribute_value varchar2 (255) NULL,
         widget_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE dashboard_config_layout_board (
        layout_id varchar2 (64) NOT NULL,
         dashboard_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE userprefs_template (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         template_type varchar2 (255) NOT NULL,
         template_name varchar2 (255) NOT NULL,
         user_id varchar2 (255) NOT NULL,
         app varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE userprefs_template_crit (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         criteria_value clob  NOT NULL,
         criteria_name varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE userprefs_template_2_crit (
        template_id varchar2 (255) NOT NULL,
         criteria_id varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE re_quote_list (
        config_name varchar2 (32) NOT NULL,
         quote_name varchar2 (255) NOT NULL,
         instrument_type varchar2 (32) NOT NULL,
         display_name varchar2 (255) NULL,
         group_name varchar2 (32) NULL,
         triangulation_set varchar2 (255) NULL,
         version_num numeric  DEFAULT 1 NOT NULL,
         tx_id numeric  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE re_quote_rule_config (
        config_id numeric  NOT NULL,
         config_name varchar2 (32) NOT NULL,
         version_num numeric  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE re_quote_rules (
        rule_id numeric  NOT NULL,
         config_name varchar2 (32) NOT NULL,
         rule_name varchar2 (60) NOT NULL,
         filter_type varchar2 (32) NOT NULL,
         filter_value varchar2 (255) NOT NULL,
         quote_type numeric  NOT NULL,
         market_source varchar2 (64) NOT NULL,
         is_active numeric  NOT NULL 
    ) 
/

    CREATE TABLE re_quote_rules_params (
        rule_id numeric  NOT NULL,
         param_name varchar2 (32) NOT NULL,
         param_value varchar2 (32) NOT NULL 
    ) 
/

    CREATE TABLE re_quote_dynamic_subscription (
        config_name varchar2 (32) NOT NULL,
         instrument_type varchar2 (32) NOT NULL,
         quote_name varchar2 (255) NOT NULL,
         display_name varchar2 (255) NULL,
         subscription_time timestamp  NOT NULL 
    ) 
/

    CREATE TABLE re_quote_manual_publish (
        config_name varchar2 (32) NOT NULL,
         instrument_type varchar2 (32) NULL,
         quote_name varchar2 (255) NOT NULL,
         bid float  NULL,
         ask float  NULL,
         quote_type varchar2 (64) NOT NULL,
         entered_datetime timestamp  NULL,
         entered_user varchar2 (32) NULL,
         active numeric  NULL,
         version numeric  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE re_quote_manual_publish_audit (
        config_name varchar2 (32) NOT NULL,
         instrument_type varchar2 (32) NULL,
         quote_name varchar2 (255) NOT NULL,
         bid float  NULL,
         ask float  NULL,
         quote_type varchar2 (64) NOT NULL,
         entered_datetime timestamp  NULL,
         entered_user varchar2 (32) NULL,
         active numeric  NULL,
         version numeric  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE bloom_sec_entitlement (
        feed_name varchar2 (32) NOT NULL,
         feed_address varchar2 (255) NOT NULL,
         security_eid numeric  NOT NULL 
    ) 
/

    ALTER TABLE LIQ_LIMIT_CCY_BUCKET ADD bucket_limit float NULL
/

    ALTER TABLE LIQ_LIMIT_CCY_CLASS_LVL ADD class_lvl_limit float NULL
/

    ALTER TABLE LIQ_LIMIT_CCY_CLASS_LVL_BUCKET ADD lvl_bucket_limit float NULL
/

    CREATE TABLE product_ftp (
        product_id numeric  NOT NULL,
         original_security_id numeric  NOT NULL,
         original_trade_id numeric  NOT NULL,
         original_trade_version numeric  NOT NULL,
         original_trade_model numeric  NOT NULL,
         original_trade_blob blob  NULL,
         product_sub_type varchar2 (32) NOT NULL,
         funding_cost varchar2 (32) NOT NULL,
         is_mirror numeric  NOT NULL,
         maturity_date timestamp  NOT NULL,
         principal float  NULL,
         kpi_ms numeric  NOT NULL,
         kpi_ms_remote numeric  NOT NULL,
         kpi_ms_explode numeric  NOT NULL,
         kpi_ms_generate numeric  NOT NULL,
         kpi_ms_measures numeric  NOT NULL,
         num_legs numeric  NOT NULL,
         num_error numeric  NOT NULL,
         num_reconventions numeric  NOT NULL,
         num_effective_dates numeric  NOT NULL,
         update_time timestamp  NOT NULL,
         update_revision varchar2 (32) NOT NULL 
    ) 
/

    CREATE TABLE product_ftp_leg (
        product_id numeric  NOT NULL,
         trade_date_time timestamp  NOT NULL,
         effective_date timestamp  NOT NULL,
         end_date timestamp  NOT NULL,
         original_trade_version numeric  NOT NULL,
         trade_blob blob  NULL,
         trade_measures blob  NULL,
         trade_status varchar2 (32) NULL,
         trade_error varchar2 (255) NULL,
         update_time timestamp  NOT NULL 
    ) 
/

    CREATE TABLE objstore_files (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) DEFAULT 'user' NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) DEFAULT 'user' NOT NULL,
         file_name varchar2 (1024) NOT NULL,
         file_key varchar2 (64) NOT NULL,
         mime_type varchar2 (64) NOT NULL,
         file_size numeric  NOT NULL,
         app_name VARCHAR(64)  NOT NULL 
    ) 
/

    CREATE TABLE objstore_files_content (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) DEFAULT 'user' NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) DEFAULT 'user' NOT NULL,
         file_name varchar2 (64) NOT NULL,
         file_size varchar2 (64) NOT NULL,
         file_content blob  NOT NULL,
         app_name VARCHAR(64)  NOT NULL 
    ) 
/

    CREATE TABLE core_account_attribute (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         account_id varchar2 (36) NOT NULL,
         name varchar2 (255) NOT NULL,
         value varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_account_interest_config (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         currency varchar2 (255) NOT NULL,
         instance varchar2 (255) NULL,
         quote_set_name varchar2 (255) NULL 
    ) 
/

    CREATE TABLE core_bond (
        acc_daycount varchar2 (255) NULL,
         accrual_rounding numeric  NULL,
         acr_rounding_mthd varchar2 (255) NULL,
         active_date numeric  NULL,
         amort_amount FLOAT  NULL,
         amort_rate FLOAT  NULL,
         amort_structure varchar2 (10) NULL,
         announce_date numeric  NULL,
         auction_date numeric  NULL,
         bond_name varchar2 (64) NULL,
         bond_status varchar2 (32) NULL,
         bond_type varchar2 (32) NULL,
         call_date numeric  NULL,
         cap_strike FLOAT  NULL,
         cmp_frequency varchar2 (255) NULL,
         comments varchar2 (512) NULL,
         country varchar2 (32) NULL,
         coupon FLOAT  NULL,
         coupon_currency varchar2 (3) NULL,
         coupon_date_roll varchar2 (255) NULL,
         coupon_date_rule numeric  NULL,
         coupon_frequency varchar2 (255) NULL,
         coupon_holidays varchar2 (128) NULL,
         coupon_offset numeric  NULL,
         coupon_payment_type varchar2 (16) NULL,
         coupon_rounding_mthd varchar2 (255) NULL,
         dated_date numeric  NULL,
         daycount varchar2 (255) NULL,
         default_date numeric  NULL,
         disc_method numeric  NULL,
         face_value FLOAT  NULL,
         first_coupon_date numeric  NULL,
         flip_frequency varchar2 (255) NULL,
         flipper_date numeric  NULL,
         floor_strike FLOAT  NULL,
         fx_rate FLOAT  NULL,
         has_odd_first_coupon numeric  NULL,
         has_odd_last_coupon numeric  NULL,
         inactive_date numeric  NULL,
         ipa_le_id varchar2 (36) NULL,
         is_amortizing numeric  NULL,
         is_cpn_off_bus_day numeric  NULL,
         is_fixed numeric  NULL,
         is_floater numeric  NULL,
         is_reset_bus_lag numeric  NULL,
         is_reset_cutoff_bus_day numeric  NULL,
         is_reset_in_arrears numeric  NULL,
         issue_date numeric  NULL,
         issue_price FLOAT  NULL,
         issue_yield FLOAT  NULL,
         deliverable_lot_size FLOAT  NULL,
         issuer_le_id varchar2 (36) NULL,
         maturity_date numeric  NULL,
         maturity_tenor varchar2 (255) NULL,
         min_purchase_amt FLOAT  NULL,
         nominal_decimals numeric  NULL,
         option_type varchar2 (32) NULL,
         penult_cpn_date numeric  NULL,
         price_decimals numeric  NULL,
         price_rnd_mthd varchar2 (255) NULL,
         quote_type varchar2 (64) NULL,
         quoting_currency varchar2 (3) NULL,
         rate_index varchar2 (128) NULL,
         rate_index_factor FLOAT  NULL,
         rate_index_id varchar2 (36) NULL,
         rate_index_spread FLOAT  NULL,
         record_days numeric  NULL,
         redeem_days numeric  NULL,
         redem_currency varchar2 (3) NULL,
         redem_fx_rate FLOAT  NULL,
         redemption_price FLOAT  NULL,
         reset_avg_method varchar2 (18) NULL,
         reset_cmp_mthd varchar2 (32) NULL,
         reset_cutoff numeric  NULL,
         reset_days numeric  NULL,
         reset_frequency varchar2 (255) NULL,
         reset_holidays varchar2 (128) NULL,
         rolling_day numeric  NULL,
         rounding_unit numeric  NULL,
         sample_weekday numeric  NULL,
         settlement_days numeric  NULL,
         tick_size varchar2 (10) NULL,
         total_issued FLOAT  NULL,
         trustee_le_id varchar2 (36) NULL,
         value_days numeric  NULL,
         withholding_tax FLOAT  NULL,
         yield_decimals numeric  NULL,
         yield_method varchar2 (15) NULL,
         yield_rnd_mthd varchar2 (255) NULL,
         id varchar2 (36) NOT NULL,
         maturity_tenor_days numeric  NULL 
    ) 
/

    CREATE TABLE core_country (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         code varchar2 (255) NOT NULL,
         name varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_currency (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         code varchar2 (255) NOT NULL,
         country varchar2 (255) NULL,
         description varchar2 (255) NULL,
         rounding_decimal numeric  NOT NULL,
         rounding_method varchar2 (255) NOT NULL,
         data_source_id varchar2 (36) NULL 
    ) 
/

    CREATE TABLE core_currencypair (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         primary_currency varchar2 (255) NOT NULL,
         quoting_currency varchar2 (255) NOT NULL,
         data_source_id varchar2 (36) NULL 
    ) 
/

    CREATE TABLE core_data_policy (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         data_type varchar2 (255) NOT NULL,
         policy varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_equity (
        active_date numeric  NULL,
         comments varchar2 (255) NULL,
         corporate varchar2 (64) NULL,
         country varchar2 (32) NULL,
         dividend_currency varchar2 (3) NULL,
         dividend_date_rule numeric  NULL,
         dividend_decimals numeric  NULL,
         dividend_frequency varchar2 (255) NULL,
         equity_name varchar2 (32) NULL,
         equity_status varchar2 (32) NULL,
         exchange_code varchar2 (128) NULL,
         exchange_id varchar2 (36) NULL,
         fixing_type varchar2 (32) NULL,
         inactive_date numeric  NULL,
         is_pay_dividend numeric  NULL,
         nominal_decimals numeric  NULL,
         par_value FLOAT  NULL,
         quote_type varchar2 (64) NULL,
         subtype varchar2 (32) NULL,
         total_issued FLOAT  NULL,
         trading_country varchar2 (255) NULL,
         issuer_le_id varchar2 (36) NULL,
         trading_size FLOAT  NULL,
         id varchar2 (36) NOT NULL 
    ) 
/

    CREATE TABLE core_holiday (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         code varchar2 (255) NOT NULL,
         data_source_id varchar2 (36) NOT NULL,
         name varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_holiday_event (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         hol_date numeric  NOT NULL,
         description varchar2 (255) NULL,
         holiday_id varchar2 (36) NOT NULL 
    ) 
/

    CREATE TABLE core_index (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         currency varchar2 (255) NOT NULL,
         name varchar2 (255) NOT NULL,
         data_source_id varchar2 (36) NULL 
    ) 
/

    CREATE TABLE core_inflation_index (
        publication_lag numeric  NOT NULL,
         reference_day numeric  NOT NULL,
         id varchar2 (36) NOT NULL 
    ) 
/

    CREATE TABLE core_interest_config (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         effective_date numeric  NOT NULL,
         fixed_rate FLOAT  NULL,
         rate_index_id varchar2 (36) NULL,
         rate_type varchar2 (255) NOT NULL,
         spread FLOAT  NULL,
         day_count varchar2 (255) DEFAULT 'DC_30_360' NOT NULL 
    ) 
/

    CREATE TABLE core_junc_interest_config (
        account_interest_config_id0 varchar2 (255) NOT NULL,
         interest_config_id1 varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_le_address (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         address_line varchar2 (255) NULL,
         city varchar2 (255) NULL,
         country varchar2 (255) NOT NULL,
         postal_code varchar2 (255) NULL,
         state varchar2 (255) NULL 
    ) 
/

    CREATE TABLE core_le_contact (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         data_source_id varchar2 (36) NULL,
         email varchar2 (255) NOT NULL,
         first_name varchar2 (255) NOT NULL,
         last_name varchar2 (255) NOT NULL,
         legal_entity_id varchar2 (36) NOT NULL,
         phone_number varchar2 (255) NOT NULL,
         type varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_legal_entity (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         data_source_id varchar2 (36) NULL,
         financial numeric  NULL,
         legal_name varchar2 (255) NOT NULL,
         legal_short_name varchar2 (255) NOT NULL,
         lei varchar2 (255) NULL,
         parent_id varchar2 (255) NULL,
         ultimate_parent_id varchar2 (255) NULL,
         legaladdress_id varchar2 (36) NOT NULL 
    ) 
/

    CREATE TABLE core_legal_entity_roles (
        le_id varchar2 (36) NOT NULL,
         legal_role varchar2 (255) NULL 
    ) 
/

    CREATE TABLE core_pf_from_to (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         exclude_from numeric  NOT NULL,
         exclude_to numeric  NOT NULL,
         from_field varchar2 (255) NULL,
         from_long numeric  NULL,
         from_tenor varchar2 (255) NULL,
         name varchar2 (255) NOT NULL,
         to_field varchar2 (255) NULL,
         to_long numeric  NULL,
         to_tenor varchar2 (255) NULL,
         to_tenor_days numeric  NULL,
         from_tenor_days numeric  NULL 
    ) 
/

    CREATE TABLE core_pf_from_to_map (
        pf_criterion_from_to_id varchar2 (255) NOT NULL,
         pf_id varchar2 (36) NOT NULL 
    ) 
/

    CREATE TABLE core_pf_multi_value (
        pf_multiple_values_id varchar2 (36) NOT NULL,
         multiple_values varchar2 (4000) NULL,
         multiple_values_order numeric  NOT NULL 
    ) 
/

    CREATE TABLE core_pf_multi_values (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         included numeric  NOT NULL,
         name varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_pf_multi_values_map (
        pf_criterion_multi_val_id varchar2 (255) NOT NULL,
         pf_id varchar2 (36) NOT NULL 
    ) 
/

    CREATE TABLE core_product (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         currency varchar2 (3) NULL,
         description varchar2 (255) NULL,
         type varchar2 (64) NOT NULL,
         subtype varchar2 (64) NOT NULL,
         product_type varchar2 (64) NULL,
         quote_name varchar2 (64) NULL,
         source varchar2 (64) NULL,
         data_source_id varchar2 (36) NULL 
    ) 
/

    CREATE TABLE core_product_filter (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         name varchar2 (255) NOT NULL,
         sub_filter_id varchar2 (36) NULL,
         product_type varchar2 (255) NULL 
    ) 
/

    CREATE TABLE core_product_put_call_schedule (
        bond_id0 varchar2 (255) NOT NULL,
         put_call_date_id1 varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_product_sec_attribute (
        product_id2 varchar2 (255) NOT NULL,
         security_attribute_id3 varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_product_sec_id (
        security_id0 varchar2 (255) NOT NULL,
         security_identifier_id1 varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_put_call_date (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         exercise_style varchar2 (255) NOT NULL,
         expiry_date numeric  NOT NULL,
         first_exercise_date numeric  NULL,
         option_type varchar2 (255) NOT NULL,
         strike FLOAT  NOT NULL 
    ) 
/

    CREATE TABLE core_quote_definition (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         market_quote_type varchar2 (255) NOT NULL,
         quote_name varchar2 (255) NOT NULL,
         source_quotable_id varchar2 (36) NOT NULL,
         source_quotable_type varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_quote_set (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         description varchar2 (255) NOT NULL,
         quote_set_name varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_rate_index (
        date_roll varchar2 (255) NOT NULL,
         day_count varchar2 (255) NOT NULL,
         reset_days numeric  NOT NULL,
         source varchar2 (255) NOT NULL,
         tenor varchar2 (255) NOT NULL,
         id varchar2 (36) NOT NULL,
         tenor_days numeric  NULL 
    ) 
/

    CREATE TABLE core_rateindexresetholidays (
        rate_idx_id varchar2 (36) NOT NULL,
         reset_holidays_ids varchar2 (255) NULL 
    ) 
/

    CREATE TABLE core_rating (
        rating_agn_id varchar2 (36) NOT NULL,
         available_ratings varchar2 (255) NULL,
         available_ratings_order numeric  NOT NULL 
    ) 
/

    CREATE TABLE core_rating_agency (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         name varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_rating_le (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         agency_id varchar2 (36) NOT NULL,
         effective_date numeric  NOT NULL,
         legal_entity_id varchar2 (36) NOT NULL,
         seniority varchar2 (255) NOT NULL,
         value varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE core_security (
        id varchar2 (36) NOT NULL,
         country varchar2 (36) NULL,
         source varchar2 (36) NULL,
         regulatory_id varchar2 (36) NULL 
    ) 
/

    CREATE TABLE core_regulatory (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         esma varchar2 (4) NULL,
         ftc varchar2 (4) NULL,
         jfa varchar2 (4) NULL 
    ) 
/

    CREATE TABLE core_security_attribute (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         name varchar2 (255) NOT NULL,
         value varchar2 (32) NOT NULL 
    ) 
/

    CREATE TABLE core_security_identifier (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         type varchar2 (255) NOT NULL,
         value varchar2 (32) NOT NULL 
    ) 
/

    CREATE TABLE core_settlement_account (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         account_identifier varchar2 (255) NOT NULL,
         agent_id varchar2 (36) NOT NULL,
         currency varchar2 (255) NOT NULL,
         name varchar2 (255) NOT NULL,
         settle_type varchar2 (255) NOT NULL,
         data_source_id varchar2 (36) NULL 
    ) 
/

    CREATE TABLE core_split_currency (
        id varchar2 (36) NOT NULL,
         creation_date numeric  NULL,
         creation_user varchar2 (255) NULL,
         creation_user_type varchar2 (255) NULL,
         tenant_id numeric  NOT NULL,
         last_update_date numeric  NULL,
         last_update_user varchar2 (255) NULL,
         last_update_user_type varchar2 (255) NULL,
         version numeric  NOT NULL,
         primary_currency varchar2 (255) NOT NULL,
         quoting_currency varchar2 (255) NOT NULL,
         split_currency varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cls_schedule (
        schedule_id numeric  NOT NULL,
         version_num numeric  NOT NULL,
         clsb_reference varchar2 (22) NOT NULL,
         party_id numeric  NOT NULL,
         timestamp timestamp  DEFAULT TIMESTAMP'1970-01-01 00:00:00.0' NOT NULL,
         value_date timestamp  DEFAULT TIMESTAMP'1970-01-01 00:00:00.0' NOT NULL,
         type varchar2 (32) NOT NULL,
         timing varchar2 (32) NOT NULL,
         sttlm_session varchar2 (16) NOT NULL,
         acknowledged numeric  NOT NULL,
         ack_identifier varchar2 (32) NULL,
         xml_message clob  NULL 
    ) 
/

    CREATE TABLE cls_schedule_item (
        schedule_id numeric  NOT NULL,
         currency varchar2 (3) NOT NULL,
         amount float  NOT NULL,
         deadline timestamp  NULL,
         type varchar2 (20) NOT NULL 
    ) 
/

    CREATE TABLE cls_message (
        id numeric  NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         message_id varchar2 (4) NOT NULL,
         sub_message_id varchar2 (10) NOT NULL,
         clsb_reference varchar2 (22) NOT NULL,
         settlement_session varchar2 (16) NULL,
         event_param varchar2 (128) NULL,
         timestamp timestamp  DEFAULT TIMESTAMP'1970-01-01 00:00:00.0' NOT NULL,
         content varchar2 (2000) NOT NULL,
         needs_ack numeric  DEFAULT 0 NOT NULL,
         acknowledged numeric  DEFAULT 0 NOT NULL,
         ack_timestamp timestamp  NULL,
         ack_identifier varchar2 (32) NULL,
         recipient numeric  NULL,
         xml_message varchar2 (4000) NULL 
    ) 
/

    CREATE TABLE cls_reco (
        schedule_id numeric  NOT NULL,
         currency varchar2 (3) NOT NULL,
         reco_time timestamp  DEFAULT TIMESTAMP'1970-01-01 00:00:00.0' NOT NULL,
         cls_amount float  NULL,
         calypso_amount float  NULL 
    ) 
/

    CREATE TABLE cls_trade_info (
        id numeric  NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         trade_id numeric  NOT NULL,
         statement_id numeric  NOT NULL,
         total_splits numeric  DEFAULT 0 NULL,
         settled_splits numeric  DEFAULT 0 NULL,
         po_suspended numeric  DEFAULT 0 NOT NULL,
         cp_suspended numeric  DEFAULT 0 NOT NULL,
         notif_seq_no varchar2 (22) NOT NULL,
         clsb_ref varchar2 (22) NOT NULL,
         matching_ref varchar2 (22) NULL,
         matched_side_ref varchar2 (22) NULL,
         is_alleged numeric  DEFAULT 0 NOT NULL,
         status varchar2 (17) NOT NULL,
         sub_status varchar2 (16) NULL,
         status_subtype varchar2 (16) NULL,
         settlement_session varchar2 (16) NOT NULL,
         is_split_trade numeric  DEFAULT 0 NOT NULL,
         timestamp timestamp  DEFAULT TIMESTAMP'1970-01-01 00:00:00.0' NOT NULL,
         valuedate timestamp  DEFAULT TIMESTAMP'1970-01-01 00:00:00.0' NOT NULL,
         tradedate timestamp  DEFAULT TIMESTAMP'1970-01-01 00:00:00.0' NOT NULL,
         buy_amount float  NOT NULL,
         buy_currency varchar2 (3) NOT NULL,
         sell_amount float  NOT NULL,
         sell_currency varchar2 (3) NOT NULL,
         rate float  NOT NULL,
         originator_ref varchar2 (16) NOT NULL,
         common_ref varchar2 (16) NULL,
         related_ref varchar2 (16) NULL,
         last_instr_ref varchar2 (16) NULL,
         cpty_ref varchar2 (16) NULL,
         originator_sm varchar2 (11) NOT NULL,
         originator_name varchar2 (200) NULL,
         originator_bic varchar2 (11) NULL,
         originator_lei varchar2 (32) NULL,
         fund_lei varchar2 (32) NULL,
         fund_idr varchar2 (11) NULL,
         fund_name varchar2 (32) NULL,
         custodian_idr varchar2 (32) NULL,
         counterparty_sm varchar2 (11) NOT NULL,
         counterparty_name varchar2 (200) NULL,
         counterparty_bic varchar2 (11) NULL,
         cpty_lei varchar2 (32) NULL,
         cpty_fund_idr varchar2 (11) NULL,
         cpty_fund_name varchar2 (32) NULL,
         cpty_custodian_idr varchar2 (32) NULL,
         unq_tx_idr varchar2 (64) NULL,
         prior_unq_tx_idr varchar2 (64) NULL,
         cpty_unq_tx_idr varchar2 (64) NULL,
         cpty_prior_unq_tx_idr varchar2 (64) NULL,
         product_type varchar2 (16) NULL,
         operation_scope varchar2 (16) NULL,
         sender_receiver_info varchar2 (210) NULL,
         reporting_jurisdiction varchar2 (32) NULL,
         execution_venue varchar2 (64) NULL,
         execution_timestamp timestamp  DEFAULT TIMESTAMP'1970-01-01 00:00:00.0' NULL,
         third_party_id varchar2 (64) NULL,
         third_party_ref varchar2 (64) NULL,
         third_party_specific1 varchar2 (64) NULL,
         third_party_specific2 varchar2 (64) NULL,
         third_party_specific3 varchar2 (64) NULL,
         cls_type varchar2 (64) DEFAULT 'House' NULL 
    ) 
/

    CREATE TABLE cls_non_repudiation (
        snf_ref varchar2 (128) NOT NULL,
         snf_session varchar2 (128) NOT NULL,
         snf_outout_seq numeric  NOT NULL,
         snf_delivery_time timestamp  NOT NULL,
         retrieved numeric  DEFAULT 0 NOT NULL,
         doc_type varchar2 (16) NULL,
         nr_message blob  NULL 
    ) 
/

    CREATE TABLE cls_account_notification (
        id numeric  NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         trade_id numeric  DEFAULT 0 NOT NULL,
         clsb_reference varchar2 (35) NOT NULL,
         value_date timestamp  DEFAULT TIMESTAMP'1970-01-01 00:00:00.0' NOT NULL,
         booking_date timestamp  DEFAULT TIMESTAMP'1970-01-01 00:00:00.0' NOT NULL,
         currency varchar2 (3) NOT NULL,
         amount float  NOT NULL,
         direction varchar2 (4) NOT NULL,
         movement_ref varchar2 (35) NOT NULL,
         owner varchar2 (140) NULL,
         central_bank_ref varchar2 (35) NULL,
         ordering_bank_ref varchar2 (35) NULL,
         xml_message varchar2 (4000) NULL 
    ) 
/

    CREATE TABLE cdsabs_markit_flows_version (
        product_id numeric  NOT NULL,
         version_number numeric  NOT NULL 
    ) 
/

    CREATE TABLE margin_run_info (
        margin_hierarchy varchar2 (64) NOT NULL,
         calculation_set varchar2 (250) NOT NULL,
         eod numeric  DEFAULT 1 NOT NULL,
         margin_data_type varchar2 (64) NOT NULL,
         valuation_date timestamp  NOT NULL,
         valuation_date_time timestamp  NOT NULL,
         time_zone varchar2 (64) NULL 
    ) 
/

    CREATE TABLE margin_mfm_multiplier (
        aggregation_key varchar2 (64) NOT NULL,
         etl_lower_bound float  NOT NULL,
         etl_upper_bound float  NOT NULL,
         value float  NOT NULL 
    ) 
/

    ALTER TABLE MARGIN_ADDON ADD description varchar2 (250)  NULL
/

    ALTER TABLE MARGIN_ADDON_HIST ADD description varchar2 (250)  NULL
/

    CREATE TABLE margin_addon_temp (
        currency varchar2 (3) NOT NULL,
         valuation_date timestamp  NOT NULL,
         margin_agreement_name varchar2 (250) NOT NULL,
         value float  NOT NULL,
         add_on_type varchar2 (250) NOT NULL,
         description varchar2 (250) NULL 
    ) 
/

    ALTER TABLE MARGIN_LIQUIDITY ADD eod numeric DEFAULT 1 NOT NULL
/

    ALTER TABLE MARGIN_TRADE_LIQUIDITY ADD eod numeric DEFAULT 1 NOT NULL
/

    CREATE TABLE margin_unsettled_vm_temp (
        margin_agreement_name varchar2 (250) NOT NULL,
         amount float  NOT NULL,
         valuation_date timestamp  NOT NULL,
         currency varchar2 (3) NOT NULL,
         version numeric  DEFAULT 0 NOT NULL 
    ) 
/

    ALTER TABLE MARGIN_TRADE_VM ADD (po_view numeric DEFAULT 0 NOT NULL,eod numeric DEFAULT 1 NOT NULL,im_portfolio_name varchar2 (250)  NULL,calculation_set varchar2 (250)  NULL,po numeric DEFAULT 0 NOT NULL)
/

    ALTER TABLE MARGIN_TRADE_VM_HIST ADD (po_view numeric DEFAULT 0 NOT NULL,eod numeric DEFAULT 1 NOT NULL,im_portfolio_name varchar2 (250)  NULL,calculation_set varchar2 (250)  NULL,po numeric DEFAULT 0 NOT NULL)
/

    CREATE TABLE margin_trade_vm_temp (
        trade_id varchar2 (60) NOT NULL,
         po_view numeric  DEFAULT 0 NOT NULL,
         valuation_date timestamp  NOT NULL,
         currency varchar2 (3) NULL,
         eod numeric  DEFAULT 1 NOT NULL,
         margin_agreement_name varchar2 (250) NOT NULL,
         im_portfolio_name varchar2 (250) NOT NULL,
         calculation_set varchar2 (250) NOT NULL,
         vm float  NOT NULL,
         vm_collaterized float  DEFAULT 0 NOT NULL,
         vm_cash float  NOT NULL,
         npv float  NOT NULL,
         npv_adj float  NOT NULL,
         pai float  NOT NULL,
         vm_exposure float  NOT NULL,
         leg_direction varchar2 (60) NULL,
         po numeric  DEFAULT 0 NOT NULL,
         additional_measure_1 float  NOT NULL,
         additional_measure_2 float  NOT NULL,
         additional_measure_3 float  NOT NULL,
         additional_measure_4 float  NOT NULL,
         additional_measure_5 float  NOT NULL,
         additional_measure_6 float  NOT NULL,
         additional_measure_7 float  NOT NULL,
         additional_measure_8 float  NOT NULL,
         additional_measure_9 float  NOT NULL,
         additional_measure_10 float  NOT NULL,
         additional_measure_11 float  NOT NULL,
         additional_measure_12 float  NOT NULL,
         additional_measure_13 float  NOT NULL,
         additional_measure_14 float  NOT NULL,
         additional_measure_15 float  NOT NULL 
    ) 
/

    ALTER TABLE MARGIN_PORTFOLIO_VM ADD (eod numeric DEFAULT 1 NOT NULL,im_portfolio_name varchar2 (250)  NULL,calculation_set varchar2 (250)  NULL,po_view numeric DEFAULT 0 NULL)
/

    ALTER TABLE MARGIN_PORTFOLIO_VM_HIST ADD (eod numeric DEFAULT 1 NOT NULL,im_portfolio_name varchar2 (250)  NULL,calculation_set varchar2 (250)  NULL,po_view numeric DEFAULT 0 NULL)
/

    CREATE TABLE margin_portfolio_vm_temp (
        version numeric  DEFAULT 0 NOT NULL,
         valuation_date timestamp  NOT NULL,
         currency varchar2 (3) NULL,
         eod numeric  DEFAULT 1 NOT NULL,
         margin_agreement_name varchar2 (250) NOT NULL,
         im_portfolio_name varchar2 (250) NOT NULL,
         calculation_set varchar2 (250) NOT NULL,
         vm float  NOT NULL,
         vm_collaterized float  DEFAULT 0 NOT NULL,
         vm_cash float  NOT NULL,
         npv float  NOT NULL,
         npv_adj float  NOT NULL,
         pai float  NOT NULL,
         vm_exposure float  NOT NULL,
         additional_measure_1 float  NOT NULL,
         additional_measure_2 float  NOT NULL,
         additional_measure_3 float  NOT NULL,
         additional_measure_4 float  NOT NULL,
         additional_measure_5 float  NOT NULL,
         additional_measure_6 float  NOT NULL,
         additional_measure_7 float  NOT NULL,
         additional_measure_8 float  NOT NULL,
         additional_measure_9 float  NOT NULL,
         additional_measure_10 float  NOT NULL,
         additional_measure_11 float  NOT NULL,
         additional_measure_12 float  NOT NULL,
         additional_measure_13 float  NOT NULL,
         additional_measure_14 float  NOT NULL,
         additional_measure_15 float  NOT NULL,
         po_view numeric  DEFAULT 0 NULL 
    ) 
/

    ALTER TABLE MARGIN_RESULT ADD (eod numeric DEFAULT 1 NOT NULL,wcl float DEFAULT 0.0 NULL,var float DEFAULT 0.0 NULL,credit_multiplier float DEFAULT 0.0 NULL,holiday_multiplier float DEFAULT 0.0 NULL,calibration_margin float DEFAULT 0.0 NULL,calibration_multiplier float DEFAULT 0.0 NULL,mfm_add_on float DEFAULT 0.0 NULL,liquidity_add_on float DEFAULT 0.0 NULL,status varchar2 (255)  DEFAULT 'Unknown' NOT NULL,service varchar2 (255)  DEFAULT 'MARGIN-OTC' NOT NULL,calculation_request_id varchar2 (64)  NULL,calculation_set varchar2 (64)  DEFAULT 'Default' NOT NULL,time_horizon varchar2 (255)  NULL)
/

    ALTER TABLE MARGIN_RESULT_HIST ADD (eod numeric DEFAULT 1 NOT NULL,wcl float DEFAULT 0.0 NULL,var float DEFAULT 0.0 NULL,credit_multiplier float DEFAULT 0.0 NULL,holiday_multiplier float DEFAULT 0.0 NULL,calibration_margin float DEFAULT 0.0 NULL,calibration_multiplier float DEFAULT 0.0 NULL,mfm_add_on float DEFAULT 0.0 NULL,liquidity_add_on float DEFAULT 0.0 NULL,status varchar2 (255)  DEFAULT 'Unknown' NOT NULL,service varchar2 (255)  DEFAULT 'MARGIN-OTC' NOT NULL,calculation_request_id varchar2 (64)  NULL,calculation_set varchar2 (64)  DEFAULT 'Default' NOT NULL,time_horizon varchar2 (255)  NULL)
/

    CREATE TABLE margin_result_temp (
        id varchar2 (64) NOT NULL,
         version numeric  DEFAULT 0 NULL,
         account_id varchar2 (64) NOT NULL,
         eod numeric  DEFAULT 1 NOT NULL,
         currency varchar2 (3) NOT NULL,
         valuation_date timestamp  NOT NULL,
         additionalim float  DEFAULT 0.0 NULL,
         scheduleim float  DEFAULT 0.0 NULL,
         simmim float  DEFAULT 0.0 NULL,
         totalim float  DEFAULT 0.0 NULL,
         maintenance float  DEFAULT 0.0 NULL,
         nov float  DEFAULT 0.0 NULL,
         regulator varchar2 (255) NULL,
         direction varchar2 (255) NOT NULL,
         methodology varchar2 (255) NOT NULL,
         etl float  DEFAULT 0.0 NULL,
         wcl float  DEFAULT 0.0 NULL,
         var float  DEFAULT 0.0 NULL,
         discretionary_margin float  DEFAULT 0.0 NULL,
         credit_margin float  DEFAULT 0.0 NULL,
         holiday_margin float  DEFAULT 0.0 NULL,
         credit_multiplier float  DEFAULT 0.0 NULL,
         holiday_multiplier float  DEFAULT 0.0 NULL,
         calibration_margin float  DEFAULT 0.0 NULL,
         calibration_multiplier float  DEFAULT 0.0 NULL,
         mfm_add_on float  DEFAULT 0.0 NULL,
         liquidity_add_on float  DEFAULT 0.0 NULL,
         status varchar2 (255) DEFAULT 'Unknown' NOT NULL,
         service varchar2 (255) DEFAULT 'MARGIN-OTC' NOT NULL,
         calculation_request_id varchar2 (64) NOT NULL,
         calculation_set varchar2 (64) DEFAULT 'Default' NOT NULL,
         time_horizon varchar2 (255) NULL 
    ) 
/

    CREATE TABLE margin_result_errors_temp (
        error_messages varchar2 (255) NOT NULL,
         tree_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE margin_result_node_temp (
        id varchar2 (64) NOT NULL,
         version numeric  DEFAULT 0 NULL,
         node_name varchar2 (250) NOT NULL,
         currency varchar2 (3) NOT NULL,
         attribute_key varchar2 (255) NULL,
         depth numeric  NOT NULL,
         node_index numeric  NOT NULL,
         numeric_value float  DEFAULT 0.0 NULL,
         string_value varchar2 (255) NULL,
         tree_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE audit_record (
        id varchar2 (64) NOT NULL,
         version numeric  NOT NULL,
         tenant_id numeric  NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         creation_user_type varchar2 (255) DEFAULT 'user' NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         last_update_user_type varchar2 (255) DEFAULT 'user' NOT NULL,
         capture_time numeric  NOT NULL,
         acting_user_type varchar2 (255) NOT NULL,
         acting_user_id varchar2 (64) NOT NULL,
         app varchar2 (64) NOT NULL,
         type varchar2 (64) NOT NULL,
         class_name varchar2 (255) NOT NULL,
         entity_id varchar2 (64) NOT NULL,
         entity_version_before numeric  NOT NULL,
         property varchar2 (255) NULL,
         before varchar2 (255) NULL,
         after varchar2 (255) NULL,
         group_tag varchar2 (64) NOT NULL,
         recalled numeric  NOT NULL 
    ) 
/

    ALTER TABLE BLOOM_BOND_MAP ADD version_num numeric DEFAULT 1 NOT NULL
/

    ALTER TABLE SEND_CONFIG ADD (by_jms_b numeric DEFAULT 0 NOT NULL,jms_name varchar2 (32)  NULL)
/

    ALTER TABLE CALYPSO_CACHE ADD cache_limit numeric DEFAULT 100000 NOT NULL
/

    ALTER TABLE BLOOMBERG_VALUES ADD version_num numeric DEFAULT 1 NOT NULL
/

    ALTER TABLE BLOOM_DAYCNT_MAP ADD version_num numeric DEFAULT 1 NOT NULL
/

    ALTER TABLE BLOOM_HEADER_OPT ADD version_num numeric DEFAULT 1 NOT NULL
/

    ALTER TABLE LEGAL_ENTITY ADD anonymized numeric DEFAULT 0 NOT NULL
/

    CREATE TABLE cm_result (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         account_id varchar2 (64) NOT NULL,
         currency varchar2 (3) NOT NULL,
         direction varchar2 (255) NOT NULL,
         regulator varchar2 (255) NULL,
         valuation_date numeric  NOT NULL,
         status varchar2 (255) DEFAULT 'COMPLETED' NOT NULL,
         additionalim float  NOT NULL,
         scheduleim float  NOT NULL,
         simmim float  NOT NULL,
         totalim float  NOT NULL,
         totalimusd float  NOT NULL,
         maintenance float  NOT NULL,
         etl float  DEFAULT 0 NOT NULL,
         wcl float  DEFAULT 0 NOT NULL,
         calibration_multiplier float  DEFAULT 0.0 NULL,
         calibration_margin float  DEFAULT 0.0 NULL,
         discretionary_margin float  DEFAULT 0 NOT NULL,
         credit_margin float  DEFAULT 0 NOT NULL,
         holiday_margin float  DEFAULT 0 NOT NULL,
         nov float  NOT NULL,
         var float  DEFAULT 0 NOT NULL,
         credit_multiplier float  DEFAULT 0.0 NULL,
         holiday_multiplier float  DEFAULT 0.0 NULL,
         mfm_add_on float  DEFAULT 0.0 NULL,
         liquidity_add_on float  DEFAULT 0.0 NULL,
         calculationsummary_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_result_errors (
        error_messages varchar2 (255) NOT NULL,
         tree_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_calculation_summary (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         status varchar2 (255) NOT NULL,
         service varchar2 (255) NOT NULL,
         calculation_request_id varchar2 (64) NOT NULL,
         calculation_set_id varchar2 (64) NOT NULL,
         time_horizon varchar2 (255) NULL 
    ) 
/

    CREATE TABLE cm_result_node (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         node_name varchar2 (255) NOT NULL,
         currency varchar2 (3) NOT NULL,
         tree_id varchar2 (64) NOT NULL,
         depth numeric  NOT NULL,
         node_index numeric  NOT NULL,
         attribute_key varchar2 (255) NULL,
         string_value varchar2 (255) NULL,
         numeric_value float  NULL 
    ) 
/

    CREATE TABLE cm_result_hist (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         account_id varchar2 (64) NOT NULL,
         currency varchar2 (3) NOT NULL,
         direction varchar2 (255) NOT NULL,
         regulator varchar2 (255) NULL,
         valuation_date numeric  NOT NULL,
         status varchar2 (255) DEFAULT 'COMPLETED' NOT NULL,
         additionalim float  NOT NULL,
         scheduleim float  NOT NULL,
         simmim float  NOT NULL,
         totalim float  NOT NULL,
         totalimusd float  NOT NULL,
         maintenance float  NOT NULL,
         etl float  DEFAULT 0 NOT NULL,
         wcl float  DEFAULT 0 NOT NULL,
         calibration_multiplier float  DEFAULT 0.0 NULL,
         calibration_margin float  DEFAULT 0.0 NULL,
         discretionary_margin float  DEFAULT 0 NOT NULL,
         credit_margin float  DEFAULT 0 NOT NULL,
         holiday_margin float  DEFAULT 0 NOT NULL,
         nov float  NOT NULL,
         var float  DEFAULT 0 NOT NULL,
         credit_multiplier float  DEFAULT 0.0 NULL,
         holiday_multiplier float  DEFAULT 0.0 NULL,
         mfm_add_on float  DEFAULT 0.0 NULL,
         liquidity_add_on float  DEFAULT 0.0 NULL,
         calculationsummary_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_result_temp (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         account_id varchar2 (64) NOT NULL,
         currency varchar2 (3) NOT NULL,
         direction varchar2 (255) NOT NULL,
         regulator varchar2 (255) NULL,
         valuation_date numeric  NOT NULL,
         status varchar2 (255) DEFAULT 'COMPLETED' NOT NULL,
         additionalim float  NOT NULL,
         scheduleim float  NOT NULL,
         simmim float  NOT NULL,
         totalim float  NOT NULL,
         totalimusd float  NOT NULL,
         maintenance float  NOT NULL,
         etl float  DEFAULT 0 NOT NULL,
         wcl float  DEFAULT 0 NOT NULL,
         calibration_multiplier float  DEFAULT 0.0 NULL,
         calibration_margin float  DEFAULT 0.0 NULL,
         discretionary_margin float  DEFAULT 0 NOT NULL,
         credit_margin float  DEFAULT 0 NOT NULL,
         holiday_margin float  DEFAULT 0 NOT NULL,
         nov float  NOT NULL,
         var float  DEFAULT 0 NOT NULL,
         credit_multiplier float  DEFAULT 0.0 NULL,
         holiday_multiplier float  DEFAULT 0.0 NULL,
         mfm_add_on float  DEFAULT 0.0 NULL,
         liquidity_add_on float  DEFAULT 0.0 NULL,
         calculationsummary_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_result_errors_hist (
        error_messages varchar2 (255) NOT NULL,
         tree_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_result_errors_temp (
        error_messages varchar2 (255) NOT NULL,
         tree_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_calculation_summary_hist (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         status varchar2 (255) NOT NULL,
         service varchar2 (255) NOT NULL,
         calculation_request_id varchar2 (64) NOT NULL,
         time_horizon varchar2 (255) NULL,
         calculation_set_id varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_calculation_summary_temp (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         status varchar2 (255) NOT NULL,
         service varchar2 (255) NOT NULL,
         calculation_request_id varchar2 (64) NOT NULL,
         time_horizon varchar2 (255) NULL,
         calculation_set_id varchar2 (255) NULL 
    ) 
/

    CREATE TABLE cm_result_node_hist (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         node_name varchar2 (255) NOT NULL,
         currency varchar2 (3) NOT NULL,
         tree_id varchar2 (64) NOT NULL,
         depth numeric  NOT NULL,
         node_index numeric  NOT NULL,
         attribute_key varchar2 (255) NULL,
         string_value varchar2 (255) NULL,
         numeric_value float  NULL 
    ) 
/

    CREATE TABLE cm_result_node_temp (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         node_name varchar2 (255) NOT NULL,
         currency varchar2 (3) NOT NULL,
         tree_id varchar2 (64) NOT NULL,
         depth numeric  NOT NULL,
         node_index numeric  NOT NULL,
         attribute_key varchar2 (255) NULL,
         string_value varchar2 (255) NULL,
         numeric_value float  NULL 
    ) 
/

    CREATE TABLE cm_simm_regulator (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         name varchar2 (32) NOT NULL 
    ) 
/

    CREATE TABLE cm_account (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         name varchar2 (255) NOT NULL,
         currency varchar2 (3) NOT NULL,
         methodology varchar2 (255) NOT NULL,
         accountdetails_id varchar2 (64) NOT NULL,
         calculator_type varchar2 (255) NULL,
         csadetails_id varchar2 (64) NULL 
    ) 
/

    CREATE TABLE cm_account_details (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL 
    ) 
/

    CREATE TABLE cm_etd_accounts (
        id varchar2 (64) NOT NULL,
         origin varchar2 (255) NULL,
         activity_type varchar2 (255) NULL 
    ) 
/

    CREATE TABLE cm_simm_accounts (
        id varchar2 (64) NOT NULL,
         active_from numeric  NULL,
         active_to numeric  NULL 
    ) 
/

    CREATE TABLE cm_simm_account (
        id varchar2 (64) NOT NULL,
         active_from numeric  NULL,
         active_to numeric  NULL,
         post_currency varchar2 (3) DEFAULT 'XXX' NOT NULL,
         collect_currency varchar2 (3) DEFAULT 'XXX' NOT NULL,
         post_threshold float  DEFAULT 0 NOT NULL,
         collect_threshold float  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_post_regulators (
        post_regulators varchar2 (255) NOT NULL,
         simmmarginaccount_id varchar2 (64) NULL 
    ) 
/

    CREATE TABLE cm_simm_collect_regulators (
        collect_regulators varchar2 (255) NOT NULL,
         simmmarginaccount_id varchar2 (64) NULL 
    ) 
/

    CREATE TABLE cm_simm_regulator_parameters (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         regulator varchar2 (255) NOT NULL,
         simmmarginaccount_id varchar2 (64) NULL 
    ) 
/

    CREATE TABLE cm_simm_parameters (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         parameter_type varchar2 (255) NOT NULL,
         regulatorparameter_id varchar2 (64) NOT NULL,
         value float  NULL,
         criteria varchar2 (255) NULL 
    ) 
/

    CREATE TABLE cm_flat_simm_param (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         regulator varchar2 (32) NOT NULL,
         accountdetails_id varchar2 (64) NULL,
         direction varchar2 (16) NULL,
         parameter_type varchar2 (255) NULL,
         value float  NULL,
         criteria varchar2 (255) NULL 
    ) 
/

    CREATE TABLE cm_whatif_result (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         request_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_whatif_result_detail (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         account_id varchar2 (64) NOT NULL,
         currency varchar2 (3) NOT NULL,
         valuation_date numeric  NOT NULL,
         totalim float  NOT NULL,
         fx_rate float  NOT NULL,
         threshold float  NOT NULL 
    ) 
/

    CREATE TABLE cm_whatif_result_before (
        result_id varchar2 (64) NOT NULL,
         detail_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_whatif_result_after (
        result_id varchar2 (64) NOT NULL,
         detail_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_isda_product_type (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         product_type varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_im_th_monitoring_config (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         csa_trigger float  NOT NULL,
         history_length varchar2 (7) NOT NULL 
    ) 
/

    CREATE TABLE cm_im_th_monitoring_result (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         tree_id varchar2 (64) NOT NULL,
         account_id varchar2 (64) NOT NULL,
         calculation_set_id varchar2 (64) NOT NULL,
         direction varchar2 (255) NOT NULL,
         threshold_status varchar2 (255) NOT NULL,
         csa_status varchar2 (255) NOT NULL,
         currency varchar2 (3) NOT NULL,
         valuation_date numeric  NOT NULL,
         threshold float  NOT NULL,
         threshold_utilization float  NOT NULL,
         totalim float  NOT NULL,
         csa_trigger float  NOT NULL 
    ) 
/

    CREATE TABLE cm_csa_account_details (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         csa_status varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE reuters_open_dacs_entitlement (
        feed_name varchar2 (32) NOT NULL,
         feed_address varchar2 (255) NOT NULL,
         dacs_lock blob  NOT NULL 
    ) 
/

    CREATE TABLE reutersdss_config_name (
        config_id numeric  NOT NULL,
         config_name varchar2 (64) NOT NULL,
         rpt_typ varchar2 (32) NOT NULL,
         config_status numeric  NULL,
         rpt_tmplt_id numeric  NOT NULL,
         rpt_col_id numeric  NOT NULL,
         instrument_id numeric  NOT NULL,
         schedules_id numeric  NOT NULL,
         output_filename varchar2 (255) NULL,
         pricingenv varchar2 (100) NULL,
         updated_date_time timestamp  NULL,
         updated_by varchar2 (32) NULL,
         version_num numeric  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE reutersdss_rpt_templates (
        rpt_tmplt_id numeric  NOT NULL,
         rpt_typ varchar2 (32) NOT NULL,
         rpt_tmplt_name varchar2 (64) NOT NULL,
         compress_format varchar2 (10) NULL,
         report_template_type varchar2 (10) NULL,
         header varchar2 (2) NULL,
         start_date timestamp  NULL,
         end_date timestamp  NULL,
         curry_scaling varchar2 (2) NULL,
         delta_extract varchar2 (2) NULL,
         delta_extract_date timestamp  NULL,
         delta_extract_days numeric  NOT NULL,
         fitch_rating varchar2 (2) NULL,
         moody_rating varchar2 (2) NULL,
         sp_rating varchar2 (2) NULL,
         updated_date_time timestamp  NULL,
         updated_by varchar2 (255) NULL,
         version_num numeric  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE reutersdss_rpt_cols (
        rpt_col_id numeric  NOT NULL,
         rpt_col_tmplt_name varchar2 (64) NOT NULL,
         rpt_typ varchar2 (32) NOT NULL,
         col_name varchar2 (255) NOT NULL,
         mapping_type varchar2 (255) NULL,
         sequence numeric  NOT NULL,
         updated_date_time timestamp  NULL,
         updated_by varchar2 (32) NULL,
         version_num numeric  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE reutersdss_instruments (
        instrument_id numeric  NOT NULL,
         instrument_tmplt_name varchar2 (64) NOT NULL,
         rpt_typ varchar2 (32) NOT NULL,
         iden_name varchar2 (255) NOT NULL,
         iden_type varchar2 (40) NOT NULL,
         iden_desc varchar2 (64) NOT NULL,
         prod_type varchar2 (60) NULL,
         updated_date_time timestamp  NULL,
         updated_by varchar2 (32) NULL,
         version_num numeric  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE reutersdss_schedules (
        schedules_id numeric  NOT NULL,
         schedules_tmplt_name varchar2 (64) NOT NULL,
         rpt_typ varchar2 (32) NOT NULL,
         price_flag varchar2 (30) NULL,
         extract_time varchar2 (255) NULL,
         eod_price_typ varchar2 (10) NULL,
         extract_expiry_time timestamp  NULL,
         extract_expiry_day varchar2 (1) NULL,
         extract_days timestamp  NULL,
         extract_days_typ varchar2 (32) NULL,
         extract_weekly_days varchar2 (20) NULL,
         extract_monthly varchar2 (20) NULL,
         updated_date_time timestamp  NULL,
         updated_by varchar2 (32) NULL,
         version_num numeric  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE reutersdss_mapping (
        intf_type varchar2 (50) NOT NULL,
         typename varchar2 (96) NOT NULL,
         intf_value varchar2 (255) NOT NULL,
         calypso_value varchar2 (255) NULL,
         complex_typ varchar2 (255) NULL,
         version_num numeric  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE reutersdss_mapping_rules (
        id numeric  NOT NULL,
         intf_value varchar2 (64) NOT NULL,
         calypso_value varchar2 (64) NULL,
         rule_name varchar2 (255) NOT NULL,
         rule_value varchar2 (255) NOT NULL,
         rule_group varchar2 (64) NOT NULL,
         mandatory varchar2 (10) NULL,
         version_num numeric  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE reutersdss_prod_mapping (
        id numeric  NOT NULL,
         product_type varchar2 (255) NOT NULL,
         template_name varchar2 (255) NULL,
         sub_type varchar2 (255) NULL,
         description varchar2 (255) NULL,
         version_num numeric  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE tr_reporting_attr (
        reporting_attribute_id numeric  NOT NULL,
         version numeric  NOT NULL,
         attribute_name varchar2 (128) NOT NULL,
         category varchar2 (128) DEFAULT 'ALL' NOT NULL,
         support varchar2 (128) DEFAULT 'trade' NOT NULL,
         map_to varchar2 (128) NOT NULL,
         iflag varchar2 (10) DEFAULT 'WEAK_SET' NOT NULL,
         oflag varchar2 (10) DEFAULT 'GET' NOT NULL,
         dsmatch_iflag varchar2 (10) DEFAULT 'WEAK_SET' NOT NULL,
         dsmatch_oflag varchar2 (10) DEFAULT 'GET' NOT NULL,
         visible numeric  DEFAULT 1 NOT NULL,
         readonly numeric  DEFAULT 1 NOT NULL,
         copiable numeric  DEFAULT 0 NOT NULL,
         description varchar2 (511) NULL,
         attribute_domain varchar2 (255) NULL 
    ) 
/

    CREATE TABLE tr_reporting_attr_restriction (
        reporting_attribute_id numeric  NOT NULL,
         value varchar2 (128) NOT NULL 
    ) 
/

    CREATE TABLE tr_regulation (
        regulation_id numeric  NOT NULL,
         regulation_code varchar2 (10) NOT NULL,
         regulation_name varchar2 (20) NOT NULL,
         dtcc_repository varchar2 (10) NOT NULL 
    ) 
/

    CREATE TABLE tr_supervisor (
        supervisor_id numeric  NOT NULL,
         regulation_id numeric  NOT NULL,
         supervisor_code varchar2 (10) NOT NULL,
         enabled numeric  NOT NULL 
    ) 
/

    CREATE TABLE tr_le_id_source (
        source_id numeric  NOT NULL,
         source_code varchar2 (10) NOT NULL,
         fpml_url varchar2 (200) NOT NULL,
         le_attribute_value varchar2 (255) NULL,
         official_source_b numeric  NOT NULL,
         used_in_rp_det_b numeric  NOT NULL 
    ) 
/

    CREATE TABLE tr_po_role (
        role_code varchar2 (2) NOT NULL,
         role_name varchar2 (30) NOT NULL 
    ) 
/

    CREATE TABLE tr_usi_uti (
        trade_id numeric  NOT NULL,
         regulation_id numeric  NOT NULL,
         type varchar2 (2) NOT NULL,
         issuer_source_id numeric  NOT NULL,
         issuer_reference varchar2 (40) NOT NULL,
         trade_reference varchar2 (70) NOT NULL 
    ) 
/

    CREATE TABLE tr_submission_state (
        trade_id numeric  NOT NULL,
         supervisor_id numeric  NOT NULL,
         purpose_code varchar2 (2) NOT NULL,
         submission_time timestamp  NOT NULL,
         response_time timestamp  NULL,
         validation_code varchar2 (2) NULL 
    ) 
/

    CREATE TABLE tr_report_regime (
        trade_id numeric  NOT NULL,
         supervisor_id numeric  NOT NULL,
         po_role_code varchar2 (2) NOT NULL,
         po_etd_role_code varchar2 (2) NULL,
         clearing_mandatory_b numeric  NULL,
         counterparty_masked_b numeric  NULL,
         po_local_b numeric  NULL,
         cpty_local_b numeric  NULL,
         po_uti_generator_b numeric  NULL 
    ) 
/

    CREATE TABLE tr_business_unit (
        trade_id numeric  NOT NULL,
         bu_role_code varchar2 (2) NOT NULL,
         id varchar2 (50) NULL,
         name varchar2 (50) NULL,
         country varchar2 (3) NULL 
    ) 
/

    CREATE TABLE tr_position_uti (
        id numeric  NOT NULL,
         version numeric  NOT NULL,
         product_id numeric  NOT NULL,
         position_id varchar2 (250) NOT NULL,
         account_id numeric  NOT NULL,
         liq_config_id numeric  NOT NULL,
         account_type varchar2 (50) NOT NULL,
         position_uti varchar2 (50) NULL,
         action_type varchar2 (50) NULL,
         last_processed_date timestamp  NULL 
    ) 
/

    CREATE TABLE tr_report (
        trade_id numeric  NOT NULL,
         upi_source varchar2 (5) NOT NULL,
         upi varchar2 (255) NOT NULL,
         primary_asset_class varchar2 (2) NOT NULL,
         secondary_asset_class varchar2 (2) NULL,
         underlying_asset_code_type varchar2 (4) NULL,
         underlying_asset_code varchar2 (35) NULL,
         execution_venue varchar2 (3) NULL,
         po_collat_status_code varchar2 (2) NULL,
         cpty_collat_status_code varchar2 (2) NULL,
         allocation_indicator varchar2 (2) NULL,
         confirmation_indicator varchar2 (2) NULL,
         off_ptf_verification_indicator varchar2 (2) NULL,
         price_type varchar2 (3) NULL,
         price_currency varchar2 (3) NULL,
         price float  NULL,
         additional_price_type varchar2 (3) NULL,
         additional_price_currency varchar2 (3) NULL,
         additional_price float  NULL,
         payment_frequency_method varchar2 (1) NULL,
         clearing_dco_b numeric  NULL,
         price_forming_b numeric  NULL,
         non_standard_b numeric  NULL,
         confirmation_time timestamp  NULL,
         execution_time timestamp  NULL,
         po_trading_capacity varchar2 (2) NULL,
         cpty_trading_capacity varchar2 (2) NULL,
         po_commercial_activity_b numeric  NULL,
         cpty_commercial_activity_b numeric  NULL,
         po_collateral_portfolio_code varchar2 (20) NULL,
         cpty_collateral_portfolio_code varchar2 (20) NULL,
         po_desk_location varchar2 (2) NULL,
         po_trader_location varchar2 (2) NULL,
         cpty_desk_location varchar2 (2) NULL,
         cpty_trader_location varchar2 (2) NULL,
         po_branch_location varchar2 (2) NULL,
         cpty_branch_location varchar2 (2) NULL,
         portfolio_compression_b numeric  NULL,
         terminated_by_compression_b numeric  NULL,
         compression_far_b numeric  NULL,
         terminated_by_compression_far numeric  NULL,
         large_size_trade_b numeric  NULL,
         clearing_house_id numeric  DEFAULT 0 NOT NULL,
         clearing_timestamp timestamp  NULL,
         cpty_desk varchar2 (50) NULL,
         cpty_trader varchar2 (50) NULL,
         po_beneficiary_id numeric  DEFAULT 0 NOT NULL,
         cpty_beneficiary_id numeric  DEFAULT 0 NOT NULL,
         po_execution_agent_id numeric  DEFAULT 0 NOT NULL,
         cpty_execution_agent_id numeric  DEFAULT 0 NOT NULL,
         po_settlement_agent_id numeric  DEFAULT 0 NOT NULL,
         cpty_settlement_agent_id numeric  DEFAULT 0 NOT NULL,
         cpty_broker_id numeric  DEFAULT 0 NOT NULL,
         cpty_clearing_broker_id numeric  DEFAULT 0 NOT NULL,
         additional_repository1 varchar2 (128) NULL,
         additional_repository2 varchar2 (128) NULL,
         additional_repository3 varchar2 (128) NULL,
         etd_cpty_issuer varchar2 (128) NULL,
         etd_cpty_trade varchar2 (128) NULL,
         po_party_viewer varchar2 (255) NULL,
         cpty_party_viewer varchar2 (255) NULL,
         gtr_version varchar2 (255) NULL 
    ) 
/

    CREATE TABLE tr_usi_uti_hist (
        trade_id numeric  NOT NULL,
         regulation_id numeric  NOT NULL,
         type varchar2 (2) NOT NULL,
         issuer_source_id numeric  NOT NULL,
         issuer_reference varchar2 (40) NOT NULL,
         trade_reference varchar2 (70) NOT NULL 
    ) 
/

    CREATE TABLE tr_submission_state_hist (
        trade_id numeric  NOT NULL,
         supervisor_id numeric  NOT NULL,
         purpose_code varchar2 (2) NOT NULL,
         submission_time timestamp  NOT NULL,
         response_time timestamp  NULL,
         validation_code varchar2 (2) NULL 
    ) 
/

    CREATE TABLE tr_report_regime_hist (
        trade_id numeric  NOT NULL,
         supervisor_id numeric  NOT NULL,
         po_role_code varchar2 (2) NOT NULL,
         po_etd_role_code varchar2 (2) NULL,
         clearing_mandatory_b numeric  NULL,
         counterparty_masked_b numeric  NULL,
         po_local_b numeric  NULL,
         cpty_local_b numeric  NULL,
         po_uti_generator_b numeric  NULL 
    ) 
/

    CREATE TABLE tr_business_unit_hist (
        trade_id numeric  NOT NULL,
         bu_role_code varchar2 (2) NOT NULL,
         id varchar2 (10) NULL,
         name varchar2 (50) NULL,
         country varchar2 (3) NULL 
    ) 
/

    CREATE TABLE tr_report_hist (
        trade_id numeric  NOT NULL,
         upi_source varchar2 (5) NOT NULL,
         upi varchar2 (255) NOT NULL,
         primary_asset_class varchar2 (2) NOT NULL,
         secondary_asset_class varchar2 (2) NULL,
         underlying_asset_code_type varchar2 (4) NULL,
         underlying_asset_code varchar2 (35) NULL,
         execution_venue varchar2 (3) NULL,
         po_collat_status_code varchar2 (2) NULL,
         cpty_collat_status_code varchar2 (2) NULL,
         allocation_indicator varchar2 (2) NULL,
         confirmation_indicator varchar2 (2) NULL,
         off_ptf_verification_indicator varchar2 (2) NULL,
         price_type varchar2 (3) NULL,
         price_currency varchar2 (3) NULL,
         price float  NULL,
         additional_price_type varchar2 (3) NULL,
         additional_price_currency varchar2 (3) NULL,
         additional_price float  NULL,
         payment_frequency_method varchar2 (1) NULL,
         clearing_dco_b numeric  NULL,
         price_forming_b numeric  NULL,
         non_standard_b numeric  NULL,
         confirmation_time timestamp  NULL,
         execution_time timestamp  NULL,
         po_trading_capacity varchar2 (2) NULL,
         cpty_trading_capacity varchar2 (2) NULL,
         po_commercial_activity_b numeric  NULL,
         cpty_commercial_activity_b numeric  NULL,
         po_collateral_portfolio_code varchar2 (20) NULL,
         cpty_collateral_portfolio_code varchar2 (20) NULL,
         po_desk_location varchar2 (2) NULL,
         po_trader_location varchar2 (2) NULL,
         cpty_desk_location varchar2 (2) NULL,
         cpty_trader_location varchar2 (2) NULL,
         po_branch_location varchar2 (2) NULL,
         cpty_branch_location varchar2 (2) NULL,
         portfolio_compression_b numeric  NULL,
         terminated_by_compression_b numeric  NULL,
         compression_far_b numeric  NULL,
         terminated_by_compression_far numeric  NULL,
         large_size_trade_b numeric  NULL,
         clearing_house_id numeric  DEFAULT 0 NOT NULL,
         clearing_timestamp timestamp  NULL,
         cpty_desk varchar2 (50) NULL,
         cpty_trader varchar2 (50) NULL,
         po_beneficiary_id numeric  DEFAULT 0 NOT NULL,
         cpty_beneficiary_id numeric  DEFAULT 0 NOT NULL,
         po_execution_agent_id numeric  DEFAULT 0 NOT NULL,
         cpty_execution_agent_id numeric  DEFAULT 0 NOT NULL,
         po_settlement_agent_id numeric  DEFAULT 0 NOT NULL,
         cpty_settlement_agent_id numeric  DEFAULT 0 NOT NULL,
         cpty_broker_id numeric  DEFAULT 0 NOT NULL,
         cpty_clearing_broker_id numeric  DEFAULT 0 NOT NULL,
         additional_repository1 varchar2 (128) NULL,
         additional_repository2 varchar2 (128) NULL,
         additional_repository3 varchar2 (128) NULL,
         etd_cpty_issuer varchar2 (128) NULL,
         etd_cpty_trade varchar2 (128) NULL,
         po_party_viewer varchar2 (255) NULL,
         cpty_party_viewer varchar2 (255) NULL,
         gtr_version varchar2 (255) NULL 
    ) 
/

    CREATE TABLE trade_filter_po_role_criterion (
        trade_filter_name varchar2 (255) NOT NULL,
         and_combination numeric  DEFAULT 1 NOT NULL 
    ) 
/

    CREATE TABLE trade_filter_po_role_element (
        trade_filter_name varchar2 (255) NOT NULL,
         supervisor_id numeric  NOT NULL,
         po_role_code varchar2 (2) NOT NULL 
    ) 
/

    CREATE TABLE trade_filter_uti_criterion (
        trade_filter_name varchar2 (255) NOT NULL,
         and_combination numeric  DEFAULT 1 NOT NULL 
    ) 
/

    CREATE TABLE trade_filter_uti_element (
        trade_filter_name varchar2 (255) NOT NULL,
         regulation_id numeric  NOT NULL,
         uti_type_id numeric  NOT NULL,
         comparison_operator varchar2 (10) NOT NULL,
         comparison_value varchar2 (50) NOT NULL 
    ) 
/

    CREATE TABLE incoming_linked_msg_identifier (
        config_id numeric  NOT NULL,
         version_num numeric  NULL,
         template varchar2 (64) NOT NULL,
         msg_attr varchar2 (255) NOT NULL,
         outgoing_templates varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE value_date_control_config (
        value_date_control_config_id numeric  NOT NULL,
         version_num numeric  NULL,
         currency varchar2 (32) NOT NULL,
         method varchar2 (32) NOT NULL,
         holidays varchar2 (32) NOT NULL,
         time numeric  NOT NULL,
         days numeric  DEFAULT 0 NOT NULL,
         business_b numeric  DEFAULT 1 NOT NULL,
         update_settle_date_b numeric  DEFAULT 1 NOT NULL 
    ) 
/

    CREATE TABLE re_quote_rule_definition (
        rule_name varchar2 (60) NOT NULL,
         rule_type varchar2 (32) NOT NULL,
         class_name varchar2 (255) NOT NULL,
         comments varchar2 (255) NULL,
         version numeric  DEFAULT 1 NOT NULL 
    ) 
/


/* Applying Schema Statements - end */



/* Applying xtra statements - start */



/* Applying xtra statements - end */



/* one time install statements - start */



/* one time install statements - end */

/* Pre Upgrade - Start */
CREATE OR REPLACE PROCEDURE add_column_if_not_exists
    (tab_name IN user_tab_columns.table_name%TYPE,
     col_name IN user_tab_columns.column_name%TYPE,
     data_type IN varchar2)
AS
    x number;
BEGIN
    begin
    select count(*) INTO x FROM user_tab_columns WHERE table_name=UPPER(tab_name) and column_name=upper(col_name);
    exception
        when NO_DATA_FOUND THEN
        x:=0;
        when others then
        null;
    end;
    IF x = 0 THEN
        EXECUTE IMMEDIATE 'alter table ' || tab_name || ' add '||col_name||' '||data_type;
    END IF;
END;
/

CREATE OR REPLACE PROCEDURE drop_function ( proc_name IN user_tab_columns.table_name%TYPE) AS
 x number;
BEGIN
   BEGIN
   SELECT count(*) into x FROM user_objects WHERE object_name=UPPER(proc_name) and object_type= 'FUNCTION';
   exception
        when NO_DATA_FOUND THEN
        x:=0;
        when others then
        null;
    end;
    IF x > 0 THEN
       EXECUTE IMMEDIATE 'drop function '|| proc_name;
    END IF;
END drop_function;
/

CREATE OR REPLACE PROCEDURE drop_column_if_exists
    (tab_name IN user_tab_columns.table_name%TYPE,
     col_name IN user_tab_columns.column_name%TYPE)
AS
    x number;
BEGIN
    begin
    select count(*) INTO x FROM user_tab_columns WHERE table_name=UPPER(tab_name) and column_name=upper(col_name);
    exception
        when NO_DATA_FOUND THEN
        x:=0;
        when others then
        null;
    end;
    IF x > 0 THEN
        EXECUTE IMMEDIATE 'alter table ' || tab_name || ' drop column '||col_name;
    END IF;
END;
/

CREATE OR REPLACE PROCEDURE add_domain_values (dname IN varchar2, dvalue in varchar2, ddescription in varchar2) AS
x number :=0 ;
BEGIN
   BEGIN
   SELECT count(*) INTO x FROM domain_values WHERE name= dname and value= dvalue;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:=0;
      WHEN others THEN
         null;
    END;
        if x = 1 then
                execute immediate 'delete from domain_values where name='||chr(39)||dname||chr(39)||' and value ='||chr(39)||dvalue||chr(39);
                execute immediate 'insert into domain_values ( name, value, description )
                VALUES ('||chr(39)||dname||chr(39)||','||chr(39)||dvalue||chr(39)||','||chr(39)||ddescription||chr(39)||')';
        elsif x=0 THEN
	        execute immediate 'insert into domain_values ( name, value, description ) 
                VALUES ('||chr(39)||dname||chr(39)||','||chr(39)||dvalue||chr(39)||','||chr(39)||ddescription||chr(39)||')';
    END IF;
END add_domain_values;
/

CREATE OR REPLACE PROCEDURE delete_domain_values (dname IN varchar2, dvalue in varchar2) AS
x number :=0 ;
BEGIN
   BEGIN
   SELECT count(*) INTO x FROM domain_values WHERE name= dname and value= dvalue;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:=0;
      WHEN others THEN
         null;
    END;
        if x = 1 then
                execute immediate 'delete from domain_values where name='||chr(39)||dname||chr(39)||' and value ='||chr(39)||dvalue||chr(39);
        
    END IF;
END delete_domain_values;
/

CREATE OR REPLACE PROCEDURE drop_fk_on_table (tab_name IN varchar2) AS
BEGIN
   DECLARE cursor c1 IS 
      SELECT table_name, constraint_name FROM user_constraints WHERE constraint_type = 'R' AND table_name=UPPER(tab_name);
   v_sql varchar2(128);
   BEGIN
      FOR c1_rec IN c1 LOOP 
         v_sql := 'ALTER TABLE '||c1_rec.table_name||' DROP CONSTRAINT '||c1_rec.constraint_name;
         EXECUTE IMMEDIATE v_sql;
      END LOOP;
   END;
END;
/

CREATE OR REPLACE PROCEDURE drop_pk_if_exists (tab_name IN varchar2) AS
x number :=0 ;
BEGIN
   BEGIN
   SELECT count(*) INTO x FROM user_constraints WHERE table_name=UPPER(tab_name) and constraint_type= 'P';
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:=0;
      WHEN others THEN
         null;
    END;
    IF x > 0 THEN
       EXECUTE IMMEDIATE 'ALTER TABLE ' ||tab_name||' DROP PRIMARY KEY DROP INDEX';
    END IF;
END drop_pk_if_exists;
/

CREATE OR REPLACE PROCEDURE drop_uk_if_exists (tab_name IN varchar2) AS
x varchar2(100) ;
BEGIN
   BEGIN
   SELECT  c.constraint_name INTO x FROM user_constraints c, user_tables t WHERE t.table_name=UPPER(tab_name) 
   and c.constraint_type= 'U' and t.table_name=c.table_name;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:='0';
      WHEN others THEN
         null;
    END;
    IF x != '0' THEN
       EXECUTE IMMEDIATE 'ALTER TABLE ' ||tab_name||' DROP constraint '||x;
    END IF;
END drop_uk_if_exists;
/

CREATE OR REPLACE PROCEDURE drop_procedure_if_exists

    (proc_name IN user_objects.object_name%TYPE)

AS

    x number;

BEGIN

    begin

    select count(*) INTO x FROM user_objects WHERE object_name=UPPER(proc_name) and object_type = 'PROCEDURE';

    exception

        when NO_DATA_FOUND THEN

        x:=0;

        when others then

        null;

    end;

    IF x > 0 THEN

        EXECUTE IMMEDIATE 'drop procedure ' || UPPER(proc_name);

    END IF;

END drop_procedure_if_exists;
/

CREATE OR REPLACE PROCEDURE drop_uq_on_table (tab_name IN varchar2) AS
BEGIN
   DECLARE cursor c1 IS 
      SELECT table_name, constraint_name FROM user_constraints WHERE constraint_type = 'U' AND table_name=UPPER(tab_name);
   v_sql varchar2(128);
   BEGIN
      FOR c1_rec IN c1 LOOP 
         v_sql := 'ALTER TABLE '||c1_rec.table_name||' DROP CONSTRAINT '||c1_rec.constraint_name;
         EXECUTE IMMEDIATE v_sql;
      END LOOP;
   END;
END;
/

CREATE OR REPLACE PROCEDURE drop_unique_if_exists (tab_name IN varchar2) AS
constraint_name varchar2(255);
BEGIN
   BEGIN
   SELECT constraint_name INTO constraint_name FROM user_constraints WHERE table_name=UPPER(tab_name) and constraint_type= 'U';
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         constraint_name := NULL;
      WHEN others THEN
         null;
    END;
    IF constraint_name IS NOT NULL THEN
       EXECUTE IMMEDIATE 'ALTER TABLE ' ||tab_name||' DROP CONSTRAINT ' || constraint_name || ' DROP INDEX';
    END IF;
END drop_unique_if_exists;
/

CREATE OR REPLACE PROCEDURE drop_table_if_exists
    (tab_name IN varchar2)
AS
    x number :=0 ;
BEGIN
begin
select count(*) INTO x FROM user_tables WHERE table_name=UPPER(tab_name) ;
exception
when NO_DATA_FOUND THEN
x:=0;
when others then null;
end;
IF x > 0 THEN
EXECUTE IMMEDIATE 'drop table ' ||tab_name;
END IF;
END drop_table_if_exists;
/

CREATE OR REPLACE PROCEDURE add_pk_if_not_exists (tab_name IN varchar2, pk_name in varchar2, c_name in varchar2) AS
x number :=0 ;
BEGIN
   BEGIN
   SELECT count(*) INTO x FROM user_constraints WHERE table_name=UPPER(tab_name) and constraint_type= 'P';
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:=0;
      WHEN others THEN
         null;
    END;
    IF x = 0 THEN
       EXECUTE IMMEDIATE 'ALTER TABLE ' ||tab_name||' add constraint '||pk_name||' primary key ('||c_name||')';
    END IF;
END add_pk_if_not_exists;
/

CREATE OR REPLACE
TYPE list_of_names_t IS  
   TABLE of VARCHAR2(100);
/

CREATE OR REPLACE
PROCEDURE run_query_if_tables_exist
    (tab_names IN list_of_names_t, query IN varchar2)
AS
    x number :=0 ;
    y number :=0 ;
BEGIN
	BEGIN
		select count(*) INTO x FROM table(tab_names);
		select count(*) INTO y FROM user_tables WHERE table_name in (select * from table(tab_names));
	END;
	IF x = y THEN
		EXECUTE IMMEDIATE query;
	END IF;
END run_query_if_tables_exist;
/

CREATE OR REPLACE PROCEDURE rename_column_if_exists
    (tab_name IN user_tab_columns.table_name%TYPE,
     col_name IN user_tab_columns.column_name%TYPE,
     new_col_name IN varchar2)
AS
    x number;
	y number;
BEGIN
    begin 
    select count(*) INTO x FROM user_tab_columns WHERE table_name=UPPER(tab_name) and column_name=upper(col_name);
    exception
        when NO_DATA_FOUND THEN
        x:=0;
        when others then
        null;
    end;
    IF x = 1 THEN
        EXECUTE IMMEDIATE 'alter table ' || tab_name || ' rename  column '||col_name||' to '||new_col_name;
    END IF;
END;
/

/* Pre Upgrade - End */
/* Start of the SQL statements from file:LIQ-7125-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('liquidity','LIQ-7125',1,CURRENT_TIMESTAMP,'started')
/

alter table liq_limit_ccy_bucket rename column bucket_limit to bucket_limit_bck
/

alter table liq_limit_ccy_bucket rename column limit to bucket_limit
/

alter table liq_limit_ccy_class_lvl rename column class_lvl_limit to class_lvl_limit_bck
/

alter table liq_limit_ccy_class_lvl rename column limit to class_lvl_limit
/

alter table liq_limit_ccy_class_lvl_bucket rename column lvl_bucket_limit to lvl_bucket_limit_bck
/

alter table liq_limit_ccy_class_lvl_bucket rename column limit to lvl_bucket_limit
/

alter table liq_limit_ccy_bucket drop column bucket_limit_bck
/

alter table liq_limit_ccy_class_lvl drop column class_lvl_limit_bck
/

alter table liq_limit_ccy_class_lvl_bucket drop column lvl_bucket_limit_bck
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='LIQ-7125' and version=1 and module='liquidity'
/

/* End of the SQL statements from file:LIQ-7125-1.sql */
/* Start of the SQL statements from file:LIQ-7520-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('liquidity','LIQ-7520',1,CURRENT_TIMESTAMP,'started')
/

/* LIQ-7520 : Deprecate Trading book FTP */
delete from domain_values where name = 'FtpCostComponentNames' and value in ( 'SECURITIZED_FUNDING_INTEREST_COST' , 
'SECURITIZED_FUNDING_SECURITY_SWEEP_COST' , 'SECURITIZED_FUNDING_CASH_SWEEP_COST' , 'OVERNIGHT_CASH_SWEEP_COST' , 'OVERNIGHT_CASH_INTEREST_COST' )
/

delete from domain_values where name = 'scheduledTask' and value = 'GEN_FUNDING_FTP_ACCRUALS'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='LIQ-7520' and version=1 and module='liquidity'
/

/* End of the SQL statements from file:LIQ-7520-1.sql */
/* Start of the SQL statements from file:LIQ-7588-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('liquidity','LIQ-7588',1,CURRENT_TIMESTAMP,'started')
/

/* LIQ-7588 : Readding the delete script since there was a regression issue with subsequent versions in liquidity modules */
delete from domain_values where name = 'scheduledTask' and value = 'GEN_FUNDING_FTP_ACCRUALS'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='LIQ-7588' and version=1 and module='liquidity'
/

/* End of the SQL statements from file:LIQ-7588-1.sql */
/* Start of the SQL statements from file:MGNC-776-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-776',1,CURRENT_TIMESTAMP,'started')
/

update pricer_measure set measure_id = 500 where measure_id = 1500
/

update pricer_measure set measure_id = 501 where measure_id = 1501
/

update pricer_measure set measure_id = 502 where measure_id = 1502
/

update pricer_measure set measure_id = 503 where measure_id = 1503
/

update pricer_measure set measure_id = 504 where measure_id = 1504
/

update pricer_measure set measure_id = 505 where measure_id = 1505
/

update pricer_measure set measure_id = 506 where measure_id = 1506
/

update pricer_measure set measure_id = 507 where measure_id = 1507
/

update pricer_measure set measure_id = 508 where measure_id = 1508
/

update pricer_measure set measure_id = 509 where measure_id = 1509
/

update pricer_measure set measure_id = 510 where measure_id = 1510
/

update pricer_measure set measure_id = 511 where measure_id = 1511
/

update pricer_measure set measure_id = 512 where measure_id = 1512
/

update pricer_measure set measure_id = 513 where measure_id = 1513
/

update pricer_measure set measure_id = 514 where measure_id = 1514
/

update pricer_measure set measure_id = 515 where measure_id = 1515
/

update pricer_measure set measure_id = 516 where measure_id = 1516
/

update pricer_measure set measure_id = 517 where measure_id = 1517
/

update pricer_measure set measure_id = 518 where measure_id = 1518
/

update pricer_measure set measure_id = 519 where measure_id = 1519
/

update pricer_measure set measure_id = 520 where measure_id = 1520
/

update pricer_measure set measure_id = 521 where measure_id = 1521
/

update pricer_measure set measure_id = 522 where measure_id = 1522
/

update pricer_measure set measure_id = 523 where measure_id = 1523
/

update pricer_measure set measure_id = 524 where measure_id = 1524
/

update pricer_measure set measure_id = 525 where measure_id = 1525
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-776' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-776-1.sql */
/* Start of the SQL statements from file:MGNC-986-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-986',1,CURRENT_TIMESTAMP,'started')
/

update margin_trade_vm set po_view = (
(select case when count(*) > 0 THEN 1 else 0 end
from quartz_sched_task_attr where attr_name = 'VM View' and attr_value = 'PO' 
and task_id in (select task_id from quartz_sched_task where task_type = 'MARGIN_OTC_VM_CALCULATOR')
and task_id in (select task_id from quartz_sched_task_attr where attr_name = 'Hierarchy Name' and attr_value in (select hierarchy_name from ers_hierarchy where node_name = margin_trade_vm.margin_agreement_name))
)
)
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-986' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-986-1.sql */
/* Start of the SQL statements from file:MGNC-1040-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-1040',1,CURRENT_TIMESTAMP,'started')
/

INSERT INTO domain_values (name, value, description)
	values ('ISDASIMM.treatIRCurveAsXccyBasis.Currencies', 'CNY', '')
/

INSERT INTO domain_values (name, value, description)
	values ('ISDASIMM.treatIRCurveAsXccyBasis.Currencies', 'IDR', '')
/

INSERT INTO domain_values (name, value, description)
	values ('ISDASIMM.treatIRCurveAsXccyBasis.Currencies', 'KRW', '')
/

INSERT INTO domain_values (name, value, description)
	values ('ISDASIMM.flipXccyBasisRisk.Currencies', 'CLP', '')
/

INSERT INTO domain_values (name, value, description)
	values ('ISDASIMM.flipXccyBasisRisk.Currencies', 'COP', '')
/

INSERT INTO domain_values (name, value, description)
	values ('ISDASIMM.flipXccyBasisRisk.Currencies', 'MXN', '')
/

INSERT INTO domain_values (name, value, description)
	values ('ISDASIMM.flipXccyBasisRisk.Currencies', 'PEN', '')
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-1040' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-1040-1.sql */
/* Start of the SQL statements from file:MGNC-451-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-451',1,CURRENT_TIMESTAMP,'started')
/

INSERT INTO scenario_rule (scenario_name,class_name,comments,version_num,owner_name,is_parametric) 
	values ('FXQuotes1pct','com.calypso.tk.risk.ScenarioRuleQuotes',null,0,'',0)
/

INSERT INTO scenario_items (scenario_name, class_name, item_seq, attribute_name, attribute_value)
	values ('FXQuotes1pct','com.calypso.tk.risk.ScenarioRuleQuotes',0,'FXConvertCcy','Delta Display')
/

INSERT INTO scenario_items (scenario_name, class_name, item_seq, attribute_name, attribute_value)
	values ('FXQuotes1pct','com.calypso.tk.risk.ScenarioRuleQuotes',0,'LOAD_QUOTES_NAME','Y')
/

INSERT INTO scenario_items (scenario_name, class_name, item_seq, attribute_name, attribute_value)
	values ('FXQuotes1pct','com.calypso.tk.risk.ScenarioRuleQuotes',0,'LOAD_QUOTE_NAMES','Y')
/

INSERT INTO scenario_items (scenario_name, class_name, item_seq, attribute_name, attribute_value)
	values ('FXQuotes1pct','com.calypso.tk.risk.ScenarioRuleQuotes',0,'SPECIFIC','0 FX. 1 %(rel)')
/

INSERT INTO scenario_items (scenario_name, class_name, item_seq, attribute_name, attribute_value)
	values ('FXQuotes1pct','com.calypso.tk.risk.ScenarioRuleQuotes',0,'Separately','TRUE')
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-451' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-451-1.sql */
/* Start of the SQL statements from file:MGNC-1178-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-1178',1,CURRENT_TIMESTAMP,'started')
/

declare
    vScenarioName varchar2(16) := 'all_fx';
    vCount number;
begin
    select count(*) into vCount from scenario_rule where scenario_name = vScenarioName;
    if vCount < 1 then
        insert into scenario_rule (scenario_name,class_name,comments,version_num,owner_name,is_parametric) values (vScenarioName,'com.calypso.tk.risk.ScenarioMarketData',null,0,'calypso_user',0);
    end if;

    select count(*) into vCount from scenario_items where scenario_name = vScenarioName;
    if vCount < 1 then
        insert into scenario_items (scenario_name,class_name,item_seq,attribute_name,attribute_value) values (vScenarioName,'com.calypso.tk.risk.ScenarioMarketData',0,'SPECIFIC','FX ANY ANY ANY');
        insert into scenario_items (scenario_name,class_name,item_seq,attribute_name,attribute_value) values (vScenarioName,'com.calypso.tk.risk.ScenarioMarketData',1,'SPECIFIC','FXVolatility ANY ANY ANY');
    end if;
end;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-1178' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-1178-1.sql */
/* Start of the SQL statements from file:MGNC-536-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-536',1,CURRENT_TIMESTAMP,'started')
/

update margin_trade_vm set calculation_set = 'Default'
/

update margin_trade_vm_hist set calculation_set = 'Default'
/

update margin_portfolio_vm set calculation_set = 'Default'
/

update margin_portfolio_vm_hist set calculation_set = 'Default'
/

update margin_run_info set calculation_set = 'Default'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-536' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-536-1.sql */
/* Start of the SQL statements from file:MGNC-1338-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-1338',1,CURRENT_TIMESTAMP,'started')
/

update margin_portfolio_vm set po_view = (
(select case when count(*) > 0 THEN 1 else 0 end
from quartz_sched_task_attr where attr_name = 'VM View' and attr_value = 'PO' 
and task_id in (select task_id from quartz_sched_task where task_type = 'MARGIN_OTC_VM_CALCULATOR')
and task_id in (select task_id from quartz_sched_task_attr where attr_name = 'Hierarchy Name' and attr_value in (select hierarchy_name from ers_hierarchy where node_name = margin_portfolio_vm.margin_agreement_name))
)
)
/

delete from quartz_sched_task_attr where attr_name = 'VM View'
and task_id in (select task_id from quartz_sched_task where task_type = 'MARGIN_OTC_VM_CALCULATOR')
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-1338' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-1338-1.sql */
/* Start of the SQL statements from file:MGNC-1432-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-1432',1,CURRENT_TIMESTAMP,'started')
/

INSERT INTO quartz_sched_task_attr (
    task_id,
    attr_name,
    attr_value,
    value_order
)
    SELECT
        task_id,
        'Calculation Set',
        'Default',
        0
    FROM
        quartz_sched_task
    WHERE
        task_type = 'MARGIN_OTC_CALCULATOR'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-1432' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-1432-1.sql */
/* Start of the SQL statements from file:MGNC-1493-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-1493',1,CURRENT_TIMESTAMP,'started')
/

MERGE
INTO    margin_trade_vm v
USING   (
        SELECT DISTINCT tr.trade_id AS trade_id, b.legal_entity_id
            FROM book b, trade tr, margin_trade_vm v
            WHERE v.trade_id = tr.trade_id
            AND tr.book_id = b. book_id
        ) src
ON      (v.trade_id = src.trade_id)
WHEN MATCHED THEN UPDATE
    SET v.po = legal_entity_id
    where v.po = 0
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-1493' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-1493-1.sql */
/* Start of the SQL statements from file:MGNC-1619-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-1619',1,CURRENT_TIMESTAMP,'started')
/

INSERT INTO margin_vm_definition (name,leg,additional_column_index,product_type,measure_name,intraday,cumulative,flip_sign)
        values ('CVM','NEAR',-1,'FXSwap','CVM_NEAR',1,1,1)
/

INSERT INTO margin_vm_definition (name,leg,additional_column_index,product_type,measure_name,intraday,cumulative,flip_sign)
        values ('CVM','FAR',-1,'FXSwap','CVM_FAR',1,1,1)
/

INSERT INTO pricer_measure (measure_name, measure_class_name, measure_id)
        values ('CVM_NEAR','margin.vm.pricer.PricerMeasureVariationMargin', 533)
/

INSERT INTO pricer_measure (measure_name, measure_class_name, measure_id)
        values ('CVM_FAR','margin.vm.pricer.PricerMeasureVariationMargin', 532)
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-1619' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-1619-1.sql */
/* Start of the SQL statements from file:MGNC-1601-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-1601',1,CURRENT_TIMESTAMP,'started')
/

update margin_trade_vm set im_portfolio_name = margin_agreement_name
/

update margin_portfolio_vm set im_portfolio_name = margin_agreement_name
/

update margin_trade_vm_hist set im_portfolio_name = margin_agreement_name
/

update margin_portfolio_vm_hist set im_portfolio_name = margin_agreement_name
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-1601' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-1601-1.sql */
/* Start of the SQL statements from file:CAL-385583-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-385583',1,CURRENT_TIMESTAMP,'started')
/

DELETE
FROM investment_cash_position
WHERE position_id IN
  (SELECT p.position_id
  FROM official_pl_mark m
  RIGHT JOIN investment_cash_position p
  ON m.trade_id = p.position_id
  INNER JOIN
    (SELECT treasury_portfolio_id,
      book_id,
      currency
    FROM investment_cash_position
    GROUP BY treasury_portfolio_id,
      book_id,
      currency
    HAVING COUNT(*) > 1
    ) d
  ON p.treasury_portfolio_id = d.treasury_portfolio_id
  AND p.book_id              =d.book_id
  AND p.currency             =d.currency
  WHERE m.mark_id           IS NULL
  )
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-385583' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-385583-1.sql */
/* Start of the SQL statements from file:CAL-363765-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-363765',1,CURRENT_TIMESTAMP,'started')
/

BEGIN
	DECLARE
		query VARCHAR2(4000);
		tablesToCheck list_of_names_t := list_of_names_t('ERSC_RULE_GROUP','ENTITY_MODIF_METADATA');
	BEGIN
		query := 'UPDATE ersc_rule_group t
		SET
		creation_user =
		CASE WHEN (SELECT m.user_info FROM entity_modif_metadata m WHERE m.id = t.created_meta_data_id) IS NOT NULL
		THEN (SELECT m.user_info FROM entity_modif_metadata m WHERE m.id = t.created_meta_data_id)
		ELSE ''00112233-4455-6677-8899-aabbccddeeff''
		END,
		creation_date =
		CASE WHEN (SELECT m.date_info FROM entity_modif_metadata m WHERE m.id = t.created_meta_data_id) IS NOT NULL
		THEN (SELECT m.date_info FROM entity_modif_metadata m WHERE m.id = t.created_meta_data_id)
		ELSE 0
		END,
		last_update_user =
		CASE WHEN (SELECT m.user_info FROM entity_modif_metadata m WHERE m.id = t.updated_meta_data_id) IS NOT NULL
		THEN (SELECT m.user_info FROM entity_modif_metadata m WHERE m.id = t.updated_meta_data_id)
		ELSE ''00112233-4455-6677-8899-aabbccddeeff''
		END,
		last_update_date =
		CASE WHEN (SELECT m.date_info FROM entity_modif_metadata m WHERE m.id = t.updated_meta_data_id) IS NOT NULL
		THEN (SELECT m.date_info FROM entity_modif_metadata m WHERE m.id = t.updated_meta_data_id)
		ELSE 0
		END
		';
    run_query_if_tables_exist(tablesToCheck, query);
	END;
END;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-363765' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-363765-1.sql */
/* Start of the SQL statements from file:CAL-362799-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-362799',1,CURRENT_TIMESTAMP,'started')
/

update product_seclending set maturity_type = 'TERM' where maturity_type is null and open_term_b = 0
/

update product_seclending set maturity_type = 'OPEN' where maturity_type is null and open_term_b = 1
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-362799' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-362799-1.sql */
/* Start of the SQL statements from file:CAL-359149-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-359149',1,CURRENT_TIMESTAMP,'started')
/

update product_desc set product_sub_type ='Standard' where product_id in (select tlock.product_id from product_tlock tlock,product_bond bond where tlock.ref_product_id = bond.product_id and bond.notional_index is null)
/

update product_desc set product_sub_type ='Inflation' where product_id in (select tlock.product_id from product_tlock tlock,product_bond bond where tlock.ref_product_id = bond.product_id and bond.notional_index is not null)
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-359149' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-359149-1.sql */
/* Start of the SQL statements from file:CAL-364282-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-364282',1,CURRENT_TIMESTAMP,'started')
/

delete from pricer_measure where measure_name = 'PRICE_UNDERLYING_INDEX'
/

INSERT INTO pricer_measure(measure_name,measure_class_name,measure_id) VALUES ('PRICE_UNDERLYING_INDEX','tk.pricer.PricerMeasureCredit',925)
/

delete from pricer_measure where measure_name = 'ACCRUAL_FINANCING'
/

INSERT INTO pricer_measure(measure_name,measure_class_name,measure_id) VALUES ('ACCRUAL_FINANCING','tk.pricer.PricerMeasureCredit',926)
/

delete from pricer_measure where measure_name = 'ACCRUAL_INDEX'
/

INSERT INTO pricer_measure(measure_name,measure_class_name,measure_id) VALUES ('ACCRUAL_INDEX','tk.pricer.PricerMeasureCredit',927)
/

delete from pricer_measure where measure_name = 'MTM_INDEX'
/

INSERT INTO pricer_measure(measure_name,measure_class_name,measure_id) VALUES ('MTM_INDEX','tk.pricer.PricerMeasureCredit',928)
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-364282' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-364282-1.sql */
/* Start of the SQL statements from file:CAL-363666-2.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-363666',2,CURRENT_TIMESTAMP,'started')
/

ALTER TABLE ersc_rule_group MODIFY (ID varchar2(36))
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-363666' and version=2 and module='core'
/

/* End of the SQL statements from file:CAL-363666-2.sql */
/* Start of the SQL statements from file:CAL-363816-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-363816',1,CURRENT_TIMESTAMP,'started')
/

delete pricer_measure where measure_name = 'MTM_CCY' and measure_id = 500
/

delete pricer_measure where measure_name = 'FX_PL' and measure_id = 501
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-363816' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-363816-1.sql */
/* Start of the SQL statements from file:CAL-365914-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-365914',1,CURRENT_TIMESTAMP,'started')
/

DECLARE
   cnt_decimal INT;
   cnt_method INT;
   cnt_rounding_decimal INT;
   cnt_rounding_method INT;
BEGIN
	SELECT COUNT(*) INTO cnt_decimal FROM user_tab_cols WHERE upper(table_name)='PRODUCT_ROUNDING_RULE' AND upper(column_name) = 'DECIMALS';
	SELECT COUNT(*) INTO cnt_method FROM user_tab_cols WHERE upper(table_name)='PRODUCT_ROUNDING_RULE' AND upper(column_name) = 'METHOD';
	SELECT COUNT(*) INTO cnt_rounding_decimal FROM user_tab_cols WHERE upper(table_name)='PRODUCT_ROUNDING_RULE' AND upper(column_name) = 'ROUNDING_DECIMALS';
	SELECT COUNT(*) INTO cnt_rounding_method FROM user_tab_cols WHERE upper(table_name)='PRODUCT_ROUNDING_RULE' AND upper(column_name) = 'ROUNDING_METHOD';
	
	-- While running execute sql, rounding_decimals column will be added if it is not there since we have modified the column name in schema base, 
	-- so we need drop that column and rename the existing column(decimals) to rounding_decimals
	IF(cnt_rounding_decimal = 1 AND cnt_decimal =1) THEN
		execute immediate 'alter table product_rounding_rule rename column rounding_decimals to rounding_decimals_bck';
	END IF;
	IF cnt_decimal = 1 THEN
		execute immediate 'alter table product_rounding_rule rename column decimals to rounding_decimals';
	END IF;
	--Similar to above, do the same thing for rounding_method column
	IF(cnt_rounding_method = 1 AND cnt_method =1) THEN
		execute immediate 'alter table product_rounding_rule rename column rounding_method to rounding_method_bck';
	END IF;
	IF cnt_method = 1 THEN
		execute immediate 'alter table product_rounding_rule rename column method to rounding_method';	
	END IF;
	
	--Finally drop the bck columns	
	IF(cnt_rounding_decimal = 1 AND cnt_rounding_method = 1 AND cnt_method = 1 AND cnt_decimal =1) THEN
		execute immediate 'alter table product_rounding_rule drop (rounding_decimals_bck , rounding_method_bck)';
	END IF;	
END;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-365914' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-365914-1.sql */
/* Start of the SQL statements from file:CAL-363813-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-363813',1,CURRENT_TIMESTAMP,'started')
/

update pricer_measure set measure_id = 924 where measure_name = 'FEES_ALL_AM_EIR'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-363813' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-363813-1.sql */
/* Start of the SQL statements from file:CAL-363986-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-363986',1,CURRENT_TIMESTAMP,'started')
/

update pricer_measure set measure_id = 907 where measure_name = 'NPV_AMF'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-363986' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-363986-1.sql */
/* Start of the SQL statements from file:CAL-366287-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-366287',1,CURRENT_TIMESTAMP,'started')
/

create table missing_plmeasure as select pl_config_id from official_pl_config 
where pl_config_id not in (select pl_config_id from official_pl_config_attr where attr_type='plmeasure' and attr_value='P' || chr(38) || 'L')
/

insert into official_pl_config_attr (pl_config_id, attr_type, attr_value, user_specified_order)
select missing_plmeasure.pl_config_id, 'plmeasure', 'P' || chr(38) || 'L', max_measureid.order_id
from missing_plmeasure, (select pl_config_id, max(user_specified_order)+1 as order_id from official_pl_config_attr where attr_type='plmeasure' group by pl_config_id) max_measureid
where missing_plmeasure.pl_config_id = max_measureid.pl_config_id
/

drop table missing_plmeasure
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-366287' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-366287-1.sql */
/* Start of the SQL statements from file:CAL-367773-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-367773',1,CURRENT_TIMESTAMP,'started')
/

begin 
drop_table_if_exists('inv_cashposition');
drop_table_if_exists('inv_cashpos_hist');
drop_table_if_exists('inv_secposition');
drop_table_if_exists('inv_secpos_hist');
drop_table_if_exists('inv_cash_balance_back152');
drop_table_if_exists('inv_cash_movement_back152');
drop_table_if_exists('inv_sec_balance_back152');
drop_table_if_exists('inv_sec_movement_back152');
drop_table_if_exists('inv_movement_history');
drop_table_if_exists('inv_secposition_new');
end;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-367773' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-367773-1.sql */
/* Start of the SQL statements from file:CAL-365662-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-365662',1,CURRENT_TIMESTAMP,'started')
/

alter table calypso_cache rename column cache_limit to cache_limit_bck
/

alter table calypso_cache rename column limit to cache_limit
/

alter table calypso_cache drop column cache_limit_bck
/

begin
drop_table_if_exists ('tf_temp_table');
end;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-365662' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-365662-1.sql */
/* Start of the SQL statements from file:CAL-365765-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-365765',1,CURRENT_TIMESTAMP,'started')
/

alter table product_credit_facility rename column credit_limit to credit_limit_bck
/

alter table acc_interest_config rename column offset_date to offset_date_bck
/

alter table product_credit_facility rename column limit to credit_limit
/

alter table acc_interest_config rename column offset to offset_date
/

alter table product_credit_facility drop column credit_limit_bck
/

alter table acc_interest_config drop column offset_date_bck
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-365765' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-365765-1.sql */
/* Start of the SQL statements from file:CAL-365777-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-365777',1,CURRENT_TIMESTAMP,'started')
/

alter table product_cap_floor rename column strike_limit to strike_limit_bck
/

alter table product_cap_floor rename column limit to strike_limit
/

alter table corr_surf_basisadj_hist rename column offset_days to offset_days_bck
/

alter table corr_surf_basisadj_hist rename column offset to offset_days
/

alter table corr_surf_data_hist rename column offset_days to offset_days_bck
/

alter table corr_surf_data_hist rename column offset to offset_days
/

alter table corr_surf_ptadj_hist rename column offset_days to offset_days_bck
/

alter table corr_surf_ptadj_hist rename column offset to offset_days
/

alter table corr_surf_timeaxis_hist rename column offset_days to offset_days_bck
/

alter table corr_surf_timeaxis_hist rename column offset to offset_days
/

alter table corr_mat_data_hist rename column offset_days to offset_days_bck
/

alter table corr_mat_data_hist rename column offset to offset_days
/

alter table corr_matrix_data rename column offset_days to offset_days_bck
/

alter table corr_matrix_data rename column offset to offset_days
/

alter table corr_surf_basisadj rename column offset_days to offset_days_bck
/

alter table corr_surf_basisadj rename column offset to offset_days
/

alter table corr_surf_data rename column offset_days to offset_days_bck
/

alter table corr_surf_data rename column offset to offset_days
/

alter table corr_surf_ptadj rename column offset_days to offset_days_bck
/

alter table corr_surf_ptadj rename column offset to offset_days
/

alter table corr_surf_timeaxis rename column offset_days to offset_days_bck
/

alter table corr_surf_timeaxis rename column offset to offset_days
/

alter table corr_tenor_ax_hist rename column offset_days to offset_days_bck
/

alter table corr_tenor_ax_hist rename column offset to offset_days
/

alter table corr_tenor_axis rename column offset_days to offset_days_bck
/

alter table corr_tenor_axis rename column offset to offset_days
/

alter table cov_mat_data_hist rename column offset_days to offset_days_bck
/

alter table cov_mat_data_hist rename column offset to offset_days
/

alter table cov_matrix_data rename column offset_days to offset_days_bck
/

alter table cov_matrix_data rename column offset to offset_days
/

alter table product_cap_floor drop column strike_limit_bck
/

alter table corr_surf_basisadj_hist drop column offset_days_bck
/

alter table corr_surf_data_hist drop column offset_days_bck
/

alter table corr_surf_ptadj_hist drop column offset_days_bck
/

alter table corr_surf_timeaxis_hist drop column offset_days_bck
/

alter table corr_mat_data_hist drop column offset_days_bck
/

alter table corr_matrix_data drop column offset_days_bck
/

alter table corr_surf_basisadj drop column offset_days_bck
/

alter table corr_surf_data drop column offset_days_bck
/

alter table corr_surf_ptadj drop column offset_days_bck
/

alter table corr_surf_timeaxis drop column offset_days_bck
/

alter table corr_tenor_ax_hist drop column offset_days_bck
/

alter table corr_tenor_axis drop column offset_days_bck
/

alter table cov_mat_data_hist drop column offset_days_bck
/

alter table cov_matrix_data drop column offset_days_bck
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-365777' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-365777-1.sql */
/* Start of the SQL statements from file:CAL-365239-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-365239',1,CURRENT_TIMESTAMP,'started')
/

update trade_keyword set keyword_name = 'Trade Average Price' where keyword_name = 'AVG Price Future'
/

update trade_keyword set keyword_name = 'Trade Average Price' where keyword_name = 'AVG Price Future Option'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-365239' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-365239-1.sql */
/* Start of the SQL statements from file:CAL-365972-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-365972',1,CURRENT_TIMESTAMP,'started')
/

begin
rename_column_if_exists ('allocation','bm_offset','bm_offset_bck');
end;
/

begin
rename_column_if_exists ('allocation','offset','bm_offset');
end;
/

begin
rename_column_if_exists ('benchmark_comp_record_item','bm_offset','bm_offset_bck');
end;
/

begin
rename_column_if_exists ('benchmark_comp_record_item','offset','bm_offset');
end;
/

begin 
drop_column_if_exists  ('allocation','bm_offset_bck');
end;
/

begin 
drop_column_if_exists  ('benchmark_comp_record_item','bm_offset_bck');
end;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-365972' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-365972-1.sql */
/* Start of the SQL statements from file:CAL-365961-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-365961',1,CURRENT_TIMESTAMP,'started')
/

alter table cu_cds rename column start_offset to start_offset_bck
/

alter table cu_cds rename column offset to start_offset
/

alter table product_otccom_opt rename column settlement_offset to settlement_offset_bck
/

alter table product_otccom_opt rename column offset to settlement_offset
/

alter table product_otceq_opt rename column settlement_offset to settlement_offset_bck
/

alter table product_otceq_opt rename column offset to settlement_offset
/

alter table accrual_schedule_params rename column accrual_offset to accrual_offset_bck
/

alter table accrual_schedule_params rename column offset to accrual_offset
/

alter table cu_cds drop column start_offset_bck
/

alter table product_otccom_opt drop column settlement_offset_bck
/

alter table product_otceq_opt drop column settlement_offset_bck
/

alter table accrual_schedule_params drop column accrual_offset_bck
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-365961' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-365961-1.sql */
/* Start of the SQL statements from file:CAL-360491-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-360491',1,CURRENT_TIMESTAMP,'started')
/

update option_contract set underlying_date_type='Underlying Add Months' where months_added>0
/

update option_contract set underlying_date_type='Underlying Date Schedule' where underlying_rule>0 AND months_added!=-999
/

update option_contract set underlying_date_type='Add Months on Product' where underlying_rule>0 AND months_added=-999
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-360491' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-360491-1.sql */
/* Start of the SQL statements from file:CAL-367501-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-367501',1,CURRENT_TIMESTAMP,'started')
/

delete from domain_values where name = 'PreciousMetalUnits.XAU'
/

delete from domain_values where name = 'domainName' and value = 'PreciousMetalUnits.XAU'
/

delete from domain_values where name = 'currencyDefaultAttribute' and value = 'PreciousMetalBaseUnit'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-367501' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-367501-1.sql */
/* Start of the SQL statements from file:CAL-300507-3.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-300507',3,CURRENT_TIMESTAMP,'started')
/

create table tempccy as  
(select distinct trade.trade_id  as trade_id , trade.product_id as product_id, decode(cp.pl_display_ccy,'Primary',cp.primary_currency, 'Secondary', cp.quoting_currency) as pl_ccy   
from currency_pair cp, trade t, swap_leg l, product_swap s , trade trade 
where trade.trade_id = t.trade_id and
    l.product_id =  s. product_id 
and t.product_id = s.product_id
and s.swap_type in  ('XCCySwap','SwapNonDeliverable','SwapCrossCurrency','NDS')
and ( (cp.primary_currency = (select l.principal_currency from swap_leg l, product_swap s 
                              where l.product_id =  s. product_id 
                              and t.product_id = s.product_id
                              and s.swap_type in  ('XCCySwap','SwapNonDeliverable','SwapCrossCurrency','NDS')
                              and l.leg_id = 1)--pay leg
	and cp.quoting_currency = (select l.principal_currency from swap_leg l, product_swap s 
                              where l.product_id =  s. product_id
                              and t.product_id = s.product_id
                              and s.swap_type in  ('XCCySwap','SwapNonDeliverable','SwapCrossCurrency','NDS')
                              and l.leg_id = 2) )  
	or (cp.primary_currency = (select l.principal_currency from swap_leg l, product_swap s 
                              where l.product_id =  s. product_id 
                              and t.product_id = s.product_id
                              and s.swap_type in  ('XCCySwap','SwapNonDeliverable','SwapCrossCurrency','NDS')
                              and l.leg_id = 2)--rec leg
	and cp.quoting_currency = (select l.principal_currency from swap_leg l, product_swap s 
                              where l.product_id =  s. product_id
                              and t.product_id = s.product_id
                              and s.swap_type in  ('XCCySwap','SwapNonDeliverable','SwapCrossCurrency','NDS')
                              and l.leg_id = 1) ) ) )
/

merge into trade using tempccy
on (trade.trade_id=tempccy.trade_id)
when matched then update set trade.trade_currency=tempccy.pl_ccy
where trade.trade_id=tempccy.trade_id
/

merge into product_desc using tempccy
on (product_desc.product_id=tempccy.product_id)
when matched then update set product_desc.currency=tempccy.pl_ccy
where product_desc.product_id=tempccy.product_id
/

drop table tempccy
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-300507' and version=3 and module='core'
/

/* End of the SQL statements from file:CAL-300507-3.sql */
/* Start of the SQL statements from file:CAL-374192-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-374192',1,CURRENT_TIMESTAMP,'started')
/

alter table  inv_cash_balance rename to inv_cash_balance_back161
/

alter table inv_cash_movement rename to inv_cash_movement_back161
/

alter table inv_sec_balance rename to inv_sec_balance_back161
/

alter table inv_sec_movement rename to inv_sec_movement_back161
/

create table inv_cash_balance(internal_external varchar2(32) not null,
position_type varchar2(32) not null,
agent_id  number not null,
account_id  number not null,
date_type varchar2(32) not null,
position_date timestamp not null,
currency_code varchar2(3) not null,
book_id  number not null,
config_id  number default 0  not null,
mcc_id  number  default 0 not null  ,
sub_account_id  number default 0 not null,
total_amount  decimal(38,15) null,
total_ote_fut  decimal(38,15) null,
total_ote_opt  decimal(38,15) null,
total_ote_disc  decimal(38,15) null,
total_vm_fut  decimal(38,15) null,
total_vm_opt  decimal(38,15) null,
total_vm_disc  decimal(38,15) null,
total_lov  decimal(38,15) null,
total_sov  decimal(38,15) null,
total_commission  decimal(38,15) null,
total_fees  decimal(38,15) null,
total_futures_pl  decimal(38,15) null,
total_option_premium  decimal(38,15) null,
total_option_cash_settlement  decimal(38,15) null,
total_cash_movements  decimal(38,15) null,
version  number not null,
total_margin_call_in decimal(38,15) null,
total_margin_call_out decimal(38,15) null,
total_mc_rehyp_in decimal(38,15) null,
total_mc_rehyp_out decimal(38,15) null,
total_mc_non_rehyp_in decimal(38,15) null,
total_mc_non_rehyp_out decimal(38,15) null,
total_mc_book_owner_in decimal(38,15) null,
total_mc_book_owner_out decimal(38,15) null)
/

insert /*+ parallel(8) */   into inv_cash_balance select  internal_external ,
 position_type  ,
 agent_id  ,
 account_id  ,
 date_type ,
 position_date ,
 currency_code ,
 book_id  ,
config_id ,
 mcc_id ,
 0,
 total_amount as total_amount   ,
 total_ote_fut as total_ote_fut   ,
 total_ote_opt as total_ote_opt   ,
 total_ote_disc as total_ote_disc   ,
 total_vm_fut as total_vm_fut   ,
 total_vm_opt as total_vm_opt   ,
 total_vm_disc as total_vm_disc   , 
 total_lov as total_lov   ,
 total_sov as total_sov   ,
 total_commission as total_commission   ,
 total_fees as total_fees   ,
 total_futures_pl as total_futures_pl   ,
 total_option_premium as total_option_premium   ,
 total_option_cash_settlement as total_option_cash_settlement   ,
 total_cash_movements as total_cash_movements   ,
 version ,
 total_margin_call_in as total_margin_call_in ,
 total_margin_call_out as total_margin_call_out ,
 total_mc_rehyp_in as total_mc_rehyp_in ,
 total_mc_rehyp_out as total_mc_rehyp_out ,
 total_mc_non_rehyp_in as total_mc_non_rehyp_in ,
 total_mc_non_rehyp_out as total_mc_non_rehyp_out ,
 total_mc_book_owner_in as total_mc_book_owner_in ,
 total_mc_book_owner_out as total_mc_book_owner_out from inv_cash_balance_back161
/

create table inv_cash_movement (internal_external varchar2(32) not null,
position_type varchar2(32) not null,
agent_id  number not null,
account_id  number not null,
date_type varchar2(32) not null,
position_date timestamp not null,
currency_code varchar2(3) not null,
book_id  number not null,
config_id  number  default 0  not null,
mcc_id  number default 0 not null  ,
sub_account_id  number default 0 not null,
daily_change  decimal(38,15) null,
daily_ote_fut  decimal(38,15) null,
daily_ote_opt  decimal(38,15) null,
daily_ote_disc  decimal(38,15) null,
daily_vm_fut  decimal(38,15) null,
daily_vm_opt  decimal(38,15) null,
daily_vm_disc  decimal(38,15) null,
daily_lov  decimal(38,15) null,
daily_sov  decimal(38,15) null,
daily_commission  decimal(38,15) null,
daily_fees  decimal(38,15) null,
daily_futures_pl  decimal(38,15) null,
daily_option_premium  decimal(38,15) null,
daily_option_cash_settlement  decimal(38,15) null,
daily_cash_movements  decimal(38,15) null,
version  number not null,
daily_margin_call_in decimal(38,15) null,
daily_margin_call_out decimal(38,15) null,
daily_mc_rehyp_in decimal(38,15) null,
daily_mc_rehyp_out decimal(38,15) null,
daily_mc_non_rehyp_in decimal(38,15) null,
daily_mc_non_rehyp_out decimal(38,15) null,
daily_mc_book_owner_in decimal(38,15) null,
daily_mc_book_owner_out decimal(38,15) null)
/

insert /*+ parallel(8) */  into inv_cash_movement 
select   
 internal_external,
 position_type,
 agent_id ,
 account_id,
 date_type,
 position_date,
 currency_code,
 book_id ,
 config_id, 
 mcc_id ,
 0,
 daily_change as daily_change, 
daily_ote_fut as daily_ote_fut,
daily_ote_opt as daily_ote_opt,
daily_ote_disc as daily_ote_disc, 
daily_vm_fut as daily_vm_fut,
daily_vm_opt as daily_vm_opt,
daily_vm_disc as daily_vm_disc, 
daily_lov as daily_lov,
daily_sov as daily_sov,
daily_commission as daily_commission,
daily_fees as daily_fees,
daily_futures_pl as daily_futures_pl,
daily_option_premium as daily_option_premium,
daily_option_cash_settlement as daily_option_cash_settlement,
daily_cash_movements as daily_cash_movements,
version ,
daily_margin_call_in as daily_margin_call_in,
daily_margin_call_out as daily_margin_call_out,
daily_mc_rehyp_in as daily_mc_rehyp_in,
daily_mc_rehyp_out as daily_mc_rehyp_out,
daily_mc_non_rehyp_in as daily_mc_non_rehyp_in,
daily_mc_non_rehyp_out as daily_mc_non_rehyp_out,
daily_mc_book_owner_in as daily_mc_book_owner_in,
daily_mc_book_owner_out as daily_mc_book_owner_out from inv_cash_movement_back161
/

create table inv_sec_balance (
internal_external  varchar2(32) not null,
        position_type  varchar2(32) not null,
        date_type  varchar2(32) not null,
        agent_id   number not null,
        account_id   number not null,
        position_date  timestamp not null,
        security_id   number not null,
        book_id   number not null,
        config_id   number  default  0  not null,
        mcc_id   number default  0 not null    ,
		sub_account_id  number default 0 not null,
		total_security   decimal(38,15) null,
        total_borrowed   decimal(38,15) null,
        t_bor_not_avl   decimal(38,15) null,
        total_borrowed_ca   decimal(38,15) null,
        total_loaned   decimal(38,15) null,
        t_loan_not_avl   decimal(38,15) null,
        total_loaned_ca   decimal(38,15) null,
        total_coll_in   decimal(38,15) null,
        t_coll_in_not_avl   decimal(38,15) null,
        total_coll_in_ca   decimal(38,15) null,
        total_coll_out   decimal(38,15) null,
        t_coll_out_not_avl   decimal(38,15) null,
        total_coll_out_ca   decimal(38,15) null,
        total_pledged_in   decimal(38,15) null,
        total_pledged_out   decimal(38,15) null,
        total_unavail   decimal(38,15) null,
        total_repo_track_in   decimal(38,15) null,
        total_repo_track_out   decimal(38,15) null,
        total_borrowed_auto   decimal(38,15) null,
        total_loaned_auto   decimal(38,15) null,
        total_pth_in   decimal(38,15) null,
        total_pth_out   decimal(38,15) null,
        total_hold_in   decimal(38,15) null,
        total_hold_out   decimal(38,15) null,
        total_margin_call_in   decimal(38,15) null,
        total_margin_call_out   decimal(38,15) null,
        total_triparty_mc_in   decimal(38,15) null,
        total_triparty_mc_out   decimal(38,15) null,
        total_simple_transfer_in   decimal(38,15) null,
		total_simple_transfer_out   decimal(38,15) null,
        total_repo_callable_in   decimal(38,15) null,
        total_repo_callable_out   decimal(38,15) null,
        total_seclending_callable_in   decimal(38,15) null,
        total_seclending_callable_out   decimal(38,15) null,
        total_margin_call_rehypo   decimal(38,15) null,        
        total_repo_bsb_in   decimal(38,15) null,        
        total_repo_bsb_out   decimal(38,15) null,               
        total_repo_in   decimal(38,15) null,   
        total_repo_out   decimal(38,15) null,          
        version   number not null,
		total_mc_rehyp_in decimal(38,15) null,
		total_mc_rehyp_out decimal(38,15) null,
		total_mc_non_rehyp_in decimal(38,15) null,
		total_mc_non_rehyp_out decimal(38,15) null,
		total_mc_book_owner_in decimal(38,15) null,
		total_mc_book_owner_out decimal(38,15) null)
/

insert /*+ parallel(8) */  into inv_sec_balance  
select 
internal_external,
position_type,
date_type,
agent_id,
account_id,
position_date,
security_id,
book_id,
config_id,
mcc_id,
0,
total_security  as total_security,
total_borrowed  as total_borrowed,
t_bor_not_avl  as t_bor_not_avl,
total_borrowed_ca  as total_borrowed_ca,
total_loaned  as total_loaned,
t_loan_not_avl  as t_loan_not_avl,
total_loaned_ca  as total_loaned_ca,
total_coll_in  as total_coll_in,
t_coll_in_not_avl  as t_coll_in_not_avl,
total_coll_in_ca  as total_coll_in_ca,
total_coll_out  as total_coll_out,
t_coll_out_not_avl  as t_coll_out_not_avl,
total_coll_out_ca  as total_coll_out_ca,
total_pledged_in  as total_pledged_in,
total_pledged_out  as total_pledged_out,
total_unavail  as total_unavail,
total_repo_track_in  as total_repo_track_in,
total_repo_track_out  as total_repo_track_out,
total_borrowed_auto  as total_borrowed_auto,
total_loaned_auto  as total_loaned_auto,
total_pth_in  as total_pth_in,
total_pth_out  as total_pth_out,
total_hold_in  as total_hold_in,
total_hold_out  as total_hold_out,
total_margin_call_in  as total_margin_call_in,
total_margin_call_out  as total_margin_call_out,
total_triparty_mc_in  as total_triparty_mc_in,
total_triparty_mc_out  as total_triparty_mc_out,
total_simple_transfer_in  as total_simple_transfer_in,
total_simple_transfer_out  as total_simple_transfer_out,
total_repo_callable_in  as total_repo_callable_in,
total_repo_callable_out  as total_repo_callable_out,
total_seclending_callable_in  as total_seclending_callable_in,
total_seclending_callable_out as total_seclending_callable_out,
total_margin_call_rehypo  as total_margin_call_rehypo,
total_repo_bsb_in  as total_repo_bsb_in,
total_repo_bsb_out  as total_repo_bsb_out,
total_repo_in  as total_repo_in,
total_repo_out  as total_repo_out ,
version ,
total_mc_rehyp_in as total_mc_rehyp_in,
total_mc_rehyp_out as total_mc_rehyp_out,
total_mc_non_rehyp_in as total_mc_non_rehyp_in,
total_mc_non_rehyp_out  as total_mc_non_rehyp_out,
total_mc_book_owner_in as total_mc_book_owner_in,
total_mc_book_owner_out as total_mc_book_owner_out from inv_sec_balance_back161
/

create table inv_sec_movement (
        internal_external varchar2(32) not null,
        position_type varchar2(32) not null,
        date_type varchar2(32) not null,
        agent_id  number not null,
        account_id  number not null,
        position_date timestamp not null,
        security_id  number not null,
        book_id  number not null,
        config_id  number default 0 not null,
        mcc_id  number default 0  not null ,
		sub_account_id  number default 0 not null,
		daily_security  decimal(38,15) null,
        daily_borrowed  decimal(38,15) null,
        d_bor_not_avl  decimal(38,15) null,
        daily_borrowed_ca  decimal(38,15) null,
        daily_loaned  decimal(38,15) null,
        d_loan_not_avl  decimal(38,15) null,
        daily_loaned_ca  decimal(38,15) null,
        daily_coll_in  decimal(38,15) null,
        d_coll_in_not_avl  decimal(38,15) null,
        daily_coll_in_ca  decimal(38,15) null,
        daily_coll_out  decimal(38,15) null,
        d_coll_out_not_avl  decimal(38,15) null,
        daily_coll_out_ca  decimal(38,15) null,
        daily_pledged_in  decimal(38,15) null,
        daily_pledged_out  decimal(38,15) null,
        daily_unavail  decimal(38,15) null,
        daily_repo_track_in  decimal(38,15) null,
        daily_repo_track_out  decimal(38,15) null,
        daily_borrowed_auto  decimal(38,15) null,
        daily_loaned_auto  decimal(38,15) null,
        daily_pth_in  decimal(38,15) null,
        daily_pth_out  decimal(38,15) null,
		daily_hold_in  decimal(38,15) null,
        daily_hold_out  decimal(38,15) null,
        daily_margin_call_in  decimal(38,15) null,
		daily_margin_call_out  decimal(38,15) null,
		daily_triparty_mc_in  decimal(38,15) null,
		daily_triparty_mc_out  decimal(38,15) null,
		daily_simple_transfer_in  decimal(38,15) null,
		daily_simple_transfer_out  decimal(38,15) null,
        daily_repo_callable_in  decimal(38,15) null,
		daily_repo_callable_out  decimal(38,15) null,
		daily_seclending_callable_in  decimal(38,15) null,
		daily_seclending_callable_out  decimal(38,15) null,
		daily_margin_call_rehypo  decimal(38,15) null,
		daily_repo_bsb_in  decimal(38,15) null,        
        daily_repo_bsb_out  decimal(38,15) null, 
        daily_repo_in  decimal(38,15) null,   
        daily_repo_out  decimal(38,15) null,      
        version  number not null,
		daily_mc_rehyp_in decimal(38,15) null, 
		daily_mc_rehyp_out decimal(38,15) null, 
		daily_mc_non_rehyp_in decimal(38,15) null, 
		daily_mc_non_rehyp_out decimal(38,15) null, 
		daily_mc_book_owner_in decimal(38,15) null, 
		daily_mc_book_owner_out decimal(38,15) null)
/

insert /*+ parallel(8) */  into  inv_sec_movement  select  
internal_external,
position_type,
date_type,
agent_id,
account_id,
position_date,
security_id,
book_id,
config_id,
mcc_id,
0,
daily_security  as daily_security,
daily_borrowed  as daily_borrowed,
d_bor_not_avl  as d_bor_not_avl,
daily_borrowed_ca  as daily_borrowed_ca,
daily_loaned  as daily_loaned,
d_loan_not_avl  as d_loan_not_avl,
daily_loaned_ca  as daily_loaned_ca,
daily_coll_in  as daily_coll_in,
d_coll_in_not_avl  as d_coll_in_not_avl,
daily_coll_in_ca  as daily_coll_in_ca,
daily_coll_out  as daily_coll_out,
d_coll_out_not_avl  as d_coll_out_not_avl,
daily_coll_out_ca  as daily_coll_out_ca,
daily_pledged_in  as daily_pledged_in,
daily_pledged_out  as daily_pledged_out,
daily_unavail  as daily_unavail,
daily_repo_track_in  as daily_repo_track_in,
daily_repo_track_out  as daily_repo_track_out,
daily_borrowed_auto  as daily_borrowed_auto,
daily_loaned_auto  as daily_loaned_auto,
daily_pth_in  as daily_pth_in,
daily_pth_out  as daily_pth_out,
daily_hold_in  as daily_hold_in,
daily_hold_out  as daily_hold_out,
daily_margin_call_in  as daily_margin_call_in,
daily_margin_call_out  as daily_margin_call_out,
daily_triparty_mc_in  as daily_triparty_mc_in,
daily_triparty_mc_out  as daily_triparty_mc_out,
daily_simple_transfer_in  as daily_simple_transfer_in,
daily_simple_transfer_out  as daily_simple_transfer_out,
daily_repo_callable_in  as daily_repo_callable_in,
daily_repo_callable_out  as daily_repo_callable_out,
daily_seclending_callable_in as daily_seclending_callable_in,
daily_seclending_callable_out as daily_seclending_callable_out,
daily_margin_call_rehypo  as daily_margin_call_rehypo,
daily_repo_bsb_in  as daily_repo_bsb_in,
daily_repo_bsb_out  as daily_repo_bsb_out,
daily_repo_in  as daily_repo_in,
daily_repo_out  as daily_repo_out,
version ,
daily_mc_rehyp_in as daily_mc_rehyp_in, 
daily_mc_rehyp_out as daily_mc_rehyp_out,
daily_mc_non_rehyp_in as daily_mc_non_rehyp_in, 
daily_mc_non_rehyp_out as daily_mc_non_rehyp_out,
daily_mc_book_owner_in as daily_mc_book_owner_in,
daily_mc_book_owner_out as daily_mc_book_owner_out from inv_sec_movement_back161
/

alter table inv_sec_movement noparallel logging
/

alter table inv_sec_balance noparallel logging
/

alter table inv_cash_movement noparallel logging
/

alter table inv_cash_balance noparallel logging
/

drop table inv_cash_balance_back161
/

drop table inv_cash_movement_back161
/

drop table inv_sec_balance_back161
/

drop table inv_sec_movement_back161
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-374192' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-374192-1.sql */
/* Start of the SQL statements from file:CAL-376349-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-376349',1,CURRENT_TIMESTAMP,'started')
/

UPDATE curve_parameter SET value = REPLACE(VALUE, ',', '.') WHERE parameter_name IN ('January','February','March','April','May','June','July','August','September','October','November','December')
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-376349' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-376349-1.sql */
/* Start of the SQL statements from file:CAL-371591-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-371591',1,CURRENT_TIMESTAMP,'started')
/

/*
CAL-371591
Sets pl methodology to 'transfer' only for SimpleTransfer products if it was 'CASH_PL' or was changed to 'AmortizedCost'
because of script provided for CAL-305182.
*/ 
UPDATE pl_methodology_config_items m
SET m.methodology_name = 'Transfer' 
WHERE m.product_type = 'SimpleTransfer' 
AND (m.methodology_name = 'CASH_PL' OR m.methodology_name = 'AmortizedCost')
/

UPDATE official_pl_mark m 
SET m.methodology = 'Transfer'
WHERE m.effective_product_type = 'SimpleTransfer' 
AND (m.methodology = 'CASH_PL' OR m.methodology = 'AmortizedCost')
/

UPDATE official_pl_mark_hist m 
SET m.methodology = 'Transfer'
WHERE m.effective_product_type = 'SimpleTransfer' 
AND (m.methodology = 'CASH_PL' OR m.methodology = 'AmortizedCost')
/

UPDATE official_pl_aggregate_item m 
SET m.methodology = 'Transfer'
WHERE m.effective_product_type = 'SimpleTransfer' 
AND (m.methodology = 'CASH_PL' OR m.methodology = 'AmortizedCost')
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-371591' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-371591-1.sql */
/* Start of the SQL statements from file:CAL-371321-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-371321',1,CURRENT_TIMESTAMP,'started')
/

update acc_rule set version_num = 0 where version_num is NULL
/

update acc_rule set po_id = 0 where po_id is NULL
/

update acc_rule set liq_agg_conf_id = 0 where liq_agg_conf_id is NULL
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-371321' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-371321-1.sql */
/* Start of the SQL statements from file:CAL-378859-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-378859',1,CURRENT_TIMESTAMP,'started')
/

/*CURVE_POINT_ADJ  & CURVE_QUOTE_ADJ grows with zero values - getPricingEnv() call performance issue*/

create table curve_point_adj_new as (select * from curve_point_adj where adj_value !=0)
/

alter table curve_point_adj rename to curve_point_adj_back
/

alter table curve_point_adj_new rename to curve_point_adj
/

drop table curve_point_adj_back
/

create table curve_quote_adj_new as (select * from curve_quote_adj where adj_value !=0)
/

alter table curve_quote_adj rename to curve_quote_adj_back
/

alter table curve_quote_adj_new rename to curve_quote_adj
/

drop table curve_quote_adj_back
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-378859' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-378859-1.sql */
/* Start of the SQL statements from file:CAL-379875-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-379875',1,CURRENT_TIMESTAMP,'started')
/

DELETE FROM domain_values WHERE name = 'engineName' AND value ='CollateralServiceIntegrationEngine'
/

DELETE FROM domain_values WHERE name = 'eventFilter' AND value ='CollateralServiceIntegrationEventFilter'
/

DELETE FROM engine_config WHERE ENGINE_NAME = 'CollateralServiceIntegrationEngine'
/

DELETE from engine_param where ENGINE_NAME = 'CollateralServiceIntegrationEngine'
/

DELETE from ps_event_config WHERE ENGINE_NAME = 'CollateralServiceIntegrationEngine'
/

DELETE from ps_event_filter WHERE ENGINE_NAME = 'CollateralServiceIntegrationEngine'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-379875' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-379875-1.sql */
/* Start of the SQL statements from file:CAL-377334-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-377334',1,CURRENT_TIMESTAMP,'started')
/

/* move official_pl_temp_id to temp table -- need to drop the table so it can be created again as temp table and to remove request_id which is not needed anymore */
begin 
drop_table_if_exists('official_pl_temp_id');
end;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-377334' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-377334-1.sql */
/* Start of the SQL statements from file:CAL-377359-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-377359',1,CURRENT_TIMESTAMP,'started')
/

declare 
y int;
x int;
BEGIN
	select max(vsize(CURRENCY_LIST)) into x from fee_config;
	select count(*) into y from fee_config;
	exception WHEN NO_DATA_FOUND THEN
	x:=0;
	y:=0;
	if (y = 0 or x <= 400) then
		execute immediate 'alter table fee_config modify (CURRENCY_LIST varchar2(400))';
	end if;
END;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-377359' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-377359-1.sql */
/* Start of the SQL statements from file:CAL-359075-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-359075',1,CURRENT_TIMESTAMP,'started')
/

create or replace procedure sp_pl_methodology_driver as
  x integer := 0;
  y integer := 0;
  z integer := 0;
  pl_meth_driver VARCHAR2(32); 
  book_attr_name VARCHAR2(32); 
  begin      
		SELECT COUNT(DISTINCT pl_methodology_driver) INTO x FROM pl_methodology_config;
		DBMS_OUTPUT.PUT_LINE('checking the methodology driver(s) in pl_methodology_config. '|| x);
		SELECT count(*) INTO y FROM book_attribute WHERE is_pl_methodology_driver = 1;
		DBMS_OUTPUT.PUT_LINE('checking pl methodology driver book attribute exist. '|| y );	
	
  IF x > 1 THEN
      DBMS_OUTPUT.PUT_LINE('Error occured - Found multiple methodology drivers in pl_methodology_config table');
  END IF;	
  
  IF y > 1 THEN
        DBMS_OUTPUT.PUT_LINE('Error occured - there should be only one book attribute set to pl methodology driver in book_attribute table');
  END IF;
  
  IF x = 1 THEN
  	SELECT DISTINCT pl_methodology_driver INTO pl_meth_driver FROM pl_methodology_config;
  	DBMS_OUTPUT.PUT_LINE('Methodology driver in pl_methodology_config - '|| pl_meth_driver);
  	
  	IF y = 0 THEN
  		SELECT count(*) INTO z FROM book_attribute WHERE attribute_name = pl_meth_driver;
  		IF z = 0 THEN
  			execute immediate 'INSERT INTO book_attribute(attribute_name,is_pl_methodology_driver) VALUES (' ||chr(39)||pl_meth_driver||chr(39)|| ', 1)';  
  		ELSIF z = 1 THEN
			execute immediate 'UPDATE book_attribute SET is_pl_methodology_driver = 1 WHERE attribute_name = ' ||chr(39)||pl_meth_driver||chr(39);
  		END IF;
  	ELSIF y = 1 THEN
  	  SELECT attribute_name INTO book_attr_name FROM book_attribute WHERE is_pl_methodology_driver = 1;
	  DBMS_OUTPUT.PUT_LINE('Pl methodology driver book attribute - '|| book_attr_name);	
  	
	  IF (pl_meth_driver != book_attr_name) THEN
	  	DBMS_OUTPUT.PUT_LINE('Error occured - Pl methodology driver in pl_methodology_config table do not match Pl methodology driver book attribute');
	  ELSE
	  	DBMS_OUTPUT.PUT_LINE('Pl methodology driver in pl_methodology_config table match Pl methodology driver book attribute');
	  END IF;
  	END IF;  
  END IF;  
END;
/

begin
sp_pl_methodology_driver;
end;
/

drop procedure sp_pl_methodology_driver
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-359075' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-359075-1.sql */
/* Start of the SQL statements from file:CAL-357588-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-357588',1,CURRENT_TIMESTAMP,'started')
/

/* initialize the new original price column on all liquidations to the first trade price */
/* then update specific liquidation types, only when average price methodologies are in use */
/* for Buy/Sell (type=0) and CA REDEMPTION (type=9), set original price to the first TOQ's price (signed), as it would be when not using average price */
/* for REALIZED liquidations (type=2), first price is a constant 0 (CA CASH) or 1 (Fees) and not related to a trade or position price; it can stay as first price */
/* for the other CA types - AMORTIZATION (3), PAYDOWN (7), REFERENTIAL (8) - set original price to the first TOQ's price (unsigned), as it would be when not using average price */
update liq_position set original_price = first_price
/

declare using_avgprice integer := 0;
begin
	select count(*) into using_avgprice from liq_info where liq_method in ('TDWAC','WAC','WACSL','AvgCost','AvgPrice');
    if using_avgprice > 0 then
    begin
		update liq_position set original_price = (select
			case
				when lp2.type in (0,9) 
				then trade_open_qty.price * SIGN(trade_open_qty.quantity) 
				when lp2.type in (3,7,8) 
				then trade_open_qty.price 
			end
			from trade_open_qty, liq_position lp2
			where trade_open_qty.book_id = lp2.book_id
			and trade_open_qty.product_id = lp2.product_id
			and trade_open_qty.liq_agg_id = lp2.liq_agg_id
			and trade_open_qty.liq_config_id = lp2.liq_config_id
			and trade_open_qty.sign = lp2.first_rel_id
			and trade_open_qty.linked_id = lp2.first_linked_id
			and trade_open_qty.settle_date = lp2.first_settle_date
			and trade_open_qty.trade_id = lp2.first_trade
			and liq_position.order_id = lp2.order_id
		)
		where liq_position.type in (0,9,3,7,8);
    end;	
    end if;
end;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-357588' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-357588-1.sql */
/* Start of the SQL statements from file:CAL-384964-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-384964',1,CURRENT_TIMESTAMP,'started')
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-384964' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-384964-1.sql */
/* Start of the SQL statements from file:CAL-385090-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-385090',1,CURRENT_TIMESTAMP,'started')
/

UPDATE credit_rating
SET debt_seniority = 'ANY'
WHERE upper(debt_seniority) = 'ANY'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-385090' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-385090-1.sql */
/* Start of the SQL statements from file:CAL-385399-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-385399',1,CURRENT_TIMESTAMP,'started')
/

DELETE FROM auth_class_config WHERE full_class_name = 'com.calypso.engine.risk.util.mcc.MCCBagTol '
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-385399' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-385399-1.sql */
/* Start of the SQL statements from file:CAL-387866-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-387866',1,CURRENT_TIMESTAMP,'started')
/

CREATE OR REPLACE
PROCEDURE rename_pws_items_columns
AS
BEGIN
  EXECUTE immediate 'CREATE TABLE am_grouping_columns_bk as (select * from am_grouping_columns)';
  EXECUTE immediate 'CREATE TABLE am_filtering_columns_bk  as (select * from am_filtering_columns)';
  EXECUTE immediate 'CREATE TABLE am_columnset_main_columns_bk as (select * from  am_columnset_main_columns)';
  EXECUTE immediate 'CREATE TABLE am_columnset_pivot_columns_bk as (select * from   am_columnset_pivot_columns)';
  EXECUTE immediate 'CREATE TABLE am_columnset_group_columns_bk as (select * from  am_columnset_group_columns)';
  EXECUTE immediate 'CREATE TABLE am_columnset_break_columns_bk as (select * from  am_columnset_breakdown_columns)';
  EXECUTE immediate 'CREATE TABLE am_coloring_colord_columns_bk as (select * from am_coloring_colored_columns)';
  EXECUTE immediate 'CREATE TABLE am_unit_denominator_column_bk as (select * from  am_unit_denominator_column)';
  EXECUTE immediate 'CREATE TABLE am_columnset_config_bk as (select * from am_columnset_configuration)';
  EXECUTE immediate 'CREATE TABLE am_columnset_profiles_bk as (select * from am_columnset_profiles)';
  EXECUTE immediate 'CREATE TABLE am_columnset_widgets_bk as (select * from am_columnset_widgets)';
  EXECUTE immediate 'CREATE TABLE am_columnset_actions_bk as (select * from am_columnset_actions)';
  EXECUTE immediate 'CREATE TABLE am_unit_configuration_bk as (select * from am_unit_configuration)';
  EXECUTE immediate 'CREATE TABLE am_unit_profiles_bk as (select * from am_unit_profiles)';
  EXECUTE immediate 'CREATE TABLE am_grouping_configuration_bk as (select * from am_grouping_configuration)';
  EXECUTE immediate 'CREATE TABLE am_grouping_profiles_bk as (select * from am_grouping_profiles)';
  EXECUTE immediate 'CREATE TABLE am_filtering_configuration_bk as (select * from am_filtering_configuration)';
  EXECUTE immediate 'CREATE TABLE am_filtering_profiles_bk as (select * from am_filtering_profiles)';
  EXECUTE immediate 'CREATE TABLE am_coloring_configuration_bk as (select * from am_coloring_configuration)';
  EXECUTE immediate 'CREATE TABLE am_coloring_profiles_bk as (select * from am_coloring_profiles)';
  EXECUTE immediate 'CREATE TABLE am_coloring_rule_config_bk as (select * from am_coloring_rule_configuration)';
  EXECUTE immediate 'truncate table am_grouping_columns';
  EXECUTE immediate 'truncate table am_filtering_columns';
  EXECUTE immediate 'truncate table am_columnset_main_columns';
  EXECUTE immediate 'truncate table am_columnset_pivot_columns';
  EXECUTE immediate 'truncate table am_columnset_group_columns';
  EXECUTE immediate 'truncate table am_columnset_breakdown_columns';
  EXECUTE immediate 'truncate table am_unit_denominator_column';
  EXECUTE immediate 'truncate table am_columnset_configuration';
  EXECUTE immediate 'truncate table am_columnset_profiles';
  EXECUTE immediate 'truncate table am_columnset_widgets';
  EXECUTE immediate 'truncate table am_columnset_actions';
  EXECUTE immediate 'truncate table am_unit_configuration';
  EXECUTE immediate 'truncate table am_unit_profiles';
  EXECUTE immediate 'truncate table am_grouping_configuration';
  EXECUTE immediate 'truncate table am_grouping_profiles';
  EXECUTE immediate 'truncate table am_filtering_configuration';
  EXECUTE immediate 'truncate table am_filtering_profiles';
  EXECUTE immediate 'truncate table am_coloring_configuration';
  EXECUTE immediate 'truncate table am_coloring_profiles';
  EXECUTE immediate 'truncate table am_coloring_rule_configuration';

EXCEPTION
WHEN OTHERS THEN
  NULL;
END rename_pws_items_columns;
/

begin 
	rename_pws_items_columns;
end;
/

DROP PROCEDURE rename_pws_items_columns
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-387866' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-387866-1.sql */
/* Start of the SQL statements from file:CAL-389341-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-389341',1,CURRENT_TIMESTAMP,'started')
/

update quartz_sched_task_attr sta set sta.attr_name = 'Save Results' where sta.attr_name = 'Save Results ? ' and exists (select NULL from quartz_sched_task st where st.task_id = sta.task_id and st.task_type = 'ERS_ANALYSIS')
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-389341' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-389341-1.sql */
/* Start of the SQL statements from file:CAL-380148-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('middleofficeam','CAL-380148',1,CURRENT_TIMESTAMP,'started')
/

update product_desc set und_security_id = product_id where product_type = 'UnitizedFund' and und_security_id = 0
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-380148' and version=1 and module='middleofficeam'
/

/* End of the SQL statements from file:CAL-380148-1.sql */
/* Start of the SQL statements from file:COLT-12800-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('collateral','COLT-12800',1,CURRENT_TIMESTAMP,'started')
/

DECLARE        
        v_rows_exists number := 0;
		v_table_exists number := 0;
 
BEGIN	
		select count(*) into v_table_exists from user_tables where table_name = 'COLLATERAL_CONFIG_FIELD_DUMMY';
		
		if (v_table_exists > 0) then
		execute immediate 'drop table COLLATERAL_CONFIG_FIELD_DUMMY';
		end if;
		
		select count(*) into v_rows_exists from collateral_config_field where mcc_field='ACADIA_AUTO_DISPUTE';
        
		if (v_rows_exists > 0) then
		
				execute immediate 'create table COLLATERAL_CONFIG_FIELD_DUMMY AS (
				select * from collateral_config_field where mcc_field=''ACADIA_AUTO_DISPUTE'')';
				
				execute immediate 'insert into collateral_config_field (mcc_id, mcc_field, mcc_value) (
				select distinct mcc_id,''ACADIA_CALL_ABOVE_TOLERANCE'' Col1, ''false'' col2 from COLLATERAL_CONFIG_FIELD_DUMMY where mcc_field in (''ACADIA_AUTO_DISPUTE'') and lower(mcc_value)=''false'')';
				
				execute immediate 'insert into collateral_config_field (mcc_id, mcc_field, mcc_value) (
				select distinct mcc_id,''ACADIA_CALL_ABOVE_TOLERANCE'' Col1, ''true'' col2 from COLLATERAL_CONFIG_FIELD_DUMMY where mcc_field in (''ACADIA_AUTO_DISPUTE'') and lower(mcc_value)=''true'')';
				
				execute immediate 'insert into collateral_config_field (mcc_id, mcc_field, mcc_value) (
				select distinct mcc_id,''ACADIA_CALL_NOTIFICATION_TIME'' Col1, ''No STP'' col2 from COLLATERAL_CONFIG_FIELD_DUMMY where mcc_field in (''ACADIA_AUTO_DISPUTE''))';
		
		end if;
		select count(*) into v_table_exists from user_tables where table_name = 'COLLATERAL_CONFIG_FIELD_DUMMY';
		
		if (v_table_exists > 0) then
		execute immediate 'drop table COLLATERAL_CONFIG_FIELD_DUMMY';
		end if;
END;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='COLT-12800' and version=1 and module='collateral'
/

/* End of the SQL statements from file:COLT-12800-1.sql */
/* Start of the SQL statements from file:COLT-13175-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('collateral','COLT-13175',1,CURRENT_TIMESTAMP,'started')
/

update collateral_config set LE_THRESH_APPL = 'IA + MTM',PO_THRESH_APPL = 'IA + MTM' where PO_THRESH_APPL is null and LE_THRESH_APPL is null
/

update exposure_group_definition set LE_THRESH_APPL = 'IA + MTM',PO_THRESH_APPL = 'IA + MTM' where PO_THRESH_APPL is null and LE_THRESH_APPL is null
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='COLT-13175' and version=1 and module='collateral'
/

/* End of the SQL statements from file:COLT-13175-1.sql */
/* Post Upgrade - Start */
drop procedure add_column_if_not_exists
/

drop procedure drop_column_if_exists
/

drop procedure add_domain_values
/

drop procedure drop_fk_on_table
/

drop procedure drop_pk_if_exists
/

drop procedure drop_uk_if_exists
/

drop procedure drop_procedure_if_exists
/

drop procedure drop_uq_on_table
/

drop procedure drop_unique_if_exists
/

drop procedure drop_table_if_exists
/

drop procedure add_pk_if_not_exists
/

drop procedure run_query_if_tables_exist
/

drop type list_of_names_t
/

drop procedure rename_column_if_exists
/

/* Post Upgrade - End */

/* Applying Schema Statements - start */

    ALTER TABLE PROD_EXCH_CODE DROP CONSTRAINT pk_prod_exch_code1 CASCADE DROP INDEX
/

    alter table tws_blotter_node 
       drop constraint fk_tws_blotter_node
/

    alter table tws_node 
       drop constraint fk_tws_node_id
/

    alter table tws_risk_node 
       drop constraint fk_tws_risk_node
/

    ALTER TABLE PS_STRATEGY_INFO DROP CONSTRAINT pk_ps_strategy_info1 CASCADE DROP INDEX
/

    ALTER TABLE PS_STRATEGY_INFO_HIST DROP CONSTRAINT pk_ps_strategy_info_1 CASCADE DROP INDEX
/

    ALTER TABLE MARGIN_RESULT DROP CONSTRAINT pk_margin_result1 CASCADE DROP INDEX
/

    ALTER TABLE MARGIN_RESULT_HIST DROP CONSTRAINT pk_margin_result_his1 CASCADE DROP INDEX
/

    ALTER TABLE CM_CALCULATION_SET MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,OFFICIAL numeric)
/

    ALTER TABLE CM_RF_SOURCE MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE CM_RF_STATUS MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,IMPORT_DATE numeric)
/

    ALTER TABLE CM_SIMM_CALC_REQUEST MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,VALUATION_DATE numeric,REQUEST_TIME numeric,SAVE_RESULTS numeric)
/

    ALTER TABLE CM_SIMM_CALC_REQUEST_ERRORS MODIFY (ERROR_MESSAGES_ORDER numeric)
/

    ALTER TABLE CM_SIMM_WHAT_IF_REQUEST MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,VALUATION_DATE numeric)
/

    ALTER TABLE CM_RF_WHAT_IF MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,VALUATION_DATE numeric)
/

    ALTER TABLE CM_RF_TRADE MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,VALUATION_DATE numeric)
/

    ALTER TABLE CM_SIMM_BUCKET MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE CM_RF_STATUS_HIST MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,IMPORT_DATE numeric)
/

    ALTER TABLE CM_RF_STATUS_TEMP MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,IMPORT_DATE numeric)
/

    ALTER TABLE CM_RF_TRADE_HIST MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,VALUATION_DATE numeric)
/

    ALTER TABLE CM_RF_TRADE_TEMP MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,VALUATION_DATE numeric)
/

    ALTER TABLE CM_SIMM_CALC_REQUEST_HIST MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,VALUATION_DATE numeric,REQUEST_TIME numeric,SAVE_RESULTS numeric)
/

    ALTER TABLE CM_SIMM_CALC_REQ_ERRORS_HIST MODIFY (ERROR_MESSAGES_ORDER numeric)
/

    ALTER TABLE CM_SIMM_CALC_REQUEST_TEMP MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,VALUATION_DATE numeric,REQUEST_TIME numeric,SAVE_RESULTS numeric)
/

    ALTER TABLE CM_SIMM_CALC_REQ_ERRORS_TEMP MODIFY (ERROR_MESSAGES_ORDER numeric)
/

    ALTER TABLE CM_SIMM_WIF_REQ_TEMP MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,VALUATION_DATE numeric)
/

    ALTER TABLE CM_RF_WHAT_IF_TEMP MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,VALUATION_DATE numeric)
/

    ALTER TABLE CM_IM_MONITORING_CONFIG MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,VARIATION numeric)
/

    ALTER TABLE COLLATERAL_CONFIG MODIFY (MCC_ID numeric,ACCOUNT_ID numeric,CLEARING_MEMBER_ID numeric,CONTRACT_DISPUTE_TOL_PERC_B numeric,ACCEPT_ON_PO_FAVOR_B numeric,EXCLUDE_FROM_OPTIMIZER numeric,IS_INITIAL_MARGIN numeric,LE_RATING_CONFIG numeric,LE_RATING_HIER_CONFIG numeric,PO_RATING_CONFIG numeric,PO_RATING_HIER_CONFIG numeric,ROUNDING_BEFORE_MTA_B numeric,SETTLEMENT_OFFSET numeric,TBA_SETTLEMENT_OFFSET numeric,TRIPARTY_B numeric,CONFIG_ADHOC_DETAILS_ID numeric,VAL_TIME_OFFSET_ID numeric,IGNORE_MTA_ON_RETURN_B numeric,IGNORE_MTA_ON_RETURN_THRES_B numeric,QUOTE_OFFSET numeric,VAL_TIME_SECONDS numeric,NOTIFICATION_TIME_SECONDS numeric,SUBSTITUTION_TIME_SECONDS numeric,IS_INDEPENDENT_WF numeric,IS_DISTRIBUTE_TO_EXP numeric,IS_PORTFOLIO_DISTRIB numeric,IS_DIRECTION_BASED_INC numeric,BOOK_CASH_IN numeric,BOOK_CASH_OUT numeric,BOOK_SEC_IN numeric,BOOK_SEC_OUT numeric,MANDATORY_AGENCIES numeric,LE_IS_REHYPOTHECABLE numeric,IS_ASYM_ELIG_CURRENCIES numeric,IS_ASYM_ELIG_FILTERS numeric,IS_ASYM_ELIG_EXCLUSION numeric,ACADIA_B numeric,IS_SWEEP_EXP_GROUP numeric,DISPUTE_AGING_START numeric,TRACK_AS_DISPUTE numeric,ACCEPT_UNDISPUTED_AMT numeric,UNDISPUTED_PERCENTAGE numeric,NOV_DATE_INCL_EXCL_B numeric,REGULATORY_CSA_B numeric)
/

    ALTER TABLE COLLATERAL_CONFIG_BIN MODIFY (MCC_ID numeric)
/

    ALTER TABLE CONFIG_LINKED MODIFY (MCC_ID numeric,LINKED_MCC_ID numeric)
/

    ALTER TABLE COLLATERAL_CONFIG_FIELD MODIFY (MCC_ID numeric)
/

    ALTER TABLE MRGCALL_CONFIG_LE MODIFY (MCC_ID numeric,LE_ID numeric)
/

    ALTER TABLE COLLATERAL_CONFIG_CURRENCY MODIFY (MRG_CALL_DEF numeric,IS_COMPOUND numeric,IS_INCLUDED numeric,IS_PROJECTED numeric,IS_AUTO_ADJUST_MARGIN numeric,IS_RATE_INDEX_FLOOR numeric,AUTO_REPAYMENT numeric,ACCOUNT_ID numeric,IS_PO_ELIG numeric,IS_LE_ELIG numeric,ADJ_ORDER numeric,IS_EXPLODE_MRG numeric)
/

    ALTER TABLE COLLATERAL_CONFIG_BUFFER MODIFY (MRG_CALL_DEF numeric)
/

    ALTER TABLE EXPOSURE_GROUP_DEFINITION MODIFY (ID numeric,MRG_CALL_DEF numeric,BOOK_ID numeric,ORDER_INDEX numeric,ENABLE_ALLOC_PROC numeric,BOOK_CASH_IN numeric,BOOK_CASH_OUT numeric,BOOK_SEC_IN numeric,BOOK_SEC_OUT numeric,PARENT_ELIGIBILITY_BOOK numeric,PARENT_ELIGIBILITY_CURRENCY numeric,PARENT_ELIGIBILITY_SECURITY numeric,PO_ID numeric,TRIPARTY_B numeric,EXC_TRADE_HAIRCUT numeric,PO_IS_REHYPOTHECABLE numeric,LE_IS_REHYPOTHECABLE numeric,IS_ASYM_ELIG_CURRENCIES numeric,IS_ASYM_ELIG_FILTERS numeric,IS_ASYM_ELIG_EXCLUSION numeric,ACADIA_B numeric)
/

    ALTER TABLE ELIGIBLE_BOOKS_KV MODIFY (INTERNAL_ID numeric)
/

    ALTER TABLE MARGIN_CALL_ENTRIES MODIFY (ID numeric,AUDIT_VERSION numeric,ORM_VERSION numeric,MCC_ID numeric,IS_FULLY_PRICED numeric,IS_CFD numeric,IS_DISPUTE numeric,PARENT_ID numeric,MASTER_ENTRY_ID numeric,MASTER_CONFIG_ID numeric,IS_VALUATION_DAY numeric,ALLOCATION_ORDER numeric,DISPUTE_AGE numeric,DISPUTE_AGE_OFFSET numeric,COLLATERAL_CONTEXT_ID numeric,MARKING_REQUIRED numeric,DIRECTIONAL_DISPUTE_AGE numeric,DIRECTIONAL_DISPUTE_AGE_OFFSET numeric,EXPOSURE_SWING numeric)
/

    ALTER TABLE PENDING_MARGIN_CALL_ENTRIES MODIFY (ID numeric,AUDIT_VERSION numeric,ORM_VERSION numeric,MCC_ID numeric,IS_FULLY_PRICED numeric,IS_CFD numeric,IS_DISPUTE numeric,PARENT_ID numeric,MASTER_ENTRY_ID numeric,MASTER_CONFIG_ID numeric,IS_VALUATION_DAY numeric,ALLOCATION_ORDER numeric,DISPUTE_AGE numeric,DISPUTE_AGE_OFFSET numeric,COLLATERAL_CONTEXT_ID numeric,MARKING_REQUIRED numeric,DIRECTIONAL_DISPUTE_AGE numeric,DIRECTIONAL_DISPUTE_AGE_OFFSET numeric,EXPOSURE_SWING numeric)
/

    ALTER TABLE MRGCALL_ENTRIES_HIST MODIFY (ID numeric,AUDIT_VERSION numeric,ORM_VERSION numeric,MCC_ID numeric,IS_FULLY_PRICED numeric,IS_CFD numeric,IS_DISPUTE numeric,PARENT_ID numeric,MASTER_ENTRY_ID numeric,MASTER_CONFIG_ID numeric,IS_VALUATION_DAY numeric,ALLOCATION_ORDER numeric,DISPUTE_AGE numeric,DISPUTE_AGE_OFFSET numeric,COLLATERAL_CONTEXT_ID numeric,MARKING_REQUIRED numeric,DIRECTIONAL_DISPUTE_AGE numeric,DIRECTIONAL_DISPUTE_AGE_OFFSET numeric,EXPOSURE_SWING numeric)
/

    ALTER TABLE PENDING_ENTRIES_HEADER MODIFY (MC_ENTRY_ID numeric,PENDING_MC_ENTRY_ID numeric,DETAILS_ID numeric)
/

    ALTER TABLE MARGIN_CALL_DETAIL_ENTRIES MODIFY (ID numeric,MC_ENTRY_ID numeric,LIABILITY_ENTRY_ID numeric,MCC_ID numeric,AUDIT_VERSION numeric,TRADE_ID numeric,PRODUCT_ID numeric,IS_EXCLUDED numeric,TRADE_VERSION numeric,IS_DISPUTE numeric,PARENT_ID numeric,COLLATERAL_DATE_OFFSET numeric,DISPUTE_AGE numeric,IS_ERROR numeric,IS_PRICEABLE numeric)
/

    ALTER TABLE PENDING_MC_DETAIL_ENTRIES MODIFY (ID numeric,MC_ENTRY_ID numeric,LIABILITY_ENTRY_ID numeric,MCC_ID numeric,AUDIT_VERSION numeric,TRADE_ID numeric,PRODUCT_ID numeric,IS_EXCLUDED numeric,TRADE_VERSION numeric,IS_DISPUTE numeric,PARENT_ID numeric,COLLATERAL_DATE_OFFSET numeric,DISPUTE_AGE numeric,IS_ERROR numeric,IS_PRICEABLE numeric)
/

    ALTER TABLE MRGCALL_DETAIL_ENTRIES_HIST MODIFY (ID numeric,MC_ENTRY_ID numeric,LIABILITY_ENTRY_ID numeric,MCC_ID numeric,AUDIT_VERSION numeric,TRADE_ID numeric,PRODUCT_ID numeric,IS_EXCLUDED numeric,TRADE_VERSION numeric,IS_DISPUTE numeric,PARENT_ID numeric,COLLATERAL_DATE_OFFSET numeric,DISPUTE_AGE numeric,IS_ERROR numeric,IS_PRICEABLE numeric)
/

    ALTER TABLE LIABILITY_GROUP_ENTRIES MODIFY (ID numeric,MC_ENTRY_ID numeric,MCC_ID numeric,ALLOCATION_ORDER numeric)
/

    ALTER TABLE PENDING_LIABILITY_GR_ENTRIES MODIFY (ID numeric,MC_ENTRY_ID numeric,MCC_ID numeric,ALLOCATION_ORDER numeric)
/

    ALTER TABLE LIAB_GR_ENTRIES_HIST MODIFY (ID numeric,MC_ENTRY_ID numeric,MCC_ID numeric,ALLOCATION_ORDER numeric)
/

    ALTER TABLE CHART_CONFIG MODIFY (ID numeric)
/

    ALTER TABLE MARGIN_CALL_POSITIONS MODIFY (MC_ENTRY_ID numeric,MCC_ID numeric,PRODUCT_ID numeric,BOOK_ID numeric,ACCOUNT_ID numeric,EXP_PO_ID numeric,SOURCE_ID numeric,SOURCE_MCC_ID numeric)
/

    ALTER TABLE PENDING_MARGIN_CALL_POSITIONS MODIFY (MC_ENTRY_ID numeric,MCC_ID numeric,PRODUCT_ID numeric,BOOK_ID numeric,ACCOUNT_ID numeric,EXP_PO_ID numeric,SOURCE_ID numeric,SOURCE_MCC_ID numeric)
/

    ALTER TABLE MRGCALL_POSITIONS_HIST MODIFY (MC_ENTRY_ID numeric,MCC_ID numeric,PRODUCT_ID numeric,BOOK_ID numeric,ACCOUNT_ID numeric,EXP_PO_ID numeric,SOURCE_ID numeric,SOURCE_MCC_ID numeric)
/

    ALTER TABLE MARGIN_CALL_ALLOCATION MODIFY (MC_ENTRY_ID numeric,LIABILITY_ENTRY_ID numeric,MCC_ID numeric,BOOK_ID numeric,SOURCE_BOOK_ID numeric,PRODUCT_ID numeric,PASS_THROUGH_B numeric,TRADE_ID numeric,IS_MANUAL_CASH numeric,LOCKED numeric,TRADE_VERSION numeric,EXECUTION_ID numeric,RESERVATION_ID numeric,RESERVATION_TRADE_ID numeric,CONTRACT_ORDER numeric,LIABILITY_ORDER numeric,ALLOCATION_ORDER numeric,SOURCE_ID numeric,CONTEXT_ID numeric,SUBSTITUTION_ID numeric,LINKED_EXPOSURE_GROUP_ID numeric,SOURCE_CONTRACT_ID numeric,EXP_PO_ID numeric,LEGAL_ENTITY_ID numeric,HOLD numeric)
/

    ALTER TABLE PENDING_MARGIN_CALL_ALLOCATION MODIFY (MC_ENTRY_ID numeric,LIABILITY_ENTRY_ID numeric,MCC_ID numeric,BOOK_ID numeric,PRODUCT_ID numeric,PASS_THROUGH_B numeric,TRADE_ID numeric,IS_MANUAL_CASH numeric,LOCKED numeric,TRADE_VERSION numeric,EXECUTION_ID numeric,RESERVATION_ID numeric,RESERVATION_TRADE_ID numeric,CONTRACT_ORDER numeric,LIABILITY_ORDER numeric,ALLOCATION_ORDER numeric,SOURCE_ID numeric,CONTEXT_ID numeric,SUBSTITUTION_ID numeric,SOURCE_BOOK_ID numeric,LINKED_EXPOSURE_GROUP_ID numeric,SOURCE_CONTRACT_ID numeric,EXP_PO_ID numeric,LEGAL_ENTITY_ID numeric,HOLD numeric)
/

    ALTER TABLE MRGCALL_ALLOCATION_HIST MODIFY (MC_ENTRY_ID numeric,LIABILITY_ENTRY_ID numeric,MCC_ID numeric,BOOK_ID numeric,SOURCE_BOOK_ID numeric,PRODUCT_ID numeric,PASS_THROUGH_B numeric,TRADE_ID numeric,IS_MANUAL_CASH numeric,LOCKED numeric,TRADE_VERSION numeric,EXECUTION_ID numeric,RESERVATION_ID numeric,RESERVATION_TRADE_ID numeric,CONTRACT_ORDER numeric,LIABILITY_ORDER numeric,ALLOCATION_ORDER numeric,SOURCE_ID numeric,CONTEXT_ID numeric,SUBSTITUTION_ID numeric,LINKED_EXPOSURE_GROUP_ID numeric,SOURCE_CONTRACT_ID numeric,EXP_PO_ID numeric,LEGAL_ENTITY_ID numeric,HOLD numeric)
/

    ALTER TABLE COLLATERAL_CONCENTRATION MODIFY (ENTITY_ID numeric,LIABILITY_ENTRY_ID numeric,MCC_ID numeric,NETTED_LIABILITY numeric,LIMIT_ID numeric,BREAKDOWN_DEPTH numeric)
/

    ALTER TABLE PENDING_CONCENTRATION MODIFY (ENTITY_ID numeric,LIABILITY_ENTRY_ID numeric,MCC_ID numeric,NETTED_LIABILITY numeric,LIMIT_ID numeric,BREAKDOWN_DEPTH numeric)
/

    ALTER TABLE COLL_CONCENTRATION_HIST MODIFY (ENTITY_ID numeric,LIABILITY_ENTRY_ID numeric,MCC_ID numeric,NETTED_LIABILITY numeric,LIMIT_ID numeric,BREAKDOWN_DEPTH numeric)
/

    ALTER TABLE MRG_CONFIG_CONCENTRATION_RULE MODIFY (MCC_ID numeric,RULE_ID numeric)
/

    ALTER TABLE CONCENTRATION_RULE MODIFY (ID numeric,VERSION numeric,NETTED_LIABILITY numeric)
/

    ALTER TABLE CONCENTRATION_LIMIT MODIFY (ID numeric,RULE_ID numeric,PARENT_LIMIT_ID numeric,DEPTH numeric)
/

    ALTER TABLE OPTIMIZATION_CONFIGURATION MODIFY (ID numeric,VERSION numeric,PROCESS_ORG_ID numeric,TARGET_ID numeric,ROUNDING_DECIMALS numeric,OPTIMIZATION_DATE_OFFSET numeric,SCORING_SOLVER_ID numeric,LINKED_CONFIG_ID numeric)
/

    ALTER TABLE OPTIMIZATION_STEP MODIFY (OPTIMIZATION_CONFIG_ID numeric,DTO_ID numeric)
/

    ALTER TABLE OPTIMIZATION_STEP_KV MODIFY (ID numeric)
/

    ALTER TABLE ALLOCATION_VALIDATOR MODIFY (COLLATERAL_CONTEXT_ID numeric,DTO_ID numeric)
/

    ALTER TABLE ALLOCATION_VALIDATOR_KV MODIFY (ID numeric)
/

    ALTER TABLE TARGET_CONFIGURATION MODIFY (ID numeric,VERSION numeric,CONFIG_ID numeric,IS_REVERSE_HC numeric)
/

    ALTER TABLE ALLOCATION_RULE_CONFIGURATION MODIFY (TARGET_CONFIG_ID numeric,DTO_ID numeric)
/

    ALTER TABLE ALLOCATION_RULE_KV MODIFY (ID numeric)
/

    ALTER TABLE CONSTRAINT_CONFIGURATION MODIFY (CONFIG_ID numeric,IS_AUTOACCEPT numeric,IS_MANDATORY numeric)
/

    ALTER TABLE SUBSTITUTION_CONFIGURATION MODIFY (CONFIG_ID numeric)
/

    ALTER TABLE MRGCALL_SUBSTITUTION_CONFIG MODIFY (MRGCALL_ID numeric)
/

    ALTER TABLE ELIGIBILITY_EXCLUSION_CONFIG MODIFY (ID numeric,VERSION numeric)
/

    ALTER TABLE ELIGIBILITY_EXCLUSION MODIFY (CONFIG_ID numeric,PRODUCT_ID numeric)
/

    ALTER TABLE COLLATERAL_CONTEXT MODIFY (ID numeric,VERSION numeric,IS_DEFAULT numeric,VALUE_DATE_DAYS numeric,UNDERLYING_TEMPLATE_ID numeric,INTEREST_TEMPLATE_ID numeric,POSITION_TEMPLATE_ID numeric,ALLOCATION_TEMPLATE_ID numeric,CREDIT_RATING_SCENARIO_ID numeric,VALUATION_OFFSET numeric,QUOTE_OFFSET numeric,EXPOSURE_OFFSET numeric,LE_CASH_OFFSET numeric,PO_CASH_OFFSET numeric,LE_SECURITY_OFFSET numeric,PO_SECURITY_OFFSET numeric,OVERRIDE_COLLATERAL numeric,IS_TOLERANCE_PERCENTAGE numeric)
/

    ALTER TABLE CONTEXT_MARGIN_CALL_PROPERTY MODIFY (CONTEXT_ID numeric,IS_MANDATORY numeric,SORT_ID numeric)
/

    ALTER TABLE CONTEXT_ALLOCATION_PROPERTY MODIFY (CONTEXT_ID numeric,IS_MANDATORY numeric,IS_MANDATORY_EXEC numeric,IS_PROPAGATE numeric,IS_TKW_PROPAGATE numeric,SORT_ID numeric)
/

    ALTER TABLE CONTEXT_USER_ACTION MODIFY (CONTEXT_ID numeric,IS_ACTION_HIDDEN numeric,SORT_ID numeric)
/

    ALTER TABLE COLLATERAL_PRODUCT_DEFINITION MODIFY (SORT_ID numeric,CONTEXT_ID numeric)
/

    ALTER TABLE COLLATERAL_POSITION_DEFINITION MODIFY (SORT_ID numeric,CONTEXT_ID numeric)
/

    ALTER TABLE COLLATERAL_CURRENCY_DEFINITION MODIFY (SORT_ID numeric,CONTEXT_ID numeric)
/

    ALTER TABLE COLLATERAL_ACADIA_DEFINITION MODIFY (SORT_ID numeric,CONTEXT_ID numeric)
/

    ALTER TABLE COLL_RECON_TRADE MODIFY (ID numeric,TRADE_ID numeric)
/

    ALTER TABLE COLL_RECON_PRICER_MEASURE MODIFY (RECON_ID numeric,RECON_TRADE_ID numeric,MESSAGE_ID numeric)
/

    ALTER TABLE COLL_RECONCILIATION MODIFY (ID numeric,MCC_ID numeric,NUM_SENT numeric,NUM_PROCESSED numeric,VERSION numeric)
/

    ALTER TABLE ETL_JOB MODIFY (ID numeric,MCC_ID numeric,VERSION numeric,USE_POST_PROCESSING numeric)
/

    ALTER TABLE ETL_MAPPING MODIFY (ID numeric,JOB_ID numeric)
/

    ALTER TABLE ETL_TRANSFORM MODIFY (MAP_ID numeric)
/

    ALTER TABLE ETL_JOB_EXECUTION MODIFY (ID numeric,JOB_ID numeric,HAS_ERRORED numeric)
/

    ALTER TABLE PRODUCT_COLLATERAL_EXPOSURE MODIFY (PRODUCT_ID numeric,MCC_ID numeric)
/

    ALTER TABLE COLLATERAL_EXPOSURE_CONTEXT MODIFY (ID numeric,VERSION numeric,IS_DEFAULT numeric)
/

    ALTER TABLE COLLATERAL_EXPOSURE_DEFINITION MODIFY (ID numeric,EXPOSURE_CONTEXT_ID numeric)
/

    ALTER TABLE COLLATERAL_EXPOSURE_PROPERTY MODIFY (EXPOSURE_CONTEXT_ID numeric,EXPOSURE_DEFINITION_ID numeric,IS_MANDATORY numeric,SORT_ID numeric)
/

    ALTER TABLE COLLATERAL_INFO MODIFY (MAJOR_VERSION numeric,MINOR_VERSION numeric,SUB_VERSION numeric)
/

    ALTER TABLE GLOBAL_RATING_CONFIG MODIFY (ID numeric,VERSION numeric,IS_DEFAULT numeric)
/

    ALTER TABLE GLOBAL_RATING MODIFY (ID numeric,GLOBAL_RATING_CONFIG_ID numeric)
/

    ALTER TABLE GLOBAL_RATING_VALUE MODIFY (GLOBAL_RATING_ID numeric,PRIORITY numeric)
/

    ALTER TABLE MRGCALL_CREDIT_RATING_CONFIG MODIFY (CREDIT_RATING_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE MRGCALL_CREDIT_RATING MODIFY (ID numeric,CREDIT_RATING_ID numeric,PRIORITY numeric,VERSION_NUM numeric)
/

    ALTER TABLE MRGCALL_CREDIT_HIER_CONFIG MODIFY (ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE MRGCALL_CREDIT_HIER_LEVEL MODIFY (HIER_ID numeric,SCENARIO_ID numeric)
/

    ALTER TABLE COLLATERAL_POOL_SOURCE MODIFY (SOURCE_ID numeric,VERSION_NUMBER numeric)
/

    ALTER TABLE COLLATERAL_POOL_POSITION MODIFY (PRODUCT_ID numeric,SOURCE_ID numeric,BOOK_ID numeric,POOL_LE_ID numeric,BATCH_ID numeric)
/

    ALTER TABLE COLLATERAL_POOL_COST MODIFY (COST_ID numeric,SOURCE_ID numeric,VERSION_NUMBER numeric)
/

    ALTER TABLE COLLATERAL_INVENTORY_POOL MODIFY (POOL_ID numeric,VERSION_NUMBER numeric,LE_ID numeric)
/

    ALTER TABLE COLLATERAL_POOL_BATCH MODIFY (BATCH_ID numeric,VERSION_NUMBER numeric,SOURCE_ID numeric)
/

    ALTER TABLE COLLATERAL_POOL_ATTR MODIFY (ENTITY_ID numeric)
/

    ALTER TABLE COLLATERAL_POOL_SOURCE_ATTR MODIFY (ENTITY_ID numeric)
/

    ALTER TABLE COLLATERAL_POOL_CONNECTOR_ATTR MODIFY (ENTITY_ID numeric)
/

    ALTER TABLE COLLATERAL_POOL_POS_CASH MODIFY (POS_ID numeric,VERSION_NUMBER numeric,SOURCE_ID numeric,BATCH_ID numeric)
/

    ALTER TABLE COLLATERAL_POOL_POS_SECURITY MODIFY (POS_ID numeric,VERSION_NUMBER numeric,PRODUCT_ID numeric,SOURCE_ID numeric,BATCH_ID numeric)
/

    ALTER TABLE COLLATERAL_POOL_SOURCE_REL MODIFY (REL_ID numeric,VERSION_NUMBER numeric,POOL_ID numeric,SOURCE_ID numeric)
/

    ALTER TABLE COLLATERAL_POOL_CONNECTOR MODIFY (CON_ID numeric,VERSION_NUMBER numeric,SOURCE_ID numeric,LIST_INDEX numeric)
/

    ALTER TABLE COLLATERAL_POOL_CONSTRAINT MODIFY (CONSTRAINT_ID numeric,VERSION_NUMBER numeric,SOURCE_ID numeric)
/

    ALTER TABLE CLEARING_MEMBER_CONFIGURATION MODIFY (ID numeric,VERSION numeric,EXCESS_BUFF_AUTOCALL numeric,USE_CREDIT_EXTENSION numeric,DO_CALL numeric,CALL_DISTRIBUTION numeric)
/

    ALTER TABLE CLEARING_MEMBER_SERVICE MODIFY (CLEARING_MEMBER_ID numeric,CLEARING_SERVICE_ID numeric)
/

    ALTER TABLE CALL_PREFERENCE MODIFY (CLEARING_MEMBER_ID numeric,PRODUCT_ID numeric,FILTER_INDEX numeric)
/

    ALTER TABLE COVER_PREFERENCE MODIFY (CLEARING_MEMBER_ID numeric,FILTER_INDEX numeric)
/

    ALTER TABLE CLEARING_ELIGIBILITY_EXCLUSION MODIFY (CLEARING_MEMBER_ID numeric,FILTER_INDEX numeric)
/

    ALTER TABLE CLEARING_SERVICE MODIFY (ID numeric,VERSION numeric)
/

    ALTER TABLE CLEARING_SERVICE_ELIGIBILITY MODIFY (CONFIG_ID numeric)
/

    ALTER TABLE LIABILITY_GROUP_CONTEXT MODIFY (ID numeric,VERSION numeric,IS_DEFAULT numeric)
/

    ALTER TABLE LIABILITY_GROUP_CONFIG MODIFY (ID numeric,CONTEXT_ID numeric)
/

    ALTER TABLE LIABILITY_RULE_CONFIG MODIFY (LIABILITY_GROUP_ID numeric,DTO_ID numeric)
/

    ALTER TABLE LIABILITY_RULE_KV MODIFY (ID numeric)
/

    ALTER TABLE LIABILITY_GROUP_SERVICE MODIFY (LIABILITY_GROUP_ID numeric,CLEARING_SERVICE_ID numeric)
/

    ALTER TABLE OPTIMIZATION_DESC MODIFY (ID numeric,VERSION numeric,OPTIMIZER_ID numeric,OPTIMIZER_VERSION numeric)
/

    ALTER TABLE COLLATERAL_POOL MODIFY (ID numeric,VERSION numeric,COLLATERAL_POOL_CONFIG_ID numeric)
/

    ALTER TABLE COLLATERAL_AVAILABLE_POSITION MODIFY (ID numeric,COLLATERAL_POOL_ID numeric,PRODUCT_ID numeric)
/

    ALTER TABLE COLLAT_OPTIM_SDF_ELEM_SORTING MODIFY (ORDER_ID numeric,OPTIMIZATION_ID numeric)
/

    ALTER TABLE COLLAT_OPTIM_CANDIDATE_PROFILE MODIFY (ID numeric,OPTIMIZATION_ID numeric)
/

    ALTER TABLE COLLAT_OPTIM_SDF_SORTING MODIFY (CAND_PROFILE_ID numeric,ORDER_ID numeric)
/

    ALTER TABLE CREDIT_RATING_SCENARIO MODIFY (ID numeric,VERSION numeric)
/

    ALTER TABLE COLLATERAL_CREDIT_RATING MODIFY (SCENARIO_ID numeric,LEGAL_ENTITY_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE COLLAT_PRODUCT_CREDIT_RATING MODIFY (SCENARIO_ID numeric,PRODUCT_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE CONFIG_ADHOC_DETAILS MODIFY (ID numeric,VERSION numeric,VAL_DATE_FREQ numeric,VAL_TIME_OFFSET numeric,VAL_TIME_SECONDS numeric,MTA_REDEFINITION numeric)
/

    ALTER TABLE COLLATERAL_ENGINE_CONFIG MODIFY (ID numeric,VERSION numeric,IS_DEFAULT numeric,THREAD_POOL_SIZE numeric,COMMAND_TIMING numeric,ENGINE_TIMING numeric)
/

    ALTER TABLE SCORING_SOLVER_CONFIGURATION MODIFY (ID numeric,VERSION numeric)
/

    ALTER TABLE SCORING_SOLVER MODIFY (CONFIG_ID numeric,LOW_LIMIT numeric,HIGH_LIMIT numeric)
/

    ALTER TABLE ARCH_REGISTRY MODIFY (TABLE_SIZE numeric)
/

    ALTER TABLE MARGIN_CALL_ENTRIES_RATIO MODIFY (ID numeric,VERSION numeric,MASTER_CONTRACT_ID numeric,EXPOSURE_CONTRACT_ID numeric,MASTER_ENTRY_ID numeric,ENTRY_ID numeric,EXP_PO_ID numeric)
/

    ALTER TABLE CLEARING_ACCOUNT MODIFY (ID numeric,COLLATERAL numeric,GROUPING numeric,HAS_CHILDREN numeric,DEPOSIT_ID numeric,LIABILITY_ID numeric,PARENT_GROUP_ID numeric)
/

    ALTER TABLE MARGIN_GROUP MODIFY (ID numeric,OWNER_ID numeric)
/

    ALTER TABLE VOL_SURFACE_JACOBIAN MODIFY (VOL_SURFACE_ID numeric,JACOBIAN_ID numeric)
/

    ALTER TABLE JACOBIAN_RISK_RESULTS MODIFY (VOL_SURFACE_ID numeric,JACOBIAN_ID numeric,FIRST_INDEX numeric,SECOND_INDEX numeric)
/

    ALTER TABLE VOL_SURFACE_INTERP MODIFY (VOL_SURFACE_ID numeric)
/

    ALTER TABLE ACC_ACCOUNT MODIFY (ACC_ACCOUNT_ID numeric,STATEMENT numeric,STATEMENT_B numeric,STATEMENT_DAY numeric,ORIGINAL_ACCOUNT numeric,AUTOMATIC_B numeric,LE_ID numeric,PO_ID numeric,STMT_DATE_RULE numeric,ACC_ENGINE_ONLY_B numeric,VERSION_NUM numeric,CLOSING_ACCOUNT_ID numeric,PARENT_ACCOUNT_ID numeric,INTEREST_BEARING numeric,BILLING_B numeric,LIMIT_B numeric,LIMIT_DATE_RULE numeric,RETRO_DATE_RULE numeric,TRADE_DATE_B numeric,DEST_ACCOUNT_ID numeric,MASTER_B numeric,MASTER_ACCOUNT_ID numeric,CALL_ACCOUNT_B numeric,CALL_BOOK_ID numeric,SWINGING_B numeric,INT_BEAR_QUICK_B numeric,ARCHIVED_B numeric,PAYOUT_EXTERN_B numeric,MARGIN_QUICK_B numeric,NOTICE_DAYS numeric,TRADE_ID numeric,CAPITALIZE_B numeric,SPLIT_PAYREC_B numeric,SPLIT_ADJINT_B numeric,PROPRIETARY_B numeric,PROPRIETARY_ACCOUNT_ID numeric,MULTI_OWNER_B numeric)
/

    ALTER TABLE ACC_ACCOUNT_INTEREST MODIFY (INTEREST_ID numeric,ACCOUNT_ID numeric,CONFIG_ID numeric,IS_PENALTY_B numeric)
/

    ALTER TABLE ELIGIBILITY_RULE MODIFY (RULE_ID numeric,RULE_VERSION numeric)
/

    ALTER TABLE ANONYMIZING_AUDIT MODIFY (ENTITY_ID numeric)
/

    ALTER TABLE PSP_MARGIN_CALL_MEASURES MODIFY (CONTRACT_ID numeric,COLLATERAL_CONTRACT_ID numeric)
/

    ALTER TABLE PRODUCT_ROUNDING_RULE MODIFY (PRODUCT_ID numeric,ROUNDING_DECIMALS numeric,ROUNDING_METHOD numeric)
/

    ALTER TABLE ACC_BOOK_RULE_LINK MODIFY (ACC_LINK_ID numeric,ACC_BOOK_ID numeric,ACC_RULE_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE ACC_EVENT_CONFIG MODIFY (ACC_EVENT_CFG_ID numeric,IS_FEE numeric,VERSION_NUM numeric)
/

    ALTER TABLE ACC_EXTERNAL_NAME MODIFY (ID numeric,PRIORITY numeric,VERSION_NUM numeric)
/

    ALTER TABLE ACC_INTEREST_CONFIG MODIFY (CONFIG_ID numeric,PO_ID numeric,LE_ID numeric,ACCOUNT_ID numeric,IS_PENALTY_B numeric,OFFSET_DATE numeric,DAILY_ROUNDING numeric,CAL_DATE_RULE numeric,IS_COMPOUND_B numeric,COMPOUND_DATE_RULE numeric,PAYMENT_DATE_RULE numeric,VERSION_NUM numeric,IS_TIERED_B numeric,IS_WHOLE_BALANCE_B numeric,TRANSFER_DATE_RULE numeric)
/

    ALTER TABLE ACC_INTEREST_RANGE MODIFY (CONFIG_ID numeric,RANGE_ID numeric,IS_AMOUNT_B numeric,IS_FIXED_B numeric,APPLY_ON_SPREAD_B numeric,IS_FLOOR_B numeric,RESET_DATE_RULE numeric,ROUND16_B numeric)
/

    ALTER TABLE ACC_LIMIT_CFG MODIFY (ACC_LIMIT_CFG_ID numeric,ACCOUNT_ID numeric)
/

    ALTER TABLE ACC_RULE MODIFY (ACC_RULE_ID numeric,DAILY_CLOSING numeric,ADJUSTMENT_DAYS numeric,FIRSTLAST_B numeric,CHECKPE_B numeric,DATE_RULE numeric,VERSION_NUM numeric,PO_ID numeric,LIQ_AGG_CONF_ID numeric,LIQ_CONFIG_ID numeric)
/

    ALTER TABLE ACC_RULE_CONFIG MODIFY (ACC_CONFIG_ID numeric,ACC_RULE_ID numeric,SIGN numeric,DEBIT_ACC_ID numeric,CREDIT_ACC_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE ACC_RULE_DATE MODIFY (ACC_RULE_ID numeric)
/

    ALTER TABLE ACC_STATEMENT MODIFY (STATEMENT_ID numeric,ACCOUNT_ID numeric,STATEMENT_CFG_ID numeric,IS_CASH numeric,LINKED_ID numeric)
/

    ALTER TABLE ACC_STATEMENT_CFG MODIFY (CONFIG_ID numeric,ACCOUNT_ID numeric,IS_PAYMENT numeric,DATE_RULE numeric,DAY numeric,ADVICE_CONFIG_ID numeric,ZERO_BALANCE numeric,NO_MVT numeric)
/

    ALTER TABLE ACC_STATEMENT_XFER MODIFY (STATEMENT_ID numeric,TRANSFER_ID numeric)
/

    ALTER TABLE ACC_SWEEP_CFG MODIFY (ID numeric,PRIORITY numeric,MIN_BAL_B numeric,MAX_BAL_B numeric,AGGREGATE_B numeric,DEST_ACC_ID numeric,DEST_BOOK_ID numeric,PIVOT_ACC_ID numeric,XFER_PIVOT_ONLY numeric,VERSION numeric,BY_BOOK numeric,KICK_OFF_TIME numeric,CUT_OFF_TIME numeric)
/

    ALTER TABLE ACC_SWEEP_LNK MODIFY (SWEEP_CFG_ID numeric,ACCOUNT_ID numeric)
/

    ALTER TABLE ACC_MAPPING MODIFY (ID numeric,VERSION numeric,MAST_ACCOUNT_ID numeric,DEST_ACCOUNT_ID numeric)
/

    ALTER TABLE ACC_TRIG_EVENT MODIFY (ACC_EVENT_CFG_ID numeric)
/

    ALTER TABLE ACCOUNT_TRANS MODIFY (ACCOUNT_ID numeric,ORDER_ID numeric,TRANSLATION_B numeric)
/

    ALTER TABLE ACCRETION_INDEX MODIFY (PRODUCT_ID numeric,SUB_ID numeric,RESET_DEFAULT_B numeric,RESET_LAG numeric,RESET_BUSDAY_B numeric)
/

    ALTER TABLE ACCRETION_INDEX_HIST MODIFY (PRODUCT_ID numeric,SUB_ID numeric,RESET_DEFAULT_B numeric,RESET_LAG numeric,RESET_BUSDAY_B numeric)
/

    ALTER TABLE ACCRETION_SCHEDULE MODIFY (PRODUCT_ID numeric,SUB_ID numeric)
/

    ALTER TABLE ACCRETION_SCHEDULE_HIST MODIFY (PRODUCT_ID numeric,SUB_ID numeric)
/

    ALTER TABLE ADVICE_DOC_HIST MODIFY (DOCUMENT_ID numeric,ADVICE_ID numeric,ADVICE_SENT numeric,SEND_CONTACT_ID numeric,REC_CONTACT_ID numeric,LINK_ID numeric,IS_BINARY numeric,IS_COMPRESSED numeric)
/

    ALTER TABLE ADVICE_DOCUMENT MODIFY (DOCUMENT_ID numeric,ADVICE_ID numeric,ADVICE_SENT numeric,SEND_CONTACT_ID numeric,REC_CONTACT_ID numeric,LINK_ID numeric,IS_BINARY numeric,IS_COMPRESSED numeric)
/

    ALTER TABLE ALIVE_DATASERVERS MODIFY (IS_READ_ONLY numeric)
/

    ALTER TABLE AN_BH_BUCKET MODIFY (UNDERLYING_ID numeric)
/

    ALTER TABLE AN_BH_HEDGE MODIFY (UNDERLYING_ID numeric)
/

    ALTER TABLE AN_BHNG_BUCKET MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE AN_BHNG_RP_HEDGES MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE AN_BHNG_ULBUCKET MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE AN_BOND_RP_HEDGES MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE AN_OG_RP_HEDGES MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE AN_OUTPUT_HDR_HIST MODIFY (OUTPUT_ID numeric,COLUMN_ID numeric)
/

    ALTER TABLE AN_OUTPUT_HEADER MODIFY (OUTPUT_ID numeric,COLUMN_ID numeric)
/

    ALTER TABLE AN_OUTPUT_TOTAL MODIFY (OUTPUT_ID numeric,COLUMN_ID numeric)
/

    ALTER TABLE AN_OUTPUT_VAL_HIST MODIFY (OUTPUT_ID numeric,COLUMN_ID numeric,ROW_ID numeric)
/

    ALTER TABLE AN_OUTPUT_VALUE MODIFY (OUTPUT_ID numeric,COLUMN_ID numeric,ROW_ID numeric)
/

    ALTER TABLE AN_OUTPUT_ZIP MODIFY (OUTPUT_ID numeric)
/

    ALTER TABLE AN_OUTPUT_ZIP_HIST MODIFY (OUTPUT_ID numeric)
/

    ALTER TABLE AN_OUTPUT_ZPART MODIFY (OUTPUT_ID numeric,POS_ID numeric)
/

    ALTER TABLE AN_OUTPUT_ZPART_HIST MODIFY (OUTPUT_ID numeric,POS_ID numeric)
/

    ALTER TABLE AN_SERVICE_PARAMS MODIFY (ELEMENT_ID numeric)
/

    ALTER TABLE AN_SERVICE_SET MODIFY (ID numeric)
/

    ALTER TABLE AN_SERVICE_SET_ELEMENTS MODIFY (ID numeric,DISTRIBUTED numeric,SET_ID numeric)
/

    ALTER TABLE AN_SYNTH_HEDGE MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE ANALYSIS_OUTPUT_PERM_PAGES MODIFY (ID numeric,PAGE_NUMBER numeric,PAGE_ID numeric)
/

    ALTER TABLE ANALYSIS_OUTPUT MODIFY (OUTPUT_ID numeric,NUMBER_OF_COLUMNS numeric,NUMBER_OF_ROWS numeric)
/

    ALTER TABLE ANALYSIS_OUTPUT_HIST MODIFY (OUTPUT_ID numeric,NUMBER_OF_COLUMNS numeric,NUMBER_OF_ROWS numeric)
/

    ALTER TABLE ANALYSIS_PARAM MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE ANALYTICS_MEASURE MODIFY (MEASURE_ID numeric,PROVIDER_ID numeric,VERSION_NUM numeric,IS_CASH numeric,IS_SIZE numeric)
/

    ALTER TABLE ANALYTICS_MEASURE_VALUE MODIFY (PRODUCT_ID numeric,MEASURE_ID numeric)
/

    ALTER TABLE ARCHIVE_TEMPLATE MODIFY (TEMPLATE_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE ASIAN_PARAMETERS MODIFY (PRODUCT_ID numeric,ASIAN_PARAMETERS_ID numeric,FXRESET numeric,ADJUSTED numeric,WEIGHTED numeric,ROLL_ON_END_DATE numeric,CUSTOM numeric,DAY_TO_ROLL_ON numeric,ROLL_ON_DAY numeric)
/

    ALTER TABLE ASIAN_RESET_DATES MODIFY (PRODUCT_ID numeric,ASIAN_PARAMETERS_ID numeric,FXRESET numeric)
/

    ALTER TABLE BALANCE_POSITION MODIFY (ACCOUNT_ID numeric,SECURITY_ID numeric)
/

    ALTER TABLE BALANCE_POSITION_HIST MODIFY (ACCOUNT_ID numeric,SECURITY_ID numeric)
/

    ALTER TABLE BALANCE_POS_FXAMOUNTS MODIFY (ACCOUNT_ID numeric)
/

    ALTER TABLE BALANCE_POS_FXAMOUNTS_HIST MODIFY (ACCOUNT_ID numeric)
/

    ALTER TABLE BARRIER_PARAMETERS MODIFY (PRODUCT_ID numeric,UP_BARRIER_START_TIME numeric,UP_BARRIER_END_TIME numeric,DOWN_BARRIER_START_TIME numeric,DOWN_BARRIER_END_TIME numeric,UNDERL_EXP_TIME numeric)
/

    ALTER TABLE BASIC_PROD_KEYWORD MODIFY (BASIC_PRODUCT_ID numeric,PRODUCT_ID numeric,SUB_ID numeric)
/

    ALTER TABLE BASIC_PRODUCT MODIFY (PRODUCT_ID numeric,BASIC_PRODUCT_ID numeric,SUB_ID numeric,BOOK_ID numeric,INCLUDE_UNDERLYING_B numeric)
/

    ALTER TABLE BASKET_COMP MODIFY (PRODUCT_ID numeric,COMP_ID numeric,COMP_PROD_ID numeric,FXRESET_ID numeric,QUOTABLE_ID numeric)
/

    ALTER TABLE BO_AUDIT MODIFY (ENTITY_ID numeric,ALLOW_UNDO_B numeric,VERSION_NUM numeric,RELATED_ID numeric,COMPRESSED_B numeric,PO_ID numeric)
/

    ALTER TABLE BO_AUDIT_COMMENT MODIFY (ENTITY_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE BO_AUDIT_HIST MODIFY (ENTITY_ID numeric,ALLOW_UNDO_B numeric,VERSION_NUM numeric,RELATED_ID numeric,COMPRESSED_B numeric,PO_ID numeric)
/

    ALTER TABLE BO_CRE MODIFY (BO_CRE_ID numeric,TRADE_ID numeric,LINKED_TRADE_ID numeric,PRODUCT_ID numeric,LINKED_ID numeric,ACC_RULE_ID numeric,MATCHING numeric,BOOK_ID numeric,TRANSFER_ID numeric,NETTED_XFER_ID numeric,SUB_ID numeric,CONFIG_ID numeric,TRADE_VERSION numeric,VERSION_NUM numeric,HEDGE_ID numeric,XFER_VERSION numeric,ACC_BOOK_ID numeric)
/

    ALTER TABLE BO_CRE_HIST MODIFY (BO_CRE_ID numeric,TRADE_ID numeric,LINKED_TRADE_ID numeric,PRODUCT_ID numeric,LINKED_ID numeric,ACC_RULE_ID numeric,MATCHING numeric,BOOK_ID numeric,TRANSFER_ID numeric,NETTED_XFER_ID numeric,SUB_ID numeric,CONFIG_ID numeric,TRADE_VERSION numeric,VERSION_NUM numeric,HEDGE_ID numeric,XFER_VERSION numeric,ACC_BOOK_ID numeric)
/

    ALTER TABLE BO_IN_MESSAGE MODIFY (MESSAGE_ID numeric,OBJECT_ID numeric,SENDER_ID numeric,RECEIVER_ID numeric)
/

    ALTER TABLE BO_IN_MESSAGE_HIST MODIFY (MESSAGE_ID numeric,OBJECT_ID numeric,SENDER_ID numeric,RECEIVER_ID numeric)
/

    ALTER TABLE BO_MESSAGE MODIFY (MESSAGE_ID numeric,TRADE_ID numeric,SENDER_ID numeric,RECEIVER_ID numeric,MATCHING_B numeric,LINKED_ID numeric,TRANSFER_ID numeric,SENDER_CONTACT_ID numeric,REC_CONTACT_ID numeric,DOC_EDITED_B numeric,ADVICE_CFG_ID numeric,STATEMENT_ID numeric,TRADE_VERSION numeric,XFER_VERSION numeric,EXTERNAL_B numeric,VERSION_NUM numeric,LEGAL_ENTITY_ID numeric,BOOK_ID numeric)
/

    ALTER TABLE BO_MESSAGE_HIST MODIFY (MESSAGE_ID numeric,TRADE_ID numeric,SENDER_ID numeric,RECEIVER_ID numeric,MATCHING_B numeric,LINKED_ID numeric,TRANSFER_ID numeric,SENDER_CONTACT_ID numeric,REC_CONTACT_ID numeric,DOC_EDITED_B numeric,ADVICE_CFG_ID numeric,STATEMENT_ID numeric,TRADE_VERSION numeric,XFER_VERSION numeric,EXTERNAL_B numeric,VERSION_NUM numeric,LEGAL_ENTITY_ID numeric,BOOK_ID numeric)
/

    ALTER TABLE BO_PL_CONFIG MODIFY (ACC_RULE_ID numeric)
/

    ALTER TABLE BO_POSTING MODIFY (BO_POSTING_ID numeric,TRADE_ID numeric,PRODUCT_ID numeric,DEBIT_ACC_ID numeric,CREDIT_ACC_ID numeric,LINKED_ID numeric,ACC_RULE_ID numeric,MATCHING numeric,BOOK_ID numeric,TRANSFER_ID numeric,SUB_ID numeric,CONFIG_ID numeric,TRADE_VERSION numeric,XFER_VERSION numeric,VERSION_NUM numeric,HEDGE_ID numeric,ACC_BOOK_ID numeric,POSTING_PARTITION numeric,SECOND_TRADE_ID numeric)
/

    ALTER TABLE BO_POSTING_HIST MODIFY (BO_POSTING_ID numeric,TRADE_ID numeric,PRODUCT_ID numeric,DEBIT_ACC_ID numeric,CREDIT_ACC_ID numeric,LINKED_ID numeric,ACC_RULE_ID numeric,MATCHING numeric,BOOK_ID numeric,TRANSFER_ID numeric,SUB_ID numeric,CONFIG_ID numeric,TRADE_VERSION numeric,XFER_VERSION numeric,VERSION_NUM numeric,HEDGE_ID numeric,ACC_BOOK_ID numeric,POSTING_PARTITION numeric,SECOND_TRADE_ID numeric)
/

    ALTER TABLE POSTING_ATTRIBUTE MODIFY (POSTING_ID numeric)
/

    ALTER TABLE POSTING_ATTRIBUTE_HIST MODIFY (POSTING_ID numeric)
/

    ALTER TABLE BO_TASK MODIFY (TASK_ID numeric,TRADE_ID numeric,PRODUCT_ID numeric,OBJECT_ID numeric,BOOK_ID numeric,TASK_STATUS numeric,TASK_PRIORITY numeric,TASK_WFW_ID numeric,LEGAL_ENTITY_ID numeric,LINK_ID numeric,KICKOFF_ID numeric,TRADE_VERSION numeric,TASK_VERSION numeric,NEXT_PRIORITY numeric,PRIORITY_ID numeric,BUNDLE_ID numeric,PO_ID numeric)
/

    ALTER TABLE BO_TASK_HIST MODIFY (TASK_ID numeric,TRADE_ID numeric,PRODUCT_ID numeric,OBJECT_ID numeric,BOOK_ID numeric,TASK_STATUS numeric,TASK_PRIORITY numeric,TASK_WFW_ID numeric,LEGAL_ENTITY_ID numeric,LINK_ID numeric,KICKOFF_ID numeric,TRADE_VERSION numeric,TASK_VERSION numeric,NEXT_PRIORITY numeric,PRIORITY_ID numeric,BUNDLE_ID numeric,PO_ID numeric)
/

    ALTER TABLE TASK_COMPLETION MODIFY (TASK_ID numeric)
/

    ALTER TABLE BO_TRANSFER MODIFY (TRANSFER_ID numeric,TRADE_ID numeric,PRODUCT_ID numeric,EXT_LE_ID numeric,EXT_SDI numeric,EXT_AGENT_LE_ID numeric,INT_LE_ID numeric,INT_SDI numeric,INT_AGENT_LE_ID numeric,GL_ACCOUNT_ID numeric,START_TIME_LIMIT numeric,BOOK_ID numeric,AVAILABLE numeric,NETTED_TRANSFER numeric,NETTED_TRANSFER_ID numeric,BUNDLE_ID numeric,IS_KNOWN numeric,IS_FIXED numeric,IS_RETURN numeric,IS_PAYMENT numeric,CASH_ACCOUNT_ID numeric,INT_CASH_SDI numeric,EXT_CASH_SDI numeric,LINKED_ID numeric,ORIG_CPTY_ID numeric,MANUAL_SDI numeric,MANUAL_CASH_SDI numeric,TRADE_VERSION numeric,INT_SDI_VERSION numeric,EXT_SDI_VERSION numeric,VERSION_NUM numeric,NETTED_TRADE_ID numeric,INT_CASH_AGENT_LE_ID numeric,SUB_SEC_ACCOUNT_ID numeric,SUB_CASH_ACCOUNT_ID numeric)
/

    ALTER TABLE BO_TRANSFER_HIST MODIFY (TRANSFER_ID numeric,TRADE_ID numeric,PRODUCT_ID numeric,EXT_LE_ID numeric,EXT_SDI numeric,EXT_AGENT_LE_ID numeric,INT_LE_ID numeric,INT_SDI numeric,INT_AGENT_LE_ID numeric,GL_ACCOUNT_ID numeric,START_TIME_LIMIT numeric,BOOK_ID numeric,AVAILABLE numeric,NETTED_TRANSFER numeric,NETTED_TRANSFER_ID numeric,BUNDLE_ID numeric,IS_KNOWN numeric,IS_FIXED numeric,IS_RETURN numeric,IS_PAYMENT numeric,CASH_ACCOUNT_ID numeric,INT_CASH_SDI numeric,EXT_CASH_SDI numeric,LINKED_ID numeric,ORIG_CPTY_ID numeric,MANUAL_SDI numeric,MANUAL_CASH_SDI numeric,TRADE_VERSION numeric,INT_SDI_VERSION numeric,EXT_SDI_VERSION numeric,VERSION_NUM numeric,NETTED_TRADE_ID numeric,INT_CASH_AGENT_LE_ID numeric,SUB_SEC_ACCOUNT_ID numeric,SUB_CASH_ACCOUNT_ID numeric)
/

    ALTER TABLE BO_TS_BOOK MODIFY (BOOK_ID numeric)
/

    ALTER TABLE BO_TS_DATES MODIFY (START_DAYS numeric,END_DAYS numeric,DATE_TYPE numeric,VERSION_NUM numeric)
/

    ALTER TABLE BO_TS_ITEM MODIFY (ITEM_POSITION numeric,SUMMARY_B numeric)
/

    ALTER TABLE BO_WORKFLOW_RULE MODIFY (ID numeric)
/

    ALTER TABLE WFW_RULE_ADDITIONAL_INFO MODIFY (WORKFLOW_ID numeric)
/

    ALTER TABLE BOND_ASSET_BACKED MODIFY (PRODUCT_ID numeric,PAYDOWN_OFFSET numeric,PAYDOWN_BUS_DAY_B numeric,DELAY numeric,DELAY_BUS_DAY_B numeric)
/

    ALTER TABLE ABS_COLLATERAL_GROUP MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE BOND_BENCHMARK MODIFY (BENCHMARK_ID numeric,VERSION_NUM numeric,TARGET_TENOR numeric)
/

    ALTER TABLE BOND_BENCHMARK_LINK MODIFY (PRODUCT_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE BOND_CLN MODIFY (PRODUCT_ID numeric,CDS_ID numeric)
/

    ALTER TABLE BOND_CONVERTIBLE MODIFY (PRODUCT_ID numeric,TARGET_ID numeric)
/

    ALTER TABLE BOND_DEFAULTS MODIFY (ISSUER_ID numeric,SETTLE_DAYS numeric,VALUE_DAYS numeric,EXDIVIDEND_DAYS numeric,ROLLING_DAY numeric,FIXED_B numeric,ROUNDING_UNIT numeric,ACCRUAL_ROUNDING numeric,PRICE_DECIMALS numeric,YIELD_DECIMALS numeric,NOMINAL_DECIMALS numeric)
/

    ALTER TABLE BOND_GUARANTEE MODIFY (PRODUCT_ID numeric,NUM_COUPONS numeric)
/

    ALTER TABLE BOND_INFO MODIFY (PRODUCT_ID numeric,COMMISSION_PAID_B numeric)
/

    ALTER TABLE BOND_INFO_SYNDIC MODIFY (PRODUCT_ID numeric,LE_ID numeric)
/

    ALTER TABLE BOND_POOL_FACTOR MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE IOSINDEX_DEF MODIFY (PRODUCT_ID numeric,INDEX_ISSUER_ID numeric,REF_OB_ID numeric,ROLLING_DAY numeric,PMT_OFFSET numeric,PMT_OFFSET_BUS_DAY_B numeric)
/

    ALTER TABLE BOND_REVOLVER MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE BOOK_ATTR_VALUE MODIFY (BOOK_ID numeric)
/

    ALTER TABLE BOOK_EOD_TIME MODIFY (BOOK_ID numeric,EOD_TIME numeric)
/

    ALTER TABLE BOOK_SUBSTITUTION_REQUEST MODIFY (BOOK_SUBSTITUTION_REQUEST_ID numeric,VERSION_NUM numeric,FROM_BOOK_ID numeric,TO_BOOK_ID numeric,ACTIVE_B numeric)
/

    ALTER TABLE BOOK_VAL_CCY MODIFY (PRODUCT_ID numeric,BOOK_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE BRK_FEE_DISC MODIFY (VERSION numeric,ID numeric,BROKER_LE_ID numeric,PO_ID numeric,FROM_TENOR numeric,TO_TENOR numeric)
/

    ALTER TABLE C_FLW_CMPD_HIST MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,SUB_ID numeric,COLLATERAL_ID numeric,FIXED_RATE_B numeric,SAMPLE_WEEKDAY numeric,MANUAL_AMT_B numeric,BASIS_CONVERT_B numeric,MANUAL_FX_RATE_B numeric)
/

    ALTER TABLE C_FLW_COUPON_HIST MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,SUB_ID numeric,COLLATERAL_ID numeric,FIXED_RATE_B numeric,MANUAL_RESET_B numeric,ROUNDING_UNIT numeric,NUM_PERIODS numeric,NOTL_GUARANTEED numeric,IS_MM numeric,SAMPLE_WEEKDAY numeric,RESET_CUTOFF numeric,MANUAL_AMT_B numeric)
/

    ALTER TABLE C_FLW_OPTCPN_HIST MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,SUB_ID numeric,COLLATERAL_ID numeric,DISCOUNT_B numeric,MANUAL_RESET_B numeric,AVERAGING_B numeric,SAMPLE_WEEKDAY numeric,INTERPOLATED_B numeric,RESET_CUTOFF numeric,ROUNDING_UNIT numeric,NOTL_GUARANTEED numeric,IS_MM numeric,MANUAL_AMT_B numeric)
/

    ALTER TABLE C_FLW_OPTION_HIST MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,SUB_ID numeric,COLLATERAL_ID numeric,DISCOUNT_B numeric,MANUAL_RESET_B numeric,AVERAGING_B numeric,SAMPLE_WEEKDAY numeric,INTERPOLATED_B numeric,RESET_CUTOFF numeric,MANUAL_AMT_B numeric,DIGITAL_B numeric,DEFAULT_RESET_OFFSET_B numeric,RESET_OFFSET numeric,RESET_OFFSET_BUS_DAY_B numeric,SAMPLE_PERIOD_ROLLING_DAY numeric,SAMPLE_PERIOD_ROLLING_DAY_B numeric,ATM_PAYOFF_B numeric)
/

    ALTER TABLE C_FLW_PRIN_HIST MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,FLOW_SUB_ID numeric,COLLATERAL_ID numeric,NOTL_GUARANTEED numeric,MANUAL_PRINCIPAL numeric)
/

    ALTER TABLE C_FLW_OPTION_PRIN_HIST MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,FLOW_SUB_ID numeric,COLLATERAL_ID numeric,NOTL_GUARANTEED numeric,MANUAL_PRINCIPAL numeric)
/

    ALTER TABLE CA_OPTION MODIFY (PRODUCT_ID numeric,CPTY_ID numeric,AGENT_ID numeric,BOOK_ID numeric)
/

    ALTER TABLE CALYPSO_DATATYPE MODIFY (JDBC_TYPE numeric,LENGTH numeric,PRECISION_ numeric,SCALE numeric,IS_NULLABILITY_SET numeric,IS_NULLABLE numeric,IS_DEFAULT_NULL numeric)
/

    ALTER TABLE CALYPSO_TREE MODIFY (TREE_ID numeric)
/

    ALTER TABLE CALYPSO_TREE_NODE MODIFY (TREE_NODE_ID numeric,PARENT_NODE_ID numeric,TREE_ID numeric,LEAF_B numeric,NODE_POSITION numeric)
/

    ALTER TABLE CAP_SWAP_EXT_INFO MODIFY (PRODUCT_ID numeric,P_EX_FIRST_B numeric,P_DIG_CAP_B numeric,P_INCLUDE_SPREAD_B numeric,R_EX_FIRST_B numeric,R_DIG_CAP_B numeric,R_INCLUDE_SPREAD_B numeric)
/

    ALTER TABLE CASH_EQUIV_CONFIG MODIFY (CASH_EQUIV_CONFIG_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE CASH_EQUIV_CONFIG_ELEMENT MODIFY (CASH_EQUIV_CONFIG_ELEMENT_ID numeric,CASH_EQUIV_CONFIG_ID numeric)
/

    ALTER TABLE CASH_F_COMM MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,FLOW_SUB_ID numeric,COLLATERAL_ID numeric,FIXED_PRICE_B numeric,MANUAL_AMT_B numeric,MANUAL_RESET_B numeric,DIGITAL_B numeric,CUST_FIXN_DATES_B numeric)
/

    ALTER TABLE CASH_F_COMM_HIST MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,FLOW_SUB_ID numeric,COLLATERAL_ID numeric,FIXED_PRICE_B numeric,MANUAL_AMT_B numeric,MANUAL_RESET_B numeric,DIGITAL_B numeric,CUST_FIXN_DATES_B numeric)
/

    ALTER TABLE CASH_F_PRCHG_HIST MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,FLOW_SUB_ID numeric,COLLATERAL_ID numeric,MANUAL_AMT_B numeric,MANUAL_RESET_B numeric,FX_RESET numeric,IS_FX_RATE_FIXED numeric,EXTERNAL_ID numeric,NORMALIZE_FOR_NOTL numeric,INCL_FX_PERF numeric)
/

    ALTER TABLE CASH_FLOW_COMPOUND MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,SUB_ID numeric,COLLATERAL_ID numeric,FIXED_RATE_B numeric,SAMPLE_WEEKDAY numeric,MANUAL_AMT_B numeric,BASIS_CONVERT_B numeric,MANUAL_FX_RATE_B numeric)
/

    ALTER TABLE CASH_FLOW_COUPON MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,SUB_ID numeric,COLLATERAL_ID numeric,FIXED_RATE_B numeric,MANUAL_RESET_B numeric,ROUNDING_UNIT numeric,NUM_PERIODS numeric,NOTL_GUARANTEED numeric,IS_MM numeric,SAMPLE_WEEKDAY numeric,RESET_CUTOFF numeric,MANUAL_AMT_B numeric)
/

    ALTER TABLE CASH_FLOW_DIV MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,FLOW_SUB_ID numeric,COLLATERAL_ID numeric,CA_ID numeric,MANUAL_AMT_B numeric,EXTERNAL_ID numeric)
/

    ALTER TABLE CASH_FLOW_OPTCPN MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,SUB_ID numeric,COLLATERAL_ID numeric,DISCOUNT_B numeric,MANUAL_RESET_B numeric,AVERAGING_B numeric,SAMPLE_WEEKDAY numeric,INTERPOLATED_B numeric,RESET_CUTOFF numeric,ROUNDING_UNIT numeric,NOTL_GUARANTEED numeric,IS_MM numeric,MANUAL_AMT_B numeric)
/

    ALTER TABLE CASH_FLOW_OPTION MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,SUB_ID numeric,COLLATERAL_ID numeric,DISCOUNT_B numeric,MANUAL_RESET_B numeric,AVERAGING_B numeric,SAMPLE_WEEKDAY numeric,INTERPOLATED_B numeric,RESET_CUTOFF numeric,MANUAL_AMT_B numeric,DIGITAL_B numeric,DEFAULT_RESET_OFFSET_B numeric,RESET_OFFSET numeric,RESET_OFFSET_BUS_DAY_B numeric,SAMPLE_PERIOD_ROLLING_DAY numeric,SAMPLE_PERIOD_ROLLING_DAY_B numeric,ATM_PAYOFF_B numeric)
/

    ALTER TABLE CASH_FLOW_PRICHG MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,FLOW_SUB_ID numeric,COLLATERAL_ID numeric,MANUAL_AMT_B numeric,MANUAL_RESET_B numeric,FX_RESET numeric,IS_FX_RATE_FIXED numeric,EXTERNAL_ID numeric,NORMALIZE_FOR_NOTL numeric,INCL_FX_PERF numeric)
/

    ALTER TABLE CASH_FLOW_PRIN MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,FLOW_SUB_ID numeric,COLLATERAL_ID numeric,NOTL_GUARANTEED numeric,MANUAL_PRINCIPAL numeric)
/

    ALTER TABLE CASH_FLOW_OPTION_PRIN MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,FLOW_SUB_ID numeric,COLLATERAL_ID numeric,NOTL_GUARANTEED numeric,MANUAL_PRINCIPAL numeric)
/

    ALTER TABLE CASH_FLOW_PRIN_ADJ MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,SUB_ID numeric,RESET_B numeric)
/

    ALTER TABLE CASH_FLOW_SIMPLE MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,SUB_ID numeric,COLLATERAL_ID numeric,FIXED_RATE_B numeric,MANUAL_RESET_B numeric,SAMPLE_WEEKDAY numeric,INTERPOLATED_B numeric,RESET_CUTOFF numeric,MANUAL_AMT_B numeric,EXTERNAL_ID numeric,RATE_ROUNDING_DEC numeric,INTERP_RNDING_DEC numeric,BASIS_CONVERT_B numeric,MANUAL_FX_RATE_B numeric,RATE_INDEX_ID numeric,INTERP_INDEX_ID numeric,BASE_FX_RESET_ID numeric)
/

    ALTER TABLE CASH_FLOW_SPREAD MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,SUB_ID numeric,COLLATERAL_ID numeric,FIXED_RATE_B numeric,MANUAL_RESET_B1 numeric,MANUAL_RESET_B2 numeric,INTERPOLATED_B numeric,MANUAL_AMT_B numeric,EXTERNAL_ID numeric,RATE_ROUNDING_DEC numeric,INTERP_RNDING_DEC numeric,BASIS_CONVERT_B numeric)
/

    ALTER TABLE CASH_FLW_DIV_HIST MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,FLOW_SUB_ID numeric,COLLATERAL_ID numeric,CA_ID numeric,MANUAL_AMT_B numeric,EXTERNAL_ID numeric)
/

    ALTER TABLE CASH_FLW_SIM_HIST MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,SUB_ID numeric,COLLATERAL_ID numeric,FIXED_RATE_B numeric,MANUAL_RESET_B numeric,SAMPLE_WEEKDAY numeric,INTERPOLATED_B numeric,RESET_CUTOFF numeric,MANUAL_AMT_B numeric,EXTERNAL_ID numeric,RATE_ROUNDING_DEC numeric,INTERP_RNDING_DEC numeric,BASIS_CONVERT_B numeric,MANUAL_FX_RATE_B numeric,BASE_FX_RESET_ID numeric)
/

    ALTER TABLE CASH_FLW_SPR_HIST MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,SUB_ID numeric,COLLATERAL_ID numeric,FIXED_RATE_B numeric,MANUAL_RESET_B1 numeric,MANUAL_RESET_B2 numeric,INTERPOLATED_B numeric,MANUAL_AMT_B numeric,EXTERNAL_ID numeric,RATE_ROUNDING_DEC numeric,INTERP_RNDING_DEC numeric,BASIS_CONVERT_B numeric)
/

    ALTER TABLE CASH_FORWARD_CONFIG MODIFY (CASH_FORWARD_CONFIG_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE CASH_FORWARD_CONFIG_ELEMENT MODIFY (CASH_FORWARD_CONFIG_ELEMENT_ID numeric,CASH_FORWARD_CONFIG_ID numeric,TIME_HORIZON_DAYS numeric)
/

    ALTER TABLE CASH_SET_DT_HIST MODIFY (CASH_SETTLE_ID numeric,REVIEWED numeric)
/

    ALTER TABLE CASH_SETTLE_DATE MODIFY (CASH_SETTLE_ID numeric,REVIEWED numeric)
/

    ALTER TABLE CASH_SETTLE_DFLT MODIFY (SWAPTION_VAL_DAYS numeric,SWAPTION_PAY_DAYS numeric,SWAPTION_AUTO_EX numeric,TERMINATE_VAL_DAYS numeric,TERMINATE_EX_DAYS numeric,VERSION_NUM numeric,SWAPTION_EARLIEST_EXER_TIME numeric,SWAPTION_EXPIRATION_TIME numeric,TERMINATION_EARLIEST_EXER_TIME numeric,TERMINATION_EXPIRATION_TIME numeric,SWAPTION_VALUATION_TIME numeric,TERMINATION_VALUATION_TIME numeric,SWAPTION_ACTIVATE_CCY2 numeric,TERMINATION_ACTIVATE_CCY2 numeric)
/

    ALTER TABLE CASH_SETTLE_HIST MODIFY (CASH_SETTLE_ID numeric,PRODUCT_ID numeric,OPTIONAL_SETTLE numeric,EXPIRATION_TIME numeric,FIRST_EXER_TIME numeric,EXERCISE_PARTY_PAYING_B numeric,VALUATION_TIME numeric,VERSION_NUM numeric)
/

    ALTER TABLE CASH_SETTLE_INFO MODIFY (CASH_SETTLE_ID numeric,PRODUCT_ID numeric,OPTIONAL_SETTLE numeric,EXPIRATION_TIME numeric,FIRST_EXER_TIME numeric,EXERCISE_PARTY_PAYING_B numeric,VALUATION_TIME numeric,VERSION_NUM numeric,ACTIVATE_CCY2_B numeric)
/

    ALTER TABLE NON_DELIVERABLE_LEG MODIFY (PRODUCT_ID numeric,FX_RESET numeric,RESET_TYPE numeric)
/

    ALTER TABLE NON_DELIVERABLE_HIST MODIFY (PRODUCT_ID numeric,FX_RESET numeric,RESET_TYPE numeric)
/

    ALTER TABLE CCB_BLOTTER MODIFY (PUBLIC_B numeric)
/

    ALTER TABLE CDSABS_PREM_LEG MODIFY (PRODUCT_ID numeric,LEG_ID numeric,USE_REFOB_SCH_B numeric,REFOB_SCH_OFFSET numeric,REFOB_SCH_BUS_DAY_B numeric,STEP_UP_B numeric,CUSTOM_ROLL_B numeric,ROLLING_DAY numeric,CASHFLOW_CHANGED numeric,CASHFLOW_LOCKS numeric)
/

    ALTER TABLE CDSABS_PROT_LEG MODIFY (PRODUCT_ID numeric,LEG_ID numeric,REF_OB_ID numeric,PMT_OFFSET numeric,PMT_OFST_BUS_DAY_B numeric,CALC_AGENT_ID numeric,ESCROW_B numeric,CASHFLOW_CHANGED numeric,CASHFLOW_LOCKS numeric,WAC_B numeric,INTEREST_SHFALL_COMPD numeric)
/

    ALTER TABLE CDSABSINDEX_DEF MODIFY (PRODUCT_ID numeric,INDEX_ISSUER_ID numeric,MATURITY_TENOR numeric,ONTHERUN_B numeric,SETTLE_OFFSET numeric,SETTLE_OFFSET_BUS_B numeric,FEE_OFFSET numeric,FEE_OFFSET_BUS_B numeric)
/

    ALTER TABLE CDSBASKET_EVENTS MODIFY (PRODUCT_ID numeric,LEGAL_ENTITY_ID numeric,DELIVERED_OBLIG_ID numeric)
/

    ALTER TABLE CDSINDEX_DEF MODIFY (PRODUCT_ID numeric,INDEX_ISSUER_ID numeric,FUNDED_B numeric,MATURITY_TENOR numeric,SETTLE_OFFSET numeric,SETTLE_OFFSET_BUS_B numeric,FEE_OFFSET numeric,FEE_OFFSET_BUS_B numeric)
/

    ALTER TABLE CFD_CONTRACT MODIFY (ID numeric,PO_ID numeric,CPTY_ID numeric,VERSION numeric)
/

    ALTER TABLE CFD_CONTRACT_ATTR MODIFY (CONTRACT_ID numeric)
/

    ALTER TABLE PORTFOLIO_SWAP_CONTRACT MODIFY (ID numeric,VERSION numeric,PO_ID numeric,CPTY_ID numeric,PERFORMANCE_LEG_ID numeric,FUNDING_LEG_ID numeric,TRADING_QUOTA numeric,CASH_COLLATERAL numeric,MARGIN_CALL_CONTRACT_ID numeric,MARGIN_CALL_FX_RESET_ID numeric,PORTFOLIO_SWAP_POSITION_ID numeric)
/

    ALTER TABLE PORTFOLIO_SWAP_CONTRACT_PERF MODIFY (ID numeric,VERSION numeric,SCHEDULE_DATERULE_ID numeric,SCHEDULE_OFFSET numeric,SCHEDULE_DEF_OFFSET_B numeric,SCHEDULE_OFF_BUS_DAY_B numeric,SCHEDULE_CUSTOM_ROLL_B numeric,SCHEDULE_ROLLING_DAY numeric,RES_SCH_OFFSET numeric,RES_SCH_DEF_OFFSET_B numeric,RES_SCH_OFFSET_B numeric,RES_SCH_ROLL_B numeric,RES_SCH_ROLL_DAY numeric,DIV_SCH_OFFSET numeric,DIV_SCH_DEF_OFFSET_B numeric,DIV_SCH_OFFSET_B numeric,DIV_SCH_ROLL_B numeric,DIV_SCH_ROLL_DAY numeric)
/

    ALTER TABLE PORTFOLIO_SWAP_CONTRACT_FUND MODIFY (ID numeric,VERSION numeric,DEF_RESET_OFF_B numeric,RESET_OFFSET numeric,RESET_OFF_BUSDAY_B numeric,RESET_AVERAGING_B numeric,SAMPLE_START_OFF numeric,RESET_CUTOFF numeric,SAMPLE_WEEKDAY numeric,DISCOUNT_METHOD numeric,COUPON_OFFSET numeric,CPN_OFF_BUS_DAY_B numeric,CPN_PAY_AT_END_B numeric,ROLLING_DAY numeric,CUSTOM_ROL_DAY_B numeric,FST_STB_INTRP_B numeric,FST_STB_IDX_X numeric,FST_STB_IDX_Y numeric,LST_STB_INTRP_B numeric,LST_STB_IDX_X numeric,LST_STB_IDX_Y numeric,MAN_FIRST_DATE_B numeric,FIRST_ACCRUAL_B numeric,COMPOUND_B numeric,INCLUDE_CASH_PREPAID numeric,TRADE_SPECIFIC_SPREADS_B numeric)
/

    ALTER TABLE PORTFOLIO_SWAP_COUNTRY_REST MODIFY (ID numeric,CONTRACT_ID numeric,VERSION numeric,PRODUCT_ID numeric)
/

    ALTER TABLE PORTFOLIO_SWAP_CASH_COLL_REST MODIFY (CONTRACT_ID numeric)
/

    ALTER TABLE CFD_COUNTRY MODIFY (ID numeric,LE_ID numeric,PRODUCT_ID numeric,VERSION numeric)
/

    ALTER TABLE CFD_COUNTRY_ATTR MODIFY (CFD_COUNTRY_ID numeric)
/

    ALTER TABLE CFD_DATA MODIFY (CFD_ID numeric,CUSTOM numeric)
/

    ALTER TABLE CFD_DEPOSIT MODIFY (CONTRACT_ID numeric,SEQ_NO numeric)
/

    ALTER TABLE CFD_DETAIL MODIFY (CONTRACT_ID numeric,SEQ_NO numeric,PAYMENT_OFFSET numeric,RESET_DATE_RULE numeric,NO_PERF numeric,NET_POSITION numeric)
/

    ALTER TABLE CFD_DETAIL_RDATE MODIFY (CONTRACT_ID numeric,SEQ_NO numeric)
/

    ALTER TABLE CFD_FIN_GRID MODIFY (CONTRACT_ID numeric,SEQ_NO numeric,COUNTRY_ID numeric,ASSET_ID numeric,DIFF_SPREADS numeric)
/

    ALTER TABLE COMMODITY_CONFIRM_KEYWORDS MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE COMMODITY_INDEX MODIFY (PRODUCT_ID numeric,UNDERLYING_ID numeric)
/

    ALTER TABLE COMMODITY_LEG MODIFY (PRODUCT_ID numeric,LEG_ID numeric,COMMODITY_ID numeric,PAYMENT_OFFSET numeric,PAYMENT_OFFSET_BUS_B numeric,PAYMENT_AT_END_B numeric,ROLLING_DAY numeric,CUSTOM_ROLLING_DAY_B numeric,MANUAL_FIRST_FIXING_B numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,PAYMENT_DAY numeric,PAYMENT_DATE_RULE numeric)
/

    ALTER TABLE COMMODITY_SETTLEMENT MODIFY (LEG_ID numeric,COMMODITY_ID numeric)
/

    ALTER TABLE DAYLIGHT_SAVING_TIME MODIFY (DST_ID numeric,SPRING_DST_DATERULE_ID numeric,FALL_DST_DATERULE_ID numeric,SPRING_HOUR_DST numeric,FALL_HOUR_DST numeric,VERSION_NUM numeric)
/

    ALTER TABLE COMMODITY_RESET MODIFY (COMM_RESET_ID numeric,COMMODITY_ID numeric,RESET_HOUR numeric,CONTRACT_ID numeric,PREFERRED_B numeric,RESET_BUS_LAG_B numeric,MANUAL_B numeric,VERSION_NUM numeric,UPPER_YEAR numeric,LOWER_YEAR numeric,IS_USER_CONFIGURED numeric)
/

    ALTER TABLE COMMODITY_RESET_CODE MODIFY (COMM_RESET_ID numeric)
/

    ALTER TABLE COMMODITY_QUOTENAME_DESC MODIFY (COMMODITY_ID numeric)
/

    ALTER TABLE CONTRACT_EXT_REF MODIFY (IS_MASTER numeric,TRADE_ID numeric)
/

    ALTER TABLE CONVERSION_RESET MODIFY (PRODUCT_ID numeric,IS_RESET numeric)
/

    ALTER TABLE CORR_FIRST_AX_HIST MODIFY (MATRIX_ID numeric,AXIS_ID numeric)
/

    ALTER TABLE CORR_FIRST_AXIS MODIFY (MATRIX_ID numeric,AXIS_ID numeric)
/

    ALTER TABLE CORR_STRIKE_AXIS MODIFY (MATRIX_ID numeric)
/

    ALTER TABLE CORR_FORMULA MODIFY (CORR_FORMULA_ID numeric,CORR_SURF_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE CORR_MAT_DATA_HIST MODIFY (MATRIX_ID numeric,FIRST_INDEX numeric,SECOND_INDEX numeric,OFFSET_DAYS numeric)
/

    ALTER TABLE CORR_MAT_P_HIST MODIFY (MATRIX_ID numeric)
/

    ALTER TABLE CORR_MATRIX_DATA MODIFY (MATRIX_ID numeric,FIRST_INDEX numeric,SECOND_INDEX numeric,OFFSET_DAYS numeric)
/

    ALTER TABLE CORR_MATRIX_HIST MODIFY (MATRIX_ID numeric,IS_SIMPLE numeric,VERSION_NUM numeric)
/

    ALTER TABLE CORR_MATRIX_PARAM MODIFY (MATRIX_ID numeric)
/

    ALTER TABLE CORR_SECND_AX_HIST MODIFY (MATRIX_ID numeric,AXIS_ID numeric)
/

    ALTER TABLE CORR_SECOND_AXIS MODIFY (MATRIX_ID numeric,AXIS_ID numeric)
/

    ALTER TABLE CORR_SURF_ATTRIB MODIFY (SURFACE_ID numeric)
/

    ALTER TABLE CORR_SURF_BASISADJ MODIFY (SURFACE_ID numeric,OFFSET_DAYS numeric)
/

    ALTER TABLE CORR_SURF_DATA MODIFY (SURFACE_ID numeric,OFFSET_DAYS numeric)
/

    ALTER TABLE CORR_SURF_PARAMS MODIFY (SURFACE_ID numeric)
/

    ALTER TABLE CORR_SURF_PTADJ MODIFY (SURFACE_ID numeric,OFFSET_DAYS numeric)
/

    ALTER TABLE CORR_SURF_QTVALUE MODIFY (SURFACE_ID numeric)
/

    ALTER TABLE CORR_SURF_SPDATES MODIFY (SURFACE_ID numeric)
/

    ALTER TABLE CORR_SURF_TIMEAXIS MODIFY (SURFACE_ID numeric,OFFSET_DAYS numeric)
/

    ALTER TABLE CORR_SURF_UND MODIFY (CORR_SURF_UND_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE CORR_SURF_UND_CDS_IDX_TRANCHE MODIFY (CORR_SURF_UND_ID numeric,UND_PROD_ID numeric)
/

    ALTER TABLE CORR_SURF_XAXIS MODIFY (SURFACE_ID numeric)
/

    ALTER TABLE CORR_SURF_INDEX_DEFN MODIFY (SURFACE_ID numeric,DEFINITION_ID numeric)
/

    ALTER TABLE CORR_SURFACE MODIFY (SURFACE_ID numeric,BASKET_ID numeric,IS_SIMPLE numeric,VERSION_NUM numeric,IS_INDEX numeric)
/

    ALTER TABLE CORR_SURFACE_MEMBER MODIFY (SURFACE_ID numeric,SURFACE_UND_ID numeric)
/

    ALTER TABLE CORR_TENOR_AX_HIST MODIFY (MATRIX_ID numeric,OFFSET_DAYS numeric)
/

    ALTER TABLE CORR_TENOR_AXIS MODIFY (MATRIX_ID numeric,OFFSET_DAYS numeric)
/

    ALTER TABLE CORRELATION_MATRIX MODIFY (MATRIX_ID numeric,IS_SIMPLE numeric,VERSION_NUM numeric,IS_STRIKE_AXIS numeric)
/

    ALTER TABLE COUNTRY MODIFY (COUNTRY_ID numeric,VERSION_NUM numeric,ENABLED_B numeric)
/

    ALTER TABLE COUPON_SCHEDULE MODIFY (PRODUCT_ID numeric,SUB_ID numeric)
/

    ALTER TABLE COV_MAT_DATA_HIST MODIFY (MATRIX_ID numeric,Z_INDEX numeric,FIRST_INDEX numeric,SECOND_INDEX numeric,OFFSET_DAYS numeric)
/

    ALTER TABLE COV_MATRIX_DATA MODIFY (MATRIX_ID numeric,Z_INDEX numeric,FIRST_INDEX numeric,SECOND_INDEX numeric,OFFSET_DAYS numeric)
/

    ALTER TABLE CPN_SCHED_HIST MODIFY (PRODUCT_ID numeric,SUB_ID numeric)
/

    ALTER TABLE CQE_CONFIG MODIFY (CONFIG_ID numeric,EXPIRATION_SEC numeric)
/

    ALTER TABLE CQE_QT_MAX_SIZE MODIFY (CONFIG_ID numeric)
/

    ALTER TABLE CQE_R_SIMPLE MODIFY (CONFIG_ID numeric,RULE_ID numeric)
/

    ALTER TABLE CQE_R_TIERVOL MODIFY (CONFIG_ID numeric,RULE_ID numeric,TIER numeric,VOL_LEVEL numeric,CURRENT_VOL_LEVEL numeric)
/

    ALTER TABLE CQE_R_VOLUME MODIFY (CONFIG_ID numeric,RULE_ID numeric)
/

    ALTER TABLE CQE_RULE_HDR MODIFY (RULE_ID numeric,CONFIG_ID numeric,ENABLED_B numeric)
/

    ALTER TABLE CQE_TIERVOL MODIFY (CURRENT_VOL_LEVEL numeric,NUM_CUSTOMER_TIERS numeric,VOL_LEVEL numeric)
/

    ALTER TABLE CRE_AMOUNT MODIFY (CRE_ID numeric,AMOUNT_INDEX numeric)
/

    ALTER TABLE CRE_AMOUNT_HIST MODIFY (CRE_ID numeric,AMOUNT_INDEX numeric)
/

    ALTER TABLE CRE_ATTRIBUTE MODIFY (CRE_ID numeric)
/

    ALTER TABLE CRE_ATTRIBUTE_HIST MODIFY (CRE_ID numeric)
/

    ALTER TABLE CREDIT_EVENT MODIFY (EVENT_ID numeric,LEGAL_ENTITY_ID numeric,PRODUCT_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE CREDIT_LIMIT MODIFY (LIMIT_ID numeric)
/

    ALTER TABLE CREDIT_RATING MODIFY (LEGAL_ENTITY_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE CRV_DEF_DATA_HIST MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CSTM_KYWRDS MODIFY (TRADE_ID numeric)
/

    ALTER TABLE CSTM_KYWRDS_HIST MODIFY (TRADE_ID numeric)
/

    ALTER TABLE CU_BASIS_SWAP MODIFY (CU_ID numeric,MATURITY_TENOR numeric,BASE_COMPOUND_B numeric,BASE_CMP_SPREAD_B numeric,BASIS_COMPOUND_B numeric,BASIS_CMP_SPREAD_B numeric,BASE_AVG_B numeric,BASIS_AVG_B numeric,MAN_BASE_RESET_B numeric,MAN_BASIS_RESET_B numeric,FACTOR_QUOTED numeric,SPC_LAG_B numeric,SPC_LAG_OFFSET numeric,SPC_LAG_BUS_CAL_B numeric,BASIS_SPREAD_QUOTED_B numeric,BASIS_INFL_REAL_RATE_QUOTED_B numeric,CHK_BASE_RESET_B numeric,CHK_BASIS_RESET_B numeric,SPECIFIC_DATES_B numeric,BASE_DISCOUNT_MTHD numeric,BASIS_DISCOUNT_MTHD numeric,MULT_SPREAD_B numeric,BASE_CPN_OFFSET numeric,BASE_OFFSET_BUSDAY numeric,BASIS_CPN_OFFSET numeric,BASIS_OFFSET_BUSDAY numeric,BASE_INFL_CALC_TYPE numeric,BASIS_INFL_CALC_TYPE numeric,BASE_CUTOFF_DAYS numeric,BASE_CUTOFF_BUSDAY numeric,BASIS_CUTOFF_DAYS numeric,BASIS_CUTOFF_BUSDAY numeric)
/

    ALTER TABLE CU_BASIS_TWO_SWAP MODIFY (CU_ID numeric,MATURITY_TENOR numeric,BASE_COMPOUND_B numeric,BASE_CMP_SPREAD_B numeric,BASIS_COMPOUND_B numeric,BASIS_CMP_SPREAD_B numeric,BASE_AVG_B numeric,BASIS_AVG_B numeric,MAN_BASE_RESET_B numeric,MAN_BASIS_RESET_B numeric,PRINCIPAL_ACTUAL_B numeric,FACTOR_QUOTED numeric,SPC_LAG_B numeric,SPC_LAG_OFFSET numeric,SPC_LAG_BUS_CAL_B numeric,BASIS_SPREAD_QUOTED_B numeric,CHK_BASE_RESET_B numeric,CHK_BASIS_RESET_B numeric,PAY_FIXED_BASIS_B numeric)
/

    ALTER TABLE CU_BASIS_SWAP_DTLS MODIFY (CU_ID numeric,LEG_ID numeric,SAMPLE_DAY numeric,INTERP_B numeric)
/

    ALTER TABLE CU_BOND MODIFY (CU_ID numeric,MATURITY_TENOR numeric,UNDERLYING_BOND_ID numeric)
/

    ALTER TABLE CU_BONDSPREAD MODIFY (CU_ID numeric,BOND_SPREAD_ID numeric,MAN_FIRST_RESET_B numeric,SPREAD_ON_CURVE_B numeric)
/

    ALTER TABLE CU_CDS MODIFY (CU_ID numeric,TENOR numeric,REF_ENTITY_ID numeric,START_OFFSET numeric,OFFSET_BUS_DAY_B numeric,TICKER_ID numeric,HAS_FEE_B numeric,FEE_OFFSET numeric,FEE_OFFSET_BUS_B numeric,ISINTERPOLATED numeric,FIXEDCOUPON numeric)
/

    ALTER TABLE CU_CDSIDX MODIFY (CU_ID numeric,INDEX_DEF_ID numeric)
/

    ALTER TABLE CU_COMM_BASIS_SWAP MODIFY (CU_ID numeric,SPECIFIC_B numeric,BASE_COMMODITY_ID numeric,BASE_START_TENOR numeric,BASE_END_TENOR numeric,BASIS_COMMODITY_ID numeric,BASIS_START_TENOR numeric,BASIS_END_TENOR numeric)
/

    ALTER TABLE CU_COMM_SWAP MODIFY (CU_ID numeric,START_TENOR numeric,END_TENOR numeric,SPECIFIC_B numeric,COMMODITY_ID numeric)
/

    ALTER TABLE CU_COMM_SWAP2 MODIFY (CU_ID numeric,LEG_ID numeric)
/

    ALTER TABLE CU_COMM_SWAP_BUTTERFLY MODIFY (CU_ID numeric,START_TENOR numeric,END_TENOR numeric,START_TENOR2 numeric,END_TENOR2 numeric,START_TENOR3 numeric,END_TENOR3 numeric,SPECIFIC_B numeric,COMMODITY_ID numeric)
/

    ALTER TABLE CU_COMM_SWAP_SPREAD MODIFY (CU_ID numeric,START_TENOR numeric,END_TENOR numeric,START_TENOR2 numeric,END_TENOR2 numeric,SPECIFIC_B numeric,COMMODITY_ID numeric)
/

    ALTER TABLE CU_EQ_INDEX_FUT MODIFY (CU_ID numeric,CONTRACT_ID numeric,CONTRACT_RANK numeric)
/

    ALTER TABLE CU_EQUITY_INDEX MODIFY (CU_ID numeric,INDEX_ID numeric)
/

    ALTER TABLE CU_ETO MODIFY (CU_ID numeric,CONTRACT_ID numeric,CONTRACT_RANK numeric,OPTION_TYPE numeric,PRODUCT_ID numeric)
/

    ALTER TABLE CU_FM_ATTR MODIFY (CU_ID numeric)
/

    ALTER TABLE CU_FRA MODIFY (CU_ID numeric,START_TENOR numeric,MATURITY_TENOR numeric,SPECIFIC_B numeric,SPECIFIC_END_B numeric,START_DATE_RULE_ID numeric,END_DATE_RULE_ID numeric,RANK_ID numeric,NO_OF_UNDERLYINGS numeric,END_DATE_FROM_SPOT_B numeric)
/

    ALTER TABLE CU_LISTED_FRA MODIFY (CU_ID numeric,CONTRACT_ID numeric,CONTRACT_RANK numeric)
/

    ALTER TABLE CU_FUTURE MODIFY (CU_ID numeric,CONTRACT_ID numeric,CONTRACT_RANK numeric,SERIAL_B numeric)
/

    ALTER TABLE CU_FX_FORWARD MODIFY (CU_ID numeric,MAT_TENOR numeric)
/

    ALTER TABLE CU_FX_FIXED MODIFY (CU_ID numeric)
/

    ALTER TABLE CU_FX_MONTH_END MODIFY (CU_ID numeric,MONTH_END numeric,YEAR_OFFSET numeric)
/

    ALTER TABLE CU_MONEYMARKET MODIFY (CU_ID numeric,IS_DISCOUNT numeric,MONEY_MARKET_TENOR numeric,SETTLE_DAYS numeric,SPECIFIC_B numeric)
/

    ALTER TABLE CU_PAYOUT_FORMULA MODIFY (CU_ID numeric)
/

    ALTER TABLE CU_SPECIFIC_MMKT MODIFY (CU_ID numeric)
/

    ALTER TABLE CU_SPREAD_ON_INST MODIFY (CU_ID numeric,SPREAD_CU_ID numeric,REFERENCE_CU_ID numeric)
/

    ALTER TABLE CU_SWAP MODIFY (CU_ID numeric,MATURITY_TENOR numeric,MAN_FIRST_RESET_B numeric,SPC_LAG_B numeric,SPC_LAG_OFFSET numeric,SPC_LAG_BUS_CAL_B numeric,PRINCIPAL_ACTUAL_B numeric,DISCOUNT_METHOD numeric,FIXED_INTERP_B numeric,FLOAT_INTERP_B numeric,CHK_FIRST_RESET_B numeric,SPECIFIC_DATES_B numeric,FIX_CUSTOM_ROLL_DAY_B numeric,FLOATING_CUSTOM_ROLL_DAY_B numeric,FIX_ROLLING_DAY numeric,FLOATING_ROLLING_DAY numeric,RESET_AVERAGING_B numeric,SAMPLE_DAY numeric,DAY_OF_MONTH_B numeric,DAY_OF_MONTH numeric,FIX_CPN_OFFSET numeric,FIX_OFFSET_BUSDAY numeric,FLT_CPN_OFFSET numeric,FLT_OFFSET_BUSDAY numeric,FWD_START_TENOR numeric)
/

    ALTER TABLE CU_INSTRUMENT_SPREAD MODIFY (CU_ID numeric,BASE_CU_ID numeric)
/

    ALTER TABLE CUR_ROLL_TIMING MODIFY (VERSION numeric)
/

    ALTER TABLE CUR_ROLLOVER MODIFY (VERSION numeric,BOOK_ID numeric,ROLLOVER_BOOK_ID numeric)
/

    ALTER TABLE CUR_SPLIT MODIFY (VERSION numeric,BOOK_ID numeric,BASE_PAIR_BOOK_ID numeric,BASE_PAIR_MISMATCH_BOOK_ID numeric,OTHER_PAIR_BOOK_ID numeric,OTHER_PAIR_MISMATCH_BOOK_ID numeric,RT_SPLIT numeric,EOD_SPLIT numeric,PRIORITY numeric,SMHEDGE_BOOK_ID numeric)
/

    ALTER TABLE CURRENCY_BENCHMARK MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE CURRENCY_DEFAULT MODIFY (SPOT_DAYS numeric,DEFAULT_TENOR numeric,VERSION_NUM numeric,RATE_DECIMALS numeric,IS_PRECIOUS_METAL_B numeric,NON_DELIVERABLE_B numeric)
/

    ALTER TABLE CURRENCY_PAIR MODIFY (FIXED_B numeric,FAMILY_ROUNDING numeric,QUOTE_FACTOR numeric,BP_FACTOR numeric,BP_FWD_ROUNDING numeric,DIRECT_B numeric,BASE_B numeric,ROUNDING numeric,BIG_FIG_ROUNDING numeric,SPOT_DAYS numeric,MAX_SPOT_DAYS numeric,PAIR_POS_REF_B numeric,PRIMARY_DELTA_TERM_B numeric,VERSION_NUM numeric)
/

    ALTER TABLE CURRENCY_PAIR_GROUP MODIFY (VERSION numeric,BOOK_ID numeric)
/

    ALTER TABLE CURVE MODIFY (CURVE_ID numeric,IS_SIMPLE numeric,RATE_INDEX_TENOR numeric,SAVE_NON_BLOB numeric,VERSION_NUM numeric,INTERP_ON_BUS_DAYS numeric)
/

    ALTER TABLE CURVE_BAS_HDR_HIST MODIFY (CURVE_ID numeric,BASE_CURVE_ID numeric,FOREIGN_CURVE_ID numeric,LEGAL_ENTITY_ID numeric,TICKER_ID numeric,BASKET_ID numeric,INVERT_SHIFT_B numeric)
/

    ALTER TABLE CARVE_OUT MODIFY (ID numeric,BENCHMARK_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE CURVE_BASIS_HEADER MODIFY (CURVE_ID numeric,BASE_CURVE_ID numeric,FOREIGN_CURVE_ID numeric,LEGAL_ENTITY_ID numeric,TICKER_ID numeric,BASKET_ID numeric,INVERT_SHIFT_B numeric)
/

    ALTER TABLE CURVE_ZERO_MDI_PARAMETERS MODIFY (CURVE_ID numeric,MARKET_DATA_ITEM_ID numeric)
/

    ALTER TABLE CURVE_ZERO_MDI_PARAMETERS_HIST MODIFY (CURVE_ID numeric,MARKET_DATA_ITEM_ID numeric)
/

    ALTER TABLE CURVE_SPREAD_HEADER MODIFY (CURVE_ID numeric,BASE_CURVE_ID numeric)
/

    ALTER TABLE CURVE_SPREAD_HEADER_HIST MODIFY (CURVE_ID numeric,BASE_CURVE_ID numeric)
/

    ALTER TABLE CURVE_COMMODITY_FREQS MODIFY (CURVE_ID numeric,CU_ID numeric)
/

    ALTER TABLE CURVE_COMMODITY_HDR MODIFY (CURVE_ID numeric,COMMODITY_ID numeric,BASE_CURVE_ID numeric,DATE_RULE numeric,SEASON_CURVE_ID numeric,FIRST_DELIVERY_DATE_RULE numeric,CONV_YIELD_CURVE_ID numeric,DISC_CURVE_ID numeric)
/

    ALTER TABLE CURVE_COMMODITY_HDR_HIST MODIFY (CURVE_ID numeric,COMMODITY_ID numeric,BASE_CURVE_ID numeric,DATE_RULE numeric,SEASON_CURVE_ID numeric,FIRST_DELIVERY_DATE_RULE numeric,CONV_YIELD_CURVE_ID numeric,DISC_CURVE_ID numeric)
/

    ALTER TABLE CURVE_DEF_DATA MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CURVE_DIV_EX_DIV MODIFY (CURVE_ID numeric,PT_INDEX numeric,COMP_PROD_ID numeric)
/

    ALTER TABLE CURVE_DIV_EX_HIST MODIFY (CURVE_ID numeric,PT_INDEX numeric,COMP_PROD_ID numeric)
/

    ALTER TABLE CURVE_DIV_HDR MODIFY (CURVE_ID numeric,UNDERLYING_ID numeric)
/

    ALTER TABLE CURVE_DIV_HDR_HIST MODIFY (CURVE_ID numeric,UNDERLYING_ID numeric)
/

    ALTER TABLE CURVE_FX_HDR_HIST MODIFY (CURVE_ID numeric,BASE_CURVE_ID numeric,QUOTE_CURVE_ID numeric)
/

    ALTER TABLE CURVE_FX_HEADER MODIFY (CURVE_ID numeric,BASE_CURVE_ID numeric,QUOTE_CURVE_ID numeric)
/

    ALTER TABLE CURVE_FXD_HDR_HIST MODIFY (CURVE_ID numeric,FX_CURVE_ID numeric,ZERO_CURVE_ID numeric)
/

    ALTER TABLE CURVE_FXD_HEADER MODIFY (CURVE_ID numeric,FX_CURVE_ID numeric,ZERO_CURVE_ID numeric)
/

    ALTER TABLE CURVE_HIST MODIFY (CURVE_ID numeric,IS_SIMPLE numeric,RATE_INDEX_TENOR numeric,SAVE_NON_BLOB numeric,VERSION_NUM numeric,INTERP_ON_BUS_DAYS numeric)
/

    ALTER TABLE CURVE_INFL_HIST MODIFY (CURVE_ID numeric,BASE_CURVE_ID numeric)
/

    ALTER TABLE CURVE_INFLATION MODIFY (CURVE_ID numeric,BASE_CURVE_ID numeric)
/

    ALTER TABLE CURVE_SEASONALITY MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CURVE_COMM_SEASONALITY MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CURVE_COMM_SEASONALITY_HIST MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CURVE_INFL_MDI_PARAM MODIFY (CURVE_INFL_ID numeric,MDI_ID numeric)
/

    ALTER TABLE CURVE_INFL_MDI_PARAM_HIST MODIFY (CURVE_INFL_ID numeric,MDI_ID numeric)
/

    ALTER TABLE CURVE_MEM_RT_HIST MODIFY (CURVE_ID numeric,CU_ID numeric)
/

    ALTER TABLE CURVE_MEMBER MODIFY (CURVE_ID numeric,CU_ID numeric,INCLUDED_B numeric,GEN_PRIORITY numeric)
/

    ALTER TABLE CURVE_MEMBER_HIST MODIFY (CURVE_ID numeric,CU_ID numeric,INCLUDED_B numeric,GEN_PRIORITY numeric)
/

    ALTER TABLE CURVE_MEMBER_LINK MODIFY (CURVE_ID numeric,CU_ID numeric,IN_UNDERLYING_ID numeric)
/

    ALTER TABLE CURVE_MEMBER_RT MODIFY (CURVE_ID numeric,CU_ID numeric)
/

    ALTER TABLE CURVE_MEMLINK_HIST MODIFY (CURVE_ID numeric,CU_ID numeric,IN_UNDERLYING_ID numeric)
/

    ALTER TABLE CURVE_PARAM_HIST MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CURVE_PARAMETER MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CURVE_PM_HDR_HIST MODIFY (CURVE_ID numeric,ZERO_CURVE_ID numeric)
/

    ALTER TABLE CURVE_PM_HEADER MODIFY (CURVE_ID numeric,ZERO_CURVE_ID numeric)
/

    ALTER TABLE CURVE_PNT_ADJ_HIST MODIFY (CURVE_ID numeric,CURVE_OFFSET numeric,PT_INDEX numeric)
/

    ALTER TABLE CURVE_POINT MODIFY (CURVE_ID numeric,CURVE_OFFSET numeric,PT_INDEX numeric)
/

    ALTER TABLE CURVE_POINT_ADJ MODIFY (CURVE_ID numeric,CURVE_OFFSET numeric,PT_INDEX numeric)
/

    ALTER TABLE CURVE_POINT_HIST MODIFY (CURVE_ID numeric,CURVE_OFFSET numeric,PT_INDEX numeric)
/

    ALTER TABLE CURVE_PRC_HDR_HIST MODIFY (CURVE_ID numeric,DISC_CURVE_ID numeric,UNDERLYING_ID numeric)
/

    ALTER TABLE CURVE_PRICE_HDR MODIFY (CURVE_ID numeric,DISC_CURVE_ID numeric,UNDERLYING_ID numeric)
/

    ALTER TABLE CURVE_PROB_HIST MODIFY (CURVE_ID numeric,LEGAL_ENTITY_ID numeric,BASE_CURVE_ID numeric,BASE_CREDIT_CRV_ID numeric,BENCHMARK_TENOR numeric,TICKER_ID numeric,BASKET_ID numeric)
/

    ALTER TABLE CURVE_PROBABILITY MODIFY (CURVE_ID numeric,LEGAL_ENTITY_ID numeric,BASE_CURVE_ID numeric,BASE_CREDIT_CRV_ID numeric,BENCHMARK_TENOR numeric,TICKER_ID numeric,BASKET_ID numeric)
/

    ALTER TABLE CURVE_BONDSPREAD MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CURVE_UND_BONDSPREAD MODIFY (CU_ID numeric,REF_UND_ID numeric)
/

    ALTER TABLE CURVE_QT_ADJ_HIST MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CURVE_QT_VAL_HIST MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CURVE_QUOTE_ADJ MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CURVE_QUOTE_VALUE MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CURVE_RECOV_HIST MODIFY (CURVE_ID numeric,LEGAL_ENTITY_ID numeric,TICKER_ID numeric,BASKET_ID numeric)
/

    ALTER TABLE CURVE_RECOVERY MODIFY (CURVE_ID numeric,LEGAL_ENTITY_ID numeric,TICKER_ID numeric,BASKET_ID numeric)
/

    ALTER TABLE CURVE_PREPAY_HIST MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CURVE_PREPAY MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CURVE_DEFAULT_HIST MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CURVE_DEFAULT MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CURVE_REPO_HEADER MODIFY (CURVE_ID numeric,PRODUCT_ID numeric,UND_RATE_CURVE_ID numeric)
/

    ALTER TABLE CURVE_REPOHDR_HIST MODIFY (CURVE_ID numeric,PRODUCT_ID numeric,UND_RATE_CURVE_ID numeric)
/

    ALTER TABLE CURVE_SPC_DATE MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CURVE_SPCDATE_HIST MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CURVE_TEMP MODIFY (ID numeric,CURVE_ID numeric)
/

    ALTER TABLE CURVE_TENOR MODIFY (CURVE_ID numeric,CURVE_TENOR numeric)
/

    ALTER TABLE CURVE_TENOR_HIST MODIFY (CURVE_ID numeric,CURVE_TENOR numeric)
/

    ALTER TABLE CURVE_UNDERLYING MODIFY (CU_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE CUST_CURVE_QT_HIST MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CUST_FIXING_DATES MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,SUB_ID numeric)
/

    ALTER TABLE CUST_FIXING_DATES_HIST MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,SUB_ID numeric)
/

    ALTER TABLE CUSTOM_CURVE_QT MODIFY (CURVE_ID numeric)
/

    ALTER TABLE CUSTOMER_CALL MODIFY (CUSTOMER_ID numeric,TRADE_ID numeric)
/

    ALTER TABLE DATE_RULE_TO_DATE_RULE MODIFY (DR_OWNER numeric,DR_OWNED numeric)
/

    ALTER TABLE DATE_RULE_IN_SEQ MODIFY (DATE_RULE_ID numeric,SEQ_NUMBER numeric,NUM numeric,ORIG_DATE_RULE numeric,IS_DATE numeric)
/

    ALTER TABLE DEFAULT_FXN_METH_ATTR MODIFY (COMMODITY_ID numeric)
/

    ALTER TABLE DEL_CHAR_REF_ENT MODIFY (PRODUCT_ID numeric,REF_ENTITY_ID numeric)
/

    ALTER TABLE DEL_CHARACTERISTIC MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE CDS_ADDL_PROVISIONS MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE CDS_SETTLEMENT_CONDITIONS MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE DIVIDEND MODIFY (DIVIDEND_ID numeric,PRODUCT_ID numeric,CA_ID numeric)
/

    ALTER TABLE DOC_REGION MODIFY (REGION_ID numeric,EDITABLE numeric,FREE_FORM numeric,MAX_LENGTH numeric)
/

    ALTER TABLE DOC_REGION_VALUE MODIFY (REGION_ID numeric)
/

    ALTER TABLE DOMAIN_CONSTRAINT MODIFY (MIN_LEN numeric,MAX_LEN numeric)
/

    ALTER TABLE ECO_PL_COL_NAME MODIFY (COL_ID numeric,EXCL_CALC_B numeric)
/

    ALTER TABLE ADVICE_DOCUMENT_ATTRIBUTES MODIFY (ENTITY_ID numeric)
/

    ALTER TABLE ENTITY_GROUP MODIFY (GROUP_ID numeric)
/

    ALTER TABLE ENTITY_GROUP_MAP MODIFY (GROUP_ID numeric,ENTITY_ID numeric)
/

    ALTER TABLE ENTITY_STATE MODIFY (STATE_ID numeric,ENTITY_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE ENTT_ATTR_HIST MODIFY (ENTITY_ID numeric)
/

    ALTER TABLE EQ_LINK_LEG_HIST MODIFY (PRODUCT_ID numeric,LEG_ID numeric,TAX_REFUND numeric,IS_DIV_FX_RATE_FIXED numeric,DIV_FX_RESET_ID numeric,END_PERIOD_DIV_FX_RATE_FIX numeric,IS_WITH_SPREAD_FACTOR numeric,SPREAD numeric,EQUITY_RESET_ID numeric)
/

    ALTER TABLE EQ_LINKED_LEG MODIFY (PRODUCT_ID numeric,LEG_ID numeric,TAX_REFUND numeric,IS_DIV_FX_RATE_FIXED numeric,DIV_FX_RESET_ID numeric,END_PERIOD_DIV_FX_RATE_FIX numeric,IS_WITH_SPREAD_FACTOR numeric,SPREAD numeric,EQUITY_RESET_ID numeric)
/

    ALTER TABLE SCHEDULED_QUANTITIES MODIFY (PRODUCT_ID numeric,LEG_ID numeric)
/

    ALTER TABLE SCHEDULED_QUANTITIES_HIST MODIFY (PRODUCT_ID numeric,LEG_ID numeric)
/

    ALTER TABLE EQ_BASKET_LEG_COMPS MODIFY (PRODUCT_ID numeric,LEG_ID numeric,REF_ASSET_ID numeric,IS_FX_RATE_FIXED numeric,FX_RESET_ID numeric)
/

    ALTER TABLE EQ_BASKET_LEG_COMPS_HIST MODIFY (PRODUCT_ID numeric,LEG_ID numeric,REF_ASSET_ID numeric,IS_FX_RATE_FIXED numeric,FX_RESET_ID numeric)
/

    ALTER TABLE ETO_CONTRACT MODIFY (CONTRACT_ID numeric,LAST_EXERCISE_TIME numeric,LAST_EXERCISE_RULE numeric,SETTLE_ADD_DAYS numeric,SETTLE_BUS_DAY_B numeric,AUTO_EXERCISE numeric,VERSION_NUM numeric,CA_ID numeric,DELIVERABLE_ID numeric,TRADE_SETTLE_ADD_DAYS numeric,USE_EXCHANGE_SPOT_DAYS numeric,ASIAN_FIXINGS_B numeric,COMM_RESET_ID numeric,FUTURE_CONTRACT_ID numeric,SVN_B numeric,SVN numeric,NAME_MONTH numeric)
/

    ALTER TABLE EVENT_PURGE MODIFY (EVENT_ID numeric)
/

    ALTER TABLE EXTERNAL_TRADE_EVENTS MODIFY (ACTION_ID numeric,PRODUCT_ID numeric,TRANSFEROR_ID numeric,TRANSFEREE_ID numeric,FFCP_OPTION numeric)
/

    ALTER TABLE EVENT_TYPE_ACTION MODIFY (ACTION_ID numeric,PRODUCT_ID numeric,CANCELLED_B numeric,COLLATERAL_ID numeric,TRADE_VERSION numeric,CLEANUP_B numeric,FEE_CLEANUP numeric,INT_CLEAN_UP numeric,SEQ_NO numeric,CONVERSION_B numeric,GEN_TRADE_ID numeric,IS_RECALL_B numeric)
/

    ALTER TABLE EVT_TYPE_ACT_HIST MODIFY (ACTION_ID numeric,PRODUCT_ID numeric,CANCELLED_B numeric,COLLATERAL_ID numeric,TRADE_VERSION numeric,CLEANUP_B numeric,FEE_CLEANUP numeric,SEQ_NO numeric,CONVERSION_B numeric,GEN_TRADE_ID numeric,IS_RECALL_B numeric)
/

    ALTER TABLE EVENT_TYPE_ACTION_ATTR MODIFY (ENTITY_ID numeric)
/

    ALTER TABLE EVENT_TYPE_ACTION_ATTR_HIST MODIFY (ENTITY_ID numeric)
/

    ALTER TABLE EXPIRY_DEL_SCHED_HIST MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE EXPIRY_DELIVERY_SCHEDULE MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE EXSP_BVAR MODIFY (PRODUCT_ID numeric,LEG_ID numeric)
/

    ALTER TABLE EXSP_BVAR_MEMBERS MODIFY (PRODUCT_ID numeric,LEG_ID numeric)
/

    ALTER TABLE EXSP_FVAR MODIFY (PRODUCT_ID numeric,LEG_ID numeric)
/

    ALTER TABLE EXSP_AVAR MODIFY (PRODUCT_ID numeric,LEG_ID numeric,IS_AMOUNT numeric,SPL_LAST_ROW_LOGIC numeric)
/

    ALTER TABLE EXSP_PRODUCT_VARIABLE MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE EXSP_PVAR_OVERRIDE MODIFY (PRODUCT_ID numeric,LEG_ID numeric)
/

    ALTER TABLE EXSP_QUOTABLE_VARIABLE MODIFY (VERSION_NUM numeric,RATE_INDEX_TENOR numeric,PRODUCT_ID numeric)
/

    ALTER TABLE EXSP_QVAR_OVERRIDE MODIFY (PRODUCT_ID numeric,LEG_ID numeric,RESET_DAYS numeric,RESET_BUS_LAG_B numeric,RESET_IN_ARREAR_B numeric)
/

    ALTER TABLE EXSP_TSVAR MODIFY (PRODUCT_ID numeric,LEG_ID numeric,SAMPLING_OVERRRIDE numeric)
/

    ALTER TABLE EXSP_TSVAR_EXPLICIT_SCHEDULE MODIFY (PRODUCT_ID numeric,LEG_ID numeric)
/

    ALTER TABLE EXSP_TSVAR_SAMP_PARAMS MODIFY (PRODUCT_ID numeric,LEG_ID numeric,RESET_CUTOFF numeric,RESETCUTOFFBUSDAYB numeric,DEF_RESET_OFF_B numeric,ROLLING_DAY numeric,CUSTOM_ROL_DAY_B numeric,SAMPLE_WEEKDAY numeric,RESET_OFFSET numeric,RESET_OFF_BUSDAY_B numeric,RESET_DATE_RULE_ID numeric)
/

    ALTER TABLE EXSP_TSVAR_SCHEDULE_PARAMETERS MODIFY (PRODUCT_ID numeric,LEG_ID numeric,CUSTOM_ROL_DAY_B numeric,ROLLING_DAY numeric)
/

    ALTER TABLE EXSP_VARIABLE_SETTING MODIFY (PRODUCT_ID numeric,LEG_ID numeric)
/

    ALTER TABLE PRODUCT_XCONF_TYPE MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PROD_XCONF_TYPE_HIST MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE COMP_CONFIG MODIFY (PRODUCT_ID numeric,LEG_ID numeric,IS_EDITABLE numeric,IS_MULTI_VALUE numeric)
/

    ALTER TABLE COMP_UI_CONFIG MODIFY (PRODUCT_ID numeric,LEG_ID numeric,COMP_ORDER numeric)
/

    ALTER TABLE COMP_UI_CONFIG_PROP MODIFY (PRODUCT_ID numeric,LEG_ID numeric)
/

    ALTER TABLE XCONF_PROD_MAPPER MODIFY (PRODUCT_ID numeric,LEG_ID numeric)
/

    ALTER TABLE XCONF_PROD_MAPPER_SETTING MODIFY (PRODUCT_ID numeric,LEG_ID numeric)
/

    ALTER TABLE EXTERNAL_C_FLW_COUPON_HIST MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,SUB_ID numeric,COLLATERAL_ID numeric,FIXED_RATE_B numeric,MANUAL_RESET_B numeric,ROUNDING_UNIT numeric,NUM_PERIODS numeric,NOTL_GUARANTEED numeric,IS_MM numeric,SAMPLE_WEEKDAY numeric,RESET_CUTOFF numeric,MANUAL_AMT_B numeric)
/

    ALTER TABLE EXTERNAL_CASH_FLOW_COUPON MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,SUB_ID numeric,COLLATERAL_ID numeric,FIXED_RATE_B numeric,MANUAL_RESET_B numeric,ROUNDING_UNIT numeric,NUM_PERIODS numeric,NOTL_GUARANTEED numeric,IS_MM numeric,SAMPLE_WEEKDAY numeric,RESET_CUTOFF numeric,MANUAL_AMT_B numeric)
/

    ALTER TABLE FADER_PARAMETERS MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE FORWARD_START_PARAMETERS MODIFY (PRODUCT_ID numeric,FXRESET numeric,STRIKE_STYLE numeric)
/

    ALTER TABLE FALLBACK_STRATEGY MODIFY (STRATEGY_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE FALLBACK_STRATEGY_ITEMS MODIFY (STRATEGY_ID numeric)
/

    ALTER TABLE FEE_BILLING MODIFY (FEE_BILL_ID numeric,LEGAL_ENTITY_ID numeric,PROCESSING_ORG_ID numeric,VERSION_NUM numeric,BILLING_DR numeric,SETTLE_DR numeric,ADJ_DAYS numeric,BUS_DAYS_B numeric)
/

    ALTER TABLE FEE_DATE MODIFY (PRODUCT_ID numeric,IS_FEE_PERCENT numeric)
/

    ALTER TABLE FEE_DATE_HIST MODIFY (PRODUCT_ID numeric,IS_FEE_PERCENT numeric)
/

    ALTER TABLE FEE_GRID MODIFY (FEE_GRID_ID numeric,PO_ID numeric,LE_ID numeric,VERSION_NUM numeric,EXCHANGE numeric,UNDERLYING numeric,ACCOUNT_ID numeric,USE_MULTI_CALCULATORS numeric)
/

    ALTER TABLE FEE_GRID_ATTR MODIFY (FEE_GRID_ID numeric)
/

    ALTER TABLE FEED_ADDRESS MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE FILTER_SET MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE FILTER_SET_DOMAIN MODIFY (ELEMENT_TYPE numeric)
/

    ALTER TABLE FILTER_SET_ELEMENT MODIFY (ELEMENT_TYPE numeric,IS_VALUE numeric)
/

    ALTER TABLE FIXING_METHOD_ATTR MODIFY (PRODUCT_ID numeric,PRODUCT_SUB_ID numeric)
/

    ALTER TABLE FLOW_CMP_PERIOD MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,MANUAL_RESET_B numeric,INTERPOLATED_B numeric,RATE_ROUNDING_DEC numeric,INTERP_RNDING_DEC numeric,IS_COMPOUNDING numeric)
/

    ALTER TABLE FLOW_SPREAD_HIST MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,SPREAD_MANUAL_RSET numeric)
/

    ALTER TABLE FLOW_SPREAD_INFO MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,SPREAD_MANUAL_RSET numeric)
/

    ALTER TABLE FLW_CMP_PERD_HIST MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,MANUAL_RESET_B numeric,INTERPOLATED_B numeric,RATE_ROUNDING_DEC numeric,INTERP_RNDING_DEC numeric,IS_COMPOUNDING numeric)
/

    ALTER TABLE FOLDER MODIFY (FOLDER_ID numeric,PARENT_ID numeric,PRIVATE_B numeric,SHARED_B numeric)
/

    ALTER TABLE FOLDER_SHORTCUT MODIFY (FOLDER_ID numeric,SC_FOLDER_ID numeric)
/

    ALTER TABLE FOLDER_TRADES MODIFY (FOLDER_ID numeric,TRADE_ID numeric)
/

    ALTER TABLE FUND MODIFY (FUND_ID numeric,LE_ID numeric,BOOK_ID numeric,PRODUCT_ID numeric,INTERNAL_B numeric,POOLED_B numeric,UNITIZED_B numeric,VERSION_NUM numeric,CASH_EQUIV_CONFIG_ID numeric,USE_SHARED_BOOK_AND_LE_B numeric,BENCHMARK_ID numeric,SECONDARY_BENCHMARK_ID numeric)
/

    ALTER TABLE FUND_STRATEGY_INFO MODIFY (ID numeric,FUND_ID numeric,STRATEGY_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE FUNDING_RATE MODIFY (FUNDING_RATE_ID numeric,PROCESSING_ORG_ID numeric,BOOK_ID numeric,USE_RESET_DAYS numeric,VERSION_NUM numeric,SECURITY_ID numeric)
/

    ALTER TABLE FUTURE_CONTRACT MODIFY (CONTRACT_ID numeric,VAR_UNDERLYING_AMT numeric,TRADEDAY_RANK numeric,TRADEDAY_WEEK_DAY numeric,TRADEDAY_MTH_END_B numeric,TRADEDAY_ADD_DAYS numeric,FST_DEL_RANK numeric,FST_DEL_WEEK_DAY numeric,FST_DEL_M_BEGIN_B numeric,FST_DEL_ADD_DAYS numeric,LAST_DEL_RANK numeric,LAST_DEL_WEEK_DAY numeric,LAST_DEL_M_END_B numeric,LAST_DEL_ADD_DAYS numeric,FST_NOT_RANK numeric,FST_NOT_WEEK_DAY numeric,FST_NOT_M_BEGIN_B numeric,FST_NOT_ADD_DAYS numeric,FST_NOT_ADD_DAYS_B numeric,UNDERLYING_TENOR numeric,FUTURE_NAME_MONTH numeric,ADD_BUS_DAY_B numeric,RELATIVE_MONTH_B numeric,FST_DEL_ADD_DAYS_B numeric,VERSION_NUM numeric,FUNGIBLE_ID numeric,BENCH_ADD_DAYS numeric,BENCH_ADD_DAYS_B numeric,QUOTE_DECIMALS numeric,FIRST_NOTIFY_RULE numeric,LAST_NOTIFY_RULE numeric,CALENDAR_DELTA numeric,CCP_LAG numeric,FIRST_NOT_PREV_DATE_B numeric)
/

    ALTER TABLE LISTED_CONTRACT MODIFY (CONTRACT_ID numeric,NB_TRADE_CONTRACT numeric,TIME_MINUTE numeric,TRADING_RULE numeric,TRADING_END_RULE numeric,FIRST_DEL_RULE numeric,LAST_DEL_RULE numeric,UND_PRODUCT_ID numeric,DATE_FORMAT numeric,QUOTE_DECIMALS numeric)
/

    ALTER TABLE LISTED_FRA_CONTRACT MODIFY (CONTRACT_ID numeric,PERIODIC_SETTLEMENT_RULE numeric,START_DATE_RULE numeric,PERIODIC_SETTLEMENT_LAG numeric,RATE_INDEX numeric,PERIODIC_SETTLEMENT_LAG_B numeric,PERIODIC_DISC_FIX_LAG numeric,PERIODIC_DISC_FIX_LAG_B numeric,EXPIRATION_FIX_LAG numeric,EXPIRATION_FIX_LAG_B numeric)
/

    ALTER TABLE FUTURE_CONTRACT_SPREAD MODIFY (CONTRACT_ID numeric,SPREAD_ID numeric)
/

    ALTER TABLE FUTURE_CTD MODIFY (CONTRACT_ID numeric,UNDERLYING_ID numeric,IS_CTD_B numeric)
/

    ALTER TABLE FX_ARB_CONFIG MODIFY (SWAP_BOOK_ID numeric,MM1_BOOK_ID numeric,MM2_BOOK_ID numeric,SPOT_BOOK_ID numeric)
/

    ALTER TABLE FX_CASH_FLOW MODIFY (PRODUCT_ID numeric,ORDER_ID numeric)
/

    ALTER TABLE PRODUCT_FX_FLEXI_FORWARD MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_FX_FLEXI_FORWARD_HIST MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE FX_FLEXI_FORWARD_TAKEUP_SCH MODIFY (TAKE_UP_SCHEDULE_ID numeric,FLEXI_FORWARD_PRODUCT_ID numeric,IS_PRIMARY_NEG_B numeric,NO_OF_WINDOWS numeric,NO_OF_LATE_TK_ROLLS numeric,VERSION numeric)
/

    ALTER TABLE FX_FLEXI_FORWARD_TAKEUP_SCH_H MODIFY (TAKE_UP_SCHEDULE_ID numeric,FLEXI_FORWARD_PRODUCT_ID numeric,IS_PRIMARY_NEG_B numeric,NO_OF_WINDOWS numeric,NO_OF_LATE_TK_ROLLS numeric,VERSION numeric)
/

    ALTER TABLE FX_FLEXI_FORWARD_TAKEUP_WIN MODIFY (TAKE_UP_WINDOW_ID numeric,TAKE_UP_SCHEDULE_ID numeric,NO_OF_DAYS numeric,ACTIVE_B numeric,VERSION numeric)
/

    ALTER TABLE FX_FLEXI_FORWARD_TAKEUP_WIN_H MODIFY (TAKE_UP_WINDOW_ID numeric,TAKE_UP_SCHEDULE_ID numeric,NO_OF_DAYS numeric,ACTIVE_B numeric,VERSION numeric)
/

    ALTER TABLE FX_TAKEUP_SCHEDULE_ACTION MODIFY (ACTION_ID numeric,RELATED_TRADE_ID numeric,TAKE_UP_SCHEDULE_ID numeric,IS_PRIMARY_NEG_B numeric,NO_OF_ELAPSED_DAYS numeric,TRADE_VERSION numeric,VERSION numeric)
/

    ALTER TABLE FX_TAKEUP_SCHEDULE_ACTION_H MODIFY (ACTION_ID numeric,RELATED_TRADE_ID numeric,TAKE_UP_SCHEDULE_ID numeric,IS_PRIMARY_NEG_B numeric,NO_OF_ELAPSED_DAYS numeric,TRADE_VERSION numeric,VERSION numeric)
/

    ALTER TABLE FX_TAKEUP_SCH_ACTION_ATTR MODIFY (ACTION_ID numeric)
/

    ALTER TABLE FX_TAKEUP_SCH_ACTION_ATTR_H MODIFY (ACTION_ID numeric)
/

    ALTER TABLE FX_FLEXI_FORWARD_ACTION MODIFY (ACTION_ID numeric,RELATED_TRADE_ID numeric,MODEL_ID numeric,TRADE_VERSION numeric,VERSION numeric)
/

    ALTER TABLE FX_FLEXI_FORWARD_ACTION_H MODIFY (ACTION_ID numeric,RELATED_TRADE_ID numeric,MODEL_ID numeric,TRADE_VERSION numeric,VERSION numeric)
/

    ALTER TABLE FX_FLEXI_FORWARD_ACTION_ATTR MODIFY (ACTION_ID numeric)
/

    ALTER TABLE FX_FLEXI_FORWARD_ACTION_ATTR_H MODIFY (ACTION_ID numeric)
/

    ALTER TABLE FX_FLEXI_FORWARD_MERCHANTFX MODIFY (MERCHANTFX_ID numeric,FLEXI_FORWARD_PRODUCT_ID numeric,IS_PRIMARY_NEG_B numeric,VERSION numeric)
/

    ALTER TABLE FX_FLEXI_FORWARD_MERCHANTFX_H MODIFY (MERCHANTFX_ID numeric,FLEXI_FORWARD_PRODUCT_ID numeric,IS_PRIMARY_NEG_B numeric,VERSION numeric)
/

    ALTER TABLE FX_MERCHANTFX_FINANCING MODIFY (MERCHANTFX_ID numeric)
/

    ALTER TABLE FX_MERCHANTFX_FINANCING_H MODIFY (MERCHANTFX_ID numeric)
/

    ALTER TABLE FX_MERCHANTFX_ACTION MODIFY (ACTION_ID numeric,IS_PRIMARY_NEG_B numeric)
/

    ALTER TABLE FX_MERCHANTFX_ACTION_H MODIFY (ACTION_ID numeric,IS_PRIMARY_NEG_B numeric)
/

    ALTER TABLE FX_FLEXI_FORWARD_WINDOW_FWD MODIFY (WINDOW_FORWARD_ID numeric,FLEXI_FORWARD_PRODUCT_ID numeric,IS_PRIMARY_NEG_B numeric,VERSION numeric)
/

    ALTER TABLE FX_FLEXI_FORWARD_WINDOW_FWD_H MODIFY (WINDOW_FORWARD_ID numeric,FLEXI_FORWARD_PRODUCT_ID numeric,IS_PRIMARY_NEG_B numeric,VERSION numeric)
/

    ALTER TABLE FX_WINDOW_FORWARD_ACTION MODIFY (ACTION_ID numeric,IS_PRIMARY_NEG_B numeric)
/

    ALTER TABLE FX_WINDOW_FORWARD_ACTION_H MODIFY (ACTION_ID numeric,IS_PRIMARY_NEG_B numeric)
/

    ALTER TABLE FX_MARK_UP MODIFY (UNDERLYING_INSTRUMENT_ID numeric)
/

    ALTER TABLE FX_MARK_UP_H MODIFY (UNDERLYING_INSTRUMENT_ID numeric)
/

    ALTER TABLE FX_SPLIT_RATES_DATA MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE FX_SPLIT_RATES_DATA_H MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE ENTITY_LIFECYCLE_REL MODIFY (ENTITY_ID numeric)
/

    ALTER TABLE ENTITY_LIFECYCLE_REL_H MODIFY (ENTITY_ID numeric)
/

    ALTER TABLE CASE_LOG_ENTRY MODIFY (ENTITY_ID numeric)
/

    ALTER TABLE CASE_LOG_ENTRY_H MODIFY (ENTITY_ID numeric)
/

    ALTER TABLE TRADE_LINK_INFO MODIFY (LINK_ID numeric,MAIN_TRADE_ID numeric,VERSION numeric)
/

    ALTER TABLE LINKED_OFFSET MODIFY (LINK_ID numeric,OFFSET_TRADE_ID numeric,LINKED_TRADE_ID numeric)
/

    ALTER TABLE FX_OPT_EXP_TZ MODIFY (USE_AS_VOL_DATECUT numeric,VERSION numeric)
/

    ALTER TABLE FX_OPT_VOL_HOL_WGT MODIFY (VERSION numeric,TRANSACTION_ID numeric)
/

    ALTER TABLE FX_RATE_SPREADS MODIFY (CPTY_ID numeric,MANUAL_SPREAD numeric,PERCENT_SPREAD numeric)
/

    ALTER TABLE FX_RESET MODIFY (FX_RESET_ID numeric,RESET_DAYS numeric,RESET_BUS_LAG_B numeric,RESET_HOUR numeric,CURVE_SIDE numeric,PREFERRED_B numeric,MANUAL_B numeric,VERSION_NUM numeric,SPOT_ALT_B numeric)
/

    ALTER TABLE FX_ROLLOVER_TRADES_TEMPLATE MODIFY (VERSION numeric,BOOK_ID numeric,SPLIT_POSITION_B numeric)
/

    ALTER TABLE FX_SPOT_RISK_TRANS MODIFY (VERSION numeric,BOOK_ID numeric,TRANSFER_BOOK_ID numeric,PRIORITY numeric,USE_NOTIONAL numeric,TRADE_THRESHOLD_AMT numeric)
/

    ALTER TABLE FX_FWD_RISK_TRANS MODIFY (VERSION numeric,BOOK_ID numeric,TRANSFER_BOOK_ID numeric)
/

    ALTER TABLE FX_SPOTRES_VD_SCH MODIFY (PRODUCT_ID numeric,SCH_ID numeric,CPTY_ID numeric,CUSTOM_MARGIN_B numeric)
/

    ALTER TABLE FX_TRADES_ALLOC MODIFY (LE_ID numeric,BOOK_ID numeric)
/

    ALTER TABLE FX_VOL_EVENT_WEIGHT MODIFY (EVENT_WEIGHT_ID numeric,COUNTRY_ID numeric)
/

    ALTER TABLE FX_VOL_EVENT_WEIGHT_RULE MODIFY (EVENT_WEIGHT_RULE_ID numeric,COUNTRY_ID numeric,MONTH numeric,DAY numeric,DAY_OF_WEEK numeric,RANK numeric)
/

    ALTER TABLE FXLINKED_BOOK_SUBSTITUTION MODIFY (BOOK_SUBSTITUTION_ID numeric,FROM_BOOK_ID numeric,TO_BOOK_ID numeric,ACTIVE numeric)
/

    ALTER TABLE FXORDER_EX_ENTRY MODIFY (ID numeric,PRODUCT_ID numeric,EXECUTE_TRADE_ID numeric)
/

    ALTER TABLE GD_CODES MODIFY (ID numeric)
/

    ALTER TABLE GENERIC_COMMENT MODIFY (COMMENT_ID numeric,OBJECT_ID numeric,OBJECT_VERSION numeric)
/

    ALTER TABLE GENERIC_COMMENT_HIST MODIFY (COMMENT_ID numeric,OBJECT_ID numeric,OBJECT_VERSION numeric)
/

    ALTER TABLE GENERIC_VENDOR_ATTRIBUTES MODIFY (ENTITY_ID numeric)
/

    ALTER TABLE GROUP_ACCESS MODIFY (ACCESS_ID numeric,READ_ONLY_B numeric)
/

    ALTER TABLE HAIRCUT MODIFY (TENOR numeric,START_MATURITY numeric,VERSION_NUM numeric,ORIG_MATURITY numeric)
/

    ALTER TABLE HAIRCUT_RULE_KV_CFG MODIFY (ID numeric,VERSION numeric)
/

    ALTER TABLE HAIRCUT_RULE_KV MODIFY (ID numeric)
/

    ALTER TABLE CROSS_CURRENCY_HAIRCUT MODIFY (ID numeric,VERSION numeric,ORDER_ID numeric)
/

    ALTER TABLE HEDGE_STRATEGY MODIFY (HEDGE_ID numeric,VERSION numeric,DATE_RULE_ID numeric,DATE_RULE2_ID numeric)
/

    ALTER TABLE HEDGE_RELATIONSHIP MODIFY (HEDGE_RELATIONSHIP_ID numeric,HEDGE_STRATEGY_ID numeric,HEDGE_RELATIONSHIP_CONFIG_ID numeric,IS_DOCUMENTATION_REVIEWED numeric,VERSION numeric)
/

    ALTER TABLE HEDGE_RELATIONSHIP_CONFIG MODIFY (HEDGE_RELATIONSHIP_CONFIG_ID numeric,HEDGED_PO_ID numeric,HEDGING_PO_ID numeric,HEDGE_STRATEGY_ID numeric,VERSION numeric)
/

    ALTER TABLE HEDGE_RELATIONSHIP_TRADE MODIFY (TRADE_ID numeric,HEDGE_RELATIONSHIP_ID numeric,IS_HEDGED_TRADE numeric,HYPOTHETICAL_TRADE_ID numeric)
/

    ALTER TABLE HOLIDAY_CODE MODIFY (FST_DAY_WEEKEND numeric,SCD_DAY_WEEKEND numeric,VERSION_NUM numeric)
/

    ALTER TABLE HOLIDAY_CODE_RULE MODIFY (HOLIDAY_RULE_ID numeric)
/

    ALTER TABLE HOLIDAY_DATE MODIFY (WORKING_B numeric)
/

    ALTER TABLE HOLIDAY_RULE MODIFY (HOLIDAY_RULE_ID numeric,HOLIDAY_MONTH numeric,HOLIDAY_DAY numeric,HOLIDAY_RANK numeric,HOLIDAY_WEEKDAY numeric,EASTER_OFFSET numeric,SATURDAY_ROLL numeric,SUNDAY_ROLL numeric,VERSION_NUM numeric)
/

    ALTER TABLE PL_TAX_RULE MODIFY (PL_TAX_RULE_ID numeric,RULE_VERSION numeric,IS_POSITION numeric,LE_ID numeric)
/

    ALTER TABLE INCOMING_CONFIG MODIFY (CONFIG_ID numeric,RECEIVER_ID numeric,MATCHING_B numeric)
/

    ALTER TABLE INCOMING_DOC_HIST MODIFY (DOCUMENT_ID numeric,ADVICE_ID numeric,TRADE_ID numeric)
/

    ALTER TABLE INCOMING_DOCUMENT MODIFY (DOCUMENT_ID numeric,ADVICE_ID numeric,TRADE_ID numeric)
/

    ALTER TABLE FILE_DOCUMENT MODIFY (DOCUMENT_ID numeric,VERSION numeric,IS_BINARY numeric)
/

    ALTER TABLE INDUSTRY_HIERARCHY MODIFY (ID numeric,VERSION_NUM numeric,ALLOW_MULTI_CLASS numeric)
/

    ALTER TABLE INDUSTRY_HIERARCHY_ATTRIBUTE MODIFY (ID numeric,INDUSTRY_HIERARCHY_ID numeric,INDUSTRY_HIERARCHY_NODE_ID numeric,INDUSTRY_HIERARCHY_MAP_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE INDUSTRY_HIERARCHY_MAP MODIFY (ID numeric,INDUSTRY_HIERARCHY_ID numeric,INDUSTRY_HIERARCHY_NODE_ID numeric,STICKINESS numeric,IS_ISSUER numeric,IS_PRIMARY_CLASSIFICATION numeric,ISSUER_OR_PRODUCT_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE INDUSTRY_HIERARCHY_NODE MODIFY (ID numeric,PARENT_ID numeric,INDUSTRY_HIERARCHY_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE INIT_PRICES_HIST MODIFY (PRODUCT_ID numeric,LEG_ID numeric,REF_ASSET_ID numeric)
/

    ALTER TABLE INITIAL_PRICES MODIFY (PRODUCT_ID numeric,LEG_ID numeric,REF_ASSET_ID numeric)
/

    CREATE TABLE inv_cashpos_hist (
        internal_external varchar2 (32) NOT NULL,
         position_type varchar2 (16) NOT NULL,
         agent_id numeric  NOT NULL,
         account_id numeric  NOT NULL,
         date_type varchar2 (16) NOT NULL,
         position_date timestamp  NOT NULL,
         currency_code varchar2 (3) NOT NULL,
         book_id numeric  NOT NULL,
         config_id numeric  DEFAULT 0 NOT NULL,
         total_amount float  NULL,
         daily_change float  NULL,
         archived_date timestamp  NULL 
    ) 
/

    CREATE TABLE inv_cashposition (
        internal_external varchar2 (32) NOT NULL,
         position_type varchar2 (16) NOT NULL,
         agent_id numeric  NOT NULL,
         account_id numeric  NOT NULL,
         date_type varchar2 (16) NOT NULL,
         position_date timestamp  NOT NULL,
         currency_code varchar2 (3) NOT NULL,
         book_id numeric  NOT NULL,
         config_id numeric  DEFAULT 0 NOT NULL,
         total_amount float  NULL,
         daily_change float  NULL 
    ) 
/

    ALTER TABLE INV_CASH_MOVEMENT ADD (daily_nfa decimal (38,15)  NULL,daily_brokerage decimal (38,15)  NULL,daily_unavail decimal (38,15)  NULL)
/

    ALTER TABLE INV_CASH_BALANCE ADD (total_nfa decimal (38,15)  NULL,total_brokerage decimal (38,15)  NULL,total_unavail decimal (38,15)  NULL)
/

    ALTER TABLE INV_CUST_CASH_MOVEMENT MODIFY (AGENT_ID numeric,ACCOUNT_ID numeric,BOOK_ID numeric,CONFIG_ID numeric,MCC_ID numeric,SUB_ACCOUNT_ID numeric,VERSION numeric)
/

    ALTER TABLE INV_CUST_CASH_BALANCE MODIFY (AGENT_ID numeric,ACCOUNT_ID numeric,BOOK_ID numeric,CONFIG_ID numeric,MCC_ID numeric,SUB_ACCOUNT_ID numeric,VERSION numeric)
/

    CREATE TABLE inv_secpos_hist (
        internal_external varchar2 (32) NOT NULL,
         position_type varchar2 (16) NOT NULL,
         date_type varchar2 (16) NOT NULL,
         agent_id numeric  NOT NULL,
         account_id numeric  NOT NULL,
         position_date timestamp  NOT NULL,
         security_id numeric  NOT NULL,
         book_id numeric  NOT NULL,
         config_id numeric  DEFAULT 0 NOT NULL,
         total_security float  NULL,
         daily_security float  NULL,
         total_borrowed float  NULL,
         daily_borrowed float  NULL,
         t_bor_not_avl float  NULL,
         d_bor_not_avl float  NULL,
         total_borrowed_ca float  NULL,
         total_borrowed_collateral float  NULL,
         daily_borrowed_collateral float  NULL,
         total_loaned float  NULL,
         daily_loaned float  NULL,
         t_loan_not_avl float  NULL,
         d_loan_not_avl float  NULL,
         total_loaned_ca float  NULL,
         total_loaned_collateral float  NULL,
         daily_loaned_collateral float  NULL,
         total_coll_in float  NULL,
         daily_coll_in float  NULL,
         t_coll_in_not_avl float  NULL,
         d_coll_in_not_avl float  NULL,
         total_coll_in_ca float  NULL,
         total_coll_out float  NULL,
         daily_coll_out float  NULL,
         t_coll_out_not_avl float  NULL,
         d_coll_out_not_avl float  NULL,
         total_coll_out_ca float  NULL,
         total_pledged_in float  NULL,
         daily_pledged_in float  NULL,
         total_pledged_out float  NULL,
         daily_pledged_out float  NULL,
         daily_coll_out_ca float  NULL,
         daily_coll_in_ca float  NULL,
         total_unavail float  NULL,
         daily_unavail float  NULL,
         total_repo_track_in float  NULL,
         daily_repo_track_in float  NULL,
         total_repo_track_out float  NULL,
         daily_repo_track_out float  NULL,
         total_borrowed_auto float  NULL,
         daily_borrowed_auto float  NULL,
         total_loaned_auto float  NULL,
         daily_loaned_auto float  NULL,
         total_pth_in float  NULL,
         daily_pth_in float  NULL,
         total_pth_out float  NULL,
         daily_pth_out float  NULL,
         total_hold_in float  NULL,
         daily_hold_in float  NULL,
         total_hold_out float  NULL,
         daily_hold_out float  NULL,
         daily_repo_bsb_in float  NULL,
         daily_repo_bsb_out float  NULL,
         total_repo_bsb_in float  NULL,
         total_repo_bsb_out float  NULL,
         total_repo_in float  NULL,
         total_repo_out float  NULL,
         daily_repo_in float  NULL,
         daily_repo_out float  NULL,
         archived_date timestamp  NULL 
    ) 
/

    CREATE TABLE inv_secposition (
        internal_external varchar2 (32) NOT NULL,
         position_type varchar2 (16) NOT NULL,
         date_type varchar2 (16) NOT NULL,
         agent_id numeric  NOT NULL,
         account_id numeric  NOT NULL,
         position_date timestamp  NOT NULL,
         security_id numeric  NOT NULL,
         book_id numeric  NOT NULL,
         config_id numeric  DEFAULT 0 NOT NULL,
         total_security float  NULL,
         daily_security float  NULL,
         total_borrowed float  NULL,
         daily_borrowed float  NULL,
         t_bor_not_avl float  NULL,
         d_bor_not_avl float  NULL,
         total_borrowed_ca float  NULL,
         total_borrowed_collateral float  NULL,
         daily_borrowed_collateral float  NULL,
         total_loaned float  NULL,
         daily_loaned float  NULL,
         t_loan_not_avl float  NULL,
         d_loan_not_avl float  NULL,
         total_loaned_ca float  NULL,
         total_loaned_collateral float  NULL,
         daily_loaned_collateral float  NULL,
         total_coll_in float  NULL,
         daily_coll_in float  NULL,
         t_coll_in_not_avl float  NULL,
         d_coll_in_not_avl float  NULL,
         total_coll_in_ca float  NULL,
         total_coll_out float  NULL,
         daily_coll_out float  NULL,
         t_coll_out_not_avl float  NULL,
         d_coll_out_not_avl float  NULL,
         total_coll_out_ca float  NULL,
         total_pledged_in float  NULL,
         daily_pledged_in float  NULL,
         total_pledged_out float  NULL,
         daily_pledged_out float  NULL,
         daily_coll_out_ca float  NULL,
         daily_coll_in_ca float  NULL,
         total_unavail float  NULL,
         daily_unavail float  NULL,
         total_repo_track_in float  NULL,
         daily_repo_track_in float  NULL,
         total_repo_track_out float  NULL,
         daily_repo_track_out float  NULL,
         total_borrowed_auto float  NULL,
         daily_borrowed_auto float  NULL,
         total_loaned_auto float  NULL,
         daily_loaned_auto float  NULL,
         total_pth_in float  NULL,
         daily_pth_in float  NULL,
         total_pth_out float  NULL,
         daily_pth_out float  NULL,
         total_hold_in float  NULL,
         daily_hold_in float  NULL,
         total_hold_out float  NULL,
         daily_hold_out float  NULL,
         daily_repo_bsb_in float  NULL,
         daily_repo_bsb_out float  NULL,
         total_repo_bsb_in float  NULL,
         total_repo_bsb_out float  NULL,
         total_repo_in float  NULL,
         total_repo_out float  NULL,
         daily_repo_in float  NULL,
         daily_repo_out float  NULL 
    ) 
/

    ALTER TABLE INV_SEC_BALANCE ADD (total_borrowed_collateral float NULL,total_loaned_collateral float NULL)
/

    ALTER TABLE INV_SEC_MOVEMENT ADD (daily_borrowed_collateral float NULL,daily_loaned_collateral float NULL)
/

    ALTER TABLE INV_CUST_SEC_BALANCE MODIFY (AGENT_ID numeric,ACCOUNT_ID numeric,SECURITY_ID numeric,BOOK_ID numeric,CONFIG_ID numeric,MCC_ID numeric,SUB_ACCOUNT_ID numeric,VERSION numeric)
/

    ALTER TABLE INV_CUST_SEC_MOVEMENT MODIFY (AGENT_ID numeric,ACCOUNT_ID numeric,SECURITY_ID numeric,BOOK_ID numeric,CONFIG_ID numeric,MCC_ID numeric,SUB_ACCOUNT_ID numeric,VERSION numeric)
/

    ALTER TABLE INV_SEC_QUERY MODIFY (AGENT_ID numeric,ACCOUNT_ID numeric,SECURITY_ID numeric,BOOK_ID numeric,CONFIG_ID numeric,MCC_ID numeric,SUB_ACCOUNT_ID numeric,QUERY_ID numeric)
/

    ALTER TABLE INV_CASH_QUERY MODIFY (AGENT_ID numeric,ACCOUNT_ID numeric,BOOK_ID numeric,CONFIG_ID numeric,MCC_ID numeric,SUB_ACCOUNT_ID numeric,QUERY_ID numeric)
/

    ALTER TABLE INV_CONFIG_ID_TEMP MODIFY (QUERY_ID numeric,CONFIG_ID numeric)
/

    ALTER TABLE INV_PRODUCT_TEMP MODIFY (QUERY_ID numeric,PRODUCT_ID numeric)
/

    ALTER TABLE INV_AGG MODIFY (INV_AGG_ID numeric,SECURITY_ID numeric)
/

    ALTER TABLE KICKOFF_CFG MODIFY (KICKOFF_ID numeric,WFW_TRANSITION numeric,RECEIVER_ID numeric,KICKOFF numeric,KICKOFFTIME numeric,CUTOFF numeric,CUTOFFTIME numeric,ABSOLUTE_B numeric,SCAN_FREQ numeric,VERSION_NUM numeric,CHECK_HOLIDAY_B numeric)
/

    ALTER TABLE LE_AGR_CHILD MODIFY (LEGAL_AGREEMENT_ID numeric,LEGAL_ENTITY_ID numeric)
/

    ALTER TABLE LE_AGREEMENT_CAPITALISATION MODIFY (LE_AGREEMENT_ID numeric,CAPITALISE_CA numeric)
/

    ALTER TABLE LE_AGREEMENT_FIELD MODIFY (LE_AGREEMENT_ID numeric)
/

    ALTER TABLE LE_ATTR_CODE MODIFY (UNIQUE_B numeric,SEARCHABLE_B numeric,MANDATORY_B numeric,VERSION_NUM numeric)
/

    ALTER TABLE LE_ATTRIBUTE MODIFY (LE_ATTRIBUTE_ID numeric,LEGAL_ENTITY_ID numeric,PROCESSING_ORG_ID numeric,ANONYMIZED numeric,VERSION_NUM numeric)
/

    ALTER TABLE LE_CONTACT MODIFY (CONTACT_ID numeric,LEGAL_ENTITY_ID numeric,PO_ID numeric,VERSION_NUM numeric,ANONYMIZED numeric)
/

    ALTER TABLE LE_CONTACT MODIFY (CITY varchar2 (36) , ZIPCODE varchar2 (36) , STATE varchar2 (36) , PHONE varchar2 (36) , FAX varchar2 (36) , TELEX varchar2 (36) , SWIFT varchar2 (36))
/

    ALTER TABLE LE_CONTACT_ATTR MODIFY (CONTACT_ID numeric)
/

    ALTER TABLE LE_EOD_TIME MODIFY (LE_ID numeric,EOD_TIME numeric,VERSION_NUM numeric,TYPE numeric)
/

    ALTER TABLE LE_LEGAL_AGREEMENT MODIFY (LEGAL_AGREEMENT_ID numeric,PROCESSING_ORG_ID numeric,LEGAL_ENTITY_ID numeric,EXT_LE_ID numeric,VERSION_NUM numeric,IS_MASTER_B numeric,TRADE_TENOR numeric,REPRICE_DATE_RULE numeric,IS_SUBST_PERMITTED_B numeric,HAIRCUT_SIGN numeric,HAIRCUT_DECIMAL numeric,NOTICE_DAYS numeric,IS_TRILATERAL_B numeric,SUBSTITUTION_LIMIT numeric,CLEANUP_ON_EVENT numeric)
/

    ALTER TABLE LE_AGR_INTEREST_RATE MODIFY (LEGAL_AGREEMENT_ID numeric)
/

    ALTER TABLE LE_REGISTRATION MODIFY (ID_REGISTRATION numeric,LEGAL_ENTITY_ID numeric,AGENT_LEGAL_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE LE_RELATION MODIFY (PO_ID numeric,LE_ID numeric,LE2_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE LE_ROLE_DISABLED MODIFY (PO_ID numeric,LE_ID numeric)
/

    ALTER TABLE SDI_CASH_ACCOUNTS MODIFY (SDI_ID numeric,CASH_ACCOUNT_ID numeric)
/

    ALTER TABLE SDI_CASH_ACCOUNTS_HIST MODIFY (SDI_ID numeric,CASH_ACCOUNT_ID numeric)
/

    ALTER TABLE LE_SETTLE_DELIVERY MODIFY (SDI_ID numeric,SDI_TYPE numeric,AGENT_LE numeric,MESSAGE_TO_AGENT numeric,INT_LE numeric,MESSAGE_TO_INT numeric,BENE_LE numeric,GL_ACCOUNT_ID numeric,DIRECT_B numeric,PREFERRED_B numeric,PAY_RECEIVE numeric,PROCESS_ORG_ID numeric,INT_GL_ACC_ID numeric,PRIORITY numeric,LINK_ID numeric,INT_LE_2 numeric,MESSAGE_TO_INT2 numeric,TRADE_CPTY_ID numeric,VERSION_NUM numeric,TRADE_DATE_B numeric,ADDRESSEE_LE numeric)
/

    ALTER TABLE LE_SETTLE_DELIVERY_HIST MODIFY (SDI_ID numeric,SDI_TYPE numeric,AGENT_LE numeric,MESSAGE_TO_AGENT numeric,INT_LE numeric,MESSAGE_TO_INT numeric,BENE_LE numeric,GL_ACCOUNT_ID numeric,DIRECT_B numeric,PREFERRED_B numeric,PAY_RECEIVE numeric,PROCESS_ORG_ID numeric,INT_GL_ACC_ID numeric,PRIORITY numeric,LINK_ID numeric,INT_LE_2 numeric,MESSAGE_TO_INT2 numeric,TRADE_CPTY_ID numeric,VERSION_NUM numeric,TRADE_DATE_B numeric,ADDRESSEE_LE numeric)
/

    ALTER TABLE LE_TOLERANCE MODIFY (LE_TOLERANCE_ID numeric,LEGAL_ENTITY_ID numeric,REFERENCE_B numeric,VERSION_NUM numeric)
/

    ALTER TABLE LIMIT_ADJUSTMENT MODIFY (LIMIT_ID numeric,CONFIG_ID numeric)
/

    ALTER TABLE LIMIT_CONFIG MODIFY (CONFIG_ID numeric,ROOT_NODE_ID numeric,VERSION numeric)
/

    ALTER TABLE LIMIT_CONFIG_LIMIT MODIFY (LIMIT_ID numeric,CONFIG_ID numeric,NODE_ID numeric,INCLUDE_SUBLIMIT numeric)
/

    ALTER TABLE LIMIT_CONFIG_NODE MODIFY (CONFIG_ID numeric,NODE_ID numeric,PARENT_ID numeric)
/

    ALTER TABLE LIQ_INFO MODIFY (LIQ_INFO_ID numeric,BOOK_ID numeric,COMP_DYNAMIC_ID numeric,BY_TRADE_DATE_B numeric,HEDGING_B numeric,ENTERED_DATE_B numeric,VERSION_NUM numeric,USE_POS_ENGINE numeric,LIQ_CONFIG_ID numeric,CREATE_SNAPSHOTS numeric,EXPLODE_FEE_SETTLE_B numeric,CROSS_BOOK_ID numeric)
/

    ALTER TABLE LIQ_CONFIG_KEY_VALUE MODIFY (LIQ_CONFIG_ID numeric,ORDER_ID numeric)
/

    ALTER TABLE LIQ_INFO_AGG_MAP MODIFY (BOOK_ID numeric,LIQ_CONFIG_ID numeric,LIQ_AGG_CONF_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE COMPARATOR_DYNAMIC MODIFY (COMPARATOR_ID numeric,LIQ_DATE_TYPE numeric,VERSION numeric)
/

    ALTER TABLE OFFSETTING_ELT MODIFY (COMPARATOR_ID numeric,ORDER_ID numeric)
/

    ALTER TABLE ORDERING_CRITERIA MODIFY (COMPARATOR_ID numeric,ASCENDING numeric,ORDER_ID numeric)
/

    ALTER TABLE LIQ_POSITION MODIFY (ORDER_ID numeric,FIRST_TRADE numeric,SECOND_TRADE numeric,BOOK_ID numeric,PRODUCT_ID numeric,TYPE numeric,IS_DELETED numeric,LAST_LIQ_ID numeric,FIRST_REL_ID numeric,SEC_REL_ID numeric,INITIAL_ID numeric,LIQ_AGG_ID numeric,POSITION_ID numeric,LIQ_CONFIG_ID numeric,FIRST_LINKED_ID numeric,SECOND_LINKED_ID numeric,IS_MANUAL numeric)
/

    ALTER TABLE LIQ_POSITION_HIST MODIFY (ORDER_ID numeric,FIRST_TRADE numeric,SECOND_TRADE numeric,BOOK_ID numeric,PRODUCT_ID numeric,TYPE numeric,IS_DELETED numeric,LAST_LIQ_ID numeric,FIRST_REL_ID numeric,SEC_REL_ID numeric,INITIAL_ID numeric,LIQ_AGG_ID numeric,POSITION_ID numeric,LIQ_CONFIG_ID numeric,FIRST_LINKED_ID numeric,SECOND_LINKED_ID numeric,IS_MANUAL numeric)
/

    ALTER TABLE LIQ_POSITION_DEL MODIFY (ORDER_ID numeric,FIRST_TRADE numeric,SECOND_TRADE numeric,BOOK_ID numeric,PRODUCT_ID numeric,TYPE numeric,IS_DELETED numeric,LAST_LIQ_ID numeric,FIRST_REL_ID numeric,SEC_REL_ID numeric,INITIAL_ID numeric,LIQ_AGG_ID numeric,POSITION_ID numeric,LIQ_CONFIG_ID numeric,FIRST_LINKED_ID numeric,SECOND_LINKED_ID numeric,IS_MANUAL numeric)
/

    ALTER TABLE LIQ_TAX MODIFY (ORDER_ID numeric,PL_TAX_RULE_ID numeric,PL_TAX_RULE_VERSION numeric)
/

    ALTER TABLE LIQ_TAX_HIST MODIFY (ORDER_ID numeric,PL_TAX_RULE_ID numeric,PL_TAX_RULE_VERSION numeric)
/

    ALTER TABLE LIQ_TDWAC MODIFY (LIQ_ORDER_ID numeric)
/

    ALTER TABLE LIQ_TDWAC_HIST MODIFY (LIQ_ORDER_ID numeric)
/

    ALTER TABLE LIQ_TDWAC_DEL MODIFY (LIQ_ORDER_ID numeric)
/

    ALTER TABLE LIQ_CA_ALLOC MODIFY (ORDER_ID numeric,INV_TRADE numeric)
/

    ALTER TABLE LIQ_CA_ALLOC_HIST MODIFY (ORDER_ID numeric,INV_TRADE numeric)
/

    ALTER TABLE LIQ_PRODUCT_TEMP MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE LIST_OPT_CONTRACT MODIFY (CONTRACT_ID numeric,UNDERLYING_ID numeric,NB_CONTRACT numeric,TIME_MINUTE numeric,TRADING_RULE numeric,FIRST_DEL_RULE numeric,LAST_DEL_RULE numeric,AUTO_EXERCISE numeric,VERSION_NUM numeric)
/

    ALTER TABLE LOAN_OBLIGATIONS MODIFY (PRODUCT_ID numeric,CASH_ID numeric)
/

    ALTER TABLE LOTTERY_WIN_DATE MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE MANUAL_PARTY_SDI MODIFY (SDI_ID numeric,SEQ_NO numeric,PTY_ID numeric,IS_FINANCIAL numeric,MSG_TO_PTY numeric)
/

    ALTER TABLE MANUAL_SDI MODIFY (SDI_ID numeric,CLASSIFICATION numeric,BENE_LE_ID numeric,VERSION_NUM numeric,VALIDITY_TYPE numeric,TRADE_CPTY_ID numeric)
/

    ALTER TABLE MANUAL_SDI_ATTR MODIFY (SDI_ID numeric)
/

    ALTER TABLE MANUAL_PARTY_SDI_HIST MODIFY (SDI_ID numeric,SEQ_NO numeric,PTY_ID numeric,IS_FINANCIAL numeric,MSG_TO_PTY numeric)
/

    ALTER TABLE MANUAL_SDI_HIST MODIFY (SDI_ID numeric,CLASSIFICATION numeric,BENE_LE_ID numeric,VERSION_NUM numeric,VALIDITY_TYPE numeric,TRADE_CPTY_ID numeric)
/

    ALTER TABLE MANUAL_SDI_ATTR_HIST MODIFY (SDI_ID numeric)
/

    ALTER TABLE MAPPING_STATUS MODIFY (WORKFLOW_ID numeric)
/

    ALTER TABLE MARKET_DATA_ITEM MODIFY (MDATA_ID numeric)
/

    ALTER TABLE MARKET_DATA_ITEM_GROUP MODIFY (MARKET_DATA_ITEM_ID numeric)
/

    ALTER TABLE MARKET_DATA_KEYWORD MODIFY (MDATA_ID numeric)
/

    ALTER TABLE MASTER_CONFIRMATION MODIFY (MASTER_CONFIRMATION_ID numeric,PROCESSING_ORG_ID numeric,COUNTER_PARTY_ID numeric,PRODUCT_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE MASTER_CONFIRMATION_CHILD MODIFY (MASTER_CONFIRMATION_ID numeric,LEGAL_ENTITY_ID numeric)
/

    ALTER TABLE MASTER_CONFIRMATION_FIELD MODIFY (MASTER_CONFIRMATION_ID numeric)
/

    ALTER TABLE MESS_ATTR_HIST MODIFY (MESSAGE_ID numeric)
/

    ALTER TABLE MESS_ATTRIBUTES MODIFY (MESSAGE_ID numeric)
/

    ALTER TABLE MESSAGE_CMT_HIST MODIFY (COMMENT_ID numeric,MESSAGE_ID numeric)
/

    ALTER TABLE MESSAGE_COMMENT MODIFY (COMMENT_ID numeric,MESSAGE_ID numeric)
/

    ALTER TABLE MESSAGE_GROUP MODIFY (MESSAGE_GROUP_ID numeric)
/

    ALTER TABLE MESSAGE_RULE MODIFY (MESSAGE_RULE_ID numeric,PROCESSING_ORG_ID numeric,IS_SENT numeric,LINK_ID numeric,LE_LINK_ID numeric,LEGAL_ENTITY_ID numeric)
/

    ALTER TABLE MRGCALL_CASHPOS MODIFY (MRG_CALL_DEF numeric)
/

    ALTER TABLE MRGCALL_CONFIG MODIFY (MRG_CALL_DEF numeric,PROCESS_ORG_ID numeric,LEGAL_ENTITY_ID numeric,DATE_RULE_ID numeric,BOOK_ID numeric,STATE_DATE_RULE_ID numeric,VERSION_NUM numeric,INCLUDE_IM_B numeric,IM_TRADE_ID numeric,REHYPOTHECABLE_B numeric,PARENT_ID numeric,VAL_AGENT_ID numeric,LIMIT_PERC_B numeric,MIN_ADJ_PERC_B numeric,MAX_ADJ_PERC_B numeric,REPT_BROWSER_CONFIG_ID numeric,LE_CASH_OFFSET numeric,LE_SECURITY_CASH_OFFSET numeric,PO_CASH_OFFSET numeric,PO_SECURITY_CASH_OFFSET numeric,IND_AMOUNT_INTEREST numeric,IM_CONFIG_ID numeric,DISPUTE_TOL_PERC_B numeric,EXCLUDE_TRADE_HC numeric,ROLL_INTEREST_B numeric,ROLL_INT_SETTLE_DAYS numeric)
/

    ALTER TABLE MRGCALL_TEMPLATE_IDS MODIFY (MRG_CALL_DEF numeric,TEMPLATE_ID numeric,POSITION numeric)
/

    ALTER TABLE INITIAL_MARGIN_CONFIG MODIFY (INITIAL_MARGIN_CONFIG_ID numeric)
/

    ALTER TABLE INITIAL_MARGIN_RULE MODIFY (INITIAL_MARGIN_RULE_ID numeric,INITIAL_MARGIN_CONFIG_ID numeric)
/

    ALTER TABLE INITIAL_MARGIN_FILTER MODIFY (INITIAL_MARGIN_RULE_ID numeric,PRIORITY numeric)
/

    ALTER TABLE NOP_AGGREGATION_CONFIG MODIFY (NOP_AGGREGATION_CONFIG_ID numeric,INITIAL_MARGIN_CONFIG_ID numeric)
/

    ALTER TABLE NOP_AGGREGATION_KEY MODIFY (NOP_AGGREGATION_CONFIG_ID numeric,PRIORITY numeric)
/

    ALTER TABLE MRGCALL_CONFIG_CURRENCY MODIFY (MRG_CALL_DEF numeric,IS_COMPOUND numeric,IS_INCLUDED numeric,IS_PROJECTED numeric,IS_AUTO_ADJUST_MARGIN numeric,IS_RATE_INDEX_FLOOR numeric)
/

    ALTER TABLE MRGCALL_COLL_DATE MODIFY (MRGCALL_COLL_DATE_ID numeric,MRG_CALL_DEF numeric)
/

    ALTER TABLE MRGCALL_COLL_DATE_VALUE MODIFY (MRGCALL_COLL_DATE_ID numeric,COLLATERAL_DATE numeric)
/

    ALTER TABLE MRGCALL_CR_THRES MODIFY (VERSION_NUM numeric,PRIORITY numeric,MRG_CALL_DEF numeric)
/

    ALTER TABLE MRGCALL_FIELD MODIFY (MCC_ID numeric)
/

    ALTER TABLE MRGCALL_SECPOS MODIFY (MRG_CALL_DEF numeric,SECURITY_ID numeric)
/

    ALTER TABLE MUTATION MODIFY (MUTATION_ID numeric,VERSION_NUM numeric,MUTED_TRADE_ID numeric,MUTED_TRADE_VER numeric,EX_VERSION numeric,SEQ_NUMBER numeric)
/

    ALTER TABLE MUTATION_ATTR MODIFY (MUTATION_ID numeric)
/

    ALTER TABLE MUTATION_FLOW MODIFY (MUTATION_ID numeric,FLOW_ID numeric,LEGAL_ENTITY_ID numeric)
/

    ALTER TABLE NDS_EXT_INFO MODIFY (PRODUCT_ID numeric,FX_DEFAULT_RESET_B numeric,FX_RESET_OFFSET numeric,FX_RESET_ID numeric,FX_FIXED_RATE_B numeric)
/

    ALTER TABLE NETTING_METHOD MODIFY (NETTING_METHOD_ID numeric,LEGAL_ENTITY_ID numeric,PROCESSING_ORG_ID numeric,VERSION_NUM numeric,NETTING_GROUP numeric)
/

    ALTER TABLE NOT_SCHED_HIST MODIFY (PRODUCT_ID numeric,SUB_ID numeric,INT_CLEAN_UP numeric,SEQ_NO numeric)
/

    ALTER TABLE NOTIONAL_SCHEDULE MODIFY (PRODUCT_ID numeric,SUB_ID numeric,INT_CLEAN_UP numeric,SEQ_NO numeric)
/

    ALTER TABLE OBJ_REQUEST_LOG MODIFY (NO_TIMES_REQUESTED numeric)
/

    ALTER TABLE OBJ_REQUEST_LOG MODIFY ENTITY_NAME varchar2 (128)
/

    ALTER TABLE OBJECT_VERSION MODIFY (OBJECT_ID numeric,VERSION_NUM numeric,TX_ID numeric)
/

    ALTER TABLE OBSERVABLE MODIFY (OBSERVABLE_ID numeric,VERSION_NUM numeric,IS_PRODUCT numeric,PRODUCT_ID numeric)
/

    ALTER TABLE OBSERVATION MODIFY (MUTATION_ID numeric,OBSERVABLE_ID numeric)
/

    ALTER TABLE OPT_DELIV_HIST MODIFY (PRODUCT_ID numeric,DELIVERABLE_ID numeric,RECEIVE_B numeric,CALC_OFFSET numeric,CALC_BUS_DAY_B numeric,IS_PRODUCT numeric,DEL_PRODUCT_ID numeric)
/

    ALTER TABLE OPT_OBSERV_HIST MODIFY (PRODUCT_ID numeric,LEG_ID numeric,OBSERVABLE_VAR_ID numeric,OBSERVABLE_ID numeric,OBSERVED_TIME numeric)
/

    ALTER TABLE OPTION_CONTRACT MODIFY (CONTRACT_ID numeric,TRADEDAY_RANK numeric,TRADEDAY_WEEK_DAY numeric,TRADEDAY_M_END_B numeric,TRADEDAY_ADD_DAYS numeric,FST_DEL_RANK numeric,FST_DEL_WEEK_DAY numeric,FST_DEL_M_BEGIN_B numeric,FST_DEL_ADD_DAYS numeric,LAST_DEL_RANK numeric,LAST_DEL_WEEK_DAY numeric,LAST_DEL_M_END_B numeric,FUTURE_NAME_MONTH numeric,LAST_DEL_ADD_DAYS numeric,FST_DEL_ADD_DAYS_B numeric,ADD_BUS_DAY_B numeric,RELATIVE_MONTH_B numeric,AUTO_EXERCISE numeric,VERSION_NUM numeric,MONTHS_ADDED numeric,UNDERLYING_RULE numeric,FUNGIBLE_ID numeric)
/

    ALTER TABLE OPTION_DELIVERABLE MODIFY (PRODUCT_ID numeric,DELIVERABLE_ID numeric,RECEIVE_B numeric,CALC_OFFSET numeric,CALC_BUS_DAY_B numeric,IS_PRODUCT numeric,DEL_PRODUCT_ID numeric,ETO_CONTRACT_ID numeric)
/

    ALTER TABLE OPTION_OBSERVABLE MODIFY (PRODUCT_ID numeric,LEG_ID numeric,OBSERVABLE_VAR_ID numeric,OBSERVABLE_ID numeric,OBSERVED_TIME numeric)
/

    ALTER TABLE ORG_NAME MODIFY (ROOT_NODE numeric,VERSION_NUM numeric)
/

    ALTER TABLE ORG_NODE MODIFY (ORG_NODE_ID numeric,PARENT_ID numeric)
/

    ALTER TABLE PAYOUT_FORM_HIST MODIFY (PRODUCT_ID numeric,PRODUCT_SUB_ID numeric)
/

    ALTER TABLE PAYOUT_FORMULA MODIFY (PRODUCT_ID numeric,PRODUCT_SUB_ID numeric)
/

    ALTER TABLE PC_COMMODITY MODIFY (MARKET_DATA_ID numeric)
/

    ALTER TABLE PC_CORRELATION MODIFY (MATRIX_ID numeric)
/

    ALTER TABLE PC_CREDIT MODIFY (KEY_ID numeric,MARKET_DATA_ID numeric)
/

    ALTER TABLE PC_CREDIT_RATING MODIFY (PC_CREDIT_RATING_ID numeric,MARKET_DATA_ID numeric)
/

    ALTER TABLE PC_CREDIT_RATING_ATTRIBUTE MODIFY (PC_CREDIT_RATING_ID numeric)
/

    ALTER TABLE PC_CREDIT_ISSUER MODIFY (ISSUER_ID numeric,MARKET_DATA_ID numeric)
/

    ALTER TABLE PC_ABS MODIFY (ISSUER_ID numeric,MARKET_DATA_ID numeric)
/

    ALTER TABLE PC_DISCOUNT MODIFY (ZERO_CURVE_ID numeric)
/

    ALTER TABLE PC_FORECAST MODIFY (ZERO_CURVE_ID numeric)
/

    ALTER TABLE PC_MDI_OVERRIDE_KEY MODIFY (MARKET_DATA_ITEM_ID numeric)
/

    ALTER TABLE PC_FX MODIFY (MARKET_DATA_ID numeric)
/

    ALTER TABLE PC_INFO MODIFY (MDATA_ID numeric,IS_UNDERLYING numeric)
/

    ALTER TABLE PC_PROD_SPECIFIC MODIFY (MARKET_DATA_ID numeric)
/

    ALTER TABLE PC_REPO MODIFY (PRIORITY numeric,CURVE_ID numeric)
/

    ALTER TABLE PC_SURFACE MODIFY (VOL_SURFACE_ID numeric)
/

    ALTER TABLE PC_CALIB_DEF_TRADE MODIFY (TRADE_ID numeric)
/

    ALTER TABLE PEND_MODIF_AUDIT MODIFY (ENTITY_ID numeric,PO_ID numeric)
/

    ALTER TABLE PENDING_MODIF MODIFY (ENTITY_ID numeric,PO_ID numeric)
/

    ALTER TABLE PERCENT_ALLOC_RULE MODIFY (RULE_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE PERCENT_ALLOC_RULE_ELEMENT MODIFY (RULE_ELEMENT_ID numeric,RULE_ID numeric,LEGAL_ENTITY_ID numeric,BOOK_ID numeric,STRATEGY_ID numeric)
/

    ALTER TABLE PERF_LEG_HIST MODIFY (PRODUCT_ID numeric,LEG_ID numeric,REF_ASSET_ID numeric,RET_OFFSET numeric,DEF_RET_OFFSET_B numeric,RET_OFF_BUS_DAY_B numeric,RET_CUSTOM_ROLL_B numeric,RET_ROLLING_DAY numeric,RET_RESET_OFFSET numeric,DEF_RET_RESET_OFFSET_B numeric,RET_RESET_OFFSET_B numeric,RET_RESET_ROLL_B numeric,RET_RESET_ROLL_DAY numeric,CPN_OFFSET numeric,CPN_OFF_BUS_DAY_B numeric,CPN_CUSTOM_ROLL_B numeric,CPN_ROLLING_DAY numeric,CASHFLOW_CHANGED numeric,CASHFLOW_LOCKS numeric,IS_FX_RATE_FIXED numeric,FX_RESET_ID numeric,RET_DATE_RULE numeric)
/

    ALTER TABLE PERFORMANCE_LEG MODIFY (PRODUCT_ID numeric,LEG_ID numeric,REF_ASSET_ID numeric,RET_OFFSET numeric,DEF_RET_OFFSET_B numeric,RET_OFF_BUS_DAY_B numeric,RET_CUSTOM_ROLL_B numeric,RET_ROLLING_DAY numeric,RET_RESET_OFFSET numeric,DEF_RET_RESET_OFFSET_B numeric,RET_RESET_OFFSET_B numeric,RET_RESET_ROLL_B numeric,RET_RESET_ROLL_DAY numeric,CPN_OFFSET numeric,CPN_OFF_BUS_DAY_B numeric,CPN_CUSTOM_ROLL_B numeric,CPN_ROLLING_DAY numeric,CASHFLOW_CHANGED numeric,CASHFLOW_LOCKS numeric,IS_FX_RATE_FIXED numeric,FX_RESET_ID numeric,RET_DATE_RULE numeric)
/

    ALTER TABLE NOTIONAL_ADJUSTMENT MODIFY (ADJ_ID numeric,PRODUCT_ID numeric,LEG_ID numeric,PAYMENT_REQD numeric,VERSION_NUM numeric)
/

    ALTER TABLE PERM_BOOK_CUR_PAIR MODIFY (BOOK_ID numeric)
/

    ALTER TABLE PERM_BOOK_CURRENCY MODIFY (BOOK_ID numeric)
/

    ALTER TABLE PERM_BOOK_PRODUCT MODIFY (BOOK_ID numeric)
/

    ALTER TABLE PL_POSITION MODIFY (PRODUCT_ID numeric,BOOK_ID numeric,LAST_LIQ_ID numeric,LAST_ARCHIVE_ID numeric,VERSION_NUM numeric,LIQ_AGG_ID numeric,POSITION_ID numeric,LIQ_CONFIG_ID numeric,IS_DIRTY numeric,LIQ_INFO_ID numeric)
/

    ALTER TABLE PL_POSITION_HIST MODIFY (PRODUCT_ID numeric,BOOK_ID numeric,LAST_LIQ_ID numeric,LAST_ARCHIVE_ID numeric,VERSION_NUM numeric,LIQ_AGG_ID numeric,POSITION_ID numeric,LIQ_CONFIG_ID numeric,IS_DIRTY numeric,LIQ_INFO_ID numeric)
/

    ALTER TABLE PL_POSITION_SNAP MODIFY (PRODUCT_ID numeric,BOOK_ID numeric,LAST_LIQ_ID numeric,LAST_ARCHIVE_ID numeric,VERSION_NUM numeric,LIQ_AGG_ID numeric,POSITION_ID numeric,LIQ_CONFIG_ID numeric,IS_DIRTY numeric,LIQ_INFO_ID numeric)
/

    ALTER TABLE POS_AGG MODIFY (POS_AGG_ID numeric,POS_AGG_CONF_ID numeric,PREF numeric,STRATEGY_ID numeric)
/

    ALTER TABLE POS_AGG_CONF MODIFY (POS_AGG_CONF_ID numeric,STRATEGY_B numeric,LONG_SHORT_B numeric,CUSTODIAN_B numeric,TRADER_B numeric,VERSION_NUM numeric)
/

    ALTER TABLE POS_CASH_FLOWS MODIFY (TRADE_ID numeric)
/

    ALTER TABLE POS_INFO MODIFY (BOOK_ID numeric,PRODUCT_DATE_TYPE numeric,PRODUCT_POS_B numeric,CASH_POS_B numeric,VERSION_NUM numeric)
/

    ALTER TABLE POS_INFO_AGG_MAP MODIFY (BOOK_ID numeric,POS_AGG_CONF_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE PLMETHODOLOGY_INFO MODIFY (BOOK_ID numeric,STRATEGY numeric,CASH_TYPE numeric)
/

    ALTER TABLE PL_METHODOLOGY_CONFIG MODIFY (VERSION numeric)
/

    ALTER TABLE PL_METHODOLOGY_CONFIG_ITEMS MODIFY (BOOK_ID numeric)
/

    ALTER TABLE POS_TRANSFER MODIFY (POS_TRANSFER_ID numeric,INTERNAL numeric)
/

    ALTER TABLE POS_TRANSFER_CRIT MODIFY (POS_TRANSFER_ID numeric,IS_IN_B numeric)
/

    ALTER TABLE POSITION MODIFY (PRODUCT_ID numeric,BOOK_ID numeric,POS_AGG_ID numeric,LAST_TRADE_ID numeric,POSITION_ID numeric)
/

    ALTER TABLE POSITION_SNAP MODIFY (PRODUCT_ID numeric,BOOK_ID numeric,POS_AGG_ID numeric,LAST_TRADE_ID numeric)
/

    ALTER TABLE POSITION_SNAPSHOT MODIFY (PRODUCT_ID numeric,BOOK_ID numeric,POS_AGG_ID numeric,LAST_TRADE_ID numeric,POSITION_ID numeric)
/

    ALTER TABLE POSITION_SNAPSHOT_2 MODIFY (PRODUCT_ID numeric,BOOK_ID numeric,POS_AGG_ID numeric,LAST_TRADE_ID numeric,POSITION_ID numeric)
/

    ALTER TABLE POSITION_SPEC MODIFY (POSITION_SPEC_ID numeric,POS_AGG_CONF_ID numeric,MARKET_INDEX_PRODUCT_ID numeric,USE_CCYPAIR_POS_B numeric,USE_FX_SETTLE_DATE_POS_B numeric,PRODUCT_DATE_TYPE numeric,LIQ_CONFIG_ID numeric,FX_AS_FUNDING_POSITIONS_B numeric)
/

    ALTER TABLE PR_OTCEQTYOPT_HIST MODIFY (PRODUCT_ID numeric,IS_FX_RATE_FIXED numeric,FX_RESET_ID numeric)
/

    ALTER TABLE PR_OTCOPTION_HIST MODIFY (PRODUCT_ID numeric,AUTOMATIC_EXERCISE numeric)
/

    ALTER TABLE PRD_CDSIDX_TRAOPT MODIFY (PRODUCT_ID numeric,UNDERLYING_CDS_ID numeric,EXPIRY_TIME numeric,SETTLE_LAG numeric,SETTLE_LAG_BUS_B numeric,EARLIEST_EX_TIME numeric,LATEST_EX_TIME numeric,STRADDLE_B numeric,AUTO_EXERCISE_B numeric)
/

    ALTER TABLE PRD_COLL_HIST MODIFY (PRODUCT_ID numeric,SECURITY_ID numeric,PASS_THROUGH_B numeric,MONEY_MARKET_ID numeric,SUBSTITUTED_B numeric,FROM_SUBST_B numeric,THIRD_PARTY_CUST_B numeric,IS_MARGIN_CALL numeric,INITIAL_VERSION numeric,FINAL_VERSION numeric,OVERRIDE_VALUE_B numeric,FX_IN_PRICE numeric,COLLATERAL_FLAG numeric)
/

    ALTER TABLE PRD_FAC_REPO_HIST MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRD_FX_FWD_HIST MODIFY (PRODUCT_ID numeric,PRECIOUS_METAL_FORM_ID numeric,IS_CASH_SETTLED numeric)
/

    ALTER TABLE PRD_JGB_REPO_HIST MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRD_RESET_HIST MODIFY (PRODUCT_ID numeric,INT_CLEANUP numeric)
/

    ALTER TABLE PRD_SEC_CODE_HIST MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRD_SECLEND_HIST MODIFY (PRODUCT_ID numeric,SECURITY_ID numeric,OPEN_TERM_B numeric,NOTICE_DAYS numeric,SUBSTITUTION_B numeric,TERMINABLE_FLAG numeric,BILLING_DATE_RULE numeric,FEE_PRICE_TIMING numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,CUSTOM_FLOWS_B numeric,FEE_MARK_RULE numeric,COLL_MARK_RULE numeric,CASH_BILL_RULE numeric,FEE_MARK_LINK_B numeric,CASH_XFER_B numeric,SUBST_LIMIT numeric,SETTLEMENT_BASED_NOM_ADJ numeric)
/

    ALTER TABLE PRD_SMP_MM_HIST MODIFY (PRODUCT_ID numeric,LOAN_B numeric,FIXED_RATE_B numeric,DISCOUNT_B numeric,OPEN_TERM_B numeric,NOTICE_DAYS numeric)
/

    ALTER TABLE PRICER_CONFIG MODIFY (VERSION_NUM numeric,LAZY_REFRESH_B numeric)
/

    ALTER TABLE PSHEET_PRICER_MEASURE_PROP MODIFY (PROPERTY_ORDER numeric,SIGNIFICANT_FIGURES numeric,VERSION numeric,TRANSACTION_ID numeric)
/

    ALTER TABLE PSHEET_STRATEGY_PROP MODIFY (PROPERTY_ORDER numeric)
/

    ALTER TABLE PSHEET_LEG_LINK MODIFY (SELECTED_ID numeric,RELATIVE_SELECTED_ID numeric,REF_ID numeric,RELATIVE_REF_ID numeric,SYSTEM_DEFINED numeric,IS_EDITABLE numeric)
/

    ALTER TABLE PSHEET_CUSTOM_STRATEGIES_XML MODIFY (VERSION numeric)
/

    ALTER TABLE PSHEET_STRATEGY_PROP_EDIT MODIFY (LEG numeric,IS_EDITABLE numeric)
/

    ALTER TABLE PSHEET_STRATEGY_ATTRIBUTE MODIFY (ATTRIBUTE_ORDER numeric)
/

    ALTER TABLE PSHEET_STRATEGY_FEE_DEFINITION MODIFY (ATTRIBUTE_ORDER numeric)
/

    ALTER TABLE PSHEET_PROFILES MODIFY (IS_GROUP numeric)
/

    ALTER TABLE PSHEET_PROFILES_XML MODIFY (VERSION numeric)
/

    ALTER TABLE PRICER_MEASURE_DISPLAY MODIFY (CONFIG_ID numeric,ID numeric)
/

    ALTER TABLE PRICER_MEASURE_DISPLAY_CONFIG MODIFY (CONFIG_ID numeric)
/

    ALTER TABLE PRICING_SHEET_BUNDLE_CONFIG MODIFY (IS_ATTR_VALUE_B numeric)
/

    ALTER TABLE PRICING_SHEET_SETTING MODIFY (VERSION numeric,TRANSACTION_ID numeric)
/

    ALTER TABLE PRICING_ENV MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE PRICING_PARAM MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE PRICING_SHEET_CFG MODIFY (PRIVATE_B numeric,NO_OF_DISPATCH_JOBS numeric,AUTO_RECALC_FRQ numeric,VERSION_NUM numeric)
/

    ALTER TABLE PROD_COMM_CAPFLR MODIFY (PRODUCT_ID numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,IS_DIGITAL_B numeric,CUSTOM_FLOWS_B numeric,FLOWS_FLAG numeric,TERM_MANDATORY numeric,COMMODITY_ID numeric,PAYMENT_OFFSET numeric,PAYMENT_OFFSET_BUS_B numeric,PAYMENT_AT_END_B numeric,ROLLING_DAY numeric,CUSTOM_ROLLING_DAY_B numeric,MANUAL_FIRST_FIXING_B numeric,FX_RESET_ID numeric,DERIVED_QUOTE numeric,PAYMENT_DAY numeric,PAYMENT_DATE_RULE numeric)
/

    ALTER TABLE PROD_COMM_FWD MODIFY (PRODUCT_ID numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,CUSTOM_FLOWS_B numeric,FLOWS_FLAG numeric,COMMODITY_ID numeric,PAYMENT_OFFSET numeric,CERT_OFFSET numeric,PAYMENT_OFFSET_BUS_B numeric,CERT_OFFSET_BUS_B numeric,PAYMENT_AT_END_B numeric,PAYMENT_DAY numeric,CERT_DAY numeric,FX_RESET_ID numeric,COMM_LEG_ID numeric,COMM_RESET_ID numeric)
/

    ALTER TABLE PRODUCT_COMM_CERT MODIFY (PRODUCT_ID numeric,STATUS numeric,BUY_COMM_FWD_ID numeric,SELL_COMM_FWD_ID numeric,ACCOUNT_ID numeric,COMMODITY_ID numeric,COMMODITY_RESET_ID numeric,PARENT_ID numeric,FUTURE_DEL_SET_ID numeric,BOOK_ID numeric)
/

    ALTER TABLE PROP_TEMPLATE MODIFY (TEMPLATE_ID numeric)
/

    ALTER TABLE PROP_ATTR MODIFY (ATTRIBUTE_ID numeric,DEFAULT_VALUE_ID numeric)
/

    ALTER TABLE PROP_TEMPLATE_ATTR MODIFY (TEMPLATE_ID numeric,ATTRIBUTE_ID numeric,ORDER_ID numeric)
/

    ALTER TABLE PROP_SET MODIFY (ID numeric,TEMPLATE_ID numeric,PARENT_ID numeric)
/

    ALTER TABLE PROP_VAL MODIFY (ID numeric,PROP_SET_ID numeric,PROP_ATTR_ID numeric,ORDER_ID numeric)
/

    ALTER TABLE PROP_VAL_STRING MODIFY (ID numeric)
/

    ALTER TABLE PROP_VAL_DATE MODIFY (ID numeric)
/

    ALTER TABLE PROP_VAL_DOUBLE MODIFY (ID numeric)
/

    ALTER TABLE PROD_EXCH_CODE MODIFY (PRODUCT_ID numeric,LE_ID numeric)
/

    ALTER TABLE PRODUCT_ADR MODIFY (PRODUCT_ID numeric,PAY_DIVIDEND numeric,UNDERLYING_ID numeric,IS_SPONSORED numeric,ISSUER_ID numeric,DIVIDEND_DECIMALS numeric)
/

    ALTER TABLE PRODUCT_ASSET_SWAP MODIFY (PRODUCT_ID numeric,UNDERLYING_ID numeric,PAY_ASSET_B numeric,USE_ASSET_SCH_B numeric,USE_ASSET_AMORT_B numeric,CUSTOM_FLOWS_B numeric,FLOWS_FLAG numeric,ADJ_NOTL_OPT_EXER_B numeric,USE_SWAP_START_DATE numeric)
/

    ALTER TABLE PRODUCT_BASKET MODIFY (PRODUCT_ID numeric,MULTIPLY_TRADED_B numeric,PARENT_ID numeric,CA_ID numeric)
/

    ALTER TABLE PRODUCT_BILLING MODIFY (PRODUCT_ID numeric,ACCOUNT_ID numeric,FEE_BILLING_RULE_ID numeric)
/

    ALTER TABLE PRODUCT_BOND MODIFY (PRODUCT_ID numeric,MATURITY_TENOR numeric,ISSUER_LE_ID numeric,ODD_FIRST_COUPON numeric,ODD_LAST_COUPON numeric,SETTLEMENT_DAYS numeric,VALUE_DAYS numeric,EXDIVIDEND_DAYS numeric,RECORD_DAYS numeric,ROLLING_DAY numeric,RESET_IN_ARREARS_B numeric,BENCHMARK_ID numeric,CUSTOM_COUPONS_B numeric,AMORTIZING_B numeric,FLOATER_B numeric,FIXED_B numeric,ROUNDING_UNIT numeric,IPA_LE_ID numeric,ACCRUAL_ROUNDING numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,CA_LE_ID numeric,TRUSTEE_LE_ID numeric,RESET_DAYS numeric,RESET_BUS_LAG_B numeric,PRE_PAID_B numeric,NOTL_GUARANTEED numeric,ASSIM_PRD_ID numeric,TARGET_ID numeric,EXDIVIDEND_BUS_B numeric,COUPON_OFFSET numeric,CPN_OFF_BUS_DAY_B numeric,DISC_METHOD numeric,PRICE_DECIMALS numeric,YIELD_DECIMALS numeric,FX_RESET numeric,AMORTIZING_FV_B numeric,INFLAT_DECIMALS numeric,STUB_USE_ACCRUAL numeric,FUTURE_CONTRACT_ID numeric,RESET_DECIMALS numeric,BASKET_ID numeric,NOMINAL_DECIMALS numeric,NOTIFICATION_OFFSET numeric,NOT_OFF_BUS_DAY_B numeric,APPLY_WITHHOLD_TAX_B numeric,CONFIG_TYPE_ID numeric,CONFIG_TYPE_VER numeric,RATE_INDEX_ID numeric,NOTIONAL_INDEX_ID numeric,CAPITAL_FACTOR_DECIMALS numeric,COUPON_DATE_RULE numeric,REDEM_FX_RESET numeric,PIKABLE_B numeric,SAMPLE_WEEKDAY numeric,RESET_CUTOFF numeric,RESETCUTOFFBUSDAYB numeric,NOTIONAL_LAG numeric,ROUND_GROSS_PRICE_BEF_ADJ_B numeric,LOCKOUT_B numeric,LOCKOUT_DAYS numeric,APPLY_RESET_BEG_AT_FIRST_CPN_B numeric,REDEEM_DAYS numeric,DISCOUNT_MARGIN_DEC numeric,INFLATION_PROTECTED_B numeric,ROLL_MATURITY_PAYMENT_B numeric,DIFFERENT_RESETS_PER_COUPON_B numeric,AVERAGE_DAYS numeric,CMP_CUTOFF_LAG numeric,CMP_CUTOFF_LAG_B numeric,SAMPLE_PERIOD_SHIFT_B numeric)
/

    ALTER TABLE BOND_REOPENINGS MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_BOND_OPT MODIFY (PRODUCT_ID numeric,UNDERLYING_ID numeric,AUTO_EXERCISE numeric,EXPIRY_TIME numeric)
/

    ALTER TABLE PRODUCT_BONDSPREAD MODIFY (PRODUCT_ID numeric,YEAR_TENOR numeric,MONTH_TENOR numeric,UNDERLYING_BOND_ID numeric,INTERP_BOND_ID numeric,IS_COMPOUND_B numeric)
/

    ALTER TABLE PRODUCT_BROKERAGE MODIFY (PRODUCT_ID numeric,LINKED_ID numeric,RECALC_COM numeric,FX_RESET numeric,FEE_BILL_ID numeric)
/

    ALTER TABLE PRODUCT_BSB MODIFY (PRODUCT_ID numeric,SECURITY_ID numeric,IS_REPO_B numeric,DISCOUNT_B numeric)
/

    ALTER TABLE PRODUCT_CA MODIFY (PRODUCT_ID numeric,UNDERLYING_ID numeric,TO_PRODUCT_ID numeric,FROM_RATIO numeric,TO_RATIO numeric,IS_OPTIONAL numeric,BY_TRADE numeric,IS_DEACTIVATED numeric,IS_EXDATE_INCLUSIVE numeric,IS_RECDATE_INCLUSIVE numeric,LIQ_CONFIG_ID numeric,IS_GEN_ZERO_POS_TRADE numeric)
/

    ALTER TABLE PRODUCT_CA_ASSOCIATION MODIFY (FIRST_CA_ID numeric,SECOND_CA_ID numeric)
/

    ALTER TABLE PRODUCT_CA_AGENT_INFO MODIFY (CA_ID numeric,AGENT_ID numeric,CUSTODIAN_LE_ID numeric)
/

    ALTER TABLE PRODUCT_CA_ATTRIBUTES MODIFY (CA_ID numeric)
/

    ALTER TABLE PRODUCT_CA_TO_PRODUCT MODIFY (CA_ID numeric,PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_CA_ELECTION MODIFY (ELECTION_ID numeric,BOOK_ID numeric,PARTY_ID numeric,RELATED_ID numeric,IS_MANUAL_OVERRIDE numeric,INSTRUCTION_ID numeric,INSTRUCTION_VERSION numeric)
/

    ALTER TABLE PRODUCT_CA_ELECTED MODIFY (ELECTION_ID numeric,CA_ID numeric,DEADLINE_RULE_ID numeric,DEADLINE_RULE_VERSION numeric,DEADLINE_DATE_MANUAL_OVERRIDE numeric)
/

    ALTER TABLE PRODUCT_CA_INSTRUCTION MODIFY (INSTRUCTION_ID numeric,VERSION_NUMBER numeric,PARTY_ID numeric,BOOK_ID numeric,CA_ID numeric,PRIORITY numeric)
/

    ALTER TABLE PRODUCT_CA_DEADLINE_RULE MODIFY (DEADLINE_RULE_ID numeric,VERSION_NUMBER numeric,PARTY_ID numeric,TENOR numeric,HOURS numeric,PRIORITY numeric)
/

    ALTER TABLE PRODUCT_CALL_INFO MODIFY (PRODUCT_ID numeric,EXERCISE_SIDE numeric,EXPIRY_TIME numeric,EARLIEST_EXERCISE_TIME numeric,LATEST_EXERCISE_TIME numeric,SETTLEMENT_LAG numeric,SETTLEMENT_LAG_BUS_DAY_B numeric,FEE_AS_PERCENT numeric,EXPIRY_DELIVERY_ROLLDAY numeric)
/

    ALTER TABLE PRODUCT_CALL_ACCOUNT MODIFY (PRODUCT_ID numeric,ACCOUNT_ID numeric)
/

    ALTER TABLE PRD_CALL_ACC_HIST MODIFY (PRODUCT_ID numeric,ACCOUNT_ID numeric)
/

    ALTER TABLE PRODUCT_CALL_NOT MODIFY (PRODUCT_ID numeric,FIXED_RATE_B numeric,OPEN_TERM_B numeric,NOTICE_DAYS numeric,ROLL_OVER_B numeric,DISC_CASH_FLOW_B numeric,ROLLING_DAY numeric,LINKED_ID numeric,CAPITALIZE_INT numeric,CUSTOM_FLOWS_B numeric,AMORTIZING_B numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,PRIN_EXCH numeric,SETTLEMENT_TYPE numeric,COMPOUNDING_TYPE numeric,PAYMENT_DATE_RULE numeric,COMPOUND_DATE_RULE numeric,FST_STB_CUST_IDX_B numeric,FST_STB_IDX_X numeric,FST_STB_IDX_Y numeric,LST_STB_CUST_IDX_B numeric,LST_STB_IDX_X numeric,LST_STB_IDX_Y numeric,LOAN_B numeric,NOTICE_BUS_DAYS_B numeric,DEF_RESET_OFFSET_B numeric,RESET_OFFSET numeric,RESET_OFF_BUSDAY_B numeric,PMT_OFFSET numeric,COUPON_DATE_RULE numeric)
/

    ALTER TABLE PRODUCT_CALL_NOT_HIST MODIFY (PRODUCT_ID numeric,FIXED_RATE_B numeric,OPEN_TERM_B numeric,NOTICE_DAYS numeric,ROLL_OVER_B numeric,DISC_CASH_FLOW_B numeric,ROLLING_DAY numeric,LINKED_ID numeric,CAPITALIZE_INT numeric,CUSTOM_FLOWS_B numeric,AMORTIZING_B numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,PRIN_EXCH numeric,SETTLEMENT_TYPE numeric,COMPOUNDING_TYPE numeric,PAYMENT_DATE_RULE numeric,COMPOUND_DATE_RULE numeric,FST_STB_CUST_IDX_B numeric,FST_STB_IDX_X numeric,FST_STB_IDX_Y numeric,LST_STB_CUST_IDX_B numeric,LST_STB_IDX_X numeric,LST_STB_IDX_Y numeric,LOAN_B numeric,NOTICE_BUS_DAYS_B numeric,DEF_RESET_OFFSET_B numeric,RESET_OFFSET numeric,RESET_OFF_BUSDAY_B numeric,PMT_OFFSET numeric,COUPON_DATE_RULE numeric)
/

    ALTER TABLE PRODUCT_CREDIT_TRANCHE MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_CREDIT_TRANCHE_HIST MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_CANCDS MODIFY (PRODUCT_ID numeric,UNDERLYING_CDS_ID numeric,EXPIRY_TIME numeric,SETTLE_LAG numeric,SETTLE_LAG_BUS_B numeric,EARLIEST_EX_TIME numeric,LATEST_EX_TIME numeric)
/

    ALTER TABLE PRODUCT_CANCDSDEF MODIFY (PRODUCT_ID numeric,UNDERLYING_CDS_ID numeric,EXPIRY_TIME numeric,SETTLE_LAG numeric,SETTLE_LAG_BUS_B numeric,EARLIEST_EX_TIME numeric,LATEST_EX_TIME numeric)
/

    ALTER TABLE PRODUCT_CANCDSLOSS MODIFY (PRODUCT_ID numeric,UNDERLYING_CDS_ID numeric,EXPIRY_TIME numeric,SETTLE_LAG numeric,SETTLE_LAG_BUS_B numeric,EARLIEST_EX_TIME numeric,LATEST_EX_TIME numeric)
/

    ALTER TABLE PRODUCT_CAP_FLOOR MODIFY (PRODUCT_ID numeric,COUPON_OFFSET numeric,CPN_OFF_BUS_DAY_B numeric,ROLLING_DAY numeric,CPN_PAY_AT_END_B numeric,CUSTOM_ROL_DAY_B numeric,DEF_RESET_OFF_B numeric,RESET_OFFSET numeric,RESET_OFF_BUSDAY_B numeric,RESET_AVERAGING_B numeric,SAMPLE_START_OFF numeric,SAMPLE_WEEKDAY numeric,CUSTOM_FLOWS_B numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,RESET_CUTOFF numeric,IS_DIGITAL_B numeric,DISCOUNT_METHOD numeric,FLOWS_FLAG numeric,INCLUDE_FIRST numeric,MAN_FIRST_RESET_B numeric,TERM_MANDATORY numeric,RESET_DATE_RULE numeric,FST_STB_CUST_IDX_B numeric,FST_STB_IDX_X numeric,FST_STB_IDX_Y numeric,LST_STB_CUST_IDX_B numeric,LST_STB_IDX_X numeric,LST_STB_IDX_Y numeric,PMT_DATE_RULE numeric,PRIOR_RESET_B numeric,ACCRUAL_DATE_RULE numeric,ATM_PAYOFF_B numeric,INCL_FIRST_DAY_B numeric,INCL_LAST_DAY_B numeric,RESETCUTOFFBUSDAYB numeric,NB_ACTIVATIONS numeric)
/

    ALTER TABLE PRODUCT_BO_CASH_SETTLE MODIFY (PRODUCT_ID numeric,ACCOUNT_ID numeric,STATEMENT_ID numeric,IS_BOOKING_DATE numeric)
/

    ALTER TABLE PRODUCT_CASH MODIFY (PRODUCT_ID numeric,FIXED_RATE_B numeric,OPEN_TERM_B numeric,OPEN_TERM_BUS_DAY_B numeric,NOTICE_DAYS numeric,ROLL_OVER_B numeric,DISC_CASH_FLOW_B numeric,ROLLING_DAY numeric,LINKED_ID numeric,CAPITALIZE_INT numeric,CUSTOM_FLOWS_B numeric,AMORTIZING_B numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,PRIN_EXCH numeric,PMT_OFFSET numeric,PMT_OFF_BUS_DAY_B numeric,FLOATER_B numeric,DEF_RESET_OFFSET_B numeric,RESET_OFFSET numeric,RESET_OFF_BUSDAY_B numeric,RESET_AVERAGING_B numeric,SAMPLE_START_OFF numeric,SAMPLE_WEEKDAY numeric,FLOWS_FLAG numeric,FST_STB_CUST_IDX_B numeric,FST_STB_IDX_X numeric,FST_STB_IDX_Y numeric,LST_STB_CUST_IDX_B numeric,LST_STB_IDX_X numeric,LST_STB_IDX_Y numeric,MAN_FIRST_RESET_B numeric,INCLUDE_FIRST_B numeric,INCLUDE_LAST_B numeric,TERM_MANDATORY numeric,RESET_DATE_RULE numeric,PMT_DATE_RULE numeric,ACCRUAL_DATE_RULE numeric)
/

    ALTER TABLE PRODUCT_CASH_HIST MODIFY (PRODUCT_ID numeric,FIXED_RATE_B numeric,OPEN_TERM_B numeric,OPEN_TERM_BUS_DAY_B numeric,NOTICE_DAYS numeric,ROLL_OVER_B numeric,DISC_CASH_FLOW_B numeric,ROLLING_DAY numeric,LINKED_ID numeric,CAPITALIZE_INT numeric,CUSTOM_FLOWS_B numeric,AMORTIZING_B numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,PRIN_EXCH numeric,PMT_OFFSET numeric,PMT_OFF_BUS_DAY_B numeric,FLOATER_B numeric,DEF_RESET_OFFSET_B numeric,RESET_OFFSET numeric,RESET_OFF_BUSDAY_B numeric,RESET_AVERAGING_B numeric,SAMPLE_START_OFF numeric,SAMPLE_WEEKDAY numeric,FLOWS_FLAG numeric,FST_STB_CUST_IDX_B numeric,FST_STB_IDX_X numeric,FST_STB_IDX_Y numeric,LST_STB_CUST_IDX_B numeric,LST_STB_IDX_X numeric,LST_STB_IDX_Y numeric,MAN_FIRST_RESET_B numeric,INCLUDE_FIRST_B numeric,INCLUDE_LAST_B numeric,TERM_MANDATORY numeric,RESET_DATE_RULE numeric,PMT_DATE_RULE numeric,ACCRUAL_DATE_RULE numeric)
/

    ALTER TABLE PRODUCT_CREDIT_DRAWDOWN MODIFY (PRODUCT_ID numeric,FACILITY_ID numeric)
/

    ALTER TABLE PRODUCT_CREDIT_DRAWDOWN_HIST MODIFY (PRODUCT_ID numeric,FACILITY_ID numeric)
/

    ALTER TABLE PRODUCT_CREDIT_FACILITY MODIFY (PRODUCT_ID numeric,SECURED_B numeric,AGENT_ID numeric,STMT_DATE_RULE_ID numeric,IS_LOAN_B numeric)
/

    ALTER TABLE FACILITY_SYNDICATE MODIFY (PRODUCT_ID numeric,LE_ID numeric)
/

    ALTER TABLE DEFAULT_RATE_CONFIG MODIFY (PRODUCT_ID numeric,DEFAULT_B numeric,FIXED_B numeric)
/

    ALTER TABLE PRODUCT_CDS MODIFY (PRODUCT_ID numeric,REF_ENTITY_ID numeric,PMT_OFFSET numeric,PMT_OFST_BUS_DAY_B numeric,TERMINATED_B numeric,SINGLE_PREMIUM_B numeric,CUSTOM_FLOWS_B numeric,CALC_AGENT_ID numeric,CONV_BOND_B numeric,SUCCESSOR_B numeric,RESTRUCT_SUPPL_B numeric,DISPUTE_RES_B numeric,DOC_PRODUCING_LE numeric,PORT_INCL_ACCR_B numeric,PART_LOAN_B numeric,PART_ASSIGN_LOAN_B numeric,PART_PARTICIPAT_B numeric,ESCROW_B numeric,MULTIPLE_VAL_DAY_B numeric,FIRST_VAL_DAY numeric,SUBSEQUENT_VAL_DAY numeric,NUM_VAL_DAY numeric,VAL_TIME numeric,QUOTE_INCL_ACCR_B numeric,CAP_SETTLE_B numeric,CAP_SETTLE numeric,CAP_SETTLE_BUS_B numeric,FLOWS_FLAG numeric,ALL_GUARANTEES_B numeric,MONOLINE_SUPPL_B numeric,NOTICE_INFO_AVAILABLE numeric,SPECIFIED_NUMBER numeric,NOTICE_PHYSICAL_SETTLEMENT numeric,DELIVERED_OBLIG_ID numeric,EXTRA_DAY_ACCRUALB numeric,EX_FIRST_B numeric,DIG_CAP_B numeric,INCLUDE_SPREAD_B numeric,MATRIX_ID numeric,SETTLE_OFFSET numeric)
/

    ALTER TABLE PRODUCT_CDS_EX_DELIV_OBLIG MODIFY (PRODUCT_ID numeric,REF_OBLIG_ID numeric)
/

    ALTER TABLE PRODUCT_CDS_EX_DELIV_OBLIGDESC MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_CDS_EX_OBLIG MODIFY (PRODUCT_ID numeric,REF_OBLIG_ID numeric)
/

    ALTER TABLE PRODUCT_CDS_EX_OBLIGDESC MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_CDS_OPTION MODIFY (PRODUCT_ID numeric,UNDERLYING_CDS_ID numeric,EXPIRY_TIME numeric,SETTLE_LAG numeric,SETTLE_LAG_BUS_B numeric,EARLIEST_EX_TIME numeric,LATEST_EX_TIME numeric,STRADDLE_B numeric,AUTO_EXERCISE_B numeric)
/

    ALTER TABLE PRODUCT_CDSABS MODIFY (PRODUCT_ID numeric,TERMINATED_B numeric,CUSTOM_FLOWS_B numeric,FLOWS_FLAG numeric,OPT_EARLY_TERMINATION numeric)
/

    ALTER TABLE PRODUCT_CDSABSIDX MODIFY (PRODUCT_ID numeric,ABSINDEX_DEF_ID numeric,TERMINATED_B numeric)
/

    ALTER TABLE PRODUCT_CDSABSIDXTRANCHE MODIFY (PRODUCT_ID numeric,ABSINDEX_DEF_ID numeric,TERMINATED_B numeric)
/

    ALTER TABLE CDSABSINDEXTRANCHE_DEF MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_CDSIDX MODIFY (PRODUCT_ID numeric,INDEX_DEF_ID numeric,TERMINATED_B numeric,FUNDED_B numeric,CALC_AGENT_ID numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,CUSTOM_FLOWS_B numeric,FLOWS_FLAG numeric)
/

    ALTER TABLE PRODUCT_CDSIDXOPT MODIFY (PRODUCT_ID numeric,UNDERLYING_CDS_ID numeric,EXPIRY_TIME numeric,SETTLE_LAG numeric,SETTLE_LAG_BUS_B numeric,EARLIEST_EX_TIME numeric,LATEST_EX_TIME numeric,STRADDLE_B numeric,AUTO_EXERCISE_B numeric)
/

    ALTER TABLE PRODUCT_CDSNTHDFLT MODIFY (PRODUCT_ID numeric,START_DEFAULT numeric,END_DEFAULT numeric,GUARANTEED_B numeric)
/

    ALTER TABLE PRODUCT_CDSNTHLOSS MODIFY (PRODUCT_ID numeric,GUARANTEED_B numeric,CROSS_SUBORDINATED_B numeric)
/

    ALTER TABLE PRODUCT_CDSTRANCHE MODIFY (PRODUCT_ID numeric,INDEX_DEF_ID numeric,TERMINATED_B numeric,FUNDED_B numeric,CALC_AGENT_ID numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,CUSTOM_FLOWS_B numeric,FLOWS_FLAG numeric)
/

    ALTER TABLE PRODUCT_CFD MODIFY (PRODUCT_ID numeric,CONTRACT_ID numeric,LE_ID numeric,SECURITY_ID numeric,LINK_ID numeric)
/

    ALTER TABLE PRODUCT_CIS MODIFY (PRODUCT_ID numeric,PAY_LEG_ID numeric,TERM_MANDATORY numeric,CUSTOM_FLOWS_B numeric,FLOWS_FLAG numeric,TOTAL_RETURN_B numeric)
/

    ALTER TABLE PRODUCT_CMPD_OPT MODIFY (PRODUCT_ID numeric,UNDERLYING_ID numeric,EXPIRY_TIME numeric)
/

    ALTER TABLE PRODUCT_COLLATERAL MODIFY (PRODUCT_ID numeric,SECURITY_ID numeric,PASS_THROUGH_B numeric,MONEY_MARKET_ID numeric,SUBSTITUTED_B numeric,FROM_SUBST_B numeric,THIRD_PARTY_CUST_B numeric,IS_MARGIN_CALL numeric,INITIAL_VERSION numeric,FINAL_VERSION numeric,OVERRIDE_VALUE_B numeric,FX_IN_PRICE numeric,COLLATERAL_FLAG numeric)
/

    ALTER TABLE PRODUCT_COMMOD_MM MODIFY (PRODUCT_ID numeric,LOAN_B numeric,CUSTOM_FLOWS_B numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,FIXED_RATE_B numeric,DISCOUNT_B numeric,OPEN_TERM_B numeric,NOTICE_DAYS numeric)
/

    ALTER TABLE PRODUCT_COMMODITY MODIFY (PRODUCT_ID numeric,TYPE numeric,CASH_SETTLE_DAYS numeric,PHYS_SETTLE_DAYS numeric,QUANTITY_DECIMALS numeric)
/

    ALTER TABLE PRODUCT_COMMODITY_SWAP MODIFY (PRODUCT_ID numeric,PAY_LEG_ID numeric,RECEIVE_LEG_ID numeric,CUSTOM_FLOWS_B numeric,OPT_CAL_OFFSET numeric,OPT_CAL_BUS_B numeric,TERM_MANDATORY numeric,FLOWS_FLAG numeric,EXPIRY_TIME numeric,OPT_SCHEDULE_LOCK numeric,CALC_OFFSET_DAYS_B numeric,FX_RESET_ID numeric)
/

    ALTER TABLE PRODUCT_COMMODITY_SPOT MODIFY (PRODUCT_ID numeric,COMMODITY_RESET_ID numeric)
/

    ALTER TABLE PRODUCT_CONTRIBWITHDRAW MODIFY (PRODUCT_ID numeric,INV_PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_CRD_CONT_INFO MODIFY (PRODUCT_ID numeric,REF_ENTITY_ID numeric,NO_OF_DEFAULT numeric,PAYRECEIVE_B numeric)
/

    ALTER TABLE PRODUCT_CREDIT_RATING MODIFY (PRODUCT_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE PRODUCT_CUSTXFER MODIFY (PRODUCT_ID numeric,LINKED_ID numeric,FX_RESET numeric,MANUAL_SDI numeric,CPTY_SDI numeric,PO_SDI numeric,CUSTOMER_SDI numeric,COMMISSION_SDI numeric,REM_FEE_EX numeric,CORR_FEE_EX numeric,LIFT_FEE_EX numeric,CABLE_FEE_EX numeric,BENE_LE numeric,CHARGE_BENE_B numeric)
/

    ALTER TABLE PRODUCT_DESC MODIFY (PRODUCT_ID numeric,NEEDS_RESET_B numeric,VERSION_NUM numeric,UND_SECURITY_ID numeric,ISSUER_ID numeric)
/

    ALTER TABLE PRODUCT_DESC_HIST MODIFY (PRODUCT_ID numeric,NEEDS_RESET_B numeric,VERSION_NUM numeric,UND_SECURITY_ID numeric,ISSUER_ID numeric)
/

    ALTER TABLE PRODUCT_ATTRIBUTES MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_ATTRIBUTES_HIST MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_ECL MODIFY (PRODUCT_ID numeric,BOOK_ID numeric,UNDERLYING_ID numeric,LIQ_CONFIG_ID numeric,POS_AGG_ID numeric,TARGET_ID numeric)
/

    ALTER TABLE PRODUCT_ELS MODIFY (PRODUCT_ID numeric,MANU_NOT_B numeric,CUSTOM_FLOWS_B numeric,TERM_MANDATORY numeric,HAS_TWO_PERF_LEG_B numeric,AUTO_ADJ_SWP_NOTIONAL numeric,DATE_CALC_METHOD numeric,FLOWS_FLAG numeric,FORWARD_START numeric,FORWARD_START_ELS_TYPE numeric)
/

    ALTER TABLE PRODUCT_ELS_HIST MODIFY (PRODUCT_ID numeric,MANU_NOT_B numeric,CUSTOM_FLOWS_B numeric,TERM_MANDATORY numeric,HAS_TWO_PERF_LEG_B numeric,AUTO_ADJ_SWP_NOTIONAL numeric,DATE_CALC_METHOD numeric,FLOWS_FLAG numeric,FORWARD_START numeric,FORWARD_START_ELS_TYPE numeric)
/

    ALTER TABLE PRODUCT_EQUITY MODIFY (PRODUCT_ID numeric,PAY_DIVIDEND numeric,DIVIDEND_DATE_RULE numeric,DIVIDEND_DECIMALS numeric,NOMINAL_DECIMALS numeric,EXCHANGE_ID numeric,TRADING_COUNTRY_ID numeric)
/

    ALTER TABLE PRODUCT_EQUITY_IDX MODIFY (PRODUCT_ID numeric,MARKET_PLACE_ID numeric,ISSUER_ID numeric,ISSUE_PAY_AGENT_ID numeric,PUBLISH_DAYOFWEEK numeric,PUBLISH_DATE_RULE numeric,PUBLISH_TIME numeric,BASKET_ID numeric)
/

    ALTER TABLE PRODUCT_VOLATILITY_INDEX MODIFY (PRODUCT_ID numeric,UNDERLYING_ID numeric)
/

    ALTER TABLE PRODUCT_DIVIDEND_INDEX MODIFY (PRODUCT_ID numeric,UNDERLYING_ID numeric)
/

    ALTER TABLE PRODUCT_ETO MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE ETO_IR_EXT_INFO MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_EXTCDS MODIFY (PRODUCT_ID numeric,UNDERLYING_CDS_ID numeric,EXPIRY_TIME numeric,SETTLE_LAG numeric,SETTLE_LAG_BUS_B numeric,EARLIEST_EX_TIME numeric,LATEST_EX_TIME numeric)
/

    ALTER TABLE PRODUCT_EXTCDSDEF MODIFY (PRODUCT_ID numeric,UNDERLYING_CDS_ID numeric,EXPIRY_TIME numeric,SETTLE_LAG numeric,SETTLE_LAG_BUS_B numeric,EARLIEST_EX_TIME numeric,LATEST_EX_TIME numeric)
/

    ALTER TABLE PRODUCT_EXTCDSLOSS MODIFY (PRODUCT_ID numeric,UNDERLYING_CDS_ID numeric,EXPIRY_TIME numeric,SETTLE_LAG numeric,SETTLE_LAG_BUS_B numeric,EARLIEST_EX_TIME numeric,LATEST_EX_TIME numeric)
/

    ALTER TABLE PRODUCT_FAC_REPO MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_FACILITY MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_FRA MODIFY (PRODUCT_ID numeric,SETTLE_IN_ARREAR_B numeric,INTERPOLATED_B numeric,INTERP_FROM_TENOR numeric,INTERP_TO_TENOR numeric,DEF_RESET_OFF_B numeric,RESET_OFFSET numeric)
/

    ALTER TABLE PRODUCT_LISTED_FRA MODIFY (PRODUCT_ID numeric,CONTRACT_ID numeric,QUANTITY numeric)
/

    ALTER TABLE PRODUCT_FUT_OPT MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_FUTURE MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_LISTED MODIFY (PRODUCT_ID numeric,CONTRACT_ID numeric,UNDER_PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_FUTURE_FWD_START MODIFY (PRODUCT_ID numeric,UNDERLYING_PRODUCT_ID numeric,RESET_DAYS numeric)
/

    ALTER TABLE PRODUCT_FUTURE_FWD_START_H MODIFY (PRODUCT_ID numeric,UNDERLYING_PRODUCT_ID numeric,RESET_DAYS numeric)
/

    ALTER TABLE PRODUCT_FX MODIFY (PRODUCT_ID numeric,PRECIOUS_METAL_FORM_ID numeric)
/

    ALTER TABLE PRECIOUS_METAL_FORM MODIFY (PRECIOUS_METAL_FORM_ID numeric)
/

    ALTER TABLE PRODUCT_FX_NDF_POS MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_POS_FX_FUNDING MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_POS_FX_SELLOFF MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_POS_FX_EXPOSURE MODIFY (PRODUCT_ID numeric,REL_PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_FX_CASH MODIFY (PRODUCT_ID numeric,FLOW_COUNT numeric)
/

    ALTER TABLE PRODUCT_FX_FORWARD MODIFY (PRODUCT_ID numeric,PRECIOUS_METAL_FORM_ID numeric,IS_CASH_SETTLED numeric)
/

    ALTER TABLE PRODUCT_FX_NDF MODIFY (PRODUCT_ID numeric,FX_RESET numeric)
/

    ALTER TABLE PRODUCT_FX_OPT_FWD MODIFY (PRODUCT_ID numeric,OPTION_SETTLEMENT_TYPE numeric)
/

    ALTER TABLE PRODUCT_FX_OPT_FWD_HIST MODIFY (PRODUCT_ID numeric,OPTION_SETTLEMENT_TYPE numeric)
/

    ALTER TABLE PRODUCT_FX_OPTION MODIFY (PRODUCT_ID numeric,AUTO_EXERCISE numeric,EXPIRY_TIME numeric,FXRESET numeric,OPT_CAL_OFFSET numeric,OPT_CAL_BUS_B numeric,CALC_OFFSET_DAYS_B numeric,COMPO_FX_SOURCE numeric)
/

    ALTER TABLE PRODUCT_FX_ORDER MODIFY (PRODUCT_ID numeric,IS_FORWARD numeric,FORWARD_TENOR numeric,IS_SPOT_RES numeric)
/

    ALTER TABLE PRODUCT_FX_SPOTRES MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_FX_SWAP MODIFY (PRODUCT_ID numeric,NEAR_PRECIOUS_METAL_FORM_ID numeric,FAR_PRECIOUS_METAL_FORM_ID numeric)
/

    ALTER TABLE PRODUCT_FX_TAKEUP MODIFY (PRODUCT_ID numeric,PARENT_ID numeric)
/

    ALTER TABLE PRODUCT_FX_TAKEUP_HIST MODIFY (PRODUCT_ID numeric,PARENT_ID numeric)
/

    ALTER TABLE PRODUCT_FX_TTM MODIFY (PRODUCT_ID numeric,FXRESET numeric,SPOT_RESERVE numeric)
/

    ALTER TABLE PRODUCT_FXOPTSTRIP MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_HOLDING MODIFY (PRODUCT_ID numeric,TRADED_PRODUCT_ID numeric,PRIME_BROKER_ID numeric,BOOK_ID numeric)
/

    ALTER TABLE PRODUCT_INT_BEARING MODIFY (PRODUCT_ID numeric,ACCOUNT_ID numeric,DEST_ACCOUNT_ID numeric)
/

    ALTER TABLE PRODUCT_INTRA_MM MODIFY (PRODUCT_ID numeric,LOAN_B numeric,FIXED_RATE_B numeric,DISCOUNT_B numeric,OPEN_TERM_B numeric,NOTICE_DAYS numeric,USE_HALF_DAY numeric)
/

    ALTER TABLE PRODUCT_ISSUANCE MODIFY (PRODUCT_ID numeric,SECURITY_ID numeric)
/

    ALTER TABLE PRODUCT_JGB_REPO MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_LETTER MODIFY (PRODUCT_ID numeric,ISSUING_BANK_ID numeric,BENEFICIARY_ID numeric)
/

    ALTER TABLE PRODUCT_LIST_OPT MODIFY (PRODUCT_ID numeric,CONTRACT_ID numeric,UND_PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_LOAN MODIFY (PRODUCT_ID numeric,ISSUER_ID numeric,SETTLE_DAYS numeric,FIXED_B numeric,ROLLING_DAY numeric,COUPON_OFFSET numeric,COUPON_OFFSET_BUS_B numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric)
/

    ALTER TABLE PRODUCT_MARKET_INDEX MODIFY (PRODUCT_ID numeric,MARKET_PLACE_ID numeric,ISSUER_ID numeric,ISSUE_PAY_AGENT_ID numeric,PUBLISH_DAYOFWEEK numeric,PUBLISH_DATE_RULE numeric,PUBLISH_TIME numeric,BASKET_ID numeric,BOOK_ID numeric,PROVIDER_ID numeric,MATURITY_PAYMENT_LAG numeric)
/

    ALTER TABLE PRODUCT_MMKT MODIFY (PRODUCT_ID numeric,IS_DISCOUNT numeric,ISSUER_LE_ID numeric,TENOR numeric,SETTLE_DAYS numeric,RESET_IN_ARREARS_B numeric,ROLLING_DAY numeric,CUSTOM_FLOWS_B numeric,FIXED_B numeric,IPA_LE_ID numeric)
/

    ALTER TABLE PRODUCT_ORDER_STGY MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_OTCCOM_OPT MODIFY (PRODUCT_ID numeric,IS_FX_RATE_FIXED numeric,FX_RESET_ID numeric,SETTLEMENT_OFFSET numeric,BUS_DAY_B numeric,FWD_SETTING_B numeric)
/

    ALTER TABLE PRODUCT_OTCEQ_OPT MODIFY (PRODUCT_ID numeric,IS_FX_RATE_FIXED numeric,FX_RESET_ID numeric,SETTLEMENT_OFFSET numeric,BUS_DAY_B numeric,FWD_SETTING_B numeric,SPECIFIC_DATE_B numeric)
/

    ALTER TABLE PRODUCT_OTCEQTYOPT MODIFY (PRODUCT_ID numeric,IS_FX_RATE_FIXED numeric,FX_RESET_ID numeric)
/

    ALTER TABLE PRODUCT_OTCOPTION MODIFY (PRODUCT_ID numeric,AUTOMATIC_EXERCISE numeric)
/

    ALTER TABLE PRODUCT_PLEDGE MODIFY (PRODUCT_ID numeric,LINKED_ID numeric,SECURITY_ID numeric,ORDERER_ID numeric,IS_OPEN_TERM numeric,NOTICE_DAYS numeric)
/

    ALTER TABLE PRODUCT_PM_DEPO_LEASE MODIFY (PRODUCT_ID numeric,DEPOSIT_LEASE_TYPE numeric,SPOT_PRICE_FIXED_B numeric,FX_RESET_PM_TO_INTEREST numeric,IS_ALLOCATED numeric)
/

    ALTER TABLE PRODUCT_POOL MODIFY (PRODUCT_ID numeric,MARGIN_CALL_ID numeric)
/

    ALTER TABLE PRODUCT_POS_CASH MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_POS_INVENTORY MODIFY (PRODUCT_ID numeric,AGENT_ID numeric,ACCOUNT_ID numeric,SECURITY_ID numeric,CONFIG_ID numeric)
/

    ALTER TABLE PRODUCT_SINGLE_CCY_REP_POS MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_REPO MODIFY (PRODUCT_ID numeric,MONEY_MARKET_ID numeric,TRIPARTY_REPO_B numeric,HOLD_IN_CUSTODY_B numeric,SUBSTITUTION_B numeric,TERMINABLE_FLAG numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,CUSTOM_FLOWS_B numeric,DISPATCH_XFER_B numeric,CASH_XFER_B numeric,SUBST_LIMIT numeric,SINGLE_COLL_B numeric,BUYSELLBACK_B numeric,ZAR_B numeric,PLEDGE_B numeric,AUTO_ALLOCATION_B numeric,SUBST_DATE_RULE numeric,REPRICE_DATE_RULE numeric,MODIFY_MONEY_B numeric,CONTINUOUS_B numeric,LEGAL_AGREEMENT_ID numeric,TRIPARTY_AGREEMENT_ID numeric,TRIPARTY_ALLOC_TYPE numeric,POOL_B numeric,RSL_B numeric)
/

    ALTER TABLE PRODUCT_REPO_HIST MODIFY (PRODUCT_ID numeric,MONEY_MARKET_ID numeric,TRIPARTY_REPO_B numeric,HOLD_IN_CUSTODY_B numeric,SUBSTITUTION_B numeric,TERMINABLE_FLAG numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,CUSTOM_FLOWS_B numeric,DISPATCH_XFER_B numeric,CASH_XFER_B numeric,SUBST_LIMIT numeric,SINGLE_COLL_B numeric,BUYSELLBACK_B numeric,ZAR_B numeric,PLEDGE_B numeric,AUTO_ALLOCATION_B numeric,SUBST_DATE_RULE numeric,REPRICE_DATE_RULE numeric,MODIFY_MONEY_B numeric,CONTINUOUS_B numeric,LEGAL_AGREEMENT_ID numeric,TRIPARTY_AGREEMENT_ID numeric,TRIPARTY_ALLOC_TYPE numeric,POOL_B numeric,RSL_B numeric)
/

    ALTER TABLE PRODUCT_RESET MODIFY (PRODUCT_ID numeric,INT_CLEANUP numeric)
/

    ALTER TABLE PRODUCT_SBL_PENDING_MARK MODIFY (MARK_ID numeric,VERSION_NUMBER numeric,TRADE_ID numeric,SECURITY_ID numeric)
/

    ALTER TABLE PRODUCT_SBL_PENDING_MARK_ATTR MODIFY (ENTITY_ID numeric)
/

    ALTER TABLE PRODUCT_SEC_BASKET MODIFY (PRODUCT_ID numeric,ISSUER_ID numeric,PAYING_AGENT_ID numeric)
/

    ALTER TABLE PRODUCT_SEC_CODE MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_SEC_CODE MODIFY (CODE_VALUE varchar2 (128) , CODE_VALUE_UCASE varchar2 (128))
/

    ALTER TABLE PRODUCT_SECLENDING MODIFY (PRODUCT_ID numeric,SECURITY_ID numeric,OPEN_TERM_B numeric,NOTICE_DAYS numeric,SUBSTITUTION_B numeric,TERMINABLE_FLAG numeric,BILLING_DATE_RULE numeric,FEE_PRICE_TIMING numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,CUSTOM_FLOWS_B numeric,FEE_MARK_RULE numeric,COLL_MARK_RULE numeric,CASH_BILL_RULE numeric,FEE_MARK_LINK_B numeric,CASH_XFER_B numeric,SUBST_LIMIT numeric,SETTLEMENT_BASED_NOM_ADJ numeric)
/

    ALTER TABLE PRODUCT_SIMPLE_MM MODIFY (PRODUCT_ID numeric,LOAN_B numeric,FIXED_RATE_B numeric,DISCOUNT_B numeric,OPEN_TERM_B numeric,NOTICE_DAYS numeric)
/

    ALTER TABLE PRODUCT_SIMPLEXFER MODIFY (PRODUCT_ID numeric,LINKED_ID numeric,SECURITY_ID numeric,IS_RETURN numeric,ORDERER_ID numeric,IS_PLEDGE numeric,IS_DAP numeric)
/

    ALTER TABLE PRODUCT_SINGLESWAPLEG MODIFY (PRODUCT_ID numeric,SWAPLEG_ID numeric,CUSTOM_FLOWS_B numeric,IS_PAY_B numeric)
/

    ALTER TABLE PRODUCT_SPR_CAP_FL MODIFY (PRODUCT_ID numeric,DEF_RESET_LAG_B1 numeric,RESET_LAG1 numeric,RESET_LAG_BUSD_B1 numeric,DEF_RESET_LAG_B2 numeric,RESET_LAG2 numeric,RESET_LAG_BUSD_B2 numeric)
/

    ALTER TABLE PRODUCT_STOCKLOAN MODIFY (PRODUCT_ID numeric,SECURITY_ID numeric,LOAN_B numeric,RETURN_B numeric,LINKED_ID numeric,IS_DAP numeric)
/

    ALTER TABLE PRODUCT_STRUCTURED MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_SUBSCRIPREDEMP MODIFY (PRODUCT_ID numeric,INV_PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_SWAP MODIFY (PRODUCT_ID numeric,PAY_LEG_ID numeric,RECEIVE_LEG_ID numeric,CUSTOM_FLOWS_B numeric,OPT_CAL_OFFSET numeric,OPT_CAL_BUS_B numeric,OPT_ROLLDAY numeric,TERM_MANDATORY numeric,FLOWS_FLAG numeric,EXPIRY_TIME numeric,EARLIEST_EXERCISE_TIME numeric,LATEST_EXERCISE_TIME numeric,OPT_SCHEDULE_LOCK numeric,CALC_OFFSET_DAYS_B numeric,FXRESET_LEG_ID numeric,FXRESET_ID numeric,ADJUST_FIRST_FLOW_B numeric,FWD_START_ADJ_LEG_ID numeric)
/

    ALTER TABLE PRODUCT_SWAPTION MODIFY (PRODUCT_ID numeric,CONST_MATURITY_B numeric,UND_START_OFFSET numeric,UNDERLYING_TERM numeric,PAY_LEG_ID numeric,RECEIVE_LEG_ID numeric,CUSTOM_FLOWS_B numeric,STRADDLE_B numeric,IS_PREMIUM_PERCENTAGE numeric,OPT_CAL_OFFSET numeric,OPT_CAL_BUS_B numeric,OPT_ROLLDAY numeric,TERM_MANDATORY numeric,FLOWS_FLAG numeric,EXPIRY_TIME numeric,CALC_OFFSET_DAYS_B numeric,IS_XCCY numeric)
/

    ALTER TABLE TLOCK_SAMPLE MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_TEMP MODIFY (ID numeric,PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_TLOCK MODIFY (PRODUCT_ID numeric,REF_PRODUCT_ID numeric,CAL_OFFSET numeric,CAL_BUS_B numeric,DURATION_OVERRIDE_B numeric)
/

    ALTER TABLE PRODUCT_TRS MODIFY (PRODUCT_ID numeric,TERMINATED_B numeric,USE_ASSET_AMORT_B numeric,FEE_GUARANTEED numeric,CUSTOM_FLOWS_B numeric,FLOWS_FLAG numeric)
/

    ALTER TABLE PRODUCT_TRS_BASKET MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_VARIABLE MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE PRODUCT_VARIANCE_SWAP MODIFY (PRODUCT_ID numeric,UNDERLYING_ID numeric,UNDERLYING_FX_RESET_ID numeric,UNDERLYING_EQUITY_RESET_ID numeric,ANNUALIZATION_FACTOR numeric,INCLUDE_INCOME_B numeric,SPECIFIC_DATE_B numeric,BUSDAY_B numeric,OFFSET_DAYS numeric,PAYFX_RESET_ID numeric,PAYFX_FIXED_B numeric,OVERRIDE_RESET_HOLIDAYS_B numeric,GAMMA_USE_FIRST_OBSERVATION numeric,SPECIAL_QUOTE_TYPE numeric)
/

    ALTER TABLE PRODUCT_VARIANCE_OPTION MODIFY (PRODUCT_ID numeric,UNDERLYING_ID numeric,UNDERLYING_FX_RESET_ID numeric,UNDERLYING_EQUITY_RESET_ID numeric,ANNUALIZATION_FACTOR numeric,INCLUDE_INCOME_B numeric,SPECIFIC_DATE_B numeric,BUSDAY_B numeric,OFFSET_DAYS numeric,PAYFX_RESET_ID numeric,PAYFX_FIXED_B numeric,OVERRIDE_RESET_HOLIDAYS_B numeric,GAMMA_USE_FIRST_OBSERVATION numeric,SPECIAL_QUOTE_TYPE numeric)
/

    ALTER TABLE STATISTIC_SWAP_CONDITION MODIFY (PRODUCT_ID numeric,CONDITION_TYPE numeric)
/

    ALTER TABLE UNDERLYING MODIFY (UNDERLYING_ID numeric,PRODUCT_ID numeric)
/

    ALTER TABLE VARIANCESWAP_TERM_HIST MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE VARIANCEOPTION_TERM_HIST MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_CORRELATION_SWAP MODIFY (PRODUCT_ID numeric,BASKET_ID numeric,INCLUDE_INCOME_B numeric,SPECIFIC_DATE_B numeric,BUSDAY_B numeric,OFFSET_DAYS numeric,PAYFX_RESET_ID numeric,PAYFX_FIXED_B numeric,OVERRIDE_RESET_HOLIDAYS_B numeric,USE_FIRST_OBSERVATION numeric,SPECIAL_QUOTE_TYPE numeric)
/

    ALTER TABLE CORRELATIONSWAP_TERM_HIST MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_DIVIDEND_SWAP MODIFY (PRODUCT_ID numeric,UNDERLYING_ID numeric,BASKET_ID numeric,SPECIFIC_DATE_B numeric,BUSDAY_B numeric,OFFSET_DAYS numeric,PAYFX_RESET_ID numeric,PAYFX_FIXED_B numeric,OVERRIDE_RESET_HOLIDAYS_B numeric,IS_NOTIONAL_BASED numeric,IS_SPECIFIC_DIVIDEND numeric,SPECIAL_QUOTE_TYPE numeric)
/

    ALTER TABLE DIVIDENDSWAP_TERM_HIST MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE DIVIDEND_SWAP_PD MODIFY (PRODUCT_ID numeric,PERIOD numeric,EQUITY_POSITION numeric)
/

    ALTER TABLE STATISTIC_SWAP_CA MODIFY (PRODUCT_ID numeric,CA_ID numeric)
/

    ALTER TABLE PRODUCT_EQUITY_FORWARD MODIFY (PRODUCT_ID numeric,UNDERLYING_ID numeric,BASKET_ID numeric,SPECIFIC_DATE_B numeric,BUSDAY_B numeric,OFFSET_DAYS numeric,PAYFX_RESET_ID numeric,PAYFX_FIXED_B numeric,OVERRIDE_RESET_HOLIDAYS_B numeric,IS_SPECIFIC_DIVIDEND numeric,SPECIAL_QUOTE_TYPE numeric,EQUITY_RESET_ID numeric)
/

    ALTER TABLE EQUITYFORWARD_TERM_HIST MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_SKEW_SWAP MODIFY (PRODUCT_ID numeric,BASKET_ID numeric,INCLUDE_INCOME_B numeric,SPECIFIC_DATE_B numeric,BUSDAY_B numeric,OFFSET_DAYS numeric,PAYFX_RESET_ID numeric,PAYFX_FIXED_B numeric,OVERRIDE_RESET_HOLIDAYS_B numeric,USE_FIRST_OBSERVATION numeric,BESTOF_START numeric,BESTOF_END numeric,MEDIUM_START numeric,MEDIUM_END numeric,WORSTOF_START numeric,WORSTOF_END numeric)
/

    ALTER TABLE SKEWSWAP_TERM_HIST MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE STATISTIC_SWAP_AP MODIFY (PRODUCT_ID numeric,PARAM_NUMBER numeric,TYPE numeric)
/

    ALTER TABLE BOND_STRUCT_NOTE MODIFY (PRODUCT_ID numeric,STRUCTURED_PRODUCT_ID numeric)
/

    ALTER TABLE STRUCT_NOTE_PART MODIFY (NOTE_ID numeric,BP_SUB_ID numeric)
/

    ALTER TABLE PRODUCT_WARRANT MODIFY (PRODUCT_ID numeric,OPTION_TYPE numeric,BARRIER numeric,MATURITY_TENOR numeric,ISSUER_LE_ID numeric,EXCHANGE_ID numeric,UNDERLYING_ID numeric,BOND_ID numeric,SECONDARY_DAYS numeric,MATURITY_DAYS numeric,IPA_LE_ID numeric,CA_LE_ID numeric,GUARANTOR_LE_ID numeric,LAST_TRADING_DAYS numeric,UNDERLYING_EXCHANGE_ID numeric,AUTOMATIC_EXERCISE numeric,COVERED numeric,BUY_BACK_PERIOD_ID numeric,FX_RESET_ID numeric,EXPIRY_AVERAGE numeric,DIVIDEND_PASS_THROUGH numeric,UNDER_TO_DELIVER_ID numeric)
/

    ALTER TABLE WARRANT_FLOATING_STRIKE MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_XFERAGENT MODIFY (PRODUCT_ID numeric,LINKED_ID numeric,SECURITY_ID numeric,FROM_SDI_ID numeric,TO_SDI_ID numeric,MSG_FROM_B numeric,MSG_TO_B numeric,FROM_SUBACC_SDI_ID numeric,TO_SUBACC_SDI_ID numeric,IS_DAP numeric)
/

    ALTER TABLE PRODUCT_STRUCTURED_FLOWS MODIFY (PRODUCT_ID numeric,OPEN_TERM_B numeric,NOTICE_DAYS numeric,ROLL_OVER_B numeric,CUSTOM_FLOWS_B numeric,AMORTIZING_B numeric,CF_GENERATION_LOCKS numeric,CF_CUSTOM_CHANGES numeric,MANDATORY_TERMINATION_B numeric,IS_PAY_B numeric,IS_REVOLVING_B numeric,SECURED_FUNDING_B numeric,OPTION_METHOD numeric)
/

    ALTER TABLE PRODUCT_ADVANCE MODIFY (PRODUCT_ID numeric,PPS_B numeric,EAL_TERM numeric,TERM numeric,CICA_B numeric,TREASURY_MATURITY numeric,CALLACCOUNT_ID numeric)
/

    ALTER TABLE RECONVENTION_CONSTRAINT MODIFY (PRODUCT_ID numeric,CONSTRAINT_ID numeric)
/

    ALTER TABLE RECONV_CONSTRAINT_DATES MODIFY (CONSTRAINT_ID numeric)
/

    ALTER TABLE RECONV_CONSTRAINT_PARAM MODIFY (CONSTRAINT_ID numeric)
/

    ALTER TABLE STRUCTURED_FLOWS_ISSUANCE_INFO MODIFY (PRODUCT_ID numeric,ISSUANCE_ID numeric,ISSUER_ID numeric)
/

    ALTER TABLE BOND_ISSUANCE MODIFY (PRODUCT_ID numeric,CF_GEN_UND_PRD_ID numeric)
/

    ALTER TABLE BOND_ISSUANCE_RELATIONSHIP MODIFY (PRODUCT_ID numeric,TRADE_ID numeric)
/

    ALTER TABLE AUTHORIZED_SIGNER MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_ADVANCE_LETTER_CREDIT MODIFY (PRODUCT_ID numeric,CICA_B numeric,EVERGREEN_CLAUSE_INCLUDED_B numeric,EVERGREEN_NOTIFICATION_DAYS numeric)
/

    ALTER TABLE PRODUCT_EXTERNAL_TRADE MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE EXTERNAL_TRADE_FIELD MODIFY (PRODUCT_ID numeric,FIELD_ORDER numeric,FIELD_INT numeric)
/

    ALTER TABLE EXTERNAL_TRADE_FIELD_DEF MODIFY (CONTEXT_ID numeric,FIELD_ORDER numeric,FIELD_MANDATORY numeric)
/

    ALTER TABLE EXTERNAL_TRADE_CONTEXT MODIFY (CONTEXT_ID numeric)
/

    ALTER TABLE EXTERNAL_TRADE_FLOW MODIFY (PRODUCT_ID numeric,FLOW_ID numeric,LEG_ID numeric,FIXED numeric,KNOWN numeric,RATE_INDEX_FACTOR numeric,COMPOUNDED numeric,PERF_FACTOR numeric)
/

    ALTER TABLE MARKET_MEASURE MODIFY (PRODUCT_ID numeric,CUSTOMIZED_B numeric)
/

    ALTER TABLE PS_EVENT MODIFY (EVENT_ID numeric,OBJECT_ID numeric,ENGINE_ID numeric)
/

    ALTER TABLE PS_EVENT_CFG_NAME MODIFY (IS_DEFAULT_B numeric,VERSION_NUM numeric)
/

    ALTER TABLE PS_EVENT_INST MODIFY (EVENT_ID numeric)
/

    ALTER TABLE PUT_CALL_DATE MODIFY (PRODUCT_ID numeric,LEG_ID numeric,OPTION_TYPE numeric,PC_POSITION numeric,IS_PREMIUM_PERCENTAGE numeric,AUTO_EXERCISE numeric,IS_EXERCISED numeric,INTEREST_CLEANUP_B numeric,INCLUDED_B numeric)
/

    ALTER TABLE PUT_CALL_DT_HIST MODIFY (PRODUCT_ID numeric,LEG_ID numeric,OPTION_TYPE numeric,PC_POSITION numeric,IS_PREMIUM_PERCENTAGE numeric,AUTO_EXERCISE numeric,IS_EXERCISED numeric,INTEREST_CLEANUP_B numeric,INCLUDED_B numeric)
/

    ALTER TABLE PVAR_OVERRIDE MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE QE_CONFIG MODIFY (CONFIG_ID numeric)
/

    ALTER TABLE QE_QP_HIERARCHY MODIFY (CONFIG_ID numeric,QTPROC_ID numeric,SRC_QP_ORDER numeric,SRC_QP_ID numeric,ENABLED_B numeric,PREFERRED_B numeric)
/

    ALTER TABLE QE_QP_PARAM MODIFY (CONFIG_ID numeric,QTPROC_ID numeric,ENABLED_B numeric)
/

    ALTER TABLE QE_QPROC_HDR MODIFY (CONFIG_ID numeric,QTPROC_ID numeric)
/

    ALTER TABLE QE_RULE_HDR MODIFY (CONFIG_ID numeric,RULE_ID numeric,RULE_TYPE numeric)
/

    ALTER TABLE QE_RULE_PARAM MODIFY (CONFIG_ID numeric,RULE_ID numeric)
/

    ALTER TABLE QS_MONITOR_CFG MODIFY (ID numeric)
/

    ALTER TABLE QUOTABLE_VARIABLE MODIFY (VERSION_NUM numeric,RATE_INDEX_TENOR numeric,PRODUCT_ID numeric)
/

    ALTER TABLE QUOTE_NAME MODIFY (DECIMALS numeric)
/

    ALTER TABLE QUOTE_SET MODIFY (INTRADAY_B numeric)
/

    ALTER TABLE QUOTE_VALUE MODIFY (VERSION_NUM numeric,ESTIMATED_B numeric)
/

    ALTER TABLE QUOTE_VALUE_INTRADAY MODIFY (VERSION_NUM numeric,ESTIMATED_B numeric)
/

    ALTER TABLE QUOTE_VALUE_HIST MODIFY (VERSION_NUM numeric,ESTIMATED_B numeric)
/

    ALTER TABLE QUOTE_VALUE_ADJUSTMENT MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE QVAR_OVERRIDE MODIFY (PRODUCT_ID numeric,RESET_DAYS numeric,RESET_BUS_LAG_B numeric,RESET_IN_ARREAR_B numeric)
/

    ALTER TABLE RATE_INDEX MODIFY (RATE_INDEX_ID numeric,RATE_INDEX_TENOR numeric,VERSION_NUM numeric,END_TO_END_B numeric)
/

    ALTER TABLE RATE_INDEX_DEFAULT MODIFY (RESET_DAYS numeric,RESET_WEEKDAY numeric,RESET_BUS_LAG_B numeric,RESET_HOUR numeric,RESET_IN_ARREAR_B numeric,PAY_IN_ARREAR_B numeric,PAYMENT_BUS_LAG_B numeric,PAYMENT_DAYS numeric,PUBLISH_DTRULE numeric,VERSION_NUM numeric,NO_AUTO_INTERP_B numeric,INTERP_ROUNDING_DEC numeric,START_OFFSET numeric,DAY_OF_WEEK numeric,CUTOFF_DAYS numeric,UNADJUST_RESET numeric,AVG_ROUNDING_UNIT numeric,PUBLICATION_DAY numeric,REFERENCE_DAY numeric,REFERENCE_MONTH numeric,CU_SWAP_RATE_INDEX_TENOR numeric,MATURITY_TENOR numeric,MAN_FIRST_RESET_B numeric,SPC_LAG_B numeric,SPC_LAG_OFFSET numeric,SPC_LAG_BUS_CAL_B numeric,PRINCIPAL_ACTUAL_B numeric,DISCOUNT_METHOD numeric,CHK_FIRST_RESET_B numeric)
/

    ALTER TABLE RATE_SCHED_HIST MODIFY (PRODUCT_ID numeric,SUB_ID numeric)
/

    ALTER TABLE RATE_SCHEDULE MODIFY (PRODUCT_ID numeric,SUB_ID numeric)
/

    ALTER TABLE RATING_ADDRESS MODIFY (LE_ID numeric)
/

    ALTER TABLE DRAWING_SCHEDULE MODIFY (PRODUCT_ID numeric,BOND_ID numeric)
/

    ALTER TABLE RECON_INVEN_ROW MODIFY (RECON_INVEN_ROW_ID numeric,AGENT_ID numeric,ACCOUNT_ID numeric,BOOK_ID numeric,SUB_ACCOUNT_ID numeric,NUM_DAYS_OUT numeric,NUM_DAYS_CHANGE numeric)
/

    ALTER TABLE RECON_INVEN_RUN MODIFY (AGENT_ID numeric,AGGREGATION_TYPE numeric,PROC_ORG_ID numeric,PAY_REC_B numeric,INCLUDE_CASH numeric,INCLUDE_SEC numeric)
/

    ALTER TABLE REF_CHARACTERISTIC MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE REF_ENTITY MODIFY (REF_ENTITY_ID numeric,IS_SHARED_B numeric,VERSION_NUM numeric)
/

    ALTER TABLE REF_ENTITY_BASKET MODIFY (REF_ENTITY_ID numeric,COMPONENT_ID numeric)
/

    ALTER TABLE REF_ENTITY_BASKET_COMMENT MODIFY (REF_ENTITY_BASKET_ID numeric,MATRIX_APPLICABLE_B numeric)
/

    ALTER TABLE REF_ENTITY_CHANGES MODIFY (REF_ENTITY_ID numeric,COMPONENT_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE REF_ENTITY_NDEFAULT MODIFY (REF_ENTITY_ID numeric,UNDERLYING_ID numeric,START_DEFAULT numeric,END_DEFAULT numeric)
/

    ALTER TABLE REF_ENTITY_OB MODIFY (PRODUCT_ID numeric,ISSUER_ID numeric,PRIMARY_REF_OB numeric,VERSION_NUM numeric,STANDARD_REF_OB numeric)
/

    ALTER TABLE REF_ENTITY_SINGLE MODIFY (REF_ENTITY_ID numeric,LEGAL_ENTITY_ID numeric,TICKER_ID numeric)
/

    ALTER TABLE REF_ENTITY_SINGLE_OBG MODIFY (REF_ENTITY_ID numeric,REF_OBLIG_ID numeric)
/

    ALTER TABLE REF_ENTITY_SINGLE_OBGDESC MODIFY (REF_ENTITY_ID numeric)
/

    ALTER TABLE REF_ENTITY_TRANCHE MODIFY (REF_ENTITY_ID numeric,UNDERLYING_ID numeric,PRECISION numeric)
/

    ALTER TABLE REPO_COLL_HIST MODIFY (PRODUCT_ID numeric,COLLATERAL_ID numeric)
/

    ALTER TABLE REPO_COLLATERAL MODIFY (PRODUCT_ID numeric,COLLATERAL_ID numeric)
/

    ALTER TABLE REPORT_BROWSER_CONFIG MODIFY (REPT_BROWSER_CONFIG_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE REPORT_BROWSER_TREE_NODE MODIFY (REPT_BROWSER_CONFIG_ID numeric,NODE_ID numeric,PARENT_ID numeric)
/

    ALTER TABLE REPORT_TEMPLATE MODIFY (TEMPLATE_ID numeric,IS_HIDDEN numeric,VERSION_NUM numeric,PRIVATE_B numeric)
/

    ALTER TABLE REPORT_VIEW MODIFY (VIEW_ID numeric)
/

    ALTER TABLE REVOLVER_DRAWN MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE RISK_CONFIG MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE RISK_CONFIG_ITEM MODIFY (PRINT_B numeric,DISPLAY_B numeric,SAVE_B numeric,DISTRIBUTED_B numeric,APPEND_TIMESTAMP_B numeric,SAVE_AS_BLOB numeric,PRIORITY_LEVEL numeric,TIMEOUT numeric,ASOFDATE_B numeric,GENERATE_MKDATA_B numeric)
/

    ALTER TABLE VEGA_WEIGHTS MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE RISK_ON_DEMAND_CONFIG MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE RISK_ON_DEMAND_ITEM MODIFY (TRADE_FREQ numeric,QUOTE_FREQ numeric,RUN_FREQ numeric,MARKET_DATA_FREQ numeric,MANUAL_B numeric,KILL_IF_LAST_B numeric,OUTPUT_ID numeric,JOB_PRIORITY numeric,CATCHUP_LIMIT numeric)
/

    ALTER TABLE RISK_PRESENTER_CONFIG MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE RISK_PRESENTER_ITEM MODIFY (TRADE_FREQ numeric,QUOTE_FREQ numeric,RUN_FREQ numeric,MARKET_DATA_FREQ numeric,MANUAL_B numeric,KILL_IF_LAST_B numeric,OUTPUT_ID numeric,JOB_PRIORITY numeric,CATCHUP_LIMIT numeric)
/

    ALTER TABLE RISK_RUNNER_CONFIG MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE RISK_SHORTCUTS MODIFY (MODIFIER numeric,KEY_CHAR numeric)
/

    ALTER TABLE S_B2B_TRD_CFG_ATTR MODIFY (FROM_BOOK_ID numeric,TRANSFER_TO_BK_ID numeric)
/

    ALTER TABLE SALES_B2B_TRD_CFG MODIFY (VERSION numeric,FROM_BOOK_ID numeric,PRIORITY numeric,TRANSFER_MARGIN numeric,PV_FWD_AMT numeric,SMHEDGE_BOOK_ID numeric,TRADE_THRESHOLD_AMT numeric,POSITION_THRESHOLD_AMT numeric)
/

    ALTER TABLE SCENARIO_ITEMS MODIFY (ITEM_SEQ numeric)
/

    ALTER TABLE SCENARIO_RULE MODIFY (VERSION_NUM numeric,IS_PARAMETRIC numeric)
/

    ALTER TABLE SCHED_TASK MODIFY (TASK_ID numeric,SCHED_TIME numeric,FROM_DAYS numeric,TO_DAYS numeric,PUBLISH_B numeric,EXECUTE_B numeric,SEND_EMAIL_B numeric,VAL_TIME numeric,UNDO_TIME numeric,NEXT_ID numeric,VALDATE_OFFSET numeric,EXEC_HOL numeric,PO_ID numeric,DATE_RULE_ID numeric,EXEC_DS_B numeric,VERSION_NUM numeric,READ_ONLY_SRVR_B numeric,PRIVATE_B numeric,IS_DEACTIVATED numeric,SKIP_EXEC_B numeric,SKIP_CUTOFF_TIME numeric)
/

    ALTER TABLE SCHED_TASK_ATTR MODIFY (TASK_ID numeric,VALUE_ORDER numeric)
/

    ALTER TABLE SCHED_TASK_EXEC MODIFY (TASK_ID numeric,EXEC_STATUS_B numeric)
/

    ALTER TABLE SDI_ATTRIBUTE MODIFY (SDI_ID numeric)
/

    ALTER TABLE SDI_RELATIONSHIP MODIFY (ID numeric,LE_ID numeric,AGENT_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE SEC_BASKET_CHANGES MODIFY (PRODUCT_ID numeric,COMPONENT_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE SEC_LEND_COUNTRY MODIFY (LEGAL_AGREEMENT_ID numeric)
/

    ALTER TABLE SEC_LEND_LEGAL MODIFY (LEGAL_AGREEMENT_ID numeric,NOTICE_DAYS numeric,REPRICE_FREQ numeric,BILLINGPERIOD numeric,FEE_PRICE_TIMING numeric,SETTLEMENT_BASED_NOM_ADJ numeric)
/

    ALTER TABLE SECLEND_COL_HIST MODIFY (PRODUCT_ID numeric,COLLATERAL_ID numeric)
/

    ALTER TABLE SECLENDING_COL MODIFY (PRODUCT_ID numeric,COLLATERAL_ID numeric)
/

    ALTER TABLE SECFIN_COMPLIANCE MODIFY (COMPLIANCE_ID numeric,BUNDLE_ID numeric,EXTERNAL_TRADE_ID numeric)
/

    ALTER TABLE SECFIN_COMPLIANCE_DETAIL MODIFY (COMPLIANCE_ID numeric,BOOK_ID numeric,SECURITY_ID numeric,INTERNAL_TRADE_ID numeric)
/

    ALTER TABLE SEND_COPY_CONFIG MODIFY (SEND_CONFIG_ID numeric,SEND_CONTACT_ID numeric,REC_CONTACT_ID numeric,BY_GATEWAY_B numeric,BY_METHOD_B numeric,BY_JMS_B numeric)
/

    ALTER TABLE SETTLE_METHOD MODIFY (SETTLE_METHOD_ID numeric,PROCESSING_ORG_ID numeric,VERSION_NUM numeric,PRIORITY numeric,CUT_OFF numeric,CUT_OFF_TIME numeric,SAME_METHOD numeric,LAST_CP_AGENT_ID numeric,MATCH_METHOD numeric,REQUIRES_TRADE_KW numeric)
/

    ALTER TABLE SETTLE_MSG_SENDING MODIFY (SETTLE_MSG_ID numeric,PROCESSING_ORG_ID numeric,VERSION_NUM numeric,INTERMEDIARY1 numeric,INTERMEDIARY2 numeric,RECEIVER_ID numeric,PAY_REC numeric)
/

    ALTER TABLE SETTLE_POSITION MODIFY (PRODUCT_ID numeric,BOOK_ID numeric,POS_AGG_ID numeric,LAST_TRADE_ID numeric,POSITION_ID numeric,LAST_TRADE_VERSION numeric,EVENT_ID numeric)
/

    ALTER TABLE SETTLE_POSITION MODIFY EVENT_TYPE varchar2 (64)
/

    ALTER TABLE SETTLE_POSITION_CHANGE MODIFY (PRODUCT_ID numeric,BOOK_ID numeric,POS_AGG_ID numeric,LAST_TRADE_ID numeric,POSITION_ID numeric,LAST_TRADE_VERSION numeric,EVENT_ID numeric)
/

    ALTER TABLE SETTLE_POSITION_CHANGE MODIFY EVENT_TYPE varchar2 (64)
/

    ALTER TABLE SETTLE_POSITION_CHANGE_H MODIFY (PRODUCT_ID numeric,BOOK_ID numeric,POS_AGG_ID numeric,LAST_TRADE_ID numeric,POSITION_ID numeric,LAST_TRADE_VERSION numeric,EVENT_ID numeric)
/

    ALTER TABLE SETTLE_POSITION_BCKT MODIFY (PRODUCT_ID numeric,BOOK_ID numeric,POS_AGG_ID numeric,LAST_TRADE_ID numeric,POSITION_ID numeric)
/

    ALTER TABLE SETTLE_POSITION_CHG MODIFY (PRODUCT_ID numeric,BOOK_ID numeric,POS_AGG_ID numeric)
/

    ALTER TABLE SETTLE_POSITION_SNAP MODIFY (PRODUCT_ID numeric,BOOK_ID numeric,POS_AGG_ID numeric,LAST_TRADE_ID numeric)
/

    ALTER TABLE SETTLE_POSITION_SNAPSHOT MODIFY (PRODUCT_ID numeric,BOOK_ID numeric,POS_AGG_ID numeric,LAST_TRADE_ID numeric,POSITION_ID numeric,LAST_TRADE_VERSION numeric,EVENT_ID numeric)
/

    ALTER TABLE SETTLE_POSITION_SNAPSHOT MODIFY EVENT_TYPE varchar2 (64)
/

    ALTER TABLE SETTLE_POSITION_SNAPSHOT_2 MODIFY (PRODUCT_ID numeric,BOOK_ID numeric,POS_AGG_ID numeric,LAST_TRADE_ID numeric,POSITION_ID numeric,LAST_TRADE_VERSION numeric,EVENT_ID numeric)
/

    ALTER TABLE SETTLE_POSITION_SNAPSHOT_2 MODIFY EVENT_TYPE varchar2 (64)
/

    ALTER TABLE POSITIONS_SNAPSHOT_DEFINITION MODIFY (IS_VERIFIED_B numeric)
/

    ALTER TABLE POSITIONS_SNAPSHOT_DEFINITION2 MODIFY (IS_VERIFIED_B numeric)
/

    ALTER TABLE SPECIFIC_FXRATE MODIFY (TRADE_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE SPLOCK_EXT_INFO MODIFY (PRODUCT_ID numeric,REF_PRODUCT_ID numeric)
/

    ALTER TABLE SPOT_RISK_HEDGE MODIFY (VERSION numeric,FROM_BOOK_ID numeric,HEDGE_BOOK_ID numeric)
/

    ALTER TABLE SPR_SWAP_LEG MODIFY (PRODUCT_ID numeric,LEG_ID numeric,DEF_RESET_LAG_B1 numeric,RESET_LAG1 numeric,RESET_LAG_BUSD_B1 numeric,DEF_RESET_LAG_B2 numeric,RESET_LAG2 numeric,RESET_LAG_BUSD_B2 numeric)
/

    ALTER TABLE SPR_SWAP_LEG_HIST MODIFY (PRODUCT_ID numeric,LEG_ID numeric,DEF_RESET_LAG_B1 numeric,RESET_LAG1 numeric,RESET_LAG_BUSD_B1 numeric,DEF_RESET_LAG_B2 numeric,RESET_LAG2 numeric,RESET_LAG_BUSD_B2 numeric)
/

    ALTER TABLE SPREAD_CONFIG MODIFY (SPREAD_ID numeric)
/

    ALTER TABLE SPREAD_CRITERIA MODIFY (SPREAD_ID numeric,SPREAD_ITEM_ID numeric,SPREAD_CRITERIA_ID numeric)
/

    ALTER TABLE SPREAD_ITEM MODIFY (SPREAD_ID numeric,SPREAD_ITEM_ID numeric)
/

    ALTER TABLE STRATEGY MODIFY (ID numeric,PARENT_ID numeric,TARGET_ID numeric,INVESTMENTS_ID numeric,BENCHMARK_ID numeric,VERSION_NUM numeric,CASH_EQUIV_CONFIG_ID numeric,SECONDARY_BENCHMARK_ID numeric,PERIMETER_TYPE_ID numeric,BOOK_ID numeric,TRADING_BASKET_ID numeric)
/

    ALTER TABLE SURF_SPC_DATE_HIST MODIFY (VOL_SURFACE_ID numeric)
/

    ALTER TABLE SURFACE_SPC_DATE MODIFY (VOL_SURFACE_ID numeric)
/

    ALTER TABLE SWAP_LEG MODIFY (PRODUCT_ID numeric,LEG_ID numeric,COUPON_OFFSET numeric,CPN_OFF_BUS_DAY_B numeric,CUSTOM_ROL_DAY_B numeric,ROLLING_DAY numeric,CPN_PAY_AT_END_B numeric,COMPOUND_B numeric,DEF_RESET_OFF_B numeric,RESET_OFFSET numeric,RESET_OFF_BUSDAY_B numeric,RESET_AVERAGING_B numeric,SAMPLE_START_OFF numeric,SAMPLE_WEEKDAY numeric,MAN_FIRST_RESET_B numeric,FIRST_RATE_DECIMALS numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,RESET_CUTOFF numeric,DISCOUNT_METHOD numeric,RESET_DATE_RULE numeric,FST_STB_INTRP_B numeric,FST_STB_IDX_X numeric,FST_STB_IDX_Y numeric,LST_STB_INTRP_B numeric,LST_STB_IDX_X numeric,LST_STB_IDX_Y numeric,PMT_DATE_RULE numeric,PRIOR_RESET_B numeric,ACCRUAL_DATE_RULE numeric,INCLUDE_FIRST_B numeric,INCLUDE_LAST_B numeric,RESETCUTOFFBUSDAYB numeric,MAN_FIRST_DATE_B numeric,CONFIG_TYPE_ID numeric,CONFIG_TYPE_VER numeric,ACT_INITIAL_EXCH_B numeric,ACT_FINAL_EXCH_B numeric,ACT_AMORT_EXCH_B numeric,XSP_CUST_REDEMPTIONS numeric,SETTLE_HOLIDAYS_B numeric,FIXED_AMOUNT_B numeric,CMP_DATE_RULE numeric,PRIOR_CMP_RESET_B numeric,INFL_CALC_TYPE numeric,FWD_ADJ_LEG_RESET_B numeric,EFF_RESET_DATE_B numeric,ADD_NOTICE_DAYS_B numeric)
/

    ALTER TABLE SWAP_LEG_HIST MODIFY (PRODUCT_ID numeric,LEG_ID numeric,COUPON_OFFSET numeric,CPN_OFF_BUS_DAY_B numeric,CUSTOM_ROL_DAY_B numeric,ROLLING_DAY numeric,CPN_PAY_AT_END_B numeric,COMPOUND_B numeric,DEF_RESET_OFF_B numeric,RESET_OFFSET numeric,RESET_OFF_BUSDAY_B numeric,RESET_AVERAGING_B numeric,SAMPLE_START_OFF numeric,SAMPLE_WEEKDAY numeric,MAN_FIRST_RESET_B numeric,FIRST_RATE_DECIMALS numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,RESET_CUTOFF numeric,DISCOUNT_METHOD numeric,RESET_DATE_RULE numeric,FST_STB_INTRP_B numeric,FST_STB_IDX_X numeric,FST_STB_IDX_Y numeric,LST_STB_INTRP_B numeric,LST_STB_IDX_X numeric,LST_STB_IDX_Y numeric,PMT_DATE_RULE numeric,PRIOR_RESET_B numeric,ACCRUAL_DATE_RULE numeric,INCLUDE_FIRST_B numeric,INCLUDE_LAST_B numeric,RESETCUTOFFBUSDAYB numeric,MAN_FIRST_DATE_B numeric,CONFIG_TYPE_ID numeric,CONFIG_TYPE_VER numeric,ACT_INITIAL_EXCH_B numeric,ACT_FINAL_EXCH_B numeric,ACT_AMORT_EXCH_B numeric,XSP_CUST_REDEMPTIONS numeric,SETTLE_HOLIDAYS_B numeric,FIXED_AMOUNT_B numeric,CAPITALIZE_INT_B numeric,NOTICE_DAYS numeric,OPEN_TERM_B numeric,CMP_DATE_RULE numeric,PRIOR_CMP_RESET_B numeric,INFL_CALC_TYPE numeric,FWD_ADJ_LEG_RESET_B numeric,EFF_RESET_DATE_B numeric,ADD_NOTICE_DAYS_B numeric)
/

    ALTER TABLE REAL_YIELD_SWAP_LEG MODIFY (PRODUCT_ID numeric,LEG_ID numeric,REF_PROD_ID numeric)
/

    ALTER TABLE REAL_YIELD_SWAP_LEG_HIST MODIFY (PRODUCT_ID numeric,LEG_ID numeric,REF_PROD_ID numeric)
/

    ALTER TABLE SWAPTION_EXT_INFO MODIFY (PRODUCT_ID numeric,FIRST_EXER_TIME numeric,LAST_EXER_TIME numeric,PARTIAL_EXERCISE numeric,MULTIPLE_EXERCISE numeric,AUTO_EXERCISE numeric,OPT_SCHEDULE_LOCK numeric,ACTIVATE_CCY2_B numeric)
/

    ALTER TABLE TASK_BOOK_CONFIG MODIFY (BOOK_ID numeric)
/

    ALTER TABLE TEMPLATE_BUNDLE MODIFY (PRIVATE_B numeric)
/

    ALTER TABLE TEMPLATE_PRODUCT MODIFY (PRODUCT_ID numeric,BOOK_ID numeric,PRIVATE_B numeric,CPTY_ID numeric,MIRROR_BOOK_ID numeric,PROD_TEMP_B numeric,RELATIVE_DATE numeric)
/

    ALTER TABLE STRATEGY_TEMPLATE_INFO MODIFY (STRATEGY_TEMPLATE_ID numeric,IS_PRIVATE numeric)
/

    ALTER TABLE STRATEGY_TEMPLATE_MEMBER MODIFY (STRATEGY_TEMPLATE_ID numeric,TEMPLATE_ORDER numeric)
/

    ALTER TABLE TERM_DATE_HIST MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE TERM_EVTS_REF_ENT MODIFY (PRODUCT_ID numeric,REF_ENTITY_ID numeric,REF_ASSET_ID numeric)
/

    ALTER TABLE TERMINATION_DATE MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE TERMINATION_EVENTS MODIFY (PRODUCT_ID numeric,REF_ASSET_ID numeric,GRACE_PERIOD_B numeric,GRACE_PERIOD_DAYS numeric,GRACE_PERIOD_BUS_B numeric,MULTIPLE_HOLDER_B numeric)
/
CREATE GLOBAL TEMPORARY TABLE tf_temp_table ( request_id numeric  NOT NULL,  row_number numeric  NOT NULL,  trade_id numeric  NULL ) ON COMMIT PRESERVE ROWS
/

    ALTER TABLE TICKER MODIFY (TICKER_ID numeric,ISSUER_ID numeric,VERSION_NUM numeric,DEFAULT_OBLIG_ID numeric)
/

    ALTER TABLE TICKER_KEYWORD MODIFY (TICKER_ID numeric)
/

    ALTER TABLE TR_COMM_LEG MODIFY (PRODUCT_ID numeric,LEG_ID numeric,COMMODITY_IDX_ID numeric,CASHFLOW_CHANGED numeric,CASHFLOW_LOCKS numeric,DERIVED_QUOTE_B numeric)
/

    ALTER TABLE TRADE MODIFY (TRADE_ID numeric,PRODUCT_ID numeric,CPTY_ID numeric,BOOK_ID numeric,EXCHANGE_TRADED numeric,EXCHANGE_ID numeric,BUNDLE_ID numeric,MIRROR_TRADE_ID numeric,CUSTOM_XFRULE_B numeric,VERSION_NUM numeric,MIRROR_BOOK_ID numeric)
/

    ALTER TABLE TRADE_ALLOC_VALUES MODIFY (TRADE_ID numeric,REL_TRADE_ID numeric)
/

    ALTER TABLE TRADE_BUNDLE MODIFY (BUNDLE_ID numeric,ONE_MESSAGE numeric,VERSION_NUM numeric)
/

    ALTER TABLE TRADE_DIARY MODIFY (DIARY_ID numeric,TRADE_ID numeric,PROCESSED numeric,PRODUCT_ID numeric,COLLATERAL_ID numeric,SECURITY_ID numeric,TRADE_VERSION numeric,IS_CANCELED numeric,CANCEL_VERSION numeric,ACTION_ID numeric,SUB_ID numeric,LINKED_DIARY_ID numeric)
/

    ALTER TABLE TRADE_DIARY_HIST MODIFY (DIARY_ID numeric,TRADE_ID numeric,PROCESSED numeric,PRODUCT_ID numeric,COLLATERAL_ID numeric,SECURITY_ID numeric,TRADE_VERSION numeric,IS_CANCELED numeric,CANCEL_VERSION numeric,ACTION_ID numeric,SUB_ID numeric,LINKED_DIARY_ID numeric)
/

    ALTER TABLE TRADE_FEE MODIFY (TRADE_ID numeric,FEE_ID numeric,LEGAL_ENTITY_ID numeric,EXTERNAL_ID numeric,FEE_CONFIG_ID numeric,MANUAL_AMOUNT_B numeric,OVERRIDE_AMOUNT_B numeric)
/

    ALTER TABLE TRADE_FEE_HIST MODIFY (TRADE_ID numeric,FEE_ID numeric,LEGAL_ENTITY_ID numeric,EXTERNAL_ID numeric,FEE_CONFIG_ID numeric,MANUAL_AMOUNT_B numeric,OVERRIDE_AMOUNT_B numeric)
/

    ALTER TABLE TRADE_FILT_MIN_MAX MODIFY (IS_IN_B numeric)
/

    ALTER TABLE TRADE_FILTER MODIFY (CACHING_B numeric,SETLEDT_TENOR_MIN numeric,SETLEDT_TENOR_MAX numeric,MATDT_TENOR_MIN numeric,MATDT_TENOR_MAX numeric,CHECK_HOL_B numeric,EXCHANGE_TRADED_B numeric,VERSION_NUM numeric,CACHE_EXPIRY numeric,SQL_EXC_FUT_TRADE numeric)
/

    ALTER TABLE TRADE_FILTER_CRIT MODIFY (IS_IN_B numeric)
/

    ALTER TABLE AUDIT_FILTER MODIFY (FILTER_ID numeric,FILTER_VERSION numeric)
/

    ALTER TABLE AUDIT_FILTER_FIELD MODIFY (FILTER_ID numeric)
/

    ALTER TABLE TRADE_FILTER_PAGE MODIFY (TRADE_ID numeric,PAGE_INDEX numeric)
/

    ALTER TABLE ID_BASED_PAGER MODIFY (PAGER_ID numeric)
/

    ALTER TABLE ID_BASED_PAGER_ROW MODIFY (PAGER_ID numeric,OBJECT_ID numeric,ROW_ID numeric)
/

    ALTER TABLE TRADE_HIST MODIFY (TRADE_ID numeric,PRODUCT_ID numeric,CPTY_ID numeric,BOOK_ID numeric,EXCHANGE_TRADED numeric,EXCHANGE_ID numeric,BUNDLE_ID numeric,MIRROR_TRADE_ID numeric,CUSTOM_XFRULE_B numeric,VERSION_NUM numeric,MIRROR_BOOK_ID numeric)
/

    ALTER TABLE TRADE_KEYWORD MODIFY (TRADE_ID numeric)
/

    ALTER TABLE TRADE_KEYWORD_HIST MODIFY (TRADE_ID numeric)
/

    ALTER TABLE TRADE_NEXT_EVENT MODIFY (TRADE_ID numeric)
/

    ALTER TABLE TRADE_NOTE MODIFY (TRADE_ID numeric,TRADE_NOTE_ID numeric,PROCESSED_B numeric,PERMANENT_B numeric,SEVERITY numeric)
/

    ALTER TABLE TRADE_OPEN_QTY MODIFY (TOQ_ID numeric,VERSION_NUM numeric,TRADE_ID numeric,PRODUCT_ID numeric,UPDATE_INFO numeric,BOOK_ID numeric,SIGN numeric,IS_LIQUIDABLE numeric,IS_RETURN numeric,CA_ID numeric,LIQ_AGG_ID numeric,POSITION_ID numeric,TRADE_VERSION numeric,LIQ_CONFIG_ID numeric,LINKED_ID numeric,LIQ_OVERRIDE numeric)
/

    ALTER TABLE TRADE_OPENQTY_HIST MODIFY (TOQ_ID numeric,VERSION_NUM numeric,TRADE_ID numeric,PRODUCT_ID numeric,UPDATE_INFO numeric,BOOK_ID numeric,SIGN numeric,IS_LIQUIDABLE numeric,IS_RETURN numeric,CA_ID numeric,LIQ_AGG_ID numeric,POSITION_ID numeric,TRADE_VERSION numeric,LIQ_CONFIG_ID numeric,LINKED_ID numeric,LIQ_OVERRIDE numeric)
/

    ALTER TABLE TRADE_OPENQTY_SNAP MODIFY (TOQ_ID numeric,VERSION_NUM numeric,TRADE_ID numeric,PRODUCT_ID numeric,UPDATE_INFO numeric,BOOK_ID numeric,SIGN numeric,IS_LIQUIDABLE numeric,IS_RETURN numeric,CA_ID numeric,LIQ_AGG_ID numeric,POSITION_ID numeric,TRADE_VERSION numeric,LIQ_CONFIG_ID numeric,LINKED_ID numeric,LIQ_OVERRIDE numeric)
/

    ALTER TABLE TOQ_ETD MODIFY (TOQ_ID numeric,IS_CLOSING numeric)
/

    ALTER TABLE TOQ_ETD_SNAP MODIFY (TOQ_ID numeric,IS_CLOSING numeric)
/

    ALTER TABLE TOQ_ETD_HIST MODIFY (TOQ_ID numeric,IS_CLOSING numeric)
/

    ALTER TABLE ARCH_TOQ MODIFY (TRADE_ID numeric)
/

    ALTER TABLE TOQ_PRODUCT_TEMP MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE TRADE_PRICE MODIFY (TRADE_ID numeric,MEASURE_ID numeric)
/

    ALTER TABLE TRADE_PRICE_HIST MODIFY (TRADE_ID numeric,MEASURE_ID numeric)
/

    ALTER TABLE TRADE_ROLE_ALLOC MODIFY (TRADE_ID numeric,LEGAL_ENTITY_ID numeric,REL_TRADE_ID numeric,ALLOCATABLE_CHANGED numeric,BOOK_ID numeric,STRATEGY_ID numeric,ORDER_ID numeric)
/

    ALTER TABLE TRADE_TMPL_KEYWORD MODIFY (PRIVATE_B numeric)
/

    ALTER TABLE TRADE_XFER_RULE MODIFY (TRADE_ID numeric,PRODUCT_ID numeric,PAYER_ID numeric,PAYER_SDID numeric,RECEIVER_ID numeric,RECEIVER_SDID numeric,SEQ_NUMBER numeric,NETTING_METHOD_ID numeric,SECURITY_ID numeric,MANUAL_SDI numeric,INT_SDI_VERSION numeric,EXT_SDI_VERSION numeric)
/

    ALTER TABLE TRANSFER_RECONCIL MODIFY (TRANSFER_ID numeric,TRADE_ID numeric,PAYER_SDI numeric,RECEIVER_SDI numeric,MSG_ID numeric,PAY_SDI_V numeric,REC_SDI_V numeric)
/

    ALTER TABLE TRD_ALLOC_VAL_HIST MODIFY (TRADE_ID numeric,REL_TRADE_ID numeric)
/

    ALTER TABLE TRD_ROLEALLOC_HIST MODIFY (TRADE_ID numeric,LEGAL_ENTITY_ID numeric,REL_TRADE_ID numeric,ALLOCATABLE_CHANGED numeric,BOOK_ID numeric,STRATEGY_ID numeric,ORDER_ID numeric)
/

    ALTER TABLE TRD_XFER_RULE_HIST MODIFY (TRADE_ID numeric,PRODUCT_ID numeric,PAYER_ID numeric,PAYER_SDID numeric,RECEIVER_ID numeric,RECEIVER_SDID numeric,SEQ_NUMBER numeric,NETTING_METHOD_ID numeric,SECURITY_ID numeric,MANUAL_SDI numeric,INT_SDI_VERSION numeric,EXT_SDI_VERSION numeric)
/

    ALTER TABLE TREE_NODE MODIFY (NODE_ID numeric,PARENT_ID numeric)
/

    ALTER TABLE TRFILTER_MINMAX_DT MODIFY (TENOR_MIN numeric,TENOR_MAX numeric,TIME_MIN numeric,TIME_MAX numeric)
/

    ALTER TABLE TRIGGER_INFO MODIFY (PRODUCT_ID numeric,IS_ATM_PAYOFF numeric,TRIGGER_LAG numeric,TRIGGER_BUS_B numeric,DEFAULT_OFFSET_B numeric,TRIGGER_INDEX_ID numeric)
/

    ALTER TABLE TWS_BLOTTER_NODE MODIFY (TREE_NODE_ID numeric,BLOTTER_NODE_TYPE numeric,REPORT_TEMPLATE_ID numeric)
/

    ALTER TABLE TWS_NODE MODIFY (TREE_NODE_ID numeric,TWS_NODE_TYPE numeric,AUTO_UPDATE_B numeric,UPDATE_FREQUENCY numeric)
/

    ALTER TABLE TWS_RISK_NODE MODIFY (TREE_NODE_ID numeric)
/

    ALTER TABLE UNITIZED_FUND MODIFY (PRODUCT_ID numeric,PAYMENT_LAG numeric,RESET_LAG numeric,PAYS_PERFORMANCE_DIVIDENDS numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,CUSTOM_FLOWS_B numeric,FLOWS_FLAG numeric,PAYS_DAILY_DIVIDENDS numeric,PAYMENT_ROLLING_DAY numeric,REBATE_LAG numeric,REBATE_ROLLING_DAY numeric,SETTLEMENT_DAYS numeric,UNITS_DECIMALS numeric,PRICE_DECIMALS numeric,CUM_PRICE_DECIMALS numeric,DAILY_DIV_DECIMALS numeric,CUT_OFF_TIME numeric)
/

    ALTER TABLE ETF_FUND MODIFY (PRODUCT_ID numeric,PAYMENT_LAG numeric,RESET_LAG numeric,PAYS_PERFORMANCE_DIVIDENDS numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,CUSTOM_FLOWS_B numeric,FLOWS_FLAG numeric,PAYS_DAILY_DIVIDENDS numeric,PAYMENT_ROLLING_DAY numeric,REBATE_LAG numeric,REBATE_ROLLING_DAY numeric,SETTLEMENT_DAYS numeric,UNITS_DECIMALS numeric,PRICE_DECIMALS numeric,CUM_PRICE_DECIMALS numeric,DAILY_DIV_DECIMALS numeric,CUT_OFF_TIME numeric)
/

    ALTER TABLE MANDATE MODIFY (PRODUCT_ID numeric,PAYMENT_LAG numeric,RESET_LAG numeric,PAYS_PERFORMANCE_DIVIDENDS numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,CUSTOM_FLOWS_B numeric,FLOWS_FLAG numeric,PAYS_DAILY_DIVIDENDS numeric,PAYMENT_ROLLING_DAY numeric,REBATE_LAG numeric,REBATE_ROLLING_DAY numeric,SETTLEMENT_DAYS numeric,UNITS_DECIMALS numeric,PRICE_DECIMALS numeric,CUM_PRICE_DECIMALS numeric,DAILY_DIV_DECIMALS numeric,CUT_OFF_TIME numeric)
/

    ALTER TABLE SHARE_CLASS MODIFY (PRODUCT_ID numeric,PRICE_DECIMALS numeric,UNITIZED_FUND_ID numeric)
/

    ALTER TABLE SERIES MODIFY (PRODUCT_ID numeric,MAIN_SERIES_ID numeric,SHARE_CLASS_ID numeric,PRICE_DECIMALS numeric,UNITIZED_FUND_ID numeric)
/

    ALTER TABLE UNITIZED_FUND_UNIT MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE USER_DEFAULTS MODIFY (DEFAULT_BOOK_ID numeric,SHOW_TRADE_MENU_B numeric,PROCESS_ORG_ID numeric,RATE_DECIMALS numeric,VERSION_NUM numeric,CLEAR_AFTER_SAVE_B numeric)
/

    ALTER TABLE USER_GROUP_NAME MODIFY (IS_ADMIN_B numeric,IS_SYSTEM_B numeric,IS_DELEGATION_B numeric)
/

    ALTER TABLE USER_LAST_LOGIN MODIFY (NUMBER_ATTEMPT numeric,NUMBER_LOGIN numeric)
/

    ALTER TABLE USER_LOGIN_ATT MODIFY (LOGIN_SUCC numeric,DAY_SEQUENCE numeric)
/

    ALTER TABLE USER_LOGIN_HIST MODIFY (LOGIN_SUCC numeric,DAY_SEQUENCE numeric)
/

    ALTER TABLE USER_NAME MODIFY (PASSWD_MIN_LENGTH numeric,CHECK_DIGIT numeric,CHECK_SPEC_CHAR numeric,THRESHOLD_DAYS numeric,THRESHOLD_LOGINS numeric,USE_THRESHOLD_DAYS numeric,MAX_LOGIN_ATT numeric,LOGIN_IDDLE_DAYS numeric,ACC_LOCKED_REASON numeric,PASSWD_CHANGE_DUE numeric,PO_ID numeric)
/

    ALTER TABLE USER_VIEWER_BOOK MODIFY (BOOK_ID numeric)
/

    ALTER TABLE USER_VIEWER_BUNDLE MODIFY (BUNDLE_ID numeric)
/

    ALTER TABLE USER_VIEWER_COLUMN MODIFY (COLUMN_POSITION numeric)
/

    ALTER TABLE USER_VIEWER_DEF MODIFY (TIMER_INTERVAL numeric,REAL_TIME_B numeric,PFOL_ASOF_VDATE_B numeric)
/

    ALTER TABLE USER_VIEWER_LE MODIFY (LE_ID numeric)
/

    ALTER TABLE USR_ACCESS_PERM MODIFY (VERSION_NUM numeric,AUTO_LOGOUT numeric)
/

    ALTER TABLE VAR_DATASET MODIFY (DATASET_ID numeric)
/

    ALTER TABLE VAR_DATASET_CORR MODIFY (DATASET_DATA_ID numeric,RISK_FACTOR_ID1 numeric,RISK_FACTOR_ID2 numeric)
/

    ALTER TABLE VAR_DATASET_DATA MODIFY (DATASET_ID numeric,DATASET_DATA_ID numeric)
/

    ALTER TABLE VAR_DATASET_FACTOR MODIFY (DATASET_ID numeric,RISK_FACTOR_ID numeric)
/

    ALTER TABLE VAR_DATASET_VOL MODIFY (DATASET_DATA_ID numeric,RISK_FACTOR_ID numeric)
/

    ALTER TABLE VAR_RISK_FACTOR MODIFY (RISK_FACTOR_ID numeric,TENOR numeric)
/

    ALTER TABLE VOL_PT_BLOB MODIFY (VOL_SURFACE_ID numeric)
/

    ALTER TABLE VOL_PT_BLOB_HIST MODIFY (VOL_SURFACE_ID numeric)
/

    ALTER TABLE VOL_QUOTE_ADJ MODIFY (VOL_SURFACE_ID numeric)
/

    ALTER TABLE VOL_QUOTE_ADJ_HIST MODIFY (VOL_SURFACE_ID numeric)
/

    ALTER TABLE VOL_S_UND_CDSI_OPT MODIFY (VOL_SURF_UND_ID numeric,UND_PROD_ID numeric,OPTION_TYPE numeric)
/

    ALTER TABLE VOL_S_UND_OTC_EQT MODIFY (VOL_SURF_UND_ID numeric,UND_PROD_ID numeric,OPTION_TYPE numeric,TENOR numeric,STRIKE_REL_B numeric,DATE_RULE_ID numeric,RANK numeric)
/

    ALTER TABLE VOL_S_UND_WARRANT MODIFY (VOL_SURF_UND_ID numeric,UND_PROD_ID numeric,OPTION_TYPE numeric,TENOR numeric,STRIKE_REL_B numeric,DATE_RULE_ID numeric,RANK numeric)
/

    ALTER TABLE VOL_SRFEXPTEN_HIST MODIFY (VOL_SURFACE_ID numeric,VOL_SURFACE_TENOR numeric)
/

    ALTER TABLE VOL_SURF_EXPTENOR MODIFY (VOL_SURFACE_ID numeric,VOL_SURFACE_TENOR numeric)
/

    ALTER TABLE VOL_SURF_MDI_PARAM MODIFY (VOL_SURFACE_ID numeric,MDI_ID numeric)
/

    ALTER TABLE VOL_SURF_MDI_PARAM_HIST MODIFY (VOL_SURFACE_ID numeric,MDI_ID numeric)
/

    ALTER TABLE VOL_SURF_MEM_HIST MODIFY (VOL_SURFACE_ID numeric,VOL_SURF_UND_ID numeric)
/

    ALTER TABLE VOL_SURF_PARAM MODIFY (VOL_SURFACE_ID numeric)
/

    ALTER TABLE VOL_SURF_PNT_HIST MODIFY (VOL_SURFACE_ID numeric,VOL_SURFACE_TENOR numeric,PT_INDEX numeric)
/

    ALTER TABLE VOL_SURF_POINTADJ MODIFY (VOL_SURFACE_ID numeric,VOL_SURFACE_TENOR numeric,PT_INDEX numeric)
/

    ALTER TABLE VOL_SURF_QTVALUE MODIFY (VOL_SURFACE_ID numeric)
/

    ALTER TABLE VOL_SURF_STRK_HIST MODIFY (VOL_SURFACE_ID numeric)
/

    ALTER TABLE VOL_SURF_UND MODIFY (VOL_SURF_UND_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE VOL_SURF_UND_OTC_OPTION MODIFY (VOL_SURF_UND_ID numeric,UND_PROD_ID numeric,OPTION_TYPE numeric,TENOR numeric)
/

    ALTER TABLE VOL_SURF_UND_CAP MODIFY (VOL_SURF_UND_ID numeric,MATURITY_TENOR numeric,STRIKE_REL_B numeric,START_TENOR numeric,INCLUDE_FIRST_B numeric)
/

    ALTER TABLE VOL_SURF_UND_FOPT MODIFY (VOL_SURF_UND_ID numeric,CONTRACT_ID numeric,RANK numeric,STRIKE_REL_B numeric,SERIAL_B numeric)
/

    ALTER TABLE VOL_SURF_UND_FXOPT MODIFY (VOL_SURF_UND_ID numeric,MATURITY_TENOR numeric,DELTA numeric)
/

    ALTER TABLE VOL_SURF_UND_OPT MODIFY (VOL_SURF_UND_ID numeric,CONTRACT_ID numeric,RANK numeric,STRIKE_REL_B numeric,PRODUCT_ID numeric)
/

    ALTER TABLE VOL_SURF_UND_COMMOPT MODIFY (VOL_SURF_UND_ID numeric,PRODUCT_ID numeric,VOL_TYPE_ID numeric,DATE_FORMAT_DAILY_B numeric,SPREAD_VOL_B numeric,EXPIRY_TENOR numeric,PILLAR_TENOR numeric,UNDERLYING_RANK numeric)
/

    ALTER TABLE VOL_SURF_UND_SWPT MODIFY (VOL_SURF_UND_ID numeric,EXPIRATION_TENOR numeric,PAY_FIXED_B numeric,MATURITY_TENOR numeric,FIXED_RATE_REL_B numeric)
/

    ALTER TABLE VOL_SURF_UND_SPREAD_CAP MODIFY (VOL_SURF_UND_ID numeric,MATURITY_TENOR numeric,DATE_ROLL_CODE numeric,FREQUENCY_CODE numeric,STRIKE_REL_B numeric,START_TENOR numeric)
/

    ALTER TABLE VOL_SURFACE MODIFY (VOL_SURFACE_ID numeric,PRICE_VOL_B numeric,IS_SIMPLE_B numeric,RATE_INDEX_TENOR numeric,VOL_FWD_B numeric,PRODUCT_ID numeric,ISSUER_ID numeric,TICKER_ID numeric,VERSION_NUM numeric,BASKET_ID numeric)
/

    ALTER TABLE VOL_SURFACE_HIST MODIFY (VOL_SURFACE_ID numeric,PRICE_VOL_B numeric,IS_SIMPLE_B numeric,RATE_INDEX_TENOR numeric,VOL_FWD_B numeric,PRODUCT_ID numeric,ISSUER_ID numeric,TICKER_ID numeric,VERSION_NUM numeric,BASKET_ID numeric)
/

    ALTER TABLE VOL_SURFACE_MEMBER MODIFY (VOL_SURFACE_ID numeric,VOL_SURF_UND_ID numeric)
/

    ALTER TABLE VOL_SURFACE_POINT MODIFY (VOL_SURFACE_ID numeric,VOL_SURFACE_TENOR numeric,PT_INDEX numeric)
/

    ALTER TABLE VOL_SURFACE_POINT_TYPE_SWAP MODIFY (VOL_SURFACE_ID numeric,CU_SWAP_RATE_INDEX_TENOR numeric,MAN_FIRST_RESET_B numeric,SPC_LAG_B numeric,SPC_LAG_OFFSET numeric,SPC_LAG_BUS_CAL_B numeric,PRINCIPAL_ACTUAL_B numeric,DISCOUNT_METHOD numeric,CHK_FIRST_RESET_B numeric)
/

    ALTER TABLE VOL_SURF_POINT_TYPE_SWAP_HIST MODIFY (VOL_SURFACE_ID numeric,CU_SWAP_RATE_INDEX_TENOR numeric,MAN_FIRST_RESET_B numeric,SPC_LAG_B numeric,SPC_LAG_OFFSET numeric,SPC_LAG_BUS_CAL_B numeric,PRINCIPAL_ACTUAL_B numeric,DISCOUNT_METHOD numeric,CHK_FIRST_RESET_B numeric)
/

    ALTER TABLE VOL_SURFACE_STRIKE MODIFY (VOL_SURFACE_ID numeric)
/

    ALTER TABLE VOL_SURFACE_TEMP MODIFY (ID numeric,VOL_SURFACE_ID numeric)
/

    ALTER TABLE VOL_SURFACE_TENOR MODIFY (VOL_SURFACE_ID numeric,VOL_SURFACE_TENOR numeric)
/

    ALTER TABLE VOL_SURFPARAM_HIST MODIFY (VOL_SURFACE_ID numeric)
/

    ALTER TABLE VOL_SURFPTADJ_HIST MODIFY (VOL_SURFACE_ID numeric,VOL_SURFACE_TENOR numeric,PT_INDEX numeric)
/

    ALTER TABLE VOL_SURFQTVAL_HIST MODIFY (VOL_SURFACE_ID numeric)
/

    ALTER TABLE VOL_SURFTENOR_HIST MODIFY (VOL_SURFACE_ID numeric,VOL_SURFACE_TENOR numeric)
/

    ALTER TABLE WATCH_MEMORY_PARA MODIFY (VALUE numeric)
/

    ALTER TABLE WFW_LAYOUT MODIFY (X_COORD numeric,Y_COORD numeric)
/

    ALTER TABLE WFW_TRANSITION MODIFY (WORKFLOW_ID numeric,USE_STP_B numeric,SAME_USER_B numeric,LOG_COMPLETED_B numeric,PROCESS_ORG_ID numeric,KICK_CUTOFF_B numeric,CREATE_TASK_B numeric,VERSION_NUM numeric,PREFERED_B numeric,UPDATE_ONLY_B numeric,GEN_INT_EVENT_B numeric,NEEDS_MAN_AUTH_B numeric,AUDIT_FILTER_ID numeric,GENERIC_COMMENT_B numeric)
/

    ALTER TABLE WORKFLOW_BREAK_CONFIG MODIFY (BREAK_CONFIG_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE WORKFLOW_BREAK_CLOSING_CONFIG MODIFY (BREAK_CONFIG_ID numeric,WORKFLOW_CONFIG_ID numeric)
/

    ALTER TABLE WORKFLOW_BREAK_CLOSING_ALIAS MODIFY (BREAK_ALIAS_ID numeric)
/

    ALTER TABLE WORK_SPACE MODIFY (USE_EXCL_FILTERS numeric,SHOW_SELECTED numeric,SHOW_ALL_TRADES numeric,REAL_TIME_CHANGE numeric,SHOW_POSITION numeric)
/

    ALTER TABLE WORK_SPACE_BOOKS MODIFY (BOOK_ID numeric)
/

    ALTER TABLE WORK_SPACE_BUNDLES MODIFY (BUNDLE_ID numeric)
/

    ALTER TABLE WORK_SPACE_TRADES MODIFY (TRADE_ID numeric)
/

    ALTER TABLE XCCY_SPOT_MISMATCH MODIFY (VERSION numeric,BOOK_ID numeric,SWAP_BOOK_ID numeric)
/

    ALTER TABLE XCCY_SWAP_EXT_INFO MODIFY (PRODUCT_ID numeric,FX_RESET_B numeric,PAY_SIDE_RESET_B numeric,DEFAULT_FX_RESET_B numeric,FX_RESET_OFFSET numeric,FX_RESET_ID numeric,ADJ_FIRST_FLW_B numeric,USE_IDX_RST_DATE_B numeric)
/

    ALTER TABLE XFER_ATTR_HIST MODIFY (TRANSFER_ID numeric)
/

    ALTER TABLE XFER_ATTRIBUTES MODIFY (TRANSFER_ID numeric)
/

    ALTER TABLE PERF_SWAP_LEG MODIFY (PRODUCT_ID numeric,PERF_SWAP_ID numeric,LEG_ID numeric,REF_ASSET_ID numeric,RET_OFFSET numeric,RET_ROLLING_DAY numeric,RET_RESET_OFFSET numeric,RET_RESET_ROLL_DAY numeric,INCOME_OFFSET numeric,INCOME_ROLLING_DAY numeric,CASHFLOW_CHANGED numeric,CASHFLOW_LOCKS numeric,FX_RESET_ID numeric,RET_DATE_RULE numeric,FX_PERF_B numeric,MKT_IDX_OLD_PERF_CALC_B numeric,ACCRUAL_CALC_METHOD numeric)
/

    ALTER TABLE PERF_SWAP_LEG_HIST MODIFY (PRODUCT_ID numeric,PERF_SWAP_ID numeric,LEG_ID numeric,REF_ASSET_ID numeric,RET_OFFSET numeric,RET_ROLLING_DAY numeric,RET_RESET_OFFSET numeric,RET_RESET_ROLL_DAY numeric,INCOME_OFFSET numeric,INCOME_ROLLING_DAY numeric,CASHFLOW_CHANGED numeric,CASHFLOW_LOCKS numeric,FX_RESET_ID numeric,RET_DATE_RULE numeric,FX_PERF_B numeric,MKT_IDX_OLD_PERF_CALC_B numeric,ACCRUAL_CALC_METHOD numeric)
/

    ALTER TABLE CA_DEFAULTS MODIFY (CA_DEFAULTS_ID numeric,QUANTITY_DECIMALS numeric,STRIKE_DECIMALS numeric,FACTOR_DECIMALS numeric,VERSION_NUM numeric)
/

    ALTER TABLE CA_RULES MODIFY (ID numeric,QUANTITY_DECIMALS numeric,STRIKE_DECIMALS numeric,FACTOR_DECIMALS numeric,VERSION_NUM numeric,BARRIER_DECIMALS numeric,IS_DEFAULT numeric,SPECIAL_DIVIDEND numeric,PAY_LAG numeric)
/

    ALTER TABLE TWS_REPORT_NODE MODIFY (TREE_NODE_ID numeric,REPORT_TEMPLATE_ID numeric)
/

    ALTER TABLE TWS_RISK_AGGREGATION_NODE MODIFY (TREE_NODE_ID numeric,REPORT_TEMPLATE_ID numeric,USE_LATEST_RUN numeric)
/

    ALTER TABLE MARK MODIFY (MARK_ID numeric,TRADE_ID numeric,DISPLAY_DIGITS numeric,VERSION_NUM numeric)
/

    ALTER TABLE PRODUCT_PS MODIFY (PRODUCT_ID numeric,DATE_CALC_METHOD numeric,FLOWS_FLAG numeric,PRIMARY_LEG_ID numeric,SECONDARY_LEG_ID numeric)
/

    ALTER TABLE PRODUCT_PS_HIST MODIFY (PRODUCT_ID numeric,DATE_CALC_METHOD numeric,FLOWS_FLAG numeric,PRIMARY_LEG_ID numeric,SECONDARY_LEG_ID numeric)
/

    ALTER TABLE ARCH_CRE_TMP MODIFY (CRE_ID numeric)
/

    ALTER TABLE ARCH_TRADE MODIFY (TRADE_ID numeric,NET_ID numeric)
/

    ALTER TABLE ARCH_TRADE_HIST MODIFY (TRADE_ID numeric,NET_ID numeric)
/

    ALTER TABLE ARCH_TRADE_ID MODIFY (TRADE_ID numeric)
/

    ALTER TABLE ARCH_TRADE_TO_DELETE MODIFY (TRADE_ID numeric,NET_ID numeric)
/

    ALTER TABLE ARCH_PARTIAL_TRADE_IDS MODIFY (TRADE_ID numeric)
/

    ALTER TABLE ARCH_TRADE_NO_SYNC MODIFY (TRADE_ID numeric)
/

    ALTER TABLE ARCH_TRANSFER_NO_SYNC MODIFY (TRANSFER_ID numeric)
/

    ALTER TABLE ARCH_QUANTILE MODIFY (TRADE_ID numeric)
/

    ALTER TABLE ARCH_QUANTILE_NO_SYNC MODIFY (TRADE_ID numeric)
/

    ALTER TABLE ARCH_TRANSFER MODIFY (TRANSFER_ID numeric,NET_ID numeric)
/

    ALTER TABLE ARCHIVED_POS_TRADE_ID MODIFY (POSITION_ID numeric,TRADE_ID numeric)
/

    ALTER TABLE FX_VOL_SPREAD MODIFY (VOL_SURFACE_ID numeric,PARENT_SURFACE_ID numeric,USE_GEN_PARAMS_FROM_PARENT numeric)
/

    ALTER TABLE FX_VOL_SPREAD_HIST MODIFY (VOL_SURFACE_ID numeric,PARENT_SURFACE_ID numeric,USE_GEN_PARAMS_FROM_PARENT numeric)
/

    ALTER TABLE FX_VOL_COR MODIFY (VOL_SURFACE_ID numeric,LEG1_VOL_SURFACE_ID numeric,LEG2_VOL_SURFACE_ID numeric,CORRELATION_MATRIX_ID numeric)
/

    ALTER TABLE FX_VOL_COR_HIST MODIFY (VOL_SURFACE_ID numeric,LEG1_VOL_SURFACE_ID numeric,LEG2_VOL_SURFACE_ID numeric,CORRELATION_MATRIX_ID numeric)
/

    ALTER TABLE MDATA_LSV MODIFY (MDATA_ID numeric,PRODUCT_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE ARCH_TRANSFER_HIST MODIFY (TRANSFER_ID numeric,NET_ID numeric)
/

    ALTER TABLE ARCH_MESSAGE MODIFY (MESSAGE_ID numeric,NET_ID numeric)
/

    ALTER TABLE ARCH_MESSAGE_HIST MODIFY (MESSAGE_ID numeric,NET_ID numeric)
/

    ALTER TABLE ARCH_TASK_ENRICHMENT MODIFY (TASK_ID numeric)
/

    ALTER TABLE PRESENTATION_CONFIG MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE MKTDATA_SERVER_CONFIG MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE VOL_SURF_UND_FXOPT_SPR MODIFY (VOL_SURF_UND_ID numeric,PARENT_UND_ID numeric)
/

    ALTER TABLE USER_LAYOUT_DATA MODIFY (DATA_VERSION numeric)
/

    ALTER TABLE MDS_MKTDATA_SET MODIFY (ID numeric)
/

    ALTER TABLE TRADE_SEARCH MODIFY (SEARCH_VERSION numeric)
/

    ALTER TABLE CURVE_BORROW_HEADER MODIFY (CURVE_ID numeric,PRODUCT_ID numeric)
/

    ALTER TABLE CURVE_BORROWHDR_HIST MODIFY (CURVE_ID numeric,PRODUCT_ID numeric)
/

    ALTER TABLE CURVE_CONV_YIELD_HEADER MODIFY (CURVE_ID numeric,PRODUCT_ID numeric)
/

    ALTER TABLE CURVE_CONV_YIELDHDR_HIST MODIFY (CURVE_ID numeric,PRODUCT_ID numeric)
/

    ALTER TABLE BASKET_NOTIONAL_DEFAULT MODIFY (BASKET_ID numeric)
/

    ALTER TABLE DUAL_CCY_MM_EXT_INFO MODIFY (PRODUCT_ID numeric,FXRESET_ID numeric,PHYSICAL_SETTLEMENT_B numeric,USE_IDX_RST_DATE_B numeric)
/

    ALTER TABLE DUAL_CCY_MM_EXT_INFO_HIST MODIFY (PRODUCT_ID numeric,FXRESET_ID numeric,PHYSICAL_SETTLEMENT_B numeric,USE_IDX_RST_DATE_B numeric)
/

    ALTER TABLE COMMODITY_FWD_POINT_GENERATOR MODIFY (ID numeric,FWDPOINTDATERULE numeric,PILLARDATERULE numeric,DATEFORMAT numeric,NOOFFWDPOINTS numeric,UNDERLYING_PRODUCT numeric,VERSION_NUM numeric,CONTRACT_SIZE numeric)
/

    ALTER TABLE CU_COMMODITY_SPREAD MODIFY (CU_ID numeric,GENERATOR_ID numeric,RANK numeric)
/

    ALTER TABLE CU_COMM_SPREAD_GENERATOR MODIFY (ID numeric,FWDPOINTDATERULE numeric,PILLARDATERULE numeric,NOOFFWDPOINTS numeric,UNDERLYING_PRODUCT numeric,VERSION_NUM numeric)
/

    ALTER TABLE CU_COMMODITY_FWD_POINT MODIFY (CU_ID numeric,GENERATOR_ID numeric,RANK numeric)
/

    ALTER TABLE CU_COMMODITY_SWAP MODIFY (CU_ID numeric,GENERATOR_ID numeric,RANK numeric)
/

    ALTER TABLE CU_COMM_SWAP_GENERATOR MODIFY (ID numeric,NOOFFWDPOINTS numeric,COMM_RESET_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE CU_COMMODITY_SPOT MODIFY (CU_ID numeric,COMM_ID numeric,NB_SPOT_DAYS numeric)
/

    ALTER TABLE CU_COMMODITY_FORWARD MODIFY (CU_ID numeric,COMM_ID numeric,RANK numeric)
/

    ALTER TABLE TASK_INTERNAL_REF MODIFY (ID numeric,TASK_LEVEL numeric,SEQUENCE numeric,VERSION_NUM numeric)
/

    ALTER TABLE TASK_PRIORITY MODIFY (ID numeric,SEQUENCE numeric,INITIAL_PRIORITY numeric,CREATION_DATE_B numeric,VERSION_NUM numeric)
/

    ALTER TABLE TASK_PRIORITY_TIME MODIFY (TASK_PRIORITY_TIME_ID numeric,TASK_PRIORITY_ID numeric,PRIORITY numeric,ABSOLUTE_B numeric,CHECK_HOLIDAY_B numeric)
/

    ALTER TABLE PRODUCT_PREFERRED_SHARE MODIFY (PRODUCT_ID numeric,ACCRUAL_DIGITS numeric,SETTLE_DAYS numeric,PRICE_DIGITS numeric)
/

    ALTER TABLE DIVIDEND_CALC_INFO MODIFY (PRODUCT_ID numeric,B_CUMULATIVE numeric,EX_DIVIDEND_DAYS numeric,ROLLING_DAY numeric,DIVIDEND_DECIMALS numeric,PAYMENT_LAG numeric,BUSINESS_B numeric,DATE_RULE numeric,RESET_DAYS numeric,RESETLAG_BUS_B numeric,RESET_DECIMALS numeric,RECORD_DAYS numeric,RECORD_DAYS_B numeric,EX_DIVIDEND_DAYS_B numeric)
/

    ALTER TABLE PRODUCT_CDSLOAN MODIFY (PRODUCT_ID numeric,SECURED_LIST_B numeric,CANCELLABLE_B numeric)
/

    ALTER TABLE CDS_SETTLEMENT_MATRIX MODIFY (MATRIX_ID numeric,ALL_GUARANTEES_B numeric,NOTICE_INFO_AVAILABLE_B numeric,ESCROW_B numeric,CAP_SETTLE_B numeric,ISDA_DEFN_2009_B numeric,MONOLINE_SUPPL_B numeric,PMT_OFFSET numeric,PMT_OFST_BUS_DAY_B numeric,VERSION_NUM numeric)
/

    ALTER TABLE MATRIX_TERMINATION_EVENTS MODIFY (MATRIX_ID numeric,REF_ASSET_ID numeric,GRACE_PERIOD_B numeric,GRACE_PERIOD_DAYS numeric,GRACE_PERIOD_BUS_B numeric,MULTIPLE_HOLDER_B numeric)
/

    ALTER TABLE MATRIX_REF_CHARACTERISTIC MODIFY (MATRIX_ID numeric)
/

    ALTER TABLE MATRIX_DEL_CHARACTERISTIC MODIFY (MATRIX_ID numeric)
/

    ALTER TABLE MATRIX_PMT_HOLIDAYS MODIFY (MATRIX_ID numeric)
/

    ALTER TABLE MATRIX_ADDL_PROVISIONS MODIFY (MATRIX_ID numeric)
/

    ALTER TABLE MATRIX_SETTLEMENT_CONDITIONS MODIFY (MATRIX_ID numeric)
/

    ALTER TABLE CDSBASKET_SETTLEMENT_MATRIX MODIFY (PRODUCT_ID numeric,LEGAL_ENTITY_ID numeric,MATRIX_ID numeric)
/

    ALTER TABLE ENGINE_PROCESS MODIFY (OBJECT_ID numeric,OBJECT_VERSION numeric)
/

    ALTER TABLE ENGINE_PROCESS_HIST MODIFY (OBJECT_ID numeric,OBJECT_VERSION numeric)
/

    ALTER TABLE GENERIC_OPTION_INFO MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_GENERIC_OPTION MODIFY (PRODUCT_ID numeric,UNDERLYING_ID numeric)
/

    ALTER TABLE PRODUCT_EQ_CLIQUET MODIFY (PRODUCT_ID numeric,UNDERLYING_ID numeric,FIXING_OFFSET numeric,FIXING_ROLL_DAY numeric,PAYMENT_LAG numeric)
/

    ALTER TABLE TARGET_DIRECTORY MODIFY (TARGET_ID numeric,BENE_ID numeric,ADDRESSEE_ID numeric,MAIN_BIC_B numeric,TYPE numeric,VERSION_NUM numeric)
/

    ALTER TABLE PRODUCT_SETTLE_OBL MODIFY (PRODUCT_ID numeric,SECURITY_ID numeric,LINKED_ID numeric)
/

    ALTER TABLE SETTLE_OBLIGATION MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE SUBORDINATION_SCHEDULE MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE COMMODITY_LEG2 MODIFY (LEG_ID numeric,LEG_TYPE numeric,COMM_RESET_ID numeric,FX_RESET_ID numeric,CASHFLOW_LOCKS numeric,CASHFLOW_CHANGED numeric,VERSION numeric,ROUND_UNIT_CONV_B numeric,CUST_FX_RND_DIG numeric,PAYOUT_TYPE_ID numeric,CTD_COMM_ID numeric,DST_ID numeric,PRICE_FIXING_DECIMALS numeric)
/

    ALTER TABLE PRODUCT_COMMODITY_SWAP2 MODIFY (PRODUCT_ID numeric,PAY_LEG_ID numeric,RECEIVE_LEG_ID numeric,CUSTOM_FLOWS_B numeric)
/

    ALTER TABLE PRODUCT_COMMODITY_OTCOPTION2 MODIFY (PRODUCT_ID numeric,LEG_ID numeric,CUSTOM_FLOWS_B numeric,IS_FORWARD_STARTING numeric,IS_NOTIONAL_QUOTED numeric,IS_STRIKE_RESET numeric,IS_STRIKE_RESET_MANUAL numeric)
/

    ALTER TABLE CF_SCH_GEN_PARAMS MODIFY (PRODUCT_ID numeric,LEG_ID numeric,PAYMENT_LAG numeric,FIXING_DATE_POLICY numeric,PAYMENT_OFFSET_BUS_B numeric,PAYMENT_DAY numeric,PAYMENT_DATE_RULE numeric,FX_RESET_ID numeric,INTRADAY_CONFIG_ID numeric,FX_END_LAG numeric,RESET_WEEKDAY numeric,GAS_OIL_IDX_AVG_PERIOD numeric,GAS_OIL_IDX_LAG numeric,GAS_OIL_IDX_RECALC numeric,FX_GAS_OIL_IDX_AVG_PERIOD numeric,FX_GAS_OIL_IDX_LAG numeric,FX_GAS_OIL_IDX_RECALC numeric)
/

    ALTER TABLE CASH_FLOW_COMMODITY MODIFY (PRODUCT_ID numeric,LEG_ID numeric,FLOW_ID numeric,COLLATERAL_ID numeric,FIXED_PRICE_B numeric,CUSTOM_FIXING_DATES_B numeric,MANUAL_AMT_B numeric,MANUAL_RESET_B numeric)
/

    ALTER TABLE CF_COMM_CUST_FIXING_DATES MODIFY (PRODUCT_ID numeric,LEG_ID numeric,FLOW_ID numeric)
/

    ALTER TABLE COMM_OPT_VOL_TYPE MODIFY (ID numeric,DELTA numeric)
/

    ALTER TABLE COMMODITY_VOL_POINT_GENERATOR MODIFY (ID numeric,PRODUCT_ID numeric,DATE_RULE_ID numeric,PILLAR_DATE_RULE_ID numeric,NUM_DATES_TO_GENERATE numeric,DATE_FORMAT_DAILY_B numeric,SPREAD_VOL_B numeric,VERSION_NUM numeric)
/

    ALTER TABLE PMT_FREQ_DETAILS MODIFY (PRODUCT_ID numeric,LEG_ID numeric)
/

    ALTER TABLE SWAP_SETTLE_INFO MODIFY (PRODUCT_ID numeric,LEG_ID numeric,FX_DEFAULT_RESET_B numeric,FX_RESET_OFFSET numeric,FX_RESET_ID numeric,FX_FIXED_RATE_B numeric)
/

    ALTER TABLE CASH_POSITION_SNAPSHOT MODIFY (PRODUCT_ID numeric,BOOK_ID numeric,POS_AGG_ID numeric)
/

    ALTER TABLE CASH_POSITION_SNAPSHOTTIMES MODIFY (BOOK_ID numeric)
/

    ALTER TABLE CDSABS_CORRECTION MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PL_MARK MODIFY (MARK_ID numeric,TRADE_ID numeric,POSITION_OR_TRADE_VERSION numeric,VERSION_NUM numeric,BOOK_ID numeric)
/

    ALTER TABLE PL_MARK_HIST MODIFY (MARK_ID numeric,TRADE_ID numeric,POSITION_OR_TRADE_VERSION numeric,VERSION_NUM numeric,BOOK_ID numeric)
/

    ALTER TABLE PL_MARK_TEMP MODIFY (MARK_ID numeric,TRADE_ID numeric,POSITION_OR_TRADE_VERSION numeric,VERSION_NUM numeric,BOOK_ID numeric)
/

    ALTER TABLE OFFICIAL_PL_AGGREGATE MODIFY (AGG_ID numeric,PL_CONFIG_ID numeric,BOOK_ID numeric,PL_UNIT_ID numeric,STRATEGY_ID numeric)
/

    ALTER TABLE official_pl_aggregate MODIFY (EFFECTIVE_PRODUCT_TYPE DEFAULT ' ')
/

    ALTER TABLE OFFICIAL_PL_AGGREGATE_ITEM MODIFY (AGG_TXN_ID numeric,AGG_ID numeric,JOB_ID numeric,MARK_ID numeric,MARK_VERSION_NUM numeric,TRADE_ID numeric,BOOK_ID numeric,PL_UNIT_ID numeric,PL_BUCKET_ID numeric,PL_CONFIG_ID numeric,INACTIVE_TRADE numeric,UNIT_FUNDING_CRYST_ID numeric,OBJECT_TYPE numeric,STRATEGY_ID numeric,AGG_NODE_ID numeric,AGG_ITEM_CHECKSUM numeric)
/

    ALTER TABLE official_pl_aggregate_item MODIFY (EFFECTIVE_PRODUCT_TYPE DEFAULT ' ')
/

    ALTER TABLE OFFICIAL_PL_CONSTITUENT_TREE MODIFY (AGG_NODE_ID numeric,CHILD_NODE_ID numeric,CHILD_NODE_TYPE numeric,TRADE_ID numeric,BOOK_ID numeric,PL_CONFIG_ID numeric,AGG_ID numeric)
/

    ALTER TABLE OFFICIAL_PL_MARK MODIFY (JOB_ID numeric,MARK_ID numeric,MARK_VERSION_NUM numeric,TRADE_ID numeric,BOOK_ID numeric,PL_UNIT_ID numeric,PL_BUCKET_ID numeric,PL_CONFIG_ID numeric,INACTIVE_TRADE numeric,UNIT_FUNDING_CRYST_ID numeric,OBJECT_TYPE numeric,STRATEGY_ID numeric,AGG_NODE_ID numeric,AGG_ITEM_CHECKSUM numeric)
/

    ALTER TABLE official_pl_mark MODIFY (EFFECTIVE_PRODUCT_TYPE DEFAULT ' ')
/

    ALTER TABLE OFFICIAL_PL_MARK_HIST MODIFY (JOB_ID numeric,MARK_ID numeric,MARK_VERSION_NUM numeric,TRADE_ID numeric,BOOK_ID numeric,PL_UNIT_ID numeric,PL_BUCKET_ID numeric,PL_CONFIG_ID numeric,INACTIVE_TRADE numeric,UNIT_FUNDING_CRYST_ID numeric,OBJECT_TYPE numeric,STRATEGY_ID numeric,AGG_NODE_ID numeric,AGG_ITEM_CHECKSUM numeric)
/

    ALTER TABLE official_pl_mark_hist MODIFY (EFFECTIVE_PRODUCT_TYPE DEFAULT ' ')
/

    ALTER TABLE OFFICIAL_PL_CRYSTALLIZED_MARK MODIFY (JOB_ID numeric,TRADE_ID numeric,BOOK_ID numeric,PL_UNIT_ID numeric,PL_BUCKET_ID numeric,PL_CONFIG_ID numeric)
/

    ALTER TABLE official_pl_crystallized_mark MODIFY (EFFECTIVE_PRODUCT_TYPE DEFAULT ' ')
/

    ALTER TABLE OFFICIAL_TRADE_ATTRS MODIFY (MARK_ID numeric,TRADE_ID numeric)
/

    ALTER TABLE OFFICIAL_TRADE_ATTRS_HIST MODIFY (MARK_ID numeric,TRADE_ID numeric)
/

    ALTER TABLE OFFICIAL_PL_UNIT_FUNDING_CRYST MODIFY (ID numeric,PL_CONFIG_ID numeric,BOOK_ID numeric)
/

    ALTER TABLE OFFICIAL_ERROR_MARK_DESC MODIFY (MARK_ID numeric,PL_CONFIG_ID numeric)
/

    ALTER TABLE OFFICIAL_ERROR_MARK_DESC_HIST MODIFY (MARK_ID numeric,PL_CONFIG_ID numeric)
/

    ALTER TABLE OFFICIAL_CORRECTION_MARK MODIFY (MARK_ID numeric,PL_CONFIG_ID numeric,TRADE_ID numeric)
/

    ALTER TABLE OFFICIAL_CORRECTION_MARK_HIST MODIFY (MARK_ID numeric,PL_CONFIG_ID numeric,TRADE_ID numeric)
/

    ALTER TABLE OFFICIAL_PL_BUCKET MODIFY (PL_BUCKET_ID numeric,SUBPRODUCT_ID numeric)
/

    ALTER TABLE OFFICIAL_PLMARK_ADJ MODIFY (MARK_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE OFFICIAL_PLMARK_ADJ_VALUE MODIFY (MARK_ID numeric)
/

    ALTER TABLE OFFICIAL_PLMARK_ADJ_HIST MODIFY (MARK_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE OFFICIAL_PLMARK_ADJ_VALUE_HIST MODIFY (MARK_ID numeric)
/

    ALTER TABLE OFFICIAL_PLMARK_PERM_ADJ MODIFY (PERMANENT_ADJ_ID numeric,PL_CONFIG_ID numeric,TRADE_ID numeric,PL_UNIT_ID numeric,PL_BUCKET_ID numeric,BOOK_ID numeric,IS_VALID numeric,VERSION_NUM numeric)
/

    ALTER TABLE OFFICIAL_PLMARK_PERM_ADJ_VALUE MODIFY (PERMANENT_ADJ_ID numeric)
/

    ALTER TABLE OFFICIAL_PL_UNIT MODIFY (PL_UNIT_ID numeric,BOOK_ID numeric,PO_ID numeric,IS_BY_TRADE numeric)
/

    ALTER TABLE OFFICIAL_PL_CONFIG MODIFY (YEAR_END_MONTH numeric,USE_CUSTOM_FX_HISTO_CALC numeric,IS_AGGREGATEINACTIVEMARKS numeric,INVESTMENT_PL numeric)
/
CREATE GLOBAL TEMPORARY TABLE official_pl_temp_id ( join_id numeric  NOT NULL ) ON COMMIT PRESERVE ROWS
/

    ALTER TABLE PL_MARK_VALUE MODIFY (MARK_ID numeric,DISPLAY_DIGITS numeric,IS_ADJUSTED numeric)
/

    ALTER TABLE PL_MARK_VALUE_HIST MODIFY (MARK_ID numeric,DISPLAY_DIGITS numeric,IS_ADJUSTED numeric,IS_DERIVED numeric)
/

    ALTER TABLE PL_MARK_VALUE_TEMP MODIFY (MARK_ID numeric,DISPLAY_DIGITS numeric,IS_ADJUSTED numeric,IS_DERIVED numeric)
/

    ALTER TABLE PL_RISK_FACTOR MODIFY (TRADE_ID numeric)
/

    ALTER TABLE PL_MARK_BOOK_LOCK MODIFY (MARK_BOOK_LOCK_ID numeric,BOOK_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE FX_RESET_PRODUCT_INFO MODIFY (ID numeric,FX_RESET numeric)
/

    ALTER TABLE SORT_ORDER MODIFY (SORT_ID numeric,PRIVATE_B numeric)
/

    ALTER TABLE DEFAULTING_CONFIGURATION MODIFY (DEFAULTING_CONFIGURATION_ID numeric)
/

    ALTER TABLE DEFAULTING_CONFIGURATION_KEY MODIFY (DEFAULTING_CONFIGURATION_ID numeric,PRIORITY numeric)
/

    ALTER TABLE DEFAULTING_VALUE MODIFY (DEFAULTING_VALUE_ID numeric,DEFAULTING_CONFIGURATION_ID numeric)
/

    ALTER TABLE DEFAULTING_KEY MODIFY (DEFAULTING_VALUE_ID numeric)
/

    ALTER TABLE BETA_MATRIX MODIFY (ID numeric,USE_METHOD numeric,SPECIFIC_RISK numeric)
/

    ALTER TABLE HYPER_DATA_TYPE MODIFY (ID numeric)
/

    ALTER TABLE HYPER_DATA_DOMAIN MODIFY (ID numeric)
/

    ALTER TABLE HYPER_DATA_VALIDATOR MODIFY (ID numeric)
/

    ALTER TABLE HS_HEADER MODIFY (ID numeric)
/

    ALTER TABLE HS_GEN_PARAMS MODIFY (ID numeric)
/

    ALTER TABLE HS_HYPERSPACE MODIFY (ID numeric,SPACE_ISCONTINIOUS numeric)
/

    ALTER TABLE HS_SPACE_AXIS MODIFY (ID numeric,AXIS_ISRELATIVE numeric)
/

    ALTER TABLE HS_SPACE_VALUES MODIFY (ID numeric)
/

    ALTER TABLE HS_AXIS_TICKS MODIFY (ID numeric)
/

    ALTER TABLE HS_POINT_COORDINATES MODIFY (ID numeric,POINT_ID numeric)
/

    ALTER TABLE HS_POINT_VALUES MODIFY (ID numeric,POINT_ID numeric)
/

    ALTER TABLE HS_SPACE_MATCHERS MODIFY (ID numeric,MATCHER_NAME numeric)
/

    ALTER TABLE HS_CONTEXT_MDI MODIFY (ID numeric,MDI_ID numeric)
/

    ALTER TABLE HS_CONTEXT_MDU MODIFY (ID numeric,MDU_ID numeric)
/

    ALTER TABLE HS_CONTEXT_QV MODIFY (ID numeric,QUOTE_BID numeric,QUOTE_ASK numeric,QUOTE_OPEN numeric,QUOTE_CLOSE numeric)
/

    ALTER TABLE HS_DATATYPE_HIST MODIFY (ID numeric)
/

    ALTER TABLE HS_DATA_DOMAIN_HIST MODIFY (ID numeric)
/

    ALTER TABLE HS_VALIDATOR_HIST MODIFY (ID numeric)
/

    ALTER TABLE HS_HEADER_HIST MODIFY (ID numeric)
/

    ALTER TABLE HS_GEN_PARAM_HIST MODIFY (ID numeric)
/

    ALTER TABLE HS_SPACE_HIST MODIFY (ID numeric,SPACE_ISCONTINIOUS numeric)
/

    ALTER TABLE HS_AXIS_HIST MODIFY (ID numeric,AXIS_ISRELATIVE numeric)
/

    ALTER TABLE HS_VALUES_HIST MODIFY (ID numeric)
/

    ALTER TABLE HS_TICKS_HIST MODIFY (ID numeric)
/

    ALTER TABLE HS_COORD_HIST MODIFY (ID numeric,POINT_ID numeric)
/

    ALTER TABLE HS_VALUE_HIST MODIFY (ID numeric,POINT_ID numeric)
/

    ALTER TABLE HS_MATCHER_HIST MODIFY (ID numeric,MATCHER_NAME numeric)
/

    ALTER TABLE HS_CONTEXT_MDI_HIST MODIFY (ID numeric,MDI_ID numeric)
/

    ALTER TABLE HS_CONTEXT_MDU_HIST MODIFY (ID numeric,MDU_ID numeric)
/

    ALTER TABLE HS_CONTEXT_QV_HIST MODIFY (ID numeric,QUOTE_BID numeric,QUOTE_ASK numeric,QUOTE_OPEN numeric,QUOTE_CLOSE numeric)
/

    ALTER TABLE CALIBRATION_USAGE MODIFY (CONTEXT_ID numeric,TRADE_ID numeric)
/

    ALTER TABLE CALIBRATION MODIFY (CONTEXT_ID numeric,SEED_TRADE numeric)
/

    ALTER TABLE CALIBRATION_CONTEXT MODIFY (ID numeric)
/

    ALTER TABLE CALIBRATION_MODEL_PARAM MODIFY (CONTEXT_ID numeric,READ_ONLY numeric)
/

    ALTER TABLE MODEL_PARAM_SCALAR MODIFY (CONTEXT_ID numeric,INT_VALUE numeric)
/

    ALTER TABLE MODEL_PARAM_TIME_DEPENDENT MODIFY (CONTEXT_ID numeric)
/

    ALTER TABLE CALIBRATION_INSTRUMENT MODIFY (UNDERLYING_DEFAULTS_ID numeric,INSTRUMENT_INDEX numeric,CONTEXT_ID numeric)
/

    ALTER TABLE MODEL_CALIBRATION_INSTDATA MODIFY (MODEL_CALIBRATION_ID numeric,IS_RELATIVE_STRIKE_B numeric,IS_EXCLUDE_B numeric)
/

    ALTER TABLE CALIBRATION_INST_OVERRIDE MODIFY (UNDERLYING_DEFAULTS_ID numeric,INSTRUMENT_INDEX numeric,CONTEXT_ID numeric)
/

    ALTER TABLE INST_CTX_PRICER_MEASURE MODIFY (UNDERLYING_DEFAULTS_ID numeric,INSTRUMENT_INDEX numeric,CONTEXT_ID numeric)
/

    ALTER TABLE INST_CTX_MODEL_PARAM MODIFY (UNDERLYING_DEFAULTS_ID numeric,INSTRUMENT_INDEX numeric,CONTEXT_ID numeric)
/

    ALTER TABLE INSTRUMENT_CTX MODIFY (UNDERLYING_DEFAULTS_ID numeric,INSTRUMENT_INDEX numeric,CONTEXT_ID numeric)
/

    ALTER TABLE WHT_ATTRIBUTE MODIFY (WHT_ATTRIBUTE_ID numeric,LEGAL_ENTITY_ID numeric,PROCESSING_ORG_ID numeric,ENTITY_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE PRODUCT_EQ_STRUCT_OPTION MODIFY (PRODUCT_ID numeric,UNDERLYING_ID numeric,IS_OVERRIDEN_BASIS numeric,IS_AUTO_EXERCISE numeric,IS_PHYSICAL numeric,IS_SETTLE_DATE_LAG numeric,IS_SETTLE_BUS_DAY numeric,SETTLE_LAG_OFFSET numeric,FX_RESET_ID numeric,SPOT_FX_RESET_ID numeric,CASHFLOW_PAY_REC numeric,EQUITY_RESET_ID numeric)
/

    ALTER TABLE STRUCT_OPTION_EXT MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE OPTION_OBSERVATION_METHOD MODIFY (PRODUCT_ID numeric,VERSION numeric,SCHEDULE_ID numeric,IS_OV_BASIS numeric)
/

    ALTER TABLE OPTION_SCHEDULE_PARAMS MODIFY (SCHEDULE_ID numeric,DAY_OF_WEEK numeric,IS_CUSTOM numeric)
/

    ALTER TABLE OPTION_FORMULA MODIFY (PRODUCT_ID numeric,VERSION numeric,IS_CALL numeric)
/

    ALTER TABLE OPTION_FORMULA_PARAMS MODIFY (PARAM_ID numeric,PRODUCT_ID numeric)
/

    ALTER TABLE CLIQUET_FORMULA MODIFY (SCHEDULE_ID numeric,PRODUCT_ID numeric)
/

    ALTER TABLE CHOOSER_FORMULA MODIFY (UND_OP_SETTLE numeric,IS_EX_ON_CHOICE numeric,IS_STRIKE_PCT1 numeric,IS_CALL1 numeric,IS_STRIKE_PCT2 numeric,IS_CALL2 numeric,PRODUCT_ID numeric)
/

    ALTER TABLE COMPOUND_FORMULA MODIFY (STRIKE numeric,IS_EX_ON_CHOICE numeric,IS_STRIKE_PCT1 numeric,IS_CALL1 numeric,PRODUCT_ID numeric)
/

    ALTER TABLE COMPOUND_VANILLA_FORMULA MODIFY (IS_COMPOUND_PHYSICAL numeric,IS_COMPOUND_CALL numeric,IS_DELIVERABLE_PHYSICAL numeric,IS_DELIVERABLE_CALL numeric,DELIVERABLE_EXPIRY_TIME numeric,DELIVERABLE_SETTLE_TIME numeric,PRODUCT_ID numeric)
/

    ALTER TABLE OPTION_EXERCISE_STYLE MODIFY (PRODUCT_ID numeric,VERSION numeric)
/

    ALTER TABLE OPTION_OBSERVATION_SCHEDULE MODIFY (SCHEDULE_ID numeric,PRODUCT_ID numeric,CUSTOM numeric)
/

    ALTER TABLE OPTION_BARRIERS MODIFY (REBATE_IS_DATE_LAG numeric,REBATE_LAG_OFFSET numeric,REBATE_BUS_DAYS numeric,UNDERLYING_ID numeric,IS_FWD_STARTING numeric,IS_PERF_BASED numeric,ORDER_ID numeric,PRODUCT_ID numeric,START_TIME numeric,END_TIME numeric)
/

    ALTER TABLE PERIOD_DISTRIBUTION MODIFY (ID numeric,VERSION numeric)
/

    ALTER TABLE PERIOD_DIST_WEIGHT MODIFY (PERIOD_DIST_ID numeric,WEIGHT_INDEX numeric)
/

    ALTER TABLE INTRADAY_CONFIGURATION MODIFY (ID numeric,VERSION numeric)
/

    ALTER TABLE PRODUCT_STRUCTURED_OPTION_BC MODIFY (COMP_ID numeric,BASKET_ID numeric,PRODUCT_ID numeric)
/

    ALTER TABLE STATISTIC_SWAP_BC MODIFY (ID numeric,ASSET_ID numeric,BASKET_ID numeric,FIXING numeric,FX_RESET_ID numeric)
/

    ALTER TABLE DIVIDEND_SWAP_BC MODIFY (COMP_ID numeric,BASKET_ID numeric,PRODUCT_ID numeric)
/

    ALTER TABLE CORRELATION_SWAP_BC MODIFY (LOCAL_FXRESET_ID numeric,COMP_ID numeric,BASKET_ID numeric,PRODUCT_ID numeric)
/

    ALTER TABLE BASE_STATISTIC_BC MODIFY (COMP_ID numeric,BASKET_ID numeric,PRODUCT_ID numeric)
/

    ALTER TABLE EQUITY_FORWARD_BC MODIFY (COMP_ID numeric,BASKET_ID numeric,PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_FIXING MODIFY (PRODUCT_ID numeric,UNDERLYING_ID numeric)
/

    ALTER TABLE PRODUCT_FIXING_HIST MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE TRIPARTY_GCF_REPO_COLL MODIFY (TRADE_ID numeric,AGENT_ID numeric,PLEDGE_ID numeric,BOOK_ID numeric,MARGIN_CALL_CONTRACT numeric)
/

    ALTER TABLE TRIPARTY_ALLOCATION_RECORDS MODIFY (TRADE_ID numeric,AGENT_ID numeric,PLEDGE_ID numeric,BOOK_ID numeric,MARGIN_CALL_CONTRACT numeric,CURRENT_B numeric)
/

    ALTER TABLE TRIPARTY_ALLOCATION_ATTRIBUTES MODIFY (ENTITY_ID numeric)
/

    ALTER TABLE TRIPARTY_ALLOC_RECORDS_HIST MODIFY (TRADE_ID numeric,AGENT_ID numeric,PLEDGE_ID numeric,BOOK_ID numeric,MARGIN_CALL_CONTRACT numeric,CURRENT_B numeric)
/

    ALTER TABLE TRIPARTY_ALLOC_ATTRIBUTES_HIST MODIFY (ENTITY_ID numeric)
/

    ALTER TABLE NETTING_RUN_CONFIG MODIFY (CONFIG_ID numeric,CONFIG_VERSION numeric,TIME numeric,DAY_LAG numeric,PRIORITY numeric,UPDATE_NEXT_SETTLE_DATE numeric)
/

    ALTER TABLE WRONG_WAY_RISK_GROUP MODIFY (GROUP_ID numeric,GROUP_VERSION numeric)
/

    ALTER TABLE PL_DUMMY_TRADE MODIFY (TRADE_ID numeric,BOOK_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE PL_DUMMY_TRADE_KEYWORD MODIFY (TRADE_ID numeric)
/

    ALTER TABLE CURR_REF_ENT MODIFY (PRODUCT_ID numeric,REF_ENTITY_ID numeric)
/

    ALTER TABLE REF_BASKET_CURR_RESTRUCT_MAP MODIFY (REF_ENTITY_ID numeric,COMPONENT_ID numeric,MATRIX_ID numeric)
/

    ALTER TABLE REF_BASKET_CREDIT_EVNT_MAP MODIFY (REF_ENTITY_ID numeric,REF_ASSET_ID numeric,GRACE_PERIOD_B numeric,GRACE_PERIOD_DAYS numeric,GRACE_PERIOD_BUS_B numeric,MULTIPLE_HOLDER_B numeric)
/

    ALTER TABLE FORMATTING_STYLE MODIFY (ID numeric)
/

    ALTER TABLE SPEED_BUTTON MODIFY (BUTTON_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE VISOKIO_TEMPLATE MODIFY (VISOKIO_TEMPLATE_ID numeric)
/

    ALTER TABLE VISOKIO_TEMPLATE_NODE_MAPPING MODIFY (VISOKIO_TEMPLATE_ID numeric,TREE_NODE_ID numeric)
/

    ALTER TABLE TWS_VISOKIO_NODE MODIFY (TREE_NODE_ID numeric,VISOKIO_TEMPLATE_ID numeric,USE_LATEST_RUN numeric)
/

    ALTER TABLE OPTION_FLAVOR_BASE MODIFY (PRODUCT_ID numeric,UNDERLYING_ID numeric,IS_PHYSICAL numeric,IS_AUTO_EXERCISE numeric,EXPIRY_TIME numeric)
/

    ALTER TABLE FLAVOR_ACCRUAL MODIFY (PRODUCT_ID numeric,UNDERLYING_ID numeric,IS_PHYSICAL numeric,IS_AUTO_EXERCISE numeric,EXPIRY_TIME numeric,OBS_SOURCE_ID numeric,RESET_SOURCE_ID numeric,ACCRUAL_SCHEDULE_ID numeric,RESET_SCHEDULE_ID numeric,RESURRECTING numeric,NET_SETTLEMENT numeric)
/

    ALTER TABLE ACCRUAL_RANGE_DESCRIPTOR MODIFY (PRODUCT_ID numeric,IS_FIXED numeric,RANGE_TYPE numeric,LOW_INCLUDED numeric,HIGH_INCLUDED numeric,SPREAD_IS_PIPS numeric)
/

    ALTER TABLE ACCRUAL_SCHEDULE_PARAMS MODIFY (SCHEDULE_ID numeric,DAY_OF_WEEK numeric,IS_CUSTOM numeric,WEIGHT_HOLIDAYS numeric,WEIGHT_WEEKENDS numeric,ACCRUAL_OFFSET numeric,OFFSET_IS_BUS_DAYS numeric,ALLOW_WEEKEND numeric,ALLOW_HOLIDAY numeric)
/

    ALTER TABLE FLAVOR_DIGITAL MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE OPTION_TRIGGERS MODIFY (PRODUCT_ID numeric,ORDER_ID numeric,BARRIER_LEVEL_IN_PERCENT numeric,START_TIME numeric,END_TIME numeric,UNDERLYING_ID numeric)
/

    ALTER TABLE TRIANGULATION_CCY_RULESET MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE FX_RESET_PAIR MODIFY (FX_RESET_ID_1 numeric,FX_RESET_ID_2 numeric,VERSION_NUM numeric)
/

    ALTER TABLE PRODUCT_PL_SWEEP MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE VINTAGE_INFO MODIFY (PRODUCT_ID numeric,VINTAGE_YEAR numeric)
/

    ALTER TABLE COMMODITY_FUNGIBILITY MODIFY (LINK_ID numeric,COMMODITY_ID numeric,RESET_ID numeric)
/

    ALTER TABLE ADS_OUTPUT MODIFY (OUTPUT_ID numeric)
/

    ALTER TABLE ADS_HEADER MODIFY (OUTPUT_ID numeric,STORE_ID numeric,COLUMN_ID numeric,COLUMN_FORMAT numeric)
/

    ALTER TABLE ADS_VALUE_STRING MODIFY (OUTPUT_ID numeric,STORE_ID numeric,COLUMN_ID numeric,ROW_ID numeric)
/

    ALTER TABLE ADS_VALUE_NUMBER MODIFY (OUTPUT_ID numeric,STORE_ID numeric,COLUMN_ID numeric,ROW_ID numeric)
/

    ALTER TABLE ADS_STORE MODIFY (OUTPUT_ID numeric,STORE_COUNT numeric)
/

    ALTER TABLE ADS_DIMENSION MODIFY (OUTPUT_ID numeric,STORE_ID numeric,COLUMN_COUNT numeric,ROW_COUNT numeric)
/

    ALTER TABLE ADS_SCENARIO_RISK_VALUE MODIFY (OUTPUT_ID numeric,TRADE_ID numeric)
/

    ALTER TABLE ADS_SIMULATION_RISK_VALUE MODIFY (OUTPUT_ID numeric,TRADE_ID numeric)
/

    ALTER TABLE ADS_SCENARIO_RISK_MEASURE MODIFY (OUTPUT_ID numeric,UNDERLIER_ID numeric)
/

    ALTER TABLE ADS_SCENARIO_UNDERLIER MODIFY (OUTPUT_ID numeric,UNDERLIER_ID numeric)
/

    ALTER TABLE ADS_SCENARIO_TRADE_ATTRIBUTE MODIFY (OUTPUT_ID numeric,TRADE_ID numeric)
/

    ALTER TABLE BILLING_FEE MODIFY (PRODUCT_ID numeric,FEE_ID numeric,AGG_COUNT numeric,CALCULATOR_ID numeric,GRID_ID numeric,ACCOUNT_ID numeric,TRADE_ID numeric,TRADE_VERSION numeric,TRANSFER_ID numeric,TRANSFER_VERSION numeric,MESSAGE_ID numeric,MESSAGE_VERSION numeric,PO_ID numeric,BOOK_ID numeric,LE_ID numeric,FEE_BOOK_ID numeric,MANUAL_AMOUNT_B numeric,OVERRIDE_AMOUNT_B numeric,INCL_PRINCIPAL_B numeric)
/

    ALTER TABLE BILLING_ENTRY_DETAIL MODIFY (ID numeric,VERSION numeric,BILLING_TRADE_ID numeric,IS_AGGREGATED numeric,IS_REVERSED numeric,LINKED_ID numeric,CALCULATOR_ID numeric,GRID_ID numeric,ACCOUNT_ID numeric,TRADE_ID numeric,TRADE_VERSION numeric,TRANSFER_ID numeric,TRANSFER_VERSION numeric,MESSAGE_ID numeric,MESSAGE_VERSION numeric,PO_ID numeric,BOOK_ID numeric,LE_ID numeric,FEE_BOOK_ID numeric,MANUAL_AMOUNT_B numeric,OVERRIDE_AMOUNT_B numeric,INCL_PRINCIPAL_B numeric)
/

    ALTER TABLE PROCESS_STATUS MODIFY (ID numeric,TYPE numeric,SUBTYPE numeric,STATUS numeric,OBJECT_ID numeric,LINKED_ID numeric)
/

    ALTER TABLE SUCCESSION_EVENT MODIFY (EVENT_ID numeric)
/

    ALTER TABLE SUCCESSION_EVENT_ITEM MODIFY (EVENT_ID numeric,SOURCE_LE_ID numeric,DESTN_LE_ID numeric)
/

    ALTER TABLE SUCCESSION_EVENT_PARAMETER MODIFY (EVENT_ID numeric)
/

    ALTER TABLE TEMPLATE_BSKT_IMPORT_ID MODIFY (TEMPLATE_ID numeric,IS_PUBLIC numeric,IS_DEFAULT numeric,IS_RED_CODE numeric)
/

    ALTER TABLE TEMPLATE_BSKT_IMPORT_DETAILS MODIFY (TEMPLATE_ID numeric,COLUMN_POSITION numeric)
/

    ALTER TABLE CORR_SURF_ATTRIB_HIST MODIFY (SURFACE_ID numeric)
/

    ALTER TABLE CORR_SURF_BASISADJ_HIST MODIFY (SURFACE_ID numeric,OFFSET_DAYS numeric)
/

    ALTER TABLE CORR_SURF_DATA_HIST MODIFY (SURFACE_ID numeric,OFFSET_DAYS numeric)
/

    ALTER TABLE CORR_SURF_PARAMS_HIST MODIFY (SURFACE_ID numeric)
/

    ALTER TABLE CORR_SURF_PTADJ_HIST MODIFY (SURFACE_ID numeric,OFFSET_DAYS numeric)
/

    ALTER TABLE CORR_SURF_QTVALUE_HIST MODIFY (SURFACE_ID numeric)
/

    ALTER TABLE CORR_SURF_SPDATES_HIST MODIFY (SURFACE_ID numeric)
/

    ALTER TABLE CORR_SURF_TIMEAXIS_HIST MODIFY (SURFACE_ID numeric,OFFSET_DAYS numeric)
/

    ALTER TABLE CORR_SURF_UND_HIST MODIFY (CORR_SURF_UND_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE CORR_SURF_XAXIS_HIST MODIFY (SURFACE_ID numeric)
/

    ALTER TABLE CORR_SURF_INDEX_DEFN_HIST MODIFY (SURFACE_ID numeric,DEFINITION_ID numeric)
/

    ALTER TABLE CORR_SURFACE_HIST MODIFY (SURFACE_ID numeric,BASKET_ID numeric,IS_SIMPLE numeric,VERSION_NUM numeric,IS_INDEX numeric)
/

    ALTER TABLE CORR_SURFACE_MEMBER_HIST MODIFY (SURFACE_ID numeric,SURFACE_UND_ID numeric)
/

    ALTER TABLE DATE_WITH_COMMENT MODIFY (DATE_RULE_ID numeric)
/

    ALTER TABLE DEAL_STATION_USER_CONFIG MODIFY (ID numeric,STYLE numeric,VERSION_NUM numeric)
/

    ALTER TABLE BAI_TYPE_CODE MODIFY (ENTITY_ID numeric)
/

    ALTER TABLE PL_ARCHIVE_TRADE MODIFY (TRADE_ID numeric,BOOK_ID numeric,LIQ_AGG_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE PL_ARCHIVE_TRADE_MAP MODIFY (ARCHIVE_TRADE_ID numeric,ORIG_TRADE_ID numeric,BOOK_ID numeric,LIQ_AGG_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE PRODUCT_CCDS MODIFY (PRODUCT_ID numeric,RPS_B numeric)
/

    ALTER TABLE CCDS_UND_TRADES MODIFY (PRODUCT_ID numeric,TRADE_ID numeric)
/

    ALTER TABLE CERTIFICATE_LINK MODIFY (LINK_ID numeric,CERTIFICATE_ID numeric,PARENT_CERT_ID numeric)
/

    ALTER TABLE FUND_REBATE_SCHEDULE MODIFY (REBATE_SCHEDULE_ID numeric,FUND_ID numeric)
/

    ALTER TABLE FUND_REBATE_INTERVAL MODIFY (REBATE_INTERVAL_ID numeric,REBATE_SCHEDULE_ID numeric)
/

    ALTER TABLE DELIVERY_SET MODIFY (SET_ID numeric)
/

    ALTER TABLE DELIVERY_SET_FUTURES MODIFY (SET_ID numeric,FUTURE_ID numeric)
/

    ALTER TABLE PRICING_GRID_LAYOUT_CONFIG MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE UNITIZED_FUND_AUM MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE FX_OPTION_PREMIUM MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE TENANT MODIFY (TENANT_ID numeric,ISSHARED numeric)
/

    ALTER TABLE TOKENSTORE MODIFY (LAST_ACTIVITY_TIME numeric,CONNECTED numeric,CLIENT_ID numeric)
/

    ALTER TABLE PRICING_SCRIPT MODIFY (ID numeric,VERSION numeric)
/

    ALTER TABLE PRICING_SCRIPT_INST MODIFY (ID numeric,PS_ID numeric,PRODUCT_ID numeric,VERSION numeric)
/

    ALTER TABLE BASKET_INFO MODIFY (PRODUCT_ID numeric,BASKET_ID numeric)
/

    ALTER TABLE PRICING_SCRIPT_VARIABLE MODIFY (ID numeric,PRODUCT_ID numeric,BOOLEAN_VALUE numeric)
/

    ALTER TABLE PRICING_SCRIPT_VARIABLE_PATHS MODIFY (ANCESTOR_ID numeric,DESCENDANT_ID numeric,PATH_LENGTH numeric)
/

    ALTER TABLE PRICING_SCRIPT_META MODIFY (PS_ID numeric,NUMBER_OF_LEGS numeric)
/

    ALTER TABLE PRICING_SCRIPT_PRODUCT_MAPPING MODIFY (PS_ID numeric)
/

    ALTER TABLE PRICING_SCRIPT_VARIABLE_GROUP MODIFY (PS_ID numeric,DISPLAY_ORDER numeric)
/

    ALTER TABLE PRICING_SCRIPT_VARIABLE_META MODIFY (PS_ID numeric,DISPLAY_ORDER numeric,DECIMALS numeric)
/

    ALTER TABLE MODEL_CALIBRATION MODIFY (ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE MODEL_CALIBRATION_HIST MODIFY (ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE MODEL_CALIBRATION_PARAM MODIFY (MODEL_CALIBRATION_ID numeric)
/

    ALTER TABLE MODEL_CALIBRATION_PARAM_HIST MODIFY (MODEL_CALIBRATION_ID numeric)
/

    ALTER TABLE MODEL_CALIBRATION_MDI_PARAM MODIFY (MODEL_CALIBRATION_ID numeric,MARKET_DATA_ITEM_ID numeric)
/

    ALTER TABLE MODEL_CALIBRATION_MDI_PRM_HIST MODIFY (MODEL_CALIBRATION_ID numeric,MARKET_DATA_ITEM_ID numeric)
/

    ALTER TABLE MODEL_CALIBRATION_INSTRUMENT MODIFY (MODEL_CALIBRATION_ID numeric,EXPIRY_TENOR numeric,RELATIVE_STRIKE numeric)
/

    ALTER TABLE MODEL_CALIBRATION_INST_HIST MODIFY (MODEL_CALIBRATION_ID numeric,EXPIRY_TENOR numeric,RELATIVE_STRIKE numeric)
/

    ALTER TABLE WITHHOLDING_TAX_CONFIG MODIFY (WTH_TAX_CONFIG_ID numeric,VERSION_NUM numeric,ISSUER_COUNTRY_ID numeric,HOLDER_COUNTRY_ID numeric,TAX_AUTHORITY_LE_ID numeric,DATE_RULE_ID numeric,IS_CUSTODY numeric,WHT_DECIMAL numeric)
/

    ALTER TABLE FEE_CONFIG MODIFY (CONFIG_ID numeric,VERSION_NUM numeric,IS_TIERED_B numeric,PO_ID numeric,LE_ID numeric,FEE_DATE_RULE_ID numeric,HAS_REBATE_B numeric,RANGE_BY_TENOR numeric,CONVERSION numeric,RANGE_BY_RESIDUAL_MAT numeric)
/

    ALTER TABLE FEE_CONFIG_RANGE MODIFY (RANGE_CONFIG_ID numeric,FEE_CONFIG_ID numeric)
/

    ALTER TABLE FEE_CONFIG_REBATE_RANGE MODIFY (RANGE_CONFIG_ID numeric,FEE_CONFIG_ID numeric)
/

    ALTER TABLE USER_LE MODIFY (LE_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE BOND_EXOTIC_NOTE MODIFY (PRODUCT_ID numeric,UNDERLYING_ID numeric,PRICING_SCRIPT_ID numeric,BUSDAY_B numeric,OFFSET_DAYS numeric,RESET_ID numeric)
/

    ALTER TABLE FXRESET_OVERRIDE MODIFY (PRODUCT_ID numeric,LEG_ID numeric,FXRESET_ID numeric,IS_OVERRIDE numeric,FXRESET_OFFSET numeric,USE_IDX_RESET_DATE_B numeric,USE_DEFAULT_FXRESET_B numeric)
/

    ALTER TABLE USER_CONFIGS MODIFY (ID numeric)
/

    ALTER TABLE APPKIT_CONFIGURATION MODIFY (REVISION numeric,DESIGNATED numeric)
/

    ALTER TABLE CA_ADJUSTMENT_CONTRACT MODIFY (CONTRACT_ID_SOURCE numeric,CONTRACT_ID_NEW numeric)
/

    ALTER TABLE CA_ADJUSTMENT MODIFY (ID numeric,PRODUCT_SOURCE_ID numeric,CA_ID numeric,IS_FACTOR_MODIFIED numeric,IS_MODIFIED numeric,IS_APPLICATION_DATE_MODIFIED numeric)
/

    ALTER TABLE CA_ADJUSTMENT_VALUE MODIFY (CA_ADJUSTMENT_ID numeric)
/

    ALTER TABLE CA_ADJUSTMENT_CA MODIFY (CA_ADJUSTMENT_ID numeric,CA_PARENTS_ID numeric,CA_PARENTS_VERSION numeric)
/

    ALTER TABLE CA_ADJUSTMENT_RULE MODIFY (CA_ADJUSTMENT_ID numeric,CA_RULE_ID numeric)
/

    ALTER TABLE PORTFOLIO_SWAP_POSITION MODIFY (PRODUCT_ID numeric,CONTRACT_ID numeric,EQUITY_ID numeric)
/

    ALTER TABLE PRODUCT_PS_CONTRACT MODIFY (PRODUCT_ID numeric,CONTRACT_ID numeric,PSP_ID numeric)
/

    ALTER TABLE PORTFOLIO_SWAP MODIFY (PRODUCT_ID numeric,CONTRACT_ID numeric,ELS_ID numeric,ISRERATED numeric)
/

    ALTER TABLE PSP_INTEREST_BASE_CALC MODIFY (POSITION_ID numeric,PRODUCT_ID numeric)
/

    ALTER TABLE SPREAD_SCHEDULE MODIFY (ID numeric,VERSION numeric,PRODUCT_ID numeric)
/

    ALTER TABLE PRICING_SCRIPT_REPORT_MAPPING MODIFY (UI_ALIGN numeric)
/

    ALTER TABLE DEAD_LETTER_MESSAGES MODIFY (REDELIVERY_FLAG numeric,PROCESSED_FLAG numeric)
/

    ALTER TABLE PRODUCT_SPOT_PLSWEEP MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_SPOT_PLSWEEP_H MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE CALYPSO_SEED_HISTORY MODIFY (LAST_ID numeric,SEED_ALLOC_SIZE numeric)
/

    ALTER TABLE PROD_XML_DAT MODIFY (PRODUCT_ID numeric,XPROD_CONF_ID numeric)
/

    ALTER TABLE XPROD_CONFIG MODIFY (XPROD_CONF_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE PRODUCT_SCOT MODIFY (PRODUCT_ID numeric,UNDERLYING_ID numeric,PRICING_SCRIPT_ID numeric,RESET_ID numeric,BUSDAY_B numeric,OFFSET_DAYS numeric,BUY_SELL numeric)
/

    ALTER TABLE RATE_INDEX_PRODUCT MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PORTFOLIO_SWAP_RESET MODIFY (ID numeric,TRADE_ID numeric,RESET_ID numeric)
/

    ALTER TABLE LIFECYCLE_EVENT MODIFY (EVENT_ID numeric,ELEMENT_ID numeric,IS_SIMPLE numeric)
/

    ALTER TABLE LIFECYCLE_PROCESSOR_RULE MODIFY (RULE_ID numeric,VERSION numeric,ENABLED numeric)
/

    ALTER TABLE LIFECYCLE_TRIGGER_RULE MODIFY (RULE_ID numeric,VERSION numeric,ENABLED numeric)
/

    ALTER TABLE STRUCTURE_LIFECYCLE_DEF_NAME MODIFY (ID numeric)
/

    ALTER TABLE STRUCTURE_LIFECYCLE_DEF MODIFY (ID numeric,EVENT_INDEX numeric)
/

    ALTER TABLE STRUCTURE_LIFECYCLE_EVENT MODIFY (EVENT_ID numeric,DEFINITION_ID numeric)
/

    ALTER TABLE STRUCTURE_LIFECYCLE_EVENT_UND MODIFY (EVENT_ID numeric,UNDERLYING_EVENT_ID numeric,EVENT_INDEX numeric)
/

    ALTER TABLE TRADE_ENTRY_DEFAULT_CONFIG MODIFY (DEFAULT_CONFIG_ID numeric,VERSION_NUM numeric,ROOT_NODE_ID numeric)
/

    ALTER TABLE TRADE_ENTRY_DEFAULT_NODE MODIFY (DEFAULT_NODE_ID numeric,VERSION_NUM numeric,DEFAULT_CONFIG_ID numeric,PARENT_NODE_ID numeric,DEFAULT_NODE_PRIORITY numeric)
/

    ALTER TABLE MULTI_CURVE_MAPPING_INFO MODIFY (CURVE_ID numeric,RELATED_CURVE_ID numeric)
/

    ALTER TABLE TRADE_FILTER_ENRICH_MONO_CRIT MODIFY (CONTEXT_ID numeric,FIELD_RANK numeric)
/

    ALTER TABLE AUDIT_PROCESS_TABLE MODIFY (PROCESS_CONFIG_ID numeric,VERSION numeric)
/

    ALTER TABLE ENRICHMENT_CONTEXT MODIFY (CONTEXT_ID numeric,PRIMARY_KEY_SIZE numeric,SYNCHRONOUS numeric,ACTIVE numeric,HIDDEN numeric)
/

    ALTER TABLE ENRICHMENT_FIELD MODIFY (CONTEXT_ID numeric,FIELD_RANK numeric,SCALE numeric,NULLABLE numeric)
/

    ALTER TABLE ENRICHMENT_EXTRA_PARAMETER MODIFY (CONTEXT_ID numeric,FIELD_RANK numeric,PARAM_RANK numeric)
/

    ALTER TABLE FX_RESET_FIXING MODIFY (PRODUCT_ID numeric,FX_RESET numeric,RESET_TYPE numeric)
/

    ALTER TABLE FX_RESET_FIXING_H MODIFY (PRODUCT_ID numeric,FX_RESET numeric,RESET_TYPE numeric)
/

    ALTER TABLE POINTS_OVER_FIXING MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE POINTS_OVER_FIXING_H MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PRODUCT_FX_FORWARD_START MODIFY (PRODUCT_ID numeric,UNDERLYING_PRODUCT_ID numeric)
/

    ALTER TABLE TASK_ENRICHMENT_FIELD_CONFIG MODIFY (DB_SCALE numeric)
/

    ALTER TABLE TASK_ENRICHMENT_FILTER MODIFY (FILTER_ID numeric,VERSION numeric)
/

    ALTER TABLE TASK_ENRICH_FILTER_ELEM MODIFY (FILTER_ID numeric,ELEMENT_INDEX numeric)
/

    ALTER TABLE TASK_STATION_TAB MODIFY (TAB_ID numeric,TAB_VERSION numeric,AUTO_COUNT_B numeric,WEB_REPORT_B numeric)
/

    ALTER TABLE TS_TAB_USER_BOOK MODIFY (TAB_ID numeric,BOOK_ID numeric)
/

    ALTER TABLE TS_TAB_BOOK_NAME MODIFY (TAB_ID numeric)
/

    ALTER TABLE TS_TAB_BOOK_ATTRIBUTE MODIFY (TAB_ID numeric)
/

    ALTER TABLE TS_TAB_EVENT_TYPE MODIFY (TAB_ID numeric)
/

    ALTER TABLE LOOKUP_SERVICE_CONFIG MODIFY (LOOKUP_CONTEXT numeric,UPDATETIMESTAMP numeric,VERSION numeric)
/

    ALTER TABLE PK_LOOKUP_CONFIG MODIFY (VERSION numeric)
/

    ALTER TABLE PK_CONFIG_PERIOD_RANGE MODIFY (START_HOUR numeric,START_MINUTE numeric,START_SECOND numeric,END_HOUR numeric,END_MINUTE numeric,END_SECOND numeric,IS_ACTIVE numeric)
/

    ALTER TABLE PK_CONFIG_CURRENCY_SPLIT MODIFY (SALIENCE numeric)
/

    ALTER TABLE PK_CONFIG_CCYPAIR_EXP_OWNER MODIFY (SALIENCE numeric,IS_EXP_OWNER_BOOK numeric,EXP_OWNER_ID numeric)
/

    ALTER TABLE PK_CONFIG_CCYFUNDING_EXP_OWNER MODIFY (SALIENCE numeric,IS_EXP_OWNER_BOOK numeric,EXP_OWNER_ID numeric)
/

    ALTER TABLE PK_CONFIG_RISKYCCY_EXP_OWNER MODIFY (SALIENCE numeric,IS_EXP_OWNER_BOOK numeric,EXP_OWNER_ID numeric)
/

    ALTER TABLE PK_PERSISTENCE_ENGINE_INFO MODIFY (TRADE_ID numeric,TRADE_VERSION numeric,RESTART_ATTEMPTS numeric)
/

    ALTER TABLE PK_PERSISTENCE_ENGINE_INFO_D MODIFY (TRADE_ID numeric,TRADE_VERSION numeric)
/

    ALTER TABLE PKSERVER_PROCESSING_INFO MODIFY (TRADE_ID numeric,TRADE_VERSION numeric)
/

    ALTER TABLE PKBLOTTER_MARKSET_CONFIG MODIFY (CONFIG_ID numeric,VERSION numeric)
/

    ALTER TABLE PKBLOTTER_MARKSET_CONFIG_ITEMS MODIFY (CONFIG_ID numeric)
/

    ALTER TABLE PKBLOTTER_MARKSET_CONFIG_CRIT MODIFY (CONFIG_ID numeric,IS_IN_B numeric)
/

    ALTER TABLE PKBLOTTER_MARKS MODIFY (BOOK_ID numeric)
/

    ALTER TABLE PASSWORD_RESET_TOKEN MODIFY (USER_ID numeric)
/

    ALTER TABLE SALES_MARGIN_RULE MODIFY (RULE_ID numeric,PROCESSINGORG_ID numeric,COUNTERPARTY_OR_GROUP numeric,PRODUCT_OR_GROUP numeric,IS_MARGIN_BREAKDOWN numeric,VERSION_NUM numeric)
/

    ALTER TABLE SALES_MARGIN_TRADE_ATTRIBUTES MODIFY (RULE_ID numeric)
/

    ALTER TABLE SALES_MARGIN_ALLOCATION MODIFY (RULE_ID numeric)
/

    ALTER TABLE QUARTZ_SCHED_TASK MODIFY (TASK_ID numeric,SCHED_TIME numeric,FROM_DAYS numeric,TO_DAYS numeric,PUBLISH_B numeric,EXECUTE_B numeric,SEND_EMAIL_B numeric,VAL_TIME numeric,UNDO_TIME numeric,NEXT_ID numeric,VALDATE_OFFSET numeric,EXEC_HOL numeric,PO_ID numeric,DATE_RULE_ID numeric,EXEC_DS_B numeric,VERSION_NUM numeric,READ_ONLY_SRVR_B numeric,PRIVATE_B numeric,IS_DEACTIVATED numeric,SKIP_EXEC_B numeric,SKIP_CUTOFF_TIME numeric)
/

    ALTER TABLE QUARTZ_SCHED_TASK_ATTR MODIFY (TASK_ID numeric,VALUE_ORDER numeric)
/

    ALTER TABLE QUARTZ_SCHED_TASK_MULTI_ATTR MODIFY (TASK_ID numeric,VALUE_ORDER numeric)
/

    ALTER TABLE QUARTZ_SCHED_TASK_EXEC MODIFY (TASK_ID numeric,EXEC_STATUS_B numeric,PARENT_ID numeric,DURATION numeric,ERROR_CNT numeric)
/

    ALTER TABLE SCHD_TRIGGERS MODIFY (NEXT_FIRE_TIME numeric,PREV_FIRE_TIME numeric,PRIORITY numeric,START_TIME numeric,END_TIME numeric,MISFIRE_INSTR numeric)
/

    ALTER TABLE SCHD_SIMPLE_TRIGGERS MODIFY (REPEAT_COUNT numeric,REPEAT_INTERVAL numeric,TIMES_TRIGGERED numeric)
/

    ALTER TABLE SCHD_SIMPROP_TRIGGERS MODIFY (INT_PROP_1 numeric,INT_PROP_2 numeric,LONG_PROP_1 numeric,LONG_PROP_2 numeric,DEC_PROP_1 numeric,DEC_PROP_2 numeric)
/

    ALTER TABLE SCHD_FIRED_TRIGGERS MODIFY (FIRED_TIME numeric,PRIORITY numeric,SCHED_TIME numeric)
/

    ALTER TABLE SCHD_SCHEDULER_STATE MODIFY (LAST_CHECKIN_TIME numeric,CHECKIN_INTERVAL numeric)
/

    ALTER TABLE SCHED_TASK_CHAIN MODIFY (CHAIN_ID numeric,CURRENT_TASK_ID numeric,NEXT_TASK_ID numeric,CHECK_SUCCESS numeric,ORDER_BY numeric)
/

    ALTER TABLE NEW_OLD_SCHEDULER_MIGRATION MODIFY (OLD_SCHD_ID numeric,NEW_SCHD_ID numeric)
/

    ALTER TABLE RECONVENTION MODIFY (PRODUCT_ID numeric,IS_PRESCHEDULED numeric,CONSTRAINT_ID numeric)
/

    ALTER TABLE RECONVENTION_PARAMETER MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE PS_STRATEGY_INFO MODIFY (STRATEGY_ID numeric,TRADE_ID numeric)
/

    ALTER TABLE PS_STRATEGY_INFO_HIST MODIFY (STRATEGY_ID numeric,TRADE_ID numeric)
/

    ALTER TABLE STATEMENT_CONFIG MODIFY (CONFIG_ID numeric,VERSION_NUM numeric,PO_IN numeric,MULTI_PO numeric,SENDER_ID numeric,LE_IN numeric,MULTI_LE numeric,RECEIVER_ID numeric,RULE_ID numeric,PRODUCT_IN numeric,FLOW_TYPE_IN numeric,CCY_IN numeric,EXCHANGE_IN numeric,SD_FILTER_IN numeric)
/

    ALTER TABLE PRODUCT_BILLING_STATEMENT MODIFY (PRODUCT_ID numeric,CONFIG_ID numeric,STATEMENT_RULE_ID numeric,CLOSED_B numeric)
/

    ALTER TABLE STATEMENT_ENTRY MODIFY (PRODUCT_ID numeric,ENTRY_ID numeric,TRADE_ID numeric,TRANSFER_ID numeric,PO_ID numeric,CPTY_ID numeric,IS_ADJUSTMENT numeric,IS_LATE_SETTLEMENT numeric,IS_LATE_MINIMUM numeric,IS_DELETED numeric,SECURITY_ID numeric,POOL_ID numeric,LINKED_TRADE_ID numeric,BILLING_VERSION numeric)
/

    ALTER TABLE STATEMENT_ENTRY_DETAIL MODIFY (PRODUCT_ID numeric,ENTRY_ID numeric,DETAIL_ID numeric)
/

    ALTER TABLE FUTCON_UND_PROD_ATTRIBUTE MODIFY (CONTRACT_ID numeric)
/

    ALTER TABLE MULTI_CCY_INFO MODIFY (PRODUCT_ID numeric,USE_CUSTOM_FIRST_FX_RATE numeric,USE_CUSTOM_LAST_FX_RATE numeric)
/

    ALTER TABLE BOND_EX_DIV_SCHEDULE MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE OFFICIAL_PL_EXECUTION_STATUS MODIFY (JOB_ID numeric,NUM_MARKS numeric,NUM_TRADES numeric,PL_CONFIG_ID numeric,OUTPUT_ID numeric)
/

    ALTER TABLE CONVERSION_FACTOR_MARK_HEADER MODIFY (PL_CONFIG_ID numeric,JOB_ID numeric,VERSION numeric)
/

    ALTER TABLE CONVERSION_FACTOR_MARK MODIFY (PL_CONFIG_ID numeric)
/

    ALTER TABLE ENGINE_METRICS MODIFY (CONSUMED numeric,LOCAL_QUEUE numeric,DB_QUEUE numeric,BAD_EVENTS numeric,OLDEST_EVENT numeric)
/

    ALTER TABLE LIVE_PL_GREEKS MODIFY (LIVE_ID numeric,PL_CONFIGURATION_ID numeric)
/

    ALTER TABLE LIVE_PL_GREEKS_X MODIFY (LIVE_ID numeric,X_IDX numeric)
/

    ALTER TABLE LIVE_PL_GREEKS_MEASURE MODIFY (LIVE_ID numeric,TRADE_ID numeric,UNIT_ID numeric,BUCKET_ID numeric,MEASURE_TYPE numeric,HAS_SECOND_ORDER numeric)
/

    ALTER TABLE LIVE_PL_GREEKS_TRADE MODIFY (LIVE_ID numeric,TRADE_ID numeric,TRADE_VERSION numeric,BOOK_ID numeric)
/

    ALTER TABLE LIVE_PL_GREEKS_CURVE MODIFY (LIVE_ID numeric,INSTRUMENT_TENOR_PERIOD numeric,INSTRUMENT_CODE_PERIOD numeric)
/

    ALTER TABLE LIVE_PL_GREEKS_RECOVERY MODIFY (LIVE_ID numeric)
/

    ALTER TABLE LIVE_PL_GREEKS_VOL MODIFY (LIVE_ID numeric,TENOR_PERIOD numeric,STRIKE_PERIOD numeric,EXPIRY_TENOR_PERIOD numeric)
/

    ALTER TABLE LIVE_PL_GREEKS_VOL_UNDERLYING MODIFY (LIVE_ID numeric,TENOR_PERIOD numeric,STRIKE_PERIOD numeric,EXPIRY_TENOR_PERIOD numeric)
/

    ALTER TABLE LIVE_PL_GREEKS_QUOTE MODIFY (LIVE_ID numeric)
/

    ALTER TABLE LIVE_PL_AGGREGATION MODIFY (POSITION numeric)
/

    ALTER TABLE ENGINE_MESSAGES MODIFY (MESSAGE_ID numeric,ENGINE_ID numeric)
/

    ALTER TABLE PRODUCT_ISLAMIC_MM MODIFY (PRODUCT_ID numeric,BROKER_ID_1 numeric,BROKER_ID_2 numeric)
/

    ALTER TABLE ISLAMIC_SWAP_LEG MODIFY (PRODUCT_ID numeric,LEG_ID numeric,BROKER_ID_1 numeric,BROKER_ID_2 numeric)
/

    ALTER TABLE ISLAMIC_SWAP MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE SWAP_LEG_LAG_DETAILS MODIFY (PRODUCT_ID numeric,LEG_ID numeric,FIRST_RESET_OFFSET_DAYS numeric,FIRST_RESET_BUS_DAY_B numeric)
/

    ALTER TABLE MULTICURVEPACKAGEINFO MODIFY (PACKAGE_ID numeric)
/

    ALTER TABLE MULTICURVEPACKAGENODEINFO MODIFY (PACKAGE_ID numeric,CURVENODE_ID numeric)
/

    ALTER TABLE MULTICURVEPKGDEPENDENCYINFO MODIFY (PACKAGE_ID numeric,CURVE_ID numeric,RELATED_CURVE_ID numeric)
/

    ALTER TABLE MCPKG_INF_HIST MODIFY (PACKAGE_ID numeric)
/

    ALTER TABLE MCPKG_NODE_INF_HIST MODIFY (PACKAGE_ID numeric,CURVENODE_ID numeric)
/

    ALTER TABLE MCPKG_DEP_INF_HIST MODIFY (PACKAGE_ID numeric,CURVE_ID numeric,RELATED_CURVE_ID numeric)
/

    ALTER TABLE INVESTMENT_CASH MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE INVESTMENT_CASH_POSITION MODIFY (POSITION_ID numeric,TREASURY_PORTFOLIO_ID numeric,BOOK_ID numeric,PL_CONFIG_ID numeric)
/

    ALTER TABLE HA_HEDGE_STRATEGY MODIFY (RELATIONSHIP_ID numeric,ACCOUNTING_BOOK_ID numeric,VERSION numeric)
/

    ALTER TABLE HA_HEDGE_RELATIONSHIP MODIFY (HEDGE_RELATIONSHIP_ID numeric,HEDGE_STRATEGY_ID numeric,HEDGE_RELATIONSHIP_CONFIG_ID numeric,IS_DOCUMENTATION_REVIEWED numeric,HEDGE_ACCOUNTING_SCHEME_ID numeric,HEDGE_HYPOTHETICAL_MAPPING_ID numeric,VERSION numeric,NEEDS_PROCESSING numeric,PROCESSING_ERROR numeric,AUTOMATIC_TERMINATION numeric,AUTO_TERM_BY_EFF_DATE numeric,AUTO_HEDGE_TERM_NO_ITEM_LEFT numeric,TERM_TO_UNHEDGED numeric,GROUP_ID numeric,PTF_HEDGE_CYCLE_ID numeric,PTF_HEDGE_ORIGINAL_CYCLE_ID numeric)
/

    ALTER TABLE HA_HEDGE_RELATIONSHIP_CONFIG MODIFY (HEDGE_RELATIONSHIP_CONFIG_ID numeric,HEDGED_PO_ID numeric,HEDGING_PO_ID numeric,HEDGE_STRATEGY_ID numeric,VERSION numeric)
/

    ALTER TABLE HA_HEDGE_LIQUIDATION MODIFY (ID numeric,TRADE_ID numeric,TASK_ID numeric,APPLIED numeric,USE_EFF_DATE numeric,VERSION_NUM numeric)
/

    ALTER TABLE HA_HEDGE_LIQUIDATION_ITEM MODIFY (HEDGE_LIQ_ID numeric,TRADE_ID numeric,HEDGE_RELATIONSHIP_ID numeric,RUN_TEST numeric,HEDGE_ACTIVE numeric,OBJECT_ID numeric)
/

    ALTER TABLE HA_HEDGE_RELATIONSHIP_TRADE MODIFY (ID numeric,TRADE_ID numeric,GROUP_ID numeric,HEDGE_RELATIONSHIP_ID numeric,IS_HEDGED_TRADE numeric,TRADE_VERSION numeric,HYPOTHETICAL_TRADE_ID numeric,INCLUDE_SPREAD numeric,VERSION numeric)
/

    ALTER TABLE HA_HEDGE_MEASURE_ITEM MODIFY (GROUP_ID numeric,HEDGE_RELATIONSHIP_ID numeric)
/

    ALTER TABLE HA_HEDGE_RELATIONSHIP_STATE MODIFY (HEDGE_RELATIONSHIP_ID numeric,HEDGE_RELATIONSHIP_VERSION numeric,PASSED numeric,RETRO_TEST_ID numeric,PROSP_TEST_ID numeric,OFFICIAL numeric)
/

    ALTER TABLE HA_HEDGE_ACCOUNTING_SCHEME MODIFY (HAS_ID numeric,DATE_RULE2_ID numeric,IS_AUTO_ON_FAILURE numeric,IS_AUTO_ON_PASS numeric,VALIDATION_UNIT numeric,DATE_RULE3_ID numeric,DATE_RULE4_ID numeric,IS_DOCUMENTATION_REQUIRED numeric,IS_DOCUMENTATION_UPDATED numeric,VERSION numeric)
/

    ALTER TABLE HA_DESIGNATION_RECORD MODIFY (DESIGNATION_ID numeric,HEDGE_RELATIONSHIP_ID numeric,VERSION_FROM numeric,VERSION_TO numeric,IS_DOCUMENTATION_REVIEWED numeric,HET_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE HA_DESIGNATION_RECORD_TRADE MODIFY (TRADE_ID numeric,DESIGNATION_ID numeric,HEDGE_RELATIONSHIP_ID numeric,OTHER_TRADE_ID numeric,OTHER_DESIGNATION_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE HA_PRICER_MEASURE_MAPPING MODIFY (ID numeric,IS_HEDGED_TRADE numeric,PRIORITY numeric,VERSION numeric)
/

    ALTER TABLE HA_HEDGE_RELATIONSHIP_GROUP MODIFY (ID numeric,IS_COMPLETED numeric,PROCESSING_NUMBER numeric)
/

    ALTER TABLE HA_HEDGE_REL_GROUP_PROCESSING MODIFY (GROUP_ID numeric,HEDGE_ID numeric,PROCESSING_NUMBER numeric)
/

    ALTER TABLE HR_ENRICHMENT_MAPPING MODIFY (ID numeric,PRIORITY numeric,VERSION numeric)
/

    ALTER TABLE HA_HYPOTHETICAL_MAPPING MODIFY (ID numeric,VERSION numeric)
/

    ALTER TABLE HA_MEASURE MODIFY (ID numeric,TRADE_ID numeric,RELATIONSHIP_ID numeric,VERSION numeric)
/

    ALTER TABLE HA_EFF_ANALYSIS_FILTER MODIFY (OUTPUT_ID numeric,RELATIONSHIP_ID numeric,RELATIONSHIP_VERSION numeric,OFFICIAL numeric,GROUP_ID numeric,CYCLE_ID numeric)
/

    ALTER TABLE HA_HYPO_PL_MARK MODIFY (MARK_ID numeric,TRADE_ID numeric,VERSION_NUM numeric,BOOK_ID numeric)
/

    ALTER TABLE HA_HYPO_PL_MARK_VALUE MODIFY (MARK_ID numeric,HEDGING_TRADE_ID numeric,DISPLAY_DIGITS numeric,IS_ADJUSTED numeric,IS_DERIVED numeric)
/

    ALTER TABLE HA_PORTFOLIO_HEDGE_DEF MODIFY (ID numeric,BUCKETING_RULE_ID numeric,BUCKETS_NUMBER numeric,HEDGE_DEFINITION_ID numeric,IGNORED_BUCKETS_NUMBER numeric,HEDGE_ACCOUNTING_SCHEME_ID numeric,VERSION_NUM numeric,PARTICIPATION_RATE_CALC numeric,HEDGE_ITEM_RATE_INDEX_ID numeric)
/

    UPDATE
        HA_PORTFOLIO_HEDGE_DEF 
    SET
        HEDGE_ITEM_RATE_INDEX_ID = 0 
    WHERE
        HEDGE_ITEM_RATE_INDEX_ID IS NULL
/

    ALTER TABLE HA_PORTFOLIO_HEDGE_DEF MODIFY HEDGE_ITEM_RATE_INDEX_ID NOT NULL
/

    ALTER TABLE HA_PORTFOLIO_HEDGE_CYCLE MODIFY (ID numeric,PTF_HEDGE_DEF_ID numeric,CYCLE_NUMBER numeric,STATUS numeric,AUDIT_VERSION_NUM numeric)
/

    ALTER TABLE CALYPSO_HIERARCHY_NODE_VALUE MODIFY (NODE_ID numeric)
/

    ALTER TABLE TRADE_GROUPING_BASE MODIFY (ID numeric,VERSION numeric,UNDERLYING_ID numeric)
/

    ALTER TABLE ERSC_RULE_GROUP DROP  ( CREATED_META_DATA_ID,UPDATED_META_DATA_ID )
/

    ALTER TABLE ERSC_RULE_GROUP MODIFY (TENANT_ID numeric,VERSION numeric,ENABLED numeric,PORTFOLIO_GROUP_ID numeric,REVISION_NUMBER numeric,TRADE_FILTER_BASED numeric,REF_PO numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    UPDATE
        ERSC_RULE_GROUP 
    SET
        REF_PO = 0 
    WHERE
        REF_PO IS NULL
/

    ALTER TABLE ERSC_RULE_GROUP MODIFY REF_PO NOT NULL
/

    ALTER TABLE CUSTOM_GROUPING MODIFY (ID numeric,BENCHMARK_ID numeric,SECONDARY_BENCHMARK_ID numeric)
/

    ALTER TABLE GROUPING_REFERENCES MODIFY (GROUPING_ID numeric)
/

    ALTER TABLE GROUPING_HIERARCHY MODIFY (PARENT_ID numeric,CHILD_ORDER numeric,CHILD_ID numeric)
/

    ALTER TABLE INVESTMENT_RULE_ORDER MODIFY (OWNER_ID numeric,RULE_ID numeric,RULE_TYPE_ID numeric,RULE_INDEX numeric)
/

    ALTER TABLE INVESTMENT_RULE MODIFY (ID numeric,VERSION numeric,OWNER_ID numeric,RULE_TYPE_ID numeric)
/

    ALTER TABLE ALLOCATION_TYPE_ORDER MODIFY (ID numeric,TYPE_ORDER numeric,TYPE_ID numeric)
/

    ALTER TABLE ALLOCATION MODIFY (ALLOCATION_ID numeric,RECORD_ID numeric,TYPE_ID numeric,GROUPING_ID numeric)
/

    ALTER TABLE TREASURY_ALLOCATION MODIFY (ALLOCATION_ID numeric,GROUPING_ID numeric,TREASURY_GROUPING_ID numeric)
/

    ALTER TABLE BENCHMARK MODIFY (BENCHMARK_ID numeric,VERSION numeric,TYPE numeric,CARVEOUT_BENCHMARK numeric,ISSUER_ID numeric,MARKET_PLACE_ID numeric,PROVIDER_ID numeric,PUBLISH_DAYOFWEEK numeric,PUBLISH_DATE_RULE_ID numeric,PUBLISH_TIME numeric,IS_DRIFTED numeric,IS_RESCALING numeric,IS_LIABILITY numeric,PORTFOLIO_GROUP_ID numeric,STRATEGY_FUND_ID numeric,STRATEGY_TARGET_LEVEL numeric,PROCESSING_ORG_ID numeric,MARKET_INDEX_ID numeric,VALUATION_HISTORIZED numeric,BASE_BENCHMARK_ID numeric,ALLOCATION_INDICATOR numeric)
/

    ALTER TABLE BENCHMARK_COMP_RECORD MODIFY (RECORD_ID numeric,BENCHMARK_ID numeric,BENCHMARK_TYPE numeric,RECORD_VERSION numeric)
/

    ALTER TABLE BENCHMARK_COMP_RECORD_ITEM MODIFY (RECORD_ID numeric,OBJECT_TYPE numeric,OBJECT_ID numeric)
/

    ALTER TABLE ARCH_BENCHMARK_COMP_RECORD MODIFY (NET_ID numeric,RECORD_ID numeric)
/

    ALTER TABLE BENCHMARK_COMP_RECORD_HIST MODIFY (RECORD_ID numeric,BENCHMARK_ID numeric,BENCHMARK_VERSION numeric,BENCHMARK_TYPE numeric,RECORD_VERSION numeric)
/

    ALTER TABLE BENCHMARK_COMP_RECORD_ITEMHIST MODIFY (RECORD_ID numeric,OBJECT_TYPE numeric,OBJECT_ID numeric)
/

    ALTER TABLE BENCHMARK_HISTO MODIFY (BENCHMARK_HISTO_ID numeric,BENCHMARK_ID numeric,PLCONFIG_ID numeric)
/

    ALTER TABLE BENCHMARK_HISTO_ITEM MODIFY (BENCHMARK_HISTO_ID numeric,ITEM_TYPE numeric,ITEM_ID numeric)
/

    ALTER TABLE AMTD_COLUMN MODIFY (AMTD_COLUMN_ID numeric,VERSION numeric,TYPE numeric)
/

    ALTER TABLE AMTD_HIERARCHY_DEF MODIFY (AMTD_HIERARCHY_DEF_ID numeric,VERSION numeric)
/

    ALTER TABLE AMTD_GROUPING MODIFY (AMTD_HIERARCHY_DEF_ID numeric,GROUPING_RANK numeric,AMTD_COLUMN_ID numeric)
/

    ALTER TABLE AMTD_HIERARCHY_NODE MODIFY (AMTD_HIERARCHY_NODE_ID numeric,VERSION numeric,PARENT_NODE_ID numeric,AMTD_HIERARCHY_DEF_ID numeric,KEY_AMTD_COLUMN_ID numeric)
/

    ALTER TABLE AMTD_HIERARCHY_USAGE MODIFY (AMTD_HIERARCHY_USAGE_ID numeric,TYPE numeric,PARENT_ID numeric,AMTD_HIERARCHY_DEF_ID numeric)
/

    ALTER TABLE AMTD_INDICATOR MODIFY (AMTD_HIERARCHY_USAGE_ID numeric,INDICATOR_RANK numeric,AMTD_COLUMN_ID numeric)
/

    ALTER TABLE AMTD_RECORD MODIFY (AMTD_RECORD_ID numeric,VERSION numeric,AMTD_HIERARCHY_USAGE_ID numeric)
/

    ALTER TABLE AMTD_SEGMENT MODIFY (AMTD_SEGMENT_ID numeric,VERSION numeric,AMTD_RECORD_ID numeric,AMTD_HIERARCHY_NODE_ID numeric)
/

    ALTER TABLE AMTD_VALUE MODIFY (AMTD_SEGMENT_ID numeric,AMTD_COLUMN_ID numeric)
/

    ALTER TABLE DECSUPP_ORDER MODIFY (ORDER_ID numeric,PRODUCT_ID numeric,BOOK_ID numeric,STRATEGY_ID numeric,IS_SECONDARY_MARKET numeric,CPTY_ID numeric)
/

    ALTER TABLE DECSUPP_ORDER_HIST MODIFY (ORDER_ID numeric,PRODUCT_ID numeric,BOOK_ID numeric,STRATEGY_ID numeric,IS_SECONDARY_MARKET numeric,CPTY_ID numeric)
/

    ALTER TABLE BLOCK_ORDER_CHILD MODIFY (BLOCK_ID numeric,ORDER_ID numeric,ORDER_INDEX numeric)
/

    ALTER TABLE BLOCK_ORDER_CHILD_HIST MODIFY (BLOCK_ID numeric,ORDER_ID numeric,ORDER_INDEX numeric)
/

    ALTER TABLE ORDER_WIDGET_TEMPLATE MODIFY (CONTEXTUAL numeric,DISPLAY_EXEC numeric)
/

    ALTER TABLE ORDER_PARAM_CONFIG MODIFY (CONFIG_ID numeric,VERSION numeric,FUND_ID numeric,BOOK_ID numeric,STRATEGY_ID numeric,BROKER_ID numeric,CPTY_ID numeric)
/

    ALTER TABLE AM_SERVER_CONFIG MODIFY (CONFIG_VERSION numeric,VERSION numeric)
/

    ALTER TABLE LAYOUTS_PORTFOLIO_ASSOCIATION MODIFY (GROUPING_ID numeric)
/

    ALTER TABLE AM_SERVER_CONFIG_ID_MAP MODIFY (CONFIG_ID numeric)
/

    ALTER TABLE AM_ANALYSIS_STARTUP_GROUPING MODIFY (CONFIG_ID numeric,GROUPING_ID numeric)
/

    ALTER TABLE COMMODITY_RISK_WEIGHT MODIFY (PRODUCT_ID numeric,RANK numeric,VERSION numeric)
/

    ALTER TABLE RATING_EQUIVALENCE MODIFY (ORDER_ID numeric)
/

    ALTER TABLE PORTFOLIO_ANALYSIS_OUTPUT MODIFY (PORTFOLIO_ID numeric,ANALYSIS_OUTPUT_ID numeric)
/

    ALTER TABLE AM_CURRENCY_ADJUSTMENT MODIFY (ID numeric,VERSION numeric,BOOK_ID numeric,STRATEGY_ID numeric)
/

    ALTER TABLE AM_ORDER_MODEL MODIFY (ID numeric,VERSION numeric,UND_BENCHMARK_ID numeric,MIGRATED numeric)
/

    ALTER TABLE AM_INVESTMENT_ACTION MODIFY (ID numeric,VERSION numeric,INVALIDATED_B numeric,TRADING_BASKET_ID numeric)
/

    ALTER TABLE INVESTMENT_ACTION_MODEL_MAP MODIFY (RECORD_ID numeric,ACTION_ID numeric,GROUPING_ID numeric,ORDER_MODEL_ID numeric)
/

    ALTER TABLE ALLOCATION_RECORD MODIFY (RECORD_ID numeric,VERSION numeric,ALLOCATION_ID numeric)
/

    ALTER TABLE AM_FUND_OWNERSHIP_RATIOS MODIFY (ID numeric,VERSION numeric,FUND_ID numeric)
/

    ALTER TABLE AM_ORDER_EXECUTION MODIFY (ID numeric,VERSION numeric,BLOCK_ORDER_ID numeric,TRADE_ID numeric,PRODUCT_ID numeric,CPTYID numeric)
/

    ALTER TABLE AM_ORDER_EXECUTION_ITEM MODIFY (ID numeric,PARENT_ID numeric,PARENT_VERSION numeric,ORDER_ID numeric,TRADE_ID numeric,IS_ACTIVE numeric)
/

    ALTER TABLE AM_ORDER_EXECUTION_HIST MODIFY (ID numeric,VERSION numeric,BLOCK_ORDER_ID numeric,TRADE_ID numeric,PRODUCT_ID numeric,CPTYID numeric)
/

    ALTER TABLE AM_ORDER_EXECUTION_ITEM_HIST MODIFY (ID numeric,PARENT_ID numeric,PARENT_VERSION numeric,ORDER_ID numeric,TRADE_ID numeric,IS_ACTIVE numeric)
/

    ALTER TABLE PWS_COLUMN_CONFIG MODIFY (VERSION numeric,IS_DUPLICATE numeric,IS_CLIENT_SIDE numeric,IS_USER_COLUMN numeric)
/

    ALTER TABLE RESET_INFO MODIFY (PRODUCT_ID numeric,USE_RESET_DATES numeric,CHECK_BARRIER_ON_RESET_DATE numeric,ROLL_DAY numeric)
/

    ALTER TABLE RESET_DATE_SCHEDULE MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE C_LAYOUT_DATA MODIFY (DATA_VERSION numeric)
/

    ALTER TABLE PAYMENT_SETUP MODIFY (ID numeric,PO_ID numeric,VALIDSETUP_LE_ID numeric,VALIDSETUP_NO_CHECK numeric,CONFIRMSETUP_IS_FIXED numeric,CONFIRMSETUP_LINKEDID numeric,CONFIRMSETUP_ALLMESSAGES numeric,VALIDSETUP_REFERENCE_CURRENCY numeric)
/

    ALTER TABLE IN_MEMORY_SERVER_CONFIG MODIFY (CONFIG_VERSION numeric)
/

    ALTER TABLE IMRS_CONFIG MODIFY (VERSION numeric)
/

    ALTER TABLE FOWS_WS MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE EQUITY_RESET MODIFY (EQUITY_RESET_ID numeric,UNDERLYING_EQUITY_ID numeric)
/

    ALTER TABLE EQUITY_RESET_DEFAULT MODIFY (UNDERLYING_EQUITY_ID numeric,EQUITY_RESET_ID numeric)
/

    ALTER TABLE CA_FX_MAPPING MODIFY (ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE CHASING_CONFIG MODIFY (CHASING_CONFIG_ID numeric,ADVICE_CONFIG_ID numeric,VERSION_NUM numeric,SENDER_ID numeric,RECEIVER_ID numeric)
/

    ALTER TABLE CHASING_CONFIG_DETAILS MODIFY (CHASING_CONFIG_ID numeric,CHASING_ORDER_ID numeric,LAG_DAYS_B numeric,LAG_DAYS numeric,IS_CALENDAR_B numeric,IS_ABSOLUTE_B numeric,ABSOLUTE_HOUR numeric,ABSOLUTE_MINUTE numeric,IS_TIMELAG_B numeric,TIMELAG_HOUR numeric,TIMELAG_MINUTE numeric)
/

    ALTER TABLE KPI_CONFIGURATION MODIFY (ID numeric,INITIALIZED numeric,VERSION_NUM numeric)
/

    ALTER TABLE KPI_CONFIGURATION_COLUMN MODIFY (ID numeric,COLUMN_INDEX numeric,KPI_CONFIGURATION_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE KPI_CONFIGURATION_FILTER MODIFY (ID numeric,FILTER_INDEX numeric,KPI_CONFIGURATION_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE KPI_CONFIGURATION_FILTER_VALUE MODIFY (KPI_CONFIGURATION_FILTER_ID numeric)
/

    ALTER TABLE KPI_CONFIGURATION_PARAMETER MODIFY (ID numeric,KPI_CONFIGURATION_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE KPI_CONFIGURATION_CUSTOM MODIFY (ID numeric,CUSTOM_INDEX numeric,KPI_CONFIGURATION_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE KPI_CONF_CUST_TRADE_TTP MODIFY (ID numeric,PO_ID numeric,BOOK_ID numeric,CPTY_ID numeric,NUMBER_VALUE numeric)
/

    ALTER TABLE KPI_CONF_CUST_TRADE_TTP_CP_ATT MODIFY (ID numeric)
/

    ALTER TABLE KPI_CONF_CUST_XFER_TTP MODIFY (ID numeric,PO_ID numeric,CPTY_ID numeric,PO_AGENT_ID numeric,NUMBER_VALUE numeric)
/

    ALTER TABLE KPI_CONF_CUST_XFER_TTP_CP_ATT MODIFY (ID numeric)
/

    ALTER TABLE KPI_CONF_CUST_MSG_TTP MODIFY (ID numeric,SENDER_ID numeric,RECEIVER_ID numeric,NUMBER_VALUE numeric)
/

    ALTER TABLE KPI_CONF_CUST_MSG_TTP_RC_ATT MODIFY (ID numeric)
/

    ALTER TABLE KPI_CONF_CUST_TRADE_STPB MODIFY (ID numeric,PO_ID numeric,NUMBER_VALUE numeric)
/

    ALTER TABLE MESSAGE_EDITING MODIFY (MESSAGE_EDITING_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE MESSAGE_EDITING_DETAIL MODIFY (MESSAGE_EDITING_ID numeric,EDITABLE_B numeric,NOTEMPTY_B numeric)
/

    ALTER TABLE ADVICE_DOCUMENT_KWD MODIFY (ID numeric,ADVICE_ID numeric)
/

    ALTER TABLE CALYPSO_IMAGES MODIFY (IMAGE_ID numeric)
/

    ALTER TABLE CACHE_UPDATE MODIFY (ID numeric,VERSION numeric,LAST_UPDATED numeric,ACTION numeric,KEY_TYPE numeric)
/

    ALTER TABLE INVENTORY_CHECK_CONFIG MODIFY (ID numeric,VERSION numeric,TEMPLATE_ID numeric,WFW_TRANSITION_ID numeric,DISABLE numeric,IS_SECURITY_CHECK numeric,MIRROR_AS_ONE numeric,IS_BUSINESS_DAY numeric)
/

    ALTER TABLE ACCOUNTING_OFFSETTING_CONFIG MODIFY (ID numeric,VERSION numeric,PO_ID numeric,BOOK_ID numeric,CPTY_ID numeric,OFFSETTING_TYPE_ID numeric)
/

    ALTER TABLE ACCOUNTING_PL_CONFIG MODIFY (ID numeric,VERSION numeric,OFFICIALPLCONFIG_ID numeric,YEAREND_PRORATE_TERMINATION numeric,POSITIONBY_OPEN_TRADE numeric)
/

    ALTER TABLE ACCOUNTING_PL_ITEM MODIFY (ID numeric,VERSION numeric,ACCOUNTINGPL_CONFIG_ID numeric,TRADE_ID numeric,TRADE_VERSION numeric,IS_TRADE numeric,SECURITY_ID numeric,BOOK_ID numeric)
/

    ALTER TABLE ACCOUNTING_PL_ITEM_ATTR MODIFY (ENTITY_ID numeric)
/

    ALTER TABLE ATTRIBUTE_CONFIG MODIFY (ID numeric,VERSION numeric,SEARCHABLE numeric)
/

    ALTER TABLE EQUITYIDX_IMPLIEDCASH_CONFIG MODIFY (EQUITYIDX_ID numeric,CONTRACT_ID numeric,ROLL_LAG_DAYS numeric,IS_ROLL_BUSINESS_DAYS numeric)
/

    ALTER TABLE PL_TAX MODIFY (SOURCE_ID numeric,SOURCE_VERSION numeric,TAX_ID numeric,RULE_ID numeric,RULE_VERSION numeric)
/

    ALTER TABLE PIK_SCHEDULE MODIFY (PRODUCT_ID numeric,SUB_ID numeric)
/

    ALTER TABLE MULTIPLE_OWNER_CUSTODY_ACCOUNT MODIFY (ID numeric,ACCOUNT_ID numeric,LE_ID numeric,BLOCKED numeric)
/

    ALTER TABLE ERS_H_NODE_ATTRIBUTE_PENDING MODIFY (NODE_ID numeric)
/

    ALTER TABLE ERS_H_PENDING MODIFY (NODE_ID numeric,PARENT_ID numeric,NODE_KEY numeric)
/

    ALTER TABLE ERS_HIERARCHY_MSG MODIFY (NODE_ID numeric,MSG_ID numeric,MSG_LEVEL numeric,MSG_TYPE numeric,NODE_KEY numeric,ANALYSES_VALUEDATE numeric)
/

    ALTER TABLE ERS_HIERARCHY_NODE_ATTRIBUTE MODIFY (VERSION numeric,NODE_ID numeric)
/

    ALTER TABLE ERS_LOG MODIFY (RUN_ID numeric,CALC_ID numeric,ISEXCEPTION numeric)
/

    ALTER TABLE TRIPARTY_AGENT_MAPPING MODIFY (ID numeric,VERSION numeric)
/

    ALTER TABLE CS_PRIMING MODIFY (ISACTIVE numeric,DATERULE_ID numeric)
/

    ALTER TABLE TRIPARTY_ALLOCATION_PARAMETER MODIFY (ID numeric,LEGAL_ENTITY_ID numeric,VERSION numeric)
/

    ALTER TABLE ACCESS_PERM_DELEGATION MODIFY (DELEGATION_ID numeric,VERSION_NUM numeric,PREVIOUS_DELEGATION_ID numeric)
/

    ALTER TABLE ACTIVEMQ_ACKS MODIFY (LAST_ACKED_ID numeric,PRIORITY numeric)
/

    ALTER TABLE ACTIVEMQ_LOCK MODIFY (ID numeric,TIME numeric)
/

    ALTER TABLE ACTIVEMQ_MSGS MODIFY (ID numeric,MSGID_SEQ numeric,EXPIRATION numeric,PRIORITY numeric)
/

    ALTER TABLE MULTI_QUOTE_MAPPING MODIFY (PRODUCT_ID numeric,SETTLE_DAYS numeric,PRIORITY numeric)
/

    ALTER TABLE MULTI_QUOTE_MAPPING_EQUITY MODIFY (PRODUCT_ID numeric,SETTLE_DAYS numeric,PRIORITY numeric)
/

    ALTER TABLE PLATFORM_CORE_TENANT_INIT MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE AM_SERVER_CONFIGURATION MODIFY (SERVER_ID numeric,VERSION numeric,CALYPSO_VERSION numeric,CACHE_QUOTES_UPDATE numeric,SERVER1_TRADE_FREQUENCY numeric,SERVER1_MARKETDATA_FREQUENCY numeric,SERVER2_TRADE_FREQUENCY numeric,SERVER2_MARKETDATA_FREQUENCY numeric,SERVER3_TRADE_FREQUENCY numeric,SERVER3_MARKETDATA_FREQUENCY numeric)
/

    ALTER TABLE AM_COLUMN_CONFIGURATION MODIFY (UPDATE_VERSION numeric,AUDIT_ID numeric)
/

    ALTER TABLE AM_FORMULA_CONFIGURATION MODIFY (UPDATE_VERSION numeric,AUDIT_ID numeric)
/

    ALTER TABLE AM_COLUMNSET_CONFIGURATION MODIFY (UPDATE_VERSION numeric,AUDIT_ID numeric)
/

    ALTER TABLE AM_COLUMNSET_ACTIONS MODIFY (ACTION_ID numeric)
/

    ALTER TABLE AM_COLUMNSET_MAIN_COLUMNS MODIFY (ITEM_INDEX numeric)
/

    ALTER TABLE AM_COLUMNSET_PIVOT_COLUMNS MODIFY (ITEM_INDEX numeric)
/

    ALTER TABLE AM_COLUMNSET_GROUP_COLUMNS MODIFY (ITEM_INDEX numeric)
/

    ALTER TABLE AM_COLUMNSET_BREAKDOWN_COLUMNS MODIFY (ITEM_INDEX numeric)
/

    ALTER TABLE AM_UNIT_CONFIGURATION MODIFY (UPDATE_VERSION numeric,AUDIT_ID numeric)
/

    ALTER TABLE AM_GROUPING_CONFIGURATION MODIFY (UPDATE_VERSION numeric,AUDIT_ID numeric)
/

    ALTER TABLE AM_GROUPING_COLUMNS MODIFY (ITEM_INDEX numeric)
/

    ALTER TABLE AM_WIDGET_CONFIGURATION MODIFY (UPDATE_VERSION numeric,AUDIT_ID numeric)
/

    ALTER TABLE AM_CHART_WIDGET_CONFIGURATION MODIFY (NUMBER_OF_SEGMENTS numeric,DISPLAY_BAR_LABEL numeric)
/

    ALTER TABLE AM_LAYOUT_CONFIGURATION MODIFY (UPDATE_VERSION numeric,AUDIT_ID numeric)
/

    ALTER TABLE AM_LAYOUT_POSITION MODIFY (DISPLAY_ALL numeric,OPENED_POSITIONS numeric,CLOSED_POSITIONS numeric,INTRADAY_TRADES numeric,CLOSED_STRATEGIES numeric,CASH_INSTRUMENT numeric,BENCHMARK_INSTRUMENT numeric,LOOKTROUGH_ADJUSTMENT numeric,HIDE_NONE_GROUPS numeric)
/

    ALTER TABLE AM_LAYOUT_DISPLAY MODIFY (OVERRIDE_DECIMALS_DISPLAY numeric)
/

    ALTER TABLE AM_FILTERING_CONFIGURATION MODIFY (IS_PREFILTERING numeric,IS_AND_CRITERIA numeric,UPDATE_VERSION numeric,AUDIT_ID numeric)
/

    ALTER TABLE AM_FILTERING_COLUMNS MODIFY (ITEM_INDEX numeric)
/

    ALTER TABLE AM_COLORING_CONFIGURATION MODIFY (UPDATE_VERSION numeric,AUDIT_ID numeric)
/

    ALTER TABLE AM_COLORING_RULE_CONFIGURATION MODIFY (COLOR numeric,ITEM_INDEX numeric)
/

    ALTER TABLE PRODUCT_TRIPARTY_EXPOSURE MODIFY (PRODUCT_ID numeric,MCC_ID numeric)
/

    ALTER TABLE USERPREFS_PREFERENCES MODIFY (VERSION numeric,TENANT_ID numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE DASHBOARD_CONFIG_LAYOUT MODIFY (VERSION numeric,TENANT_ID numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE DASHBOARD_CONFIG_DASHBOARD MODIFY (VERSION numeric,TENANT_ID numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,IS_SHARED numeric)
/

    ALTER TABLE DASHBOARD_CONFIG_WIDGET MODIFY (VERSION numeric,TENANT_ID numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE DASHBOARD_CONFIG_WIDGET_ATTR MODIFY (VERSION numeric,TENANT_ID numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE USERPREFS_TEMPLATE MODIFY (VERSION numeric,TENANT_ID numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE USERPREFS_TEMPLATE_CRIT MODIFY (VERSION numeric,TENANT_ID numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE RE_QUOTE_LIST MODIFY (VERSION_NUM numeric,TX_ID numeric)
/

    ALTER TABLE RE_QUOTE_RULE_CONFIG MODIFY (CONFIG_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE RE_QUOTE_RULES MODIFY (RULE_ID numeric,QUOTE_TYPE numeric,IS_ACTIVE numeric)
/

    ALTER TABLE RE_QUOTE_RULES_PARAMS MODIFY (RULE_ID numeric)
/

    ALTER TABLE RE_QUOTE_MANUAL_PUBLISH MODIFY (ACTIVE numeric,VERSION numeric)
/

    ALTER TABLE RE_QUOTE_MANUAL_PUBLISH_AUDIT MODIFY (ACTIVE numeric,VERSION numeric)
/

    ALTER TABLE BLOOM_SEC_ENTITLEMENT MODIFY (SECURITY_EID numeric)
/

    ALTER TABLE PRODUCT_BANKING_FLOWS MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE BK_FLWS_VF MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE BK_FLWS_VF_SCHD MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE BK_FLWS_VF_ATTRBT MODIFY (PRODUCT_ID numeric,ATTRBT_COLLECTION_IDX numeric)
/

    ALTER TABLE LIQ_EXPRESSION MODIFY (EXPRESSION_ID numeric)
/

    ALTER TABLE LIQ_EXPR_VARIABLE MODIFY (VARIABLE_ID numeric)
/

    ALTER TABLE LIQ_EXPR_VARIABLE_PARAMS MODIFY (VARIABLE_ID numeric)
/

    ALTER TABLE PRODUCT_REPO_ALLOCATION MODIFY (PRODUCT_ID numeric,SECURITY_ID numeric)
/

    ALTER TABLE LIQ_FLOATING_RATE_NOTE MODIFY (ID numeric,VERSION numeric)
/

    ALTER TABLE LIQ_DOMAIN_ATTRIBUTES MODIFY (VERSION numeric)
/

    ALTER TABLE LIQ_TRADE_SNAPSHOT_DEF MODIFY (VERSION numeric)
/

    ALTER TABLE LIQ_TRADE_SNAPSHOT MODIFY (TRADE_ID numeric,VERSION numeric)
/

    ALTER TABLE LIQ_TIME_DISTRIBUTION MODIFY (TD_PERCENTAGE numeric,VERSION numeric)
/

    ALTER TABLE LIQ_OBJECT MODIFY (ID numeric,VERSION numeric)
/

    ALTER TABLE LIQ_OBJECT_ATTR MODIFY (ID numeric)
/

    ALTER TABLE BA_BEHAVIORAL_SCENARIO MODIFY (BEHAVIORAL_SCENARIO_ID numeric,PERTURB_CONFIG_ID numeric,CREDIT_DOWNGRADE_SCENARIO_ID numeric,VERSION numeric)
/

    ALTER TABLE BA_SCENARIO_RULE_MAPPING MODIFY (BEHAVIORAL_SCENARIO_ID numeric,ASSUMPTION_RULE_ID numeric,PRIORITY numeric)
/

    ALTER TABLE BA_SCENARIO_CLASS_REMAP MODIFY (BEHAVIORAL_SCENARIO_ID numeric,CLASSIFICATION_REMAP_ID numeric,PRIORITY numeric)
/

    ALTER TABLE BA_ASSUMPTION_RULE MODIFY (ASSUMPTION_RULE_ID numeric,CRITERIA_ID numeric,ACTION_ID numeric,CLASSIFICATION_ID numeric,VERSION numeric)
/

    ALTER TABLE BA_ASSUMPTION_ACTION MODIFY (ACTION_ID numeric)
/

    ALTER TABLE BA_ASSUMPTION_ACTION_PARAMS MODIFY (ACTION_ID numeric)
/

    ALTER TABLE BA_PERTURBATION_CONFIG MODIFY (PERTURB_CONFIG_ID numeric,VERSION numeric)
/

    ALTER TABLE BA_PERTURBATION_RULE MODIFY (PERTURB_CONFIG_ID numeric,RULE_ORDER numeric)
/

    ALTER TABLE CREDIT_DOWNGRADE_SCENARIO MODIFY (SCENARIO_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE CREDIT_DOWNGRADE_DETAILS MODIFY (SCENARIO_ID numeric,CLASSIFICATION_ID numeric)
/

    ALTER TABLE CREDIT_DOWNGRADE_RATING MODIFY (SCENARIO_ID numeric,OBJ_ID numeric)
/

    ALTER TABLE LIQ_CLASS_FACTOR MODIFY (ID numeric,VERSION numeric)
/

    ALTER TABLE LIQ_CLASS_ATTRIBUTE MODIFY (ID numeric,VERSION numeric)
/

    ALTER TABLE LIQ_CLASS_ATTRIBUTE_RULES MODIFY (ATTRIBUTE_ID numeric,FACTOR_ID numeric,PRIORITY numeric)
/

    ALTER TABLE LIQ_CLASS_CRITERION MODIFY (ID numeric,EXPRESSION_ID numeric,VERSION numeric)
/

    ALTER TABLE LIQ_CLASS_CLASSIFICATION MODIFY (ID numeric,VERSION numeric)
/

    ALTER TABLE LIQ_CLASS_CLASS_RULES MODIFY (CLASSIFICATION_ID numeric,PRIORITY numeric,CRITERION_ID numeric,VALUE_TYPE numeric)
/

    ALTER TABLE LIQ_CLASS_REMAP MODIFY (ID numeric,SOURCE_ID numeric,TARGET_ID numeric,VERSION numeric)
/

    ALTER TABLE LIQ_CLASS_NAMED_LIST MODIFY (ID numeric,LIST_TYPE numeric,VERSION numeric)
/

    ALTER TABLE LIQ_CLASS_NAMED_LIST_ENTRY MODIFY (NAMED_LIST_ID numeric)
/

    ALTER TABLE LIQ_CLASS_LEVEL MODIFY (ID numeric,VERSION numeric)
/

    ALTER TABLE LIQ_CLASS_LEVEL_ENTRY MODIFY (LEVEL_ID numeric,CLASS_INDEX numeric,CLASS_ID numeric)
/

    ALTER TABLE LIQ_CLASSIFICATION_LEVEL_ITEM MODIFY (ID numeric,CLASSIFICATION_LEVEL_ID numeric)
/

    ALTER TABLE FTP_TRADE_COST_COMPONENT MODIFY (TRADE_ID numeric,VERSION numeric)
/

    ALTER TABLE FTP_TRADE_COST_COMPONENT_ATTR MODIFY (TRADE_ID numeric,TRADE_VERSION numeric,VERSION numeric)
/

    ALTER TABLE FTP_TRADE_COST_COMPONENT_HIST MODIFY (TRADE_ID numeric,VERSION numeric)
/

    ALTER TABLE FTP_TRADE_COST_COMP_ATTR_HIST MODIFY (TRADE_ID numeric,TRADE_VERSION numeric,VERSION numeric)
/

    ALTER TABLE FTP_PAYMENT_SCHEDULE MODIFY (ID numeric,SOURCE_BOOK_FROM_TRADE_B numeric,SOURCE_BOOK_ID numeric,TARGET_BOOK_FROM_TRADE_B numeric,TARGET_BOOK_ID numeric,VERSION numeric,PAYOUT_TYPE numeric)
/

    ALTER TABLE FTP_RATE_RETRIEVAL_CONFIG MODIFY (ID numeric,VERSION numeric)
/

    ALTER TABLE FTP_RATE_RETRIEVAL_CONFIG_ATTR MODIFY (FTP_RATE_RETRIEVAL_CONFIG_ID numeric)
/

    ALTER TABLE FTP_COST_COMPONENT_RULE MODIFY (ID numeric,PRIORITY numeric,VERSION numeric,CLASSIFICATION_ID numeric)
/

    ALTER TABLE FTP_COST_COMPONENT_RULE_ITEM MODIFY (RULE_ID numeric,PMT_SCHEDULE_ID numeric,RATE_RETRIEVAL_CONFIG_ID numeric)
/

    ALTER TABLE FTP_COST_ACCRUAL MODIFY (TRADE_ID numeric,STATUS numeric,SOURCE_BOOK_ID numeric,TARGET_BOOK_ID numeric,FTP_TRADE_ID numeric,PAYOUT_TYPE numeric,RATE_SOURCE_TYPE numeric,VERSION numeric,TRANSACTION_ID numeric)
/

    ALTER TABLE FTP_COST_ACCRUAL_SECURITY MODIFY (TRADE_ID numeric,SECURITY_ID numeric,STATUS numeric,SOURCE_BOOK_ID numeric,TARGET_BOOK_ID numeric,FTP_TRADE_ID numeric,PAYOUT_TYPE numeric,RATE_SOURCE_TYPE numeric,VERSION numeric,TRANSACTION_ID numeric)
/

    ALTER TABLE LIQ_METRIC_CUBE MODIFY (LIQ_METRIC_CUBE_ID numeric,METRIC_CONFIG_ID numeric,VERSION numeric)
/

    ALTER TABLE LIQ_METRIC_CUBE_POINT_KEY MODIFY (LIQ_METRIC_CUBE_ID numeric,CUBE_POINT_KEY_ID numeric)
/

    ALTER TABLE LIQ_METRIC_CUBE_POINT_VALUE MODIFY (LIQ_METRIC_CUBE_ID numeric,CUBE_POINT_KEY_ID numeric,CUBE_POINT_TIME numeric)
/

    ALTER TABLE CTXT_POS_BUCKET_CONF MODIFY (CONFIG_ID numeric,VERSION_NUM numeric,DATA_BKT_1_KEY numeric,DATA_BKT_2_KEY numeric,DATA_BKT_3_KEY numeric,DATA_BKT_4_KEY numeric,DATA_BKT_5_KEY numeric,DATA_BKT_6_KEY numeric,DATA_BKT_7_KEY numeric,DATA_BKT_8_KEY numeric,BUCKET_SCOPE_ID numeric,ACTIVE_B numeric,CONFIG_TYPE numeric,PERSISTED_BKT_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_BUCKET_CONF_STAT MODIFY (CONFIG_ID numeric,POSITION_DIRTY_B numeric,SYN_POSITION_DIRTY_B numeric)
/

    ALTER TABLE CTXT_POS_FILTER MODIFY (CXT_POS_FILTER_ID numeric,CASH_CTXT_POS_CONFIG_ID numeric,SEC_CTXT_POS_CONFIG_ID numeric,IDX_CASH_CTXT_POS_CONFIG_ID numeric,EXP_CTXT_POS_CONFIG_ID numeric,MAR_CASH_CTXT_POS_CONFIG_ID numeric,MAR_SEC_CTXT_POS_CONFIG_ID numeric,EXT_BANKING_CTXT_POS_CONFIG_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE CTXT_POS_FILTER_CRIT MODIFY (ID numeric,CXT_POS_FILTER_ID numeric,BCKT_CFG_ID numeric,BCKT_KEY_ID numeric,BCKT_KEY_IDX numeric,CRIT_CONSTRAINT numeric)
/

    ALTER TABLE CTXT_POS_FILTER_CRIT_ATTR MODIFY (CTXT_POS_FILTER_CRIT_ID numeric)
/

    ALTER TABLE CONTEXT_POSITION_MOVEMENTS MODIFY (MOVEMENT_ID numeric,SOURCE_IDENTIFIER_LONG numeric,CTXT_POS_SPACE_BITMAP numeric)
/

    ALTER TABLE CTXT_POS_SRC_MVMT_TRTX MODIFY (SRC_GRP_IDENTIFIER_LONG numeric,VERSION_NUM numeric,IS_IN_ERROR numeric,TRSRY_TRD_TYPE numeric)
/

    ALTER TABLE CTXT_POS_SRC_MVMT_TRTX_HIST MODIFY (SRC_GRP_IDENTIFIER_LONG numeric,VERSION_NUM numeric,IS_IN_ERROR numeric,TRSRY_TRD_TYPE numeric)
/

    ALTER TABLE CTXT_POS_SRC_MVMT_MSG MODIFY (SRC_GRP_IDENTIFIER_LONG numeric,VERSION_NUM numeric,IS_IN_ERROR numeric,TRSRY_TRD_TYPE numeric)
/

    ALTER TABLE CTXT_POS_SRC_MVMT_MSG_HIST MODIFY (SRC_GRP_IDENTIFIER_LONG numeric,VERSION_NUM numeric,IS_IN_ERROR numeric,TRSRY_TRD_TYPE numeric)
/

    ALTER TABLE CTXT_POS_SRC_MVMT_EXT MODIFY (SRC_GRP_IDENTIFIER_LONG numeric,VERSION_NUM numeric,IS_IN_ERROR numeric,TRSRY_TRD_TYPE numeric)
/

    ALTER TABLE CTXT_POS_SRC_MVMT_EXT_HIST MODIFY (SRC_GRP_IDENTIFIER_LONG numeric,VERSION_NUM numeric,IS_IN_ERROR numeric,TRSRY_TRD_TYPE numeric)
/

    ALTER TABLE CTXT_POS_SRC_MVMT_SYNT MODIFY (SRC_GRP_IDENTIFIER_LONG numeric,VERSION_NUM numeric,IS_IN_ERROR numeric,TRSRY_TRD_TYPE numeric)
/

    ALTER TABLE CTXT_POS_SRC_MVMT_SYNT_HIST MODIFY (SRC_GRP_IDENTIFIER_LONG numeric,VERSION_NUM numeric,IS_IN_ERROR numeric,TRSRY_TRD_TYPE numeric)
/

    ALTER TABLE LIQ_EXTERNAL_MOVEMENT MODIFY (MOVEMENT_IDX numeric,MCC_ID numeric,RECORD_ID numeric,VERSION numeric)
/

    ALTER TABLE LIQ_CTXT_POS_REINIT_JOB MODIFY (JOB_ID numeric,TRADE_BATCH_SIZE numeric,TRANSFER_BATCH_SIZE numeric,MESSAGE_BATCH_SIZE numeric,POSITION_BATCH_SIZE numeric,VERSION numeric)
/

    ALTER TABLE LIQ_CTXT_POS_REINIT_TASK MODIFY (JOB_ID numeric,TASK_INDEX numeric,BATCH_START_INDEX numeric,BATCH_END_INDEX numeric)
/

    ALTER TABLE CTXT_POS_BUCKET_SCOPE MODIFY (SCOPE_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE CTXT_POS_BUCKET_SCOPE_CRIT MODIFY (SCOPE_ID numeric,ATTR_INDEX numeric,ATTR_CLASS_ID numeric,OPERATOR numeric,ATTR_NAMED_LIST_ID numeric)
/

    ALTER TABLE LIQ_LIMIT_CCY_BUCKET MODIFY (ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE LIQ_LIMIT_CCY_CLASS_LVL MODIFY (ID numeric,CLASSIFICATION_LEVEL_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE LIQ_LIMIT_CCY_CLASS_LVL_BUCKET MODIFY (ID numeric,CLASSIFICATION_LEVEL_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE LIQ_MET_CFG_FWD_LADDER MODIFY (METRIC_CONFIG_ID numeric,VERSION numeric)
/

    ALTER TABLE LIQ_MET_CFG_REF_TEMPLATE MODIFY (METRIC_CONFIG_ID numeric,VERSION numeric)
/

    ALTER TABLE LIQ_MET_CFG_AXES MODIFY (METRIC_CONFIG_ID numeric,AXIS_IDX numeric)
/

    ALTER TABLE LIQ_MET_CFG_DATA_COLS MODIFY (METRIC_CONFIG_ID numeric)
/

    ALTER TABLE CONTEXT_POSITION_BLOCK MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CONTEXT_POSITION_BLOCK_REDUCE MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_MVMTS_REINIT_1 MODIFY (MOVEMENT_ID numeric,SOURCE_IDENTIFIER_LONG numeric,CTXT_POS_SPACE_BITMAP numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_1 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_REDUCE_1 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_MVMTS_REINIT_2 MODIFY (MOVEMENT_ID numeric,SOURCE_IDENTIFIER_LONG numeric,CTXT_POS_SPACE_BITMAP numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_2 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_REDUCE_2 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_MVMTS_REINIT_3 MODIFY (MOVEMENT_ID numeric,SOURCE_IDENTIFIER_LONG numeric,CTXT_POS_SPACE_BITMAP numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_3 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_REDUCE_3 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_MVMTS_REINIT_4 MODIFY (MOVEMENT_ID numeric,SOURCE_IDENTIFIER_LONG numeric,CTXT_POS_SPACE_BITMAP numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_4 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_REDUCE_4 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_MVMTS_REINIT_5 MODIFY (MOVEMENT_ID numeric,SOURCE_IDENTIFIER_LONG numeric,CTXT_POS_SPACE_BITMAP numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_5 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_REDUCE_5 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_MVMTS_REINIT_6 MODIFY (MOVEMENT_ID numeric,SOURCE_IDENTIFIER_LONG numeric,CTXT_POS_SPACE_BITMAP numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_6 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_REDUCE_6 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_MVMTS_REINIT_7 MODIFY (MOVEMENT_ID numeric,SOURCE_IDENTIFIER_LONG numeric,CTXT_POS_SPACE_BITMAP numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_7 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_REDUCE_7 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_MVMTS_REINIT_8 MODIFY (MOVEMENT_ID numeric,SOURCE_IDENTIFIER_LONG numeric,CTXT_POS_SPACE_BITMAP numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_8 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_REDUCE_8 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_MVMTS_REINIT_9 MODIFY (MOVEMENT_ID numeric,SOURCE_IDENTIFIER_LONG numeric,CTXT_POS_SPACE_BITMAP numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_9 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_REDUCE_9 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_MVMTS_REINIT_10 MODIFY (MOVEMENT_ID numeric,SOURCE_IDENTIFIER_LONG numeric,CTXT_POS_SPACE_BITMAP numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_10 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE CTXT_POS_BLK_REINIT_REDUCE_10 MODIFY (BLOCK_ID numeric,CTXT_POS_BUCKET_CONFIG_ID numeric)
/

    ALTER TABLE TREASURY_MOVEMENTS MODIFY (MOVEMENT_ID numeric,SOURCE_IDENTIFIER_LONG numeric,CTXT_POS_SPACE_BITMAP numeric)
/

    ALTER TABLE BANKING_PRODUCT MODIFY (ID numeric,TEMPLATE_ID numeric,VERSION numeric)
/

    ALTER TABLE LIQ_INTEREST_PROJECTION MODIFY (ID numeric,PRIORITY numeric,VERSION numeric)
/

    ALTER TABLE LIQ_INTEREST_PROJ_FILTER MODIFY (ID numeric,CLASSIFICATION_ID numeric)
/

    ALTER TABLE LIQ_INTEREST_PROJ_OVERRIDE MODIFY (ID numeric,CLASSIFICATION_ID numeric)
/

    ALTER TABLE RATING_VALUES MODIFY (ORDER_ID numeric)
/

    ALTER TABLE PRODUCT_FTP MODIFY (PRODUCT_ID numeric,ORIGINAL_SECURITY_ID numeric,ORIGINAL_TRADE_ID numeric,ORIGINAL_TRADE_VERSION numeric,ORIGINAL_TRADE_MODEL numeric,IS_MIRROR numeric,KPI_MS numeric,KPI_MS_REMOTE numeric,KPI_MS_EXPLODE numeric,KPI_MS_GENERATE numeric,KPI_MS_MEASURES numeric,NUM_LEGS numeric,NUM_ERROR numeric,NUM_RECONVENTIONS numeric,NUM_EFFECTIVE_DATES numeric)
/

    ALTER TABLE PRODUCT_FTP_LEG MODIFY (PRODUCT_ID numeric,ORIGINAL_TRADE_VERSION numeric)
/

    ALTER TABLE ACC_BOOK MODIFY (ACC_BOOK_ID numeric)
/

    ALTER TABLE BOOK MODIFY (BOOK_ID numeric,ACC_BOOK_ID numeric,LEGAL_ENTITY_ID numeric,EOD_TIME numeric,VERSION_NUM numeric)
/

    ALTER TABLE CALYPSO_TABLE_EXT MODIFY (IS_STATIC_DATA numeric)
/

    ALTER TABLE FEE_DEFINITION MODIFY (IS_IN_PL_B numeric,IS_IN_TRANSFER_B numeric,IS_IN_ACCOUNTING_B numeric,IS_IN_SETTLE_AMT_B numeric,FEE_CODE numeric,VERSION_NUM numeric,OFFSET_DAYS numeric,OFFSET_BUSINESS_B numeric,IS_ALLOCATED numeric)
/

    ALTER TABLE REFERENCE_OBJECT MODIFY (REF_OBJ_ID numeric)
/

    ALTER TABLE REPORT_PANEL_DEF MODIFY (WIN_DEF_ID numeric,PANEL_INDEX numeric,TEMPLATE_ID numeric)
/

    ALTER TABLE REPORT_WIN_DEF MODIFY (WIN_DEF_ID numeric,USE_BOOK_HRCHY numeric,USE_PRICING_ENV numeric,USE_COLOR numeric)
/

    ALTER TABLE FIXING_DATE_POLICY MODIFY (FIXING_DATE_POLICY_ID numeric,INT_PARAM_1 numeric,INT_PARAM_2 numeric)
/

    ALTER TABLE PRODUCT_CODE MODIFY (UNIQUE_B numeric,SEARCHABLE_B numeric,MANDATORY_B numeric,OTC_B numeric,VERSION_NUM numeric)
/

    ALTER TABLE CUSTOM_TAB_TRADE_CONFIG MODIFY (TAB_ORDER numeric)
/

    ALTER TABLE PRICING_PARAM_NAME MODIFY (IS_GLOBAL_B numeric)
/

    ALTER TABLE AN_VIEWER_CONFIG MODIFY (READ_VIEWER_B numeric)
/

    ALTER TABLE CALYPSO_HIERARCHY MODIFY (TREE_ID numeric)
/

    ALTER TABLE CALYPSO_HIERARCHY_NODE MODIFY (TREE_ID numeric,NODE_ID numeric,PARENT_NODE_ID numeric)
/

    ALTER TABLE ERS_HIERARCHY MODIFY (VERSION numeric,NODE_ID numeric,PARENT_ID numeric,NODE_KEY numeric)
/

    ALTER TABLE ERS_HIERARCHY_ATTRIBUTE MODIFY (UNDERLYING_TYPE numeric,VERSION numeric,LATEST_VERSION numeric)
/

    ALTER TABLE ERS_INFO MODIFY (MAJOR_VERSION numeric,MINOR_VERSION numeric,SUB_VERSION numeric)
/

    ALTER TABLE OBJSTORE_FILES MODIFY (VERSION numeric,TENANT_ID numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,FILE_SIZE numeric,APP_NAME VARCHAR(64))
/

    ALTER TABLE OBJSTORE_FILES_CONTENT MODIFY (VERSION numeric,TENANT_ID numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,APP_NAME VARCHAR(64))
/

    ALTER TABLE CORE_ACCOUNT_ATTRIBUTE MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric)
/

    ALTER TABLE CORE_ACCOUNT_INTEREST_CONFIG MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric)
/

    ALTER TABLE CORE_BOND MODIFY (ACCRUAL_ROUNDING numeric,ACTIVE_DATE numeric,AMORT_AMOUNT FLOAT,AMORT_RATE FLOAT,ANNOUNCE_DATE numeric,AUCTION_DATE numeric,CALL_DATE numeric,CAP_STRIKE FLOAT,COUPON FLOAT,COUPON_DATE_RULE numeric,COUPON_OFFSET numeric,DATED_DATE numeric,DEFAULT_DATE numeric,DISC_METHOD numeric,FACE_VALUE FLOAT,FIRST_COUPON_DATE numeric,FLIPPER_DATE numeric,FLOOR_STRIKE FLOAT,FX_RATE FLOAT,HAS_ODD_FIRST_COUPON numeric,HAS_ODD_LAST_COUPON numeric,INACTIVE_DATE numeric,IS_AMORTIZING numeric,IS_CPN_OFF_BUS_DAY numeric,IS_FIXED numeric,IS_FLOATER numeric,IS_RESET_BUS_LAG numeric,IS_RESET_CUTOFF_BUS_DAY numeric,IS_RESET_IN_ARREARS numeric,ISSUE_DATE numeric,ISSUE_PRICE FLOAT,ISSUE_YIELD FLOAT,DELIVERABLE_LOT_SIZE FLOAT,MATURITY_DATE numeric,MIN_PURCHASE_AMT FLOAT,NOMINAL_DECIMALS numeric,PENULT_CPN_DATE numeric,PRICE_DECIMALS numeric,RATE_INDEX_FACTOR FLOAT,RATE_INDEX_SPREAD FLOAT,RECORD_DAYS numeric,REDEEM_DAYS numeric,REDEM_FX_RATE FLOAT,REDEMPTION_PRICE FLOAT,RESET_CUTOFF numeric,RESET_DAYS numeric,ROLLING_DAY numeric,ROUNDING_UNIT numeric,SAMPLE_WEEKDAY numeric,SETTLEMENT_DAYS numeric,TOTAL_ISSUED FLOAT,VALUE_DAYS numeric,WITHHOLDING_TAX FLOAT,YIELD_DECIMALS numeric,MATURITY_TENOR_DAYS numeric)
/

    ALTER TABLE CORE_COUNTRY MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric)
/

    ALTER TABLE CORE_CURRENCY MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric,ROUNDING_DECIMAL numeric)
/

    ALTER TABLE CORE_CURRENCYPAIR MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric)
/

    ALTER TABLE CORE_DATA_POLICY MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric)
/

    ALTER TABLE CORE_EQUITY MODIFY (ACTIVE_DATE numeric,DIVIDEND_DATE_RULE numeric,DIVIDEND_DECIMALS numeric,INACTIVE_DATE numeric,IS_PAY_DIVIDEND numeric,NOMINAL_DECIMALS numeric,PAR_VALUE FLOAT,TOTAL_ISSUED FLOAT,TRADING_SIZE FLOAT)
/

    ALTER TABLE CORE_HOLIDAY MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric)
/

    ALTER TABLE CORE_HOLIDAY_EVENT MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric,HOL_DATE numeric)
/

    ALTER TABLE CORE_INDEX MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric)
/

    ALTER TABLE CORE_INFLATION_INDEX MODIFY (PUBLICATION_LAG numeric,REFERENCE_DAY numeric)
/

    ALTER TABLE CORE_INTEREST_CONFIG MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric,EFFECTIVE_DATE numeric,FIXED_RATE FLOAT,SPREAD FLOAT)
/

    ALTER TABLE CORE_LE_ADDRESS MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric)
/

    ALTER TABLE CORE_LE_CONTACT MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric)
/

    ALTER TABLE CORE_LEGAL_ENTITY MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric,FINANCIAL numeric)
/

    ALTER TABLE CORE_PF_FROM_TO MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric,EXCLUDE_FROM numeric,EXCLUDE_TO numeric,FROM_LONG numeric,TO_LONG numeric,TO_TENOR_DAYS numeric,FROM_TENOR_DAYS numeric)
/

    ALTER TABLE CORE_PF_MULTI_VALUE MODIFY (MULTIPLE_VALUES_ORDER numeric)
/

    ALTER TABLE CORE_PF_MULTI_VALUES MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric,INCLUDED numeric)
/

    ALTER TABLE CORE_PRODUCT MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric)
/

    ALTER TABLE CORE_PRODUCT_FILTER MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric)
/

    ALTER TABLE CORE_PUT_CALL_DATE MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric,EXPIRY_DATE numeric,FIRST_EXERCISE_DATE numeric,STRIKE FLOAT)
/

    ALTER TABLE CORE_QUOTE_DEFINITION MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric)
/

    ALTER TABLE CORE_QUOTE_SET MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric)
/

    ALTER TABLE CORE_RATE_INDEX MODIFY (RESET_DAYS numeric,TENOR_DAYS numeric)
/

    ALTER TABLE CORE_RATING MODIFY (AVAILABLE_RATINGS_ORDER numeric)
/

    ALTER TABLE CORE_RATING_AGENCY MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric)
/

    ALTER TABLE CORE_RATING_LE MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric,EFFECTIVE_DATE numeric)
/

    ALTER TABLE CORE_REGULATORY MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric)
/

    ALTER TABLE CORE_SECURITY_ATTRIBUTE MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric)
/

    ALTER TABLE CORE_SECURITY_IDENTIFIER MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric)
/

    ALTER TABLE CORE_SETTLEMENT_ACCOUNT MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric)
/

    ALTER TABLE CORE_SPLIT_CURRENCY MODIFY (CREATION_DATE numeric,TENANT_ID numeric,LAST_UPDATE_DATE numeric,VERSION numeric)
/

    ALTER TABLE CLS_SCHEDULE MODIFY (SCHEDULE_ID numeric,VERSION_NUM numeric,PARTY_ID numeric,ACKNOWLEDGED numeric)
/

    ALTER TABLE CLS_SCHEDULE_ITEM MODIFY (SCHEDULE_ID numeric)
/

    ALTER TABLE CLS_MESSAGE MODIFY (ID numeric,VERSION numeric,NEEDS_ACK numeric,ACKNOWLEDGED numeric,RECIPIENT numeric)
/

    ALTER TABLE CLS_RECO MODIFY (SCHEDULE_ID numeric)
/

    ALTER TABLE CLS_TRADE_INFO MODIFY (ID numeric,VERSION numeric,TRADE_ID numeric,STATEMENT_ID numeric,TOTAL_SPLITS numeric,SETTLED_SPLITS numeric,PO_SUSPENDED numeric,CP_SUSPENDED numeric,IS_ALLEGED numeric,IS_SPLIT_TRADE numeric)
/

    ALTER TABLE CLS_NON_REPUDIATION MODIFY (SNF_OUTOUT_SEQ numeric,RETRIEVED numeric)
/

    ALTER TABLE CLS_ACCOUNT_NOTIFICATION MODIFY (ID numeric,VERSION numeric,TRADE_ID numeric)
/

    ALTER TABLE CDSABS_MARKIT_FLOWS MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE MARKIT_PRODUCT_DATA MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE CDSABS_MARKIT_FLOWS_VERSION MODIFY (PRODUCT_ID numeric,VERSION_NUMBER numeric)
/

    ALTER TABLE MARGIN_RUN_INFO MODIFY (EOD numeric)
/

    ALTER TABLE MARGIN_LIQUIDITY_FACTOR MODIFY (LIQUIDITY_SET_ID numeric)
/

    ALTER TABLE MARGIN_LIQUIDITY MODIFY (VERSION numeric,EOD numeric)
/

    ALTER TABLE MARGIN_TRADE_LIQUIDITY MODIFY (EOD numeric)
/

    ALTER TABLE MARGIN_UNSETTLED_VM MODIFY (VERSION numeric)
/

    ALTER TABLE MARGIN_UNSETTLED_VM_HIST MODIFY (VERSION numeric)
/

    ALTER TABLE MARGIN_UNSETTLED_VM_TEMP MODIFY (VERSION numeric)
/

    ALTER TABLE MARGIN_VM_DEFINITION MODIFY (ADDITIONAL_COLUMN_INDEX numeric,INTRADAY numeric,FLIP_SIGN numeric,CUMULATIVE numeric)
/

    ALTER TABLE MARGIN_TRADE_VM MODIFY (PO_VIEW numeric,EOD numeric,PO numeric)
/

    UPDATE
        MARGIN_TRADE_VM 
    SET
        IM_PORTFOLIO_NAME = ' ' 
    WHERE
        IM_PORTFOLIO_NAME IS NULL
/

    ALTER TABLE MARGIN_TRADE_VM MODIFY IM_PORTFOLIO_NAME NOT NULL
/

    UPDATE
        MARGIN_TRADE_VM 
    SET
        CALCULATION_SET = ' ' 
    WHERE
        CALCULATION_SET IS NULL
/

    ALTER TABLE MARGIN_TRADE_VM MODIFY CALCULATION_SET NOT NULL
/

    ALTER TABLE MARGIN_TRADE_VM_HIST MODIFY (PO_VIEW numeric,EOD numeric,PO numeric)
/

    UPDATE
        MARGIN_TRADE_VM_HIST 
    SET
        IM_PORTFOLIO_NAME = ' ' 
    WHERE
        IM_PORTFOLIO_NAME IS NULL
/

    ALTER TABLE MARGIN_TRADE_VM_HIST MODIFY IM_PORTFOLIO_NAME NOT NULL
/

    UPDATE
        MARGIN_TRADE_VM_HIST 
    SET
        CALCULATION_SET = ' ' 
    WHERE
        CALCULATION_SET IS NULL
/

    ALTER TABLE MARGIN_TRADE_VM_HIST MODIFY CALCULATION_SET NOT NULL
/

    ALTER TABLE MARGIN_TRADE_VM_TEMP MODIFY (PO_VIEW numeric,EOD numeric,PO numeric)
/

    ALTER TABLE MARGIN_PORTFOLIO_VM MODIFY (VERSION numeric,EOD numeric,PO_VIEW numeric)
/

    UPDATE
        MARGIN_PORTFOLIO_VM 
    SET
        IM_PORTFOLIO_NAME = ' ' 
    WHERE
        IM_PORTFOLIO_NAME IS NULL
/

    ALTER TABLE MARGIN_PORTFOLIO_VM MODIFY IM_PORTFOLIO_NAME NOT NULL
/

    UPDATE
        MARGIN_PORTFOLIO_VM 
    SET
        CALCULATION_SET = ' ' 
    WHERE
        CALCULATION_SET IS NULL
/

    ALTER TABLE MARGIN_PORTFOLIO_VM MODIFY CALCULATION_SET NOT NULL
/

    ALTER TABLE MARGIN_PORTFOLIO_VM_HIST MODIFY (VERSION numeric,EOD numeric,PO_VIEW numeric)
/

    UPDATE
        MARGIN_PORTFOLIO_VM_HIST 
    SET
        IM_PORTFOLIO_NAME = ' ' 
    WHERE
        IM_PORTFOLIO_NAME IS NULL
/

    ALTER TABLE MARGIN_PORTFOLIO_VM_HIST MODIFY IM_PORTFOLIO_NAME NOT NULL
/

    UPDATE
        MARGIN_PORTFOLIO_VM_HIST 
    SET
        CALCULATION_SET = ' ' 
    WHERE
        CALCULATION_SET IS NULL
/

    ALTER TABLE MARGIN_PORTFOLIO_VM_HIST MODIFY CALCULATION_SET NOT NULL
/

    ALTER TABLE MARGIN_PORTFOLIO_VM_TEMP MODIFY (VERSION numeric,EOD numeric,PO_VIEW numeric)
/

    ALTER TABLE MARGIN_RESULT MODIFY (VERSION numeric,EOD numeric)
/

    UPDATE
        MARGIN_RESULT 
    SET
        CALCULATION_REQUEST_ID = ' ' 
    WHERE
        CALCULATION_REQUEST_ID IS NULL
/

    ALTER TABLE MARGIN_RESULT MODIFY CALCULATION_REQUEST_ID NOT NULL
/

    ALTER TABLE MARGIN_RESULT_HIST MODIFY (VERSION numeric,EOD numeric)
/

    UPDATE
        MARGIN_RESULT_HIST 
    SET
        CALCULATION_REQUEST_ID = ' ' 
    WHERE
        CALCULATION_REQUEST_ID IS NULL
/

    ALTER TABLE MARGIN_RESULT_HIST MODIFY CALCULATION_REQUEST_ID NOT NULL
/

    ALTER TABLE MARGIN_RESULT_TEMP MODIFY (VERSION numeric,EOD numeric)
/

    ALTER TABLE MARGIN_RESULT_NODE MODIFY (VERSION numeric,DEPTH numeric,NODE_INDEX numeric)
/

    ALTER TABLE MARGIN_RESULT_NODE_HIST MODIFY (VERSION numeric,DEPTH numeric,NODE_INDEX numeric)
/

    ALTER TABLE MARGIN_RESULT_NODE_TEMP MODIFY (VERSION numeric,DEPTH numeric,NODE_INDEX numeric)
/

    ALTER TABLE AUDIT_RECORD MODIFY (VERSION numeric,TENANT_ID numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,CAPTURE_TIME numeric,ENTITY_VERSION_BEFORE numeric,RECALLED numeric)
/

    ALTER TABLE BLOOMBERG_FLOWS MODIFY (PRODUCT_ID numeric)
/

    ALTER TABLE BLOOM_BOND_MAP MODIFY (MAP_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE BLOOM_EQUITY_MAP MODIFY (MAP_ID numeric)
/

    ALTER TABLE BLOOMBERG_FIELDS MODIFY (ISCOMODTY numeric,ISEQUITY numeric,ISMUNI numeric,ISPFD numeric,ISMMKT numeric,ISGOVT numeric,ISCORP numeric,ISINDEX numeric,ISCURNCY numeric,ISMTGE numeric,STANDARD_WIDTH numeric,STANDARD_DECIMAL_PLACES numeric,ISBACKOFFICE numeric,ISEXTENDEDBACKOFFICE numeric,CURRENT_MAX_WIDTH numeric)
/

    ALTER TABLE DATE_RULE MODIFY (DATE_RULE_ID numeric,DATE_RULE_TYPE numeric,DATE_RULE_MONTH numeric,DATE_RULE_DAY numeric,DATE_RULE_RANK numeric,DATE_RULE_WEEKDAY numeric,ADD_DAYS numeric,BUS_CAL_B numeric,REL_RULE numeric,CHECK_HOLIDAYS numeric,ADD_MONTHS numeric,VERSION_NUM numeric,ADD_BUS_DAYS_B numeric)
/

    ALTER TABLE ADVICE_CONFIG MODIFY (ADVICE_CONFIG_ID numeric,PO_ID numeric,ALWAYS_SEND numeric,MATCHING numeric,INACTIVE numeric,RECEIVER_ID numeric,VERSION_NUM numeric,AUDIT_FILTER_ID numeric)
/

    ALTER TABLE SEND_CONFIG MODIFY (SEND_CONFIG_ID numeric,SEND_B numeric,SAVE_B numeric,PUBLISH_B numeric,BY_GATEWAY_B numeric,BY_METHOD_B numeric,VERSION_NUM numeric,BY_JMS_B numeric)
/

    ALTER TABLE PRICER_MEASURE MODIFY (MEASURE_ID numeric)
/

    ALTER TABLE PRICER_MEASURE MODIFY MEASURE_NAME varchar2 (64)
/

    ALTER TABLE CALYPSO_CACHE MODIFY (CACHE_LIMIT numeric,EXPIRATION numeric)
/

    ALTER TABLE REFERRING_OBJECT MODIFY (RFG_OBJ_ID numeric,REF_OBJ_ID numeric)
/

    ALTER TABLE MIME_TYPE MODIFY (DEFAULT_EXT_B numeric)
/

    ALTER TABLE SD_FILTER MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE SD_FILTER_DOMAIN MODIFY (ELEMENT_TYPE numeric)
/

    ALTER TABLE SD_FILTER_ELEMENT MODIFY (ELEMENT_TYPE numeric,IS_VALUE numeric,IS_MIN_INCLUSIVE numeric,IS_MAX_INCLUSIVE numeric)
/

    ALTER TABLE BOOK_ATTRIBUTE MODIFY (IS_PL_METHODOLOGY_DRIVER numeric)
/

    ALTER TABLE BLOOMBERG_VALUES MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE BLOOM_DAYCNT_MAP MODIFY (MAP_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE BLOOM_HEADER_OPT MODIFY (FTP_STATUS numeric,SEND_STATUS numeric,VERSION_NUM numeric)
/

    ALTER TABLE CALYPSO_SEED MODIFY (LAST_ID numeric,SEED_ALLOC_SIZE numeric)
/

    ALTER TABLE LEGAL_ENTITY MODIFY (LEGAL_ENTITY_ID numeric,PARENT_LE_ID numeric,CLASSIFICATION numeric,VERSION_NUM numeric,TRIPARTY_ALLOC_TYPE numeric,ANONYMIZED numeric)
/

    ALTER TABLE LEGAL_ENTITY_ROLE MODIFY (LEGAL_ENTITY_ID numeric)
/

    ALTER TABLE ENTITY_ATTRIBUTES MODIFY (ENTITY_ID numeric)
/

    ALTER TABLE MARGIN_SENSITIVITY MODIFY (VERSION numeric,BUCKET numeric)
/

    ALTER TABLE MARGIN_SENSITIVITY_HIST MODIFY (VERSION numeric,BUCKET numeric)
/

    ALTER TABLE MARGIN_TRADE_SENSITIVITY MODIFY (BUCKET numeric)
/

    ALTER TABLE MARGIN_TRADE_SENSITIVITY_HIST MODIFY (BUCKET numeric)
/

    ALTER TABLE CM_RESULT MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,VALUATION_DATE numeric)
/

    ALTER TABLE CM_CALCULATION_SUMMARY MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE CM_RESULT_NODE MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,DEPTH numeric,NODE_INDEX numeric)
/

    ALTER TABLE CM_RESULT_HIST MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,VALUATION_DATE numeric)
/

    ALTER TABLE CM_RESULT_TEMP MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,VALUATION_DATE numeric)
/

    ALTER TABLE CM_CALCULATION_SUMMARY_HIST MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE CM_CALCULATION_SUMMARY_TEMP MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE CM_RESULT_NODE_HIST MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,DEPTH numeric,NODE_INDEX numeric)
/

    ALTER TABLE CM_RESULT_NODE_TEMP MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,DEPTH numeric,NODE_INDEX numeric)
/

    ALTER TABLE CM_SIMM_REGULATOR MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE CM_ACCOUNT MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE CM_ACCOUNT_DETAILS MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE CM_SIMM_ACCOUNTS MODIFY (ACTIVE_FROM numeric,ACTIVE_TO numeric)
/

    ALTER TABLE CM_SIMM_ACCOUNT MODIFY (ACTIVE_FROM numeric,ACTIVE_TO numeric)
/

    ALTER TABLE CM_SIMM_REGULATOR_PARAMETERS MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE CM_SIMM_PARAMETERS MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE CM_FLAT_SIMM_PARAM MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE CM_WHATIF_RESULT MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE CM_WHATIF_RESULT_DETAIL MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,VALUATION_DATE numeric)
/

    ALTER TABLE CM_ISDA_PRODUCT_TYPE MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE CM_IM_TH_MONITORING_CONFIG MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE CM_IM_TH_MONITORING_RESULT MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric,VALUATION_DATE numeric)
/

    ALTER TABLE CM_CSA_ACCOUNT_DETAILS MODIFY (TENANT_ID numeric,VERSION numeric,CREATION_DATE numeric,LAST_UPDATE_DATE numeric)
/

    ALTER TABLE SWIFT_MESSAGE_MAPPING_CONFIG MODIFY (ID numeric,VERSION numeric,AGENT_ID numeric,PO_ID numeric,BOOK_ID numeric,CPTY_ID numeric)
/

    ALTER TABLE CALYPSO_MAPPING MODIFY (REVERSE_B numeric,VERSION_NUM numeric)
/

    ALTER TABLE MATCHING_CONTEXT MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE MATCHING_PROPERTY_DEF MODIFY (COLUMN_SIZE numeric,COLUMN_NULLABLE numeric)
/

    ALTER TABLE SUB_TYPE_MAP MODIFY (SUB_TYPE numeric)
/

    ALTER TABLE MATCHING_ALIAS MODIFY (ALIAS_ID numeric,VERSION_NUM numeric,VALUE_HASH numeric)
/

    ALTER TABLE MATCHING_ALIAS_LINK MODIFY (ALIAS_LINK_ID numeric,ALIAS_ID numeric,LE_ID numeric,PO_ID numeric)
/

    ALTER TABLE BO_MATCHABLE MODIFY (OBJECT_ID numeric,OBJECT_VERSION numeric,IS_INCOMING numeric,IS_MATCHABLE numeric,PO_ID numeric,LE_ID numeric)
/

    ALTER TABLE BO_MATCHABLE_HIST MODIFY (OBJECT_ID numeric,OBJECT_VERSION numeric,IS_INCOMING numeric,IS_MATCHABLE numeric,PO_ID numeric,LE_ID numeric)
/

    ALTER TABLE BO_MATCHABLE_THREE_WAY MODIFY (MATCHABLE_VERSION numeric,OBJECT_ID numeric,OBJECT_VERSION numeric,IS_INCOMING numeric,IS_MATCHABLE numeric,IS_BROKER numeric,IS_BROKER_INDEXABLE numeric,PO_ID numeric,LE_ID numeric)
/

    ALTER TABLE BO_MATCHABLE_THREE_WAY_HIST MODIFY (MATCHABLE_VERSION numeric,OBJECT_ID numeric,OBJECT_VERSION numeric,IS_INCOMING numeric,IS_MATCHABLE numeric,IS_BROKER numeric,IS_BROKER_INDEXABLE numeric,PO_ID numeric,LE_ID numeric)
/

    ALTER TABLE BO_MATCHABLE_DYN MODIFY (MATCHABLE_VERSION numeric,OBJECT_ID numeric,OBJECT_VERSION numeric,IS_INCOMING numeric,IS_MATCHABLE numeric,PO_ID numeric,LE_ID numeric)
/

    ALTER TABLE BO_MATCHABLE_DYN_HIST MODIFY (MATCHABLE_VERSION numeric,OBJECT_ID numeric,OBJECT_VERSION numeric,IS_INCOMING numeric,IS_MATCHABLE numeric,PO_ID numeric,LE_ID numeric)
/

    ALTER TABLE ENGINE_CONFIG MODIFY (ENGINE_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE REUTERSDSS_CONFIG_NAME MODIFY (CONFIG_ID numeric,CONFIG_STATUS numeric,RPT_TMPLT_ID numeric,RPT_COL_ID numeric,INSTRUMENT_ID numeric,SCHEDULES_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE REUTERSDSS_RPT_TEMPLATES MODIFY (RPT_TMPLT_ID numeric,DELTA_EXTRACT_DAYS numeric,VERSION_NUM numeric)
/

    ALTER TABLE REUTERSDSS_RPT_COLS MODIFY (RPT_COL_ID numeric,SEQUENCE numeric,VERSION_NUM numeric)
/

    ALTER TABLE REUTERSDSS_INSTRUMENTS MODIFY (INSTRUMENT_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE REUTERSDSS_SCHEDULES MODIFY (SCHEDULES_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE REUTERSDSS_MAPPING MODIFY (VERSION_NUM numeric)
/

    ALTER TABLE REUTERSDSS_MAPPING_RULES MODIFY (ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE REUTERSDSS_PROD_MAPPING MODIFY (ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE TR_REPORTING_ATTR MODIFY (REPORTING_ATTRIBUTE_ID numeric,VERSION numeric,VISIBLE numeric,READONLY numeric,COPIABLE numeric)
/

    ALTER TABLE TR_REPORTING_ATTR_RESTRICTION MODIFY (REPORTING_ATTRIBUTE_ID numeric)
/

    ALTER TABLE TR_REGULATION MODIFY (REGULATION_ID numeric)
/

    ALTER TABLE TR_SUPERVISOR MODIFY (SUPERVISOR_ID numeric,REGULATION_ID numeric,ENABLED numeric)
/

    ALTER TABLE TR_LE_ID_SOURCE MODIFY (SOURCE_ID numeric,OFFICIAL_SOURCE_B numeric,USED_IN_RP_DET_B numeric)
/

    ALTER TABLE TR_USI_UTI MODIFY (TRADE_ID numeric,REGULATION_ID numeric,ISSUER_SOURCE_ID numeric)
/

    ALTER TABLE TR_SUBMISSION_STATE MODIFY (TRADE_ID numeric,SUPERVISOR_ID numeric)
/

    ALTER TABLE TR_REPORT_REGIME MODIFY (TRADE_ID numeric,SUPERVISOR_ID numeric,CLEARING_MANDATORY_B numeric,COUNTERPARTY_MASKED_B numeric,PO_LOCAL_B numeric,CPTY_LOCAL_B numeric,PO_UTI_GENERATOR_B numeric)
/

    ALTER TABLE TR_BUSINESS_UNIT MODIFY (TRADE_ID numeric)
/

    ALTER TABLE TR_POSITION_UTI MODIFY (ID numeric,VERSION numeric,PRODUCT_ID numeric,ACCOUNT_ID numeric,LIQ_CONFIG_ID numeric)
/

    ALTER TABLE TR_REPORT MODIFY (TRADE_ID numeric,CLEARING_DCO_B numeric,PRICE_FORMING_B numeric,NON_STANDARD_B numeric,PO_COMMERCIAL_ACTIVITY_B numeric,CPTY_COMMERCIAL_ACTIVITY_B numeric,PORTFOLIO_COMPRESSION_B numeric,TERMINATED_BY_COMPRESSION_B numeric,COMPRESSION_FAR_B numeric,TERMINATED_BY_COMPRESSION_FAR numeric,LARGE_SIZE_TRADE_B numeric,CLEARING_HOUSE_ID numeric,PO_BENEFICIARY_ID numeric,CPTY_BENEFICIARY_ID numeric,PO_EXECUTION_AGENT_ID numeric,CPTY_EXECUTION_AGENT_ID numeric,PO_SETTLEMENT_AGENT_ID numeric,CPTY_SETTLEMENT_AGENT_ID numeric,CPTY_BROKER_ID numeric,CPTY_CLEARING_BROKER_ID numeric)
/

    ALTER TABLE TR_USI_UTI_HIST MODIFY (TRADE_ID numeric,REGULATION_ID numeric,ISSUER_SOURCE_ID numeric)
/

    ALTER TABLE TR_SUBMISSION_STATE_HIST MODIFY (TRADE_ID numeric,SUPERVISOR_ID numeric)
/

    ALTER TABLE TR_REPORT_REGIME_HIST MODIFY (TRADE_ID numeric,SUPERVISOR_ID numeric,CLEARING_MANDATORY_B numeric,COUNTERPARTY_MASKED_B numeric,PO_LOCAL_B numeric,CPTY_LOCAL_B numeric,PO_UTI_GENERATOR_B numeric)
/

    ALTER TABLE TR_BUSINESS_UNIT_HIST MODIFY (TRADE_ID numeric)
/

    ALTER TABLE TR_REPORT_HIST MODIFY (TRADE_ID numeric,CLEARING_DCO_B numeric,PRICE_FORMING_B numeric,NON_STANDARD_B numeric,PO_COMMERCIAL_ACTIVITY_B numeric,CPTY_COMMERCIAL_ACTIVITY_B numeric,PORTFOLIO_COMPRESSION_B numeric,TERMINATED_BY_COMPRESSION_B numeric,COMPRESSION_FAR_B numeric,TERMINATED_BY_COMPRESSION_FAR numeric,LARGE_SIZE_TRADE_B numeric,CLEARING_HOUSE_ID numeric,PO_BENEFICIARY_ID numeric,CPTY_BENEFICIARY_ID numeric,PO_EXECUTION_AGENT_ID numeric,CPTY_EXECUTION_AGENT_ID numeric,PO_SETTLEMENT_AGENT_ID numeric,CPTY_SETTLEMENT_AGENT_ID numeric,CPTY_BROKER_ID numeric,CPTY_CLEARING_BROKER_ID numeric)
/

    ALTER TABLE TRADE_FILTER_PO_ROLE_CRITERION MODIFY (AND_COMBINATION numeric)
/

    ALTER TABLE TRADE_FILTER_PO_ROLE_ELEMENT MODIFY (SUPERVISOR_ID numeric)
/

    ALTER TABLE TRADE_FILTER_UTI_CRITERION MODIFY (AND_COMBINATION numeric)
/

    ALTER TABLE TRADE_FILTER_UTI_ELEMENT MODIFY (REGULATION_ID numeric,UTI_TYPE_ID numeric)
/

    ALTER TABLE INCOMING_LINKED_MSG_IDENTIFIER MODIFY (CONFIG_ID numeric,VERSION_NUM numeric)
/

    ALTER TABLE VALUE_DATE_CONTROL_CONFIG MODIFY (VALUE_DATE_CONTROL_CONFIG_ID numeric,VERSION_NUM numeric,TIME numeric,DAYS numeric,BUSINESS_B numeric,UPDATE_SETTLE_DATE_B numeric)
/

    ALTER TABLE RE_QUOTE_RULE_DEFINITION MODIFY (VERSION numeric)
/
CREATE UNIQUE INDEX pk_cm_calculation_se1 ON CM_CALCULATION_SET ( id ) nologging parallel 8
/

    ALTER TABLE CM_CALCULATION_SET ADD CONSTRAINT pk_cm_calculation_se1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_calculation_se1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_rf_source1 ON CM_RF_SOURCE ( id ) nologging parallel 8
/

    ALTER TABLE CM_RF_SOURCE ADD CONSTRAINT pk_cm_rf_source1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_rf_source1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_rf_status1 ON CM_RF_STATUS ( id ) nologging parallel 8
/

    ALTER TABLE CM_RF_STATUS ADD CONSTRAINT pk_cm_rf_status1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_rf_status1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_simm_calc_requ1 ON CM_SIMM_CALC_REQUEST ( id ) nologging parallel 8
/

    ALTER TABLE CM_SIMM_CALC_REQUEST ADD CONSTRAINT pk_cm_simm_calc_requ1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_simm_calc_requ1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_simm_what_if_r1 ON CM_SIMM_WHAT_IF_REQUEST ( id ) nologging parallel 8
/

    ALTER TABLE CM_SIMM_WHAT_IF_REQUEST ADD CONSTRAINT pk_cm_simm_what_if_r1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_simm_what_if_r1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_simm_what_if_r4 ON CM_SIMM_WHAT_IF_REQ2CALC ( what_if_request_id, calc_request_id ) nologging parallel 8
/

    ALTER TABLE CM_SIMM_WHAT_IF_REQ2CALC ADD CONSTRAINT pk_cm_simm_what_if_r4 PRIMARY KEY ( what_if_request_id, calc_request_id ) USING INDEX
/

    ALTER INDEX pk_cm_simm_what_if_r4 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_rf_what_if1 ON CM_RF_WHAT_IF ( id ) nologging parallel 8
/

    ALTER TABLE CM_RF_WHAT_IF ADD CONSTRAINT pk_cm_rf_what_if1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_rf_what_if1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_rf_trade1 ON CM_RF_TRADE ( id ) nologging parallel 8
/

    ALTER TABLE CM_RF_TRADE ADD CONSTRAINT pk_cm_rf_trade1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_rf_trade1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_simm_bucket1 ON CM_SIMM_BUCKET ( id ) nologging parallel 8
/

    ALTER TABLE CM_SIMM_BUCKET ADD CONSTRAINT pk_cm_simm_bucket1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_simm_bucket1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_rf_status_hist1 ON CM_RF_STATUS_HIST ( id ) nologging parallel 8
/

    ALTER TABLE CM_RF_STATUS_HIST ADD CONSTRAINT pk_cm_rf_status_hist1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_rf_status_hist1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_rf_trade_hist1 ON CM_RF_TRADE_HIST ( id ) nologging parallel 8
/

    ALTER TABLE CM_RF_TRADE_HIST ADD CONSTRAINT pk_cm_rf_trade_hist1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_rf_trade_hist1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_simm_calc_requ3 ON CM_SIMM_CALC_REQUEST_HIST ( id ) nologging parallel 8
/

    ALTER TABLE CM_SIMM_CALC_REQUEST_HIST ADD CONSTRAINT pk_cm_simm_calc_requ3 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_simm_calc_requ3 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_simm_calc_requ5 ON CM_SIMM_CALC_REQUEST_TEMP ( id ) nologging parallel 8
/

    ALTER TABLE CM_SIMM_CALC_REQUEST_TEMP ADD CONSTRAINT pk_cm_simm_calc_requ5 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_simm_calc_requ5 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_im_monitoring_1 ON CM_IM_MONITORING_CONFIG ( id ) nologging parallel 8
/

    ALTER TABLE CM_IM_MONITORING_CONFIG ADD CONSTRAINT pk_cm_im_monitoring_1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_im_monitoring_1 noparallel logging
/
CREATE UNIQUE INDEX pk_anonymizing_audit1 ON ANONYMIZING_AUDIT ( entity_id, anonymizing_date ) nologging parallel 8
/

    ALTER TABLE ANONYMIZING_AUDIT ADD CONSTRAINT pk_anonymizing_audit1 PRIMARY KEY ( entity_id, anonymizing_date ) USING INDEX
/

    ALTER INDEX pk_anonymizing_audit1 noparallel logging
/
CREATE UNIQUE INDEX pk_curve_point_adj1 ON CURVE_POINT_ADJ ( curve_id, curve_date, curve_offset, adj_name ) nologging parallel 8
/

    ALTER TABLE CURVE_POINT_ADJ ADD CONSTRAINT pk_curve_point_adj1 PRIMARY KEY ( curve_id, curve_date, curve_offset, adj_name ) USING INDEX
/

    ALTER INDEX pk_curve_point_adj1 noparallel logging
/
CREATE UNIQUE INDEX pk_curve_quote_adj1 ON CURVE_QUOTE_ADJ ( curve_id, curve_date, quote_name, adj_name ) nologging parallel 8
/

    ALTER TABLE CURVE_QUOTE_ADJ ADD CONSTRAINT pk_curve_quote_adj1 PRIMARY KEY ( curve_id, curve_date, quote_name, adj_name ) USING INDEX
/

    ALTER INDEX pk_curve_quote_adj1 noparallel logging
/

CREATE UNIQUE INDEX pk_file_document1 ON FILE_DOCUMENT ( document_id ) nologging parallel 8
/

    ALTER TABLE FILE_DOCUMENT ADD CONSTRAINT pk_file_document1 PRIMARY KEY ( document_id ) USING INDEX
/

    ALTER INDEX pk_file_document1 noparallel logging
/
CREATE UNIQUE INDEX pk_inv_cashpos_hist1 ON inv_cashpos_hist ( internal_external, position_type, agent_id, account_id, date_type, position_date, currency_code, book_id, config_id ) nologging parallel 8
/

    ALTER TABLE inv_cashpos_hist ADD CONSTRAINT pk_inv_cashpos_hist1 PRIMARY KEY ( internal_external, position_type, agent_id, account_id, date_type, position_date, currency_code, book_id, config_id ) USING INDEX
/

    ALTER INDEX pk_inv_cashpos_hist1 noparallel logging
/
CREATE UNIQUE INDEX pk_inv_cashposition1 ON inv_cashposition ( internal_external, position_type, date_type, agent_id, account_id, currency_code, book_id, config_id, position_date ) nologging parallel 8
/

    ALTER TABLE inv_cashposition ADD CONSTRAINT pk_inv_cashposition1 PRIMARY KEY ( internal_external, position_type, date_type, agent_id, account_id, currency_code, book_id, config_id, position_date ) USING INDEX
/

    ALTER INDEX pk_inv_cashposition1 noparallel logging
/

CREATE UNIQUE INDEX pk_inv_cash_movement1 ON INV_CASH_MOVEMENT ( internal_external, position_type, date_type, agent_id, account_id, currency_code, book_id, config_id, mcc_id, position_date, sub_account_id ) nologging parallel 8
/

    ALTER TABLE INV_CASH_MOVEMENT ADD CONSTRAINT pk_inv_cash_movement1 PRIMARY KEY ( internal_external, position_type, date_type, agent_id, account_id, currency_code, book_id, config_id, mcc_id, position_date, sub_account_id ) USING INDEX
/

    ALTER INDEX pk_inv_cash_movement1 noparallel logging
/

CREATE UNIQUE INDEX pk_inv_cash_balance1 ON INV_CASH_BALANCE ( internal_external, position_type, date_type, agent_id, account_id, currency_code, book_id, config_id, mcc_id, sub_account_id ) nologging parallel 8
/

    ALTER TABLE INV_CASH_BALANCE ADD CONSTRAINT pk_inv_cash_balance1 PRIMARY KEY ( internal_external, position_type, date_type, agent_id, account_id, currency_code, book_id, config_id, mcc_id, sub_account_id ) USING INDEX
/

    ALTER INDEX pk_inv_cash_balance1 noparallel logging
/

CREATE UNIQUE INDEX pk_inv_secpos_hist1 ON inv_secpos_hist ( internal_external, position_type, date_type, agent_id, account_id, position_date, security_id, book_id, config_id ) nologging parallel 8
/

    ALTER TABLE inv_secpos_hist ADD CONSTRAINT pk_inv_secpos_hist1 PRIMARY KEY ( internal_external, position_type, date_type, agent_id, account_id, position_date, security_id, book_id, config_id ) USING INDEX
/

    ALTER INDEX pk_inv_secpos_hist1 noparallel logging
/
CREATE UNIQUE INDEX pk_inv_secposition1 ON inv_secposition ( internal_external, position_type, date_type, agent_id, account_id, security_id, book_id, config_id, position_date ) nologging parallel 8
/

    ALTER TABLE inv_secposition ADD CONSTRAINT pk_inv_secposition1 PRIMARY KEY ( internal_external, position_type, date_type, agent_id, account_id, security_id, book_id, config_id, position_date ) USING INDEX
/

    ALTER INDEX pk_inv_secposition1 noparallel logging
/

 CREATE UNIQUE INDEX pk_inv_sec_balance1 ON INV_SEC_BALANCE ( internal_external, position_type, date_type, agent_id, account_id, security_id, book_id, config_id, mcc_id, sub_account_id ) nologging parallel 8
/

    ALTER TABLE INV_SEC_BALANCE ADD CONSTRAINT pk_inv_sec_balance1 PRIMARY KEY ( internal_external, position_type, date_type, agent_id, account_id, security_id, book_id, config_id, mcc_id, sub_account_id ) USING INDEX
/

    ALTER INDEX pk_inv_sec_balance1 noparallel logging
/

CREATE UNIQUE INDEX pk_inv_sec_movement1 ON INV_SEC_MOVEMENT ( internal_external, position_type, date_type, agent_id, account_id, security_id, book_id, config_id, mcc_id, position_date, sub_account_id ) nologging parallel 8
/

    ALTER TABLE INV_SEC_MOVEMENT ADD CONSTRAINT pk_inv_sec_movement1 PRIMARY KEY ( internal_external, position_type, date_type, agent_id, account_id, security_id, book_id, config_id, mcc_id, position_date, sub_account_id ) USING INDEX
/

    ALTER INDEX pk_inv_sec_movement1 noparallel logging
/

CREATE UNIQUE INDEX pk_sdi_cash_accounts1 ON SDI_CASH_ACCOUNTS ( sdi_id, cash_currency ) nologging parallel 8
/

    ALTER TABLE SDI_CASH_ACCOUNTS ADD CONSTRAINT pk_sdi_cash_accounts1 PRIMARY KEY ( sdi_id, cash_currency ) USING INDEX
/

    ALTER INDEX pk_sdi_cash_accounts1 noparallel logging
/
CREATE UNIQUE INDEX pk_sdi_cash_accounts2 ON SDI_CASH_ACCOUNTS_HIST ( sdi_id, cash_currency ) nologging parallel 8
/

    ALTER TABLE SDI_CASH_ACCOUNTS_HIST ADD CONSTRAINT pk_sdi_cash_accounts2 PRIMARY KEY ( sdi_id, cash_currency ) USING INDEX
/

    ALTER INDEX pk_sdi_cash_accounts2 noparallel logging
/
CREATE UNIQUE INDEX pk_le_settle_deliver5 ON LE_SETTLE_DELIVERY_HIST ( sdi_id ) nologging parallel 8
/

    ALTER TABLE LE_SETTLE_DELIVERY_HIST ADD CONSTRAINT pk_le_settle_deliver5 PRIMARY KEY ( sdi_id ) USING INDEX
/

    ALTER INDEX pk_le_settle_deliver5 noparallel logging
/
CREATE UNIQUE INDEX pk_manual_party_sdi_1 ON MANUAL_PARTY_SDI_HIST ( sdi_id, seq_no ) nologging parallel 8
/

    ALTER TABLE MANUAL_PARTY_SDI_HIST ADD CONSTRAINT pk_manual_party_sdi_1 PRIMARY KEY ( sdi_id, seq_no ) USING INDEX
/

    ALTER INDEX pk_manual_party_sdi_1 noparallel logging
/
CREATE UNIQUE INDEX pk_manual_sdi_hist1 ON MANUAL_SDI_HIST ( sdi_id ) nologging parallel 8
/

    ALTER TABLE MANUAL_SDI_HIST ADD CONSTRAINT pk_manual_sdi_hist1 PRIMARY KEY ( sdi_id ) USING INDEX
/

    ALTER INDEX pk_manual_sdi_hist1 noparallel logging
/
CREATE UNIQUE INDEX pk_manual_sdi_attr_h1 ON MANUAL_SDI_ATTR_HIST ( sdi_id, attribute_name ) nologging parallel 8
/

    ALTER TABLE MANUAL_SDI_ATTR_HIST ADD CONSTRAINT pk_manual_sdi_attr_h1 PRIMARY KEY ( sdi_id, attribute_name ) USING INDEX
/

    ALTER INDEX pk_manual_sdi_attr_h1 noparallel logging
/
CREATE UNIQUE INDEX pk_prod_exch_code2 ON PROD_EXCH_CODE ( product_id, le_id, le_role, exch_code ) nologging parallel 8
/

    ALTER TABLE PROD_EXCH_CODE ADD CONSTRAINT pk_prod_exch_code2 PRIMARY KEY ( product_id, le_id, le_role, exch_code ) USING INDEX
/

    ALTER INDEX pk_prod_exch_code2 noparallel logging
/

CREATE UNIQUE INDEX pk_arch_partial_trad1 ON ARCH_PARTIAL_TRADE_IDS ( trade_id ) nologging parallel 8
/

    ALTER TABLE ARCH_PARTIAL_TRADE_IDS ADD CONSTRAINT pk_arch_partial_trad1 PRIMARY KEY ( trade_id ) USING INDEX
/

    ALTER INDEX pk_arch_partial_trad1 noparallel logging
/
CREATE UNIQUE INDEX pk_arch_trade_no_syn1 ON ARCH_TRADE_NO_SYNC ( trade_id ) nologging parallel 8
/

    ALTER TABLE ARCH_TRADE_NO_SYNC ADD CONSTRAINT pk_arch_trade_no_syn1 PRIMARY KEY ( trade_id ) USING INDEX
/

    ALTER INDEX pk_arch_trade_no_syn1 noparallel logging
/
CREATE UNIQUE INDEX pk_arch_transfer_no_1 ON ARCH_TRANSFER_NO_SYNC ( transfer_id ) nologging parallel 8
/

    ALTER TABLE ARCH_TRANSFER_NO_SYNC ADD CONSTRAINT pk_arch_transfer_no_1 PRIMARY KEY ( transfer_id ) USING INDEX
/

    ALTER INDEX pk_arch_transfer_no_1 noparallel logging
/
CREATE UNIQUE INDEX pk_arch_quantile1 ON ARCH_QUANTILE ( trade_id ) nologging parallel 8
/

    ALTER TABLE ARCH_QUANTILE ADD CONSTRAINT pk_arch_quantile1 PRIMARY KEY ( trade_id ) USING INDEX
/

    ALTER INDEX pk_arch_quantile1 noparallel logging
/
CREATE UNIQUE INDEX pk_arch_quantile_no_1 ON ARCH_QUANTILE_NO_SYNC ( trade_id ) nologging parallel 8
/

    ALTER TABLE ARCH_QUANTILE_NO_SYNC ADD CONSTRAINT pk_arch_quantile_no_1 PRIMARY KEY ( trade_id ) USING INDEX
/

    ALTER INDEX pk_arch_quantile_no_1 noparallel logging
/
CREATE UNIQUE INDEX pk_official_plmark_p1 ON OFFICIAL_PLMARK_PERM_ADJ ( permanent_adj_id ) nologging parallel 8
/

    ALTER TABLE OFFICIAL_PLMARK_PERM_ADJ ADD CONSTRAINT pk_official_plmark_p1 PRIMARY KEY ( permanent_adj_id ) USING INDEX
/

    ALTER INDEX pk_official_plmark_p1 noparallel logging
/
CREATE UNIQUE INDEX pk_official_plmark_p3 ON OFFICIAL_PLMARK_PERM_ADJ_VALUE ( permanent_adj_id, measure_name ) nologging parallel 8
/

    ALTER TABLE OFFICIAL_PLMARK_PERM_ADJ_VALUE ADD CONSTRAINT pk_official_plmark_p3 PRIMARY KEY ( permanent_adj_id, measure_name ) USING INDEX
/

    ALTER INDEX pk_official_plmark_p3 noparallel logging
/
CREATE UNIQUE INDEX pk_decsupp_order_his1 ON DECSUPP_ORDER_HIST ( order_id ) nologging parallel 8
/

    ALTER TABLE DECSUPP_ORDER_HIST ADD CONSTRAINT pk_decsupp_order_his1 PRIMARY KEY ( order_id ) USING INDEX
/

    ALTER INDEX pk_decsupp_order_his1 noparallel logging
/
CREATE UNIQUE INDEX pk_block_order_child3 ON BLOCK_ORDER_CHILD_HIST ( block_id, order_id, order_index ) nologging parallel 8
/

    ALTER TABLE BLOCK_ORDER_CHILD_HIST ADD CONSTRAINT pk_block_order_child3 PRIMARY KEY ( block_id, order_id, order_index ) USING INDEX
/

    ALTER INDEX pk_block_order_child3 noparallel logging
/
CREATE UNIQUE INDEX pk_am_order_executio6 ON AM_ORDER_EXECUTION_HIST ( id ) nologging parallel 8
/

    ALTER TABLE AM_ORDER_EXECUTION_HIST ADD CONSTRAINT pk_am_order_executio6 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_am_order_executio6 noparallel logging
/
CREATE UNIQUE INDEX pk_am_order_executio7 ON AM_ORDER_EXECUTION_ITEM_HIST ( id ) nologging parallel 8
/

    ALTER TABLE AM_ORDER_EXECUTION_ITEM_HIST ADD CONSTRAINT pk_am_order_executio7 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_am_order_executio7 noparallel logging
/
CREATE UNIQUE INDEX pk_ca_fx_mapping1 ON CA_FX_MAPPING ( id ) nologging parallel 8
/

    ALTER TABLE CA_FX_MAPPING ADD CONSTRAINT pk_ca_fx_mapping1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_ca_fx_mapping1 noparallel logging
/
CREATE UNIQUE INDEX pk_accounting_pl_con1 ON ACCOUNTING_PL_CONFIG ( id ) nologging parallel 8
/

    ALTER TABLE ACCOUNTING_PL_CONFIG ADD CONSTRAINT pk_accounting_pl_con1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_accounting_pl_con1 noparallel logging
/
CREATE UNIQUE INDEX pk_accounting_pl_ite1 ON ACCOUNTING_PL_ITEM ( id ) nologging parallel 8
/

    ALTER TABLE ACCOUNTING_PL_ITEM ADD CONSTRAINT pk_accounting_pl_ite1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_accounting_pl_ite1 noparallel logging
/
CREATE UNIQUE INDEX pk_accounting_pl_ite3 ON ACCOUNTING_PL_ITEM_ATTR ( entity_id, entity_type, attr_name ) nologging parallel 8
/

    ALTER TABLE ACCOUNTING_PL_ITEM_ATTR ADD CONSTRAINT pk_accounting_pl_ite3 PRIMARY KEY ( entity_id, entity_type, attr_name ) USING INDEX
/

    ALTER INDEX pk_accounting_pl_ite3 noparallel logging
/
CREATE UNIQUE INDEX pk_activemq_acks1 ON ACTIVEMQ_ACKS ( container, client_id, sub_name, priority ) nologging parallel 8
/

    ALTER TABLE ACTIVEMQ_ACKS ADD CONSTRAINT pk_activemq_acks1 PRIMARY KEY ( container, client_id, sub_name, priority ) USING INDEX
/

    ALTER INDEX pk_activemq_acks1 noparallel logging
/
CREATE UNIQUE INDEX pk_activemq_lock1 ON ACTIVEMQ_LOCK ( id ) nologging parallel 8
/

    ALTER TABLE ACTIVEMQ_LOCK ADD CONSTRAINT pk_activemq_lock1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_activemq_lock1 noparallel logging
/
CREATE UNIQUE INDEX pk_activemq_msgs1 ON ACTIVEMQ_MSGS ( id ) nologging parallel 8
/

    ALTER TABLE ACTIVEMQ_MSGS ADD CONSTRAINT pk_activemq_msgs1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_activemq_msgs1 noparallel logging
/
CREATE UNIQUE INDEX pk_multi_quote_mappi1 ON MULTI_QUOTE_MAPPING ( product_id, source, currency, settle_days ) nologging parallel 8
/

    ALTER TABLE MULTI_QUOTE_MAPPING ADD CONSTRAINT pk_multi_quote_mappi1 PRIMARY KEY ( product_id, source, currency, settle_days ) USING INDEX
/

    ALTER INDEX pk_multi_quote_mappi1 noparallel logging
/
CREATE UNIQUE INDEX pk_multi_quote_mappi2 ON MULTI_QUOTE_MAPPING_EQUITY ( product_id, source, currency, settle_days ) nologging parallel 8
/

    ALTER TABLE MULTI_QUOTE_MAPPING_EQUITY ADD CONSTRAINT pk_multi_quote_mappi2 PRIMARY KEY ( product_id, source, currency, settle_days ) USING INDEX
/

    ALTER INDEX pk_multi_quote_mappi2 noparallel logging
/
CREATE UNIQUE INDEX pk_platform_core_ten1 ON PLATFORM_CORE_TENANT_INIT ( id ) nologging parallel 8
/

    ALTER TABLE PLATFORM_CORE_TENANT_INIT ADD CONSTRAINT pk_platform_core_ten1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_platform_core_ten1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_server_configu1 ON AM_SERVER_CONFIGURATION ( server_id ) nologging parallel 8
/

    ALTER TABLE AM_SERVER_CONFIGURATION ADD CONSTRAINT pk_am_server_configu1 PRIMARY KEY ( server_id ) USING INDEX
/

    ALTER INDEX pk_am_server_configu1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_column_configu1 ON AM_COLUMN_CONFIGURATION ( column_id ) nologging parallel 8
/

    ALTER TABLE AM_COLUMN_CONFIGURATION ADD CONSTRAINT pk_am_column_configu1 PRIMARY KEY ( column_id ) USING INDEX
/

    ALTER INDEX pk_am_column_configu1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_column_profile1 ON AM_COLUMN_PROFILES ( profile_id ) nologging parallel 8
/

    ALTER TABLE AM_COLUMN_PROFILES ADD CONSTRAINT pk_am_column_profile1 PRIMARY KEY ( profile_id ) USING INDEX
/

    ALTER INDEX pk_am_column_profile1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_formula_config1 ON AM_FORMULA_CONFIGURATION ( formula_id ) nologging parallel 8
/

    ALTER TABLE AM_FORMULA_CONFIGURATION ADD CONSTRAINT pk_am_formula_config1 PRIMARY KEY ( formula_id ) USING INDEX
/

    ALTER INDEX pk_am_formula_config1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_formula_profil1 ON AM_FORMULA_PROFILES ( formula_id, group_name ) nologging parallel 8
/

    ALTER TABLE AM_FORMULA_PROFILES ADD CONSTRAINT pk_am_formula_profil1 PRIMARY KEY ( formula_id, group_name ) USING INDEX
/

    ALTER INDEX pk_am_formula_profil1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_formula_column1 ON AM_FORMULA_COLUMNS ( formula_id, column_name ) nologging parallel 8
/

    ALTER TABLE AM_FORMULA_COLUMNS ADD CONSTRAINT pk_am_formula_column1 PRIMARY KEY ( formula_id, column_name ) USING INDEX
/

    ALTER INDEX pk_am_formula_column1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_columnset_conf1 ON AM_COLUMNSET_CONFIGURATION ( columnset_id ) nologging parallel 8
/

    ALTER TABLE AM_COLUMNSET_CONFIGURATION ADD CONSTRAINT pk_am_columnset_conf1 PRIMARY KEY ( columnset_id ) USING INDEX
/

    ALTER INDEX pk_am_columnset_conf1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_columnset_prof1 ON AM_COLUMNSET_PROFILES ( columnset_id, group_name ) nologging parallel 8
/

    ALTER TABLE AM_COLUMNSET_PROFILES ADD CONSTRAINT pk_am_columnset_prof1 PRIMARY KEY ( columnset_id, group_name ) USING INDEX
/

    ALTER INDEX pk_am_columnset_prof1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_columnset_widg1 ON AM_COLUMNSET_WIDGETS ( columnset_id, widget_id ) nologging parallel 8
/

    ALTER TABLE AM_COLUMNSET_WIDGETS ADD CONSTRAINT pk_am_columnset_widg1 PRIMARY KEY ( columnset_id, widget_id ) USING INDEX
/

    ALTER INDEX pk_am_columnset_widg1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_columnset_acti1 ON AM_COLUMNSET_ACTIONS ( columnset_id, action_id ) nologging parallel 8
/

    ALTER TABLE AM_COLUMNSET_ACTIONS ADD CONSTRAINT pk_am_columnset_acti1 PRIMARY KEY ( columnset_id, action_id ) USING INDEX
/

    ALTER INDEX pk_am_columnset_acti1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_unit_configura1 ON AM_UNIT_CONFIGURATION ( unit_id ) nologging parallel 8
/

    ALTER TABLE AM_UNIT_CONFIGURATION ADD CONSTRAINT pk_am_unit_configura1 PRIMARY KEY ( unit_id ) USING INDEX
/

    ALTER INDEX pk_am_unit_configura1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_unit_profiles1 ON AM_UNIT_PROFILES ( unit_id, group_name ) nologging parallel 8
/

    ALTER TABLE AM_UNIT_PROFILES ADD CONSTRAINT pk_am_unit_profiles1 PRIMARY KEY ( unit_id, group_name ) USING INDEX
/

    ALTER INDEX pk_am_unit_profiles1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_grouping_confi1 ON AM_GROUPING_CONFIGURATION ( grouping_id ) nologging parallel 8
/

    ALTER TABLE AM_GROUPING_CONFIGURATION ADD CONSTRAINT pk_am_grouping_confi1 PRIMARY KEY ( grouping_id ) USING INDEX
/

    ALTER INDEX pk_am_grouping_confi1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_grouping_profi1 ON AM_GROUPING_PROFILES ( grouping_id, group_name ) nologging parallel 8
/

    ALTER TABLE AM_GROUPING_PROFILES ADD CONSTRAINT pk_am_grouping_profi1 PRIMARY KEY ( grouping_id, group_name ) USING INDEX
/

    ALTER INDEX pk_am_grouping_profi1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_widget_configu1 ON AM_WIDGET_CONFIGURATION ( widget_id ) nologging parallel 8
/

    ALTER TABLE AM_WIDGET_CONFIGURATION ADD CONSTRAINT pk_am_widget_configu1 PRIMARY KEY ( widget_id ) USING INDEX
/

    ALTER INDEX pk_am_widget_configu1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_widget_profile1 ON AM_WIDGET_PROFILES ( widget_id, group_name ) nologging parallel 8
/

    ALTER TABLE AM_WIDGET_PROFILES ADD CONSTRAINT pk_am_widget_profile1 PRIMARY KEY ( widget_id, group_name ) USING INDEX
/

    ALTER INDEX pk_am_widget_profile1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_widget_columns1 ON AM_WIDGET_COLUMNS ( widget_id, column_name ) nologging parallel 8
/

    ALTER TABLE AM_WIDGET_COLUMNS ADD CONSTRAINT pk_am_widget_columns1 PRIMARY KEY ( widget_id, column_name ) USING INDEX
/

    ALTER INDEX pk_am_widget_columns1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_chart_widget_c1 ON AM_CHART_WIDGET_CONFIGURATION ( chart_widget_id ) nologging parallel 8
/

    ALTER TABLE AM_CHART_WIDGET_CONFIGURATION ADD CONSTRAINT pk_am_chart_widget_c1 PRIMARY KEY ( chart_widget_id ) USING INDEX
/

    ALTER INDEX pk_am_chart_widget_c1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_order_widget_c1 ON AM_ORDER_WIDGET_CONFIGURATION ( order_widget_id ) nologging parallel 8
/

    ALTER TABLE AM_ORDER_WIDGET_CONFIGURATION ADD CONSTRAINT pk_am_order_widget_c1 PRIMARY KEY ( order_widget_id ) USING INDEX
/

    ALTER INDEX pk_am_order_widget_c1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_layout_configu1 ON AM_LAYOUT_CONFIGURATION ( layout_id ) nologging parallel 8
/

    ALTER TABLE AM_LAYOUT_CONFIGURATION ADD CONSTRAINT pk_am_layout_configu1 PRIMARY KEY ( layout_id ) USING INDEX
/

    ALTER INDEX pk_am_layout_configu1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_layout_profile1 ON AM_LAYOUT_PROFILES ( layout_id, group_name ) nologging parallel 8
/

    ALTER TABLE AM_LAYOUT_PROFILES ADD CONSTRAINT pk_am_layout_profile1 PRIMARY KEY ( layout_id, group_name ) USING INDEX
/

    ALTER INDEX pk_am_layout_profile1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_layout_columns1 ON AM_LAYOUT_COLUMNSET ( layout_id, columnset_id ) nologging parallel 8
/

    ALTER TABLE AM_LAYOUT_COLUMNSET ADD CONSTRAINT pk_am_layout_columns1 PRIMARY KEY ( layout_id, columnset_id ) USING INDEX
/

    ALTER INDEX pk_am_layout_columns1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_layout_fav_col1 ON AM_LAYOUT_FAV_COLUMNSET ( layout_id, columnset_id ) nologging parallel 8
/

    ALTER TABLE AM_LAYOUT_FAV_COLUMNSET ADD CONSTRAINT pk_am_layout_fav_col1 PRIMARY KEY ( layout_id, columnset_id ) USING INDEX
/

    ALTER INDEX pk_am_layout_fav_col1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_layout_groupin1 ON AM_LAYOUT_GROUPING ( layout_id, grouping_id ) nologging parallel 8
/

    ALTER TABLE AM_LAYOUT_GROUPING ADD CONSTRAINT pk_am_layout_groupin1 PRIMARY KEY ( layout_id, grouping_id ) USING INDEX
/

    ALTER INDEX pk_am_layout_groupin1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_layout_fav_gro1 ON AM_LAYOUT_FAV_GROUPING ( layout_id, grouping_id ) nologging parallel 8
/

    ALTER TABLE AM_LAYOUT_FAV_GROUPING ADD CONSTRAINT pk_am_layout_fav_gro1 PRIMARY KEY ( layout_id, grouping_id ) USING INDEX
/

    ALTER INDEX pk_am_layout_fav_gro1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_layout_filteri1 ON AM_LAYOUT_FILTERING ( layout_id, filtering_id ) nologging parallel 8
/

    ALTER TABLE AM_LAYOUT_FILTERING ADD CONSTRAINT pk_am_layout_filteri1 PRIMARY KEY ( layout_id, filtering_id ) USING INDEX
/

    ALTER INDEX pk_am_layout_filteri1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_layout_fav_fil1 ON AM_LAYOUT_FAV_FILTERING ( layout_id, filtering_id ) nologging parallel 8
/

    ALTER TABLE AM_LAYOUT_FAV_FILTERING ADD CONSTRAINT pk_am_layout_fav_fil1 PRIMARY KEY ( layout_id, filtering_id ) USING INDEX
/

    ALTER INDEX pk_am_layout_fav_fil1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_layout_widget1 ON AM_LAYOUT_WIDGET ( layout_id, widget_id ) nologging parallel 8
/

    ALTER TABLE AM_LAYOUT_WIDGET ADD CONSTRAINT pk_am_layout_widget1 PRIMARY KEY ( layout_id, widget_id ) USING INDEX
/

    ALTER INDEX pk_am_layout_widget1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_layout_fav_wid1 ON AM_LAYOUT_FAV_WIDGET ( layout_id, widget_id ) nologging parallel 8
/

    ALTER TABLE AM_LAYOUT_FAV_WIDGET ADD CONSTRAINT pk_am_layout_fav_wid1 PRIMARY KEY ( layout_id, widget_id ) USING INDEX
/

    ALTER INDEX pk_am_layout_fav_wid1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_layout_colorin1 ON AM_LAYOUT_COLORING ( layout_id, coloring_id ) nologging parallel 8
/

    ALTER TABLE AM_LAYOUT_COLORING ADD CONSTRAINT pk_am_layout_colorin1 PRIMARY KEY ( layout_id, coloring_id ) USING INDEX
/

    ALTER INDEX pk_am_layout_colorin1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_layout_fav_col2 ON AM_LAYOUT_FAV_COLORING ( layout_id, coloring_id ) nologging parallel 8
/

    ALTER TABLE AM_LAYOUT_FAV_COLORING ADD CONSTRAINT pk_am_layout_fav_col2 PRIMARY KEY ( layout_id, coloring_id ) USING INDEX
/

    ALTER INDEX pk_am_layout_fav_col2 noparallel logging
/
CREATE UNIQUE INDEX pk_am_layout_positio1 ON AM_LAYOUT_POSITION ( layout_id ) nologging parallel 8
/

    ALTER TABLE AM_LAYOUT_POSITION ADD CONSTRAINT pk_am_layout_positio1 PRIMARY KEY ( layout_id ) USING INDEX
/

    ALTER INDEX pk_am_layout_positio1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_layout_display1 ON AM_LAYOUT_DISPLAY ( layout_id ) nologging parallel 8
/

    ALTER TABLE AM_LAYOUT_DISPLAY ADD CONSTRAINT pk_am_layout_display1 PRIMARY KEY ( layout_id ) USING INDEX
/

    ALTER INDEX pk_am_layout_display1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_filtering_conf1 ON AM_FILTERING_CONFIGURATION ( filtering_id ) nologging parallel 8
/

    ALTER TABLE AM_FILTERING_CONFIGURATION ADD CONSTRAINT pk_am_filtering_conf1 PRIMARY KEY ( filtering_id ) USING INDEX
/

    ALTER INDEX pk_am_filtering_conf1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_filtering_prof1 ON AM_FILTERING_PROFILES ( filtering_id, group_name ) nologging parallel 8
/

    ALTER TABLE AM_FILTERING_PROFILES ADD CONSTRAINT pk_am_filtering_prof1 PRIMARY KEY ( filtering_id, group_name ) USING INDEX
/

    ALTER INDEX pk_am_filtering_prof1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_coloring_confi1 ON AM_COLORING_CONFIGURATION ( coloring_id ) nologging parallel 8
/

    ALTER TABLE AM_COLORING_CONFIGURATION ADD CONSTRAINT pk_am_coloring_confi1 PRIMARY KEY ( coloring_id ) USING INDEX
/

    ALTER INDEX pk_am_coloring_confi1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_coloring_profi1 ON AM_COLORING_PROFILES ( coloring_id, group_name ) nologging parallel 8
/

    ALTER TABLE AM_COLORING_PROFILES ADD CONSTRAINT pk_am_coloring_profi1 PRIMARY KEY ( coloring_id, group_name ) USING INDEX
/

    ALTER INDEX pk_am_coloring_profi1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_coloring_rule_1 ON AM_COLORING_RULE_CONFIGURATION ( coloring_rule_id ) nologging parallel 8
/

    ALTER TABLE AM_COLORING_RULE_CONFIGURATION ADD CONSTRAINT pk_am_coloring_rule_1 PRIMARY KEY ( coloring_rule_id ) USING INDEX
/

    ALTER INDEX pk_am_coloring_rule_1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_coloring_color1 ON AM_COLORING_COLORED_COLUMNS ( coloring_rule_id, column_id ) nologging parallel 8
/

    ALTER TABLE AM_COLORING_COLORED_COLUMNS ADD CONSTRAINT pk_am_coloring_color1 PRIMARY KEY ( coloring_rule_id, column_id ) USING INDEX
/

    ALTER INDEX pk_am_coloring_color1 noparallel logging
/
CREATE UNIQUE INDEX pk_product_triparty_1 ON PRODUCT_TRIPARTY_EXPOSURE ( product_id ) nologging parallel 8
/

    ALTER TABLE PRODUCT_TRIPARTY_EXPOSURE ADD CONSTRAINT pk_product_triparty_1 PRIMARY KEY ( product_id ) USING INDEX
/

    ALTER INDEX pk_product_triparty_1 noparallel logging
/
CREATE UNIQUE INDEX pk_userprefs_prefere1 ON USERPREFS_PREFERENCES ( id ) nologging parallel 8
/

    ALTER TABLE USERPREFS_PREFERENCES ADD CONSTRAINT pk_userprefs_prefere1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_userprefs_prefere1 noparallel logging
/
CREATE UNIQUE INDEX pk_dashboard_config_1 ON DASHBOARD_CONFIG_LAYOUT ( id ) nologging parallel 8
/

    ALTER TABLE DASHBOARD_CONFIG_LAYOUT ADD CONSTRAINT pk_dashboard_config_1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_dashboard_config_1 noparallel logging
/
CREATE UNIQUE INDEX pk_dashboard_config_2 ON DASHBOARD_CONFIG_DASHBOARD ( id ) nologging parallel 8
/

    ALTER TABLE DASHBOARD_CONFIG_DASHBOARD ADD CONSTRAINT pk_dashboard_config_2 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_dashboard_config_2 noparallel logging
/
CREATE UNIQUE INDEX pk_dashboard_config_3 ON DASHBOARD_CONFIG_WIDGET ( id ) nologging parallel 8
/

    ALTER TABLE DASHBOARD_CONFIG_WIDGET ADD CONSTRAINT pk_dashboard_config_3 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_dashboard_config_3 noparallel logging
/
CREATE UNIQUE INDEX pk_dashboard_config_4 ON DASHBOARD_CONFIG_WIDGET_ATTR ( id ) nologging parallel 8
/

    ALTER TABLE DASHBOARD_CONFIG_WIDGET_ATTR ADD CONSTRAINT pk_dashboard_config_4 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_dashboard_config_4 noparallel logging
/
CREATE UNIQUE INDEX pk_userprefs_templat1 ON USERPREFS_TEMPLATE ( id ) nologging parallel 8
/

    ALTER TABLE USERPREFS_TEMPLATE ADD CONSTRAINT pk_userprefs_templat1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_userprefs_templat1 noparallel logging
/
CREATE UNIQUE INDEX pk_userprefs_templat3 ON USERPREFS_TEMPLATE_CRIT ( id ) nologging parallel 8
/

    ALTER TABLE USERPREFS_TEMPLATE_CRIT ADD CONSTRAINT pk_userprefs_templat3 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_userprefs_templat3 noparallel logging
/
CREATE UNIQUE INDEX pk_re_quote_list1 ON RE_QUOTE_LIST ( config_name, quote_name ) nologging parallel 8
/

    ALTER TABLE RE_QUOTE_LIST ADD CONSTRAINT pk_re_quote_list1 PRIMARY KEY ( config_name, quote_name ) USING INDEX
/

    ALTER INDEX pk_re_quote_list1 noparallel logging
/
CREATE UNIQUE INDEX pk_re_quote_rule_con1 ON RE_QUOTE_RULE_CONFIG ( config_name ) nologging parallel 8
/

    ALTER TABLE RE_QUOTE_RULE_CONFIG ADD CONSTRAINT pk_re_quote_rule_con1 PRIMARY KEY ( config_name ) USING INDEX
/

    ALTER INDEX pk_re_quote_rule_con1 noparallel logging
/
CREATE UNIQUE INDEX pk_re_quote_rules1 ON RE_QUOTE_RULES ( config_name, rule_name, filter_value, market_source ) nologging parallel 8
/

    ALTER TABLE RE_QUOTE_RULES ADD CONSTRAINT pk_re_quote_rules1 PRIMARY KEY ( config_name, rule_name, filter_value, market_source ) USING INDEX
/

    ALTER INDEX pk_re_quote_rules1 noparallel logging
/
CREATE UNIQUE INDEX pk_re_quote_rules_pa1 ON RE_QUOTE_RULES_PARAMS ( rule_id, param_name ) nologging parallel 8
/

    ALTER TABLE RE_QUOTE_RULES_PARAMS ADD CONSTRAINT pk_re_quote_rules_pa1 PRIMARY KEY ( rule_id, param_name ) USING INDEX
/

    ALTER INDEX pk_re_quote_rules_pa1 noparallel logging
/
CREATE UNIQUE INDEX pk_re_quote_manual_p1 ON RE_QUOTE_MANUAL_PUBLISH ( config_name, quote_name ) nologging parallel 8
/

    ALTER TABLE RE_QUOTE_MANUAL_PUBLISH ADD CONSTRAINT pk_re_quote_manual_p1 PRIMARY KEY ( config_name, quote_name ) USING INDEX
/

    ALTER INDEX pk_re_quote_manual_p1 noparallel logging
/
CREATE UNIQUE INDEX pk_re_quote_manual_p2 ON RE_QUOTE_MANUAL_PUBLISH_AUDIT ( config_name, quote_name, version ) nologging parallel 8
/

    ALTER TABLE RE_QUOTE_MANUAL_PUBLISH_AUDIT ADD CONSTRAINT pk_re_quote_manual_p2 PRIMARY KEY ( config_name, quote_name, version ) USING INDEX
/

    ALTER INDEX pk_re_quote_manual_p2 noparallel logging
/
CREATE UNIQUE INDEX pk_bloom_sec_entitle1 ON BLOOM_SEC_ENTITLEMENT ( feed_name, feed_address ) nologging parallel 8
/

    ALTER TABLE BLOOM_SEC_ENTITLEMENT ADD CONSTRAINT pk_bloom_sec_entitle1 PRIMARY KEY ( feed_name, feed_address ) USING INDEX
/

    ALTER INDEX pk_bloom_sec_entitle1 noparallel logging
/
CREATE UNIQUE INDEX pk_product_ftp1 ON PRODUCT_FTP ( product_id ) nologging parallel 8
/

    ALTER TABLE PRODUCT_FTP ADD CONSTRAINT pk_product_ftp1 PRIMARY KEY ( product_id ) USING INDEX
/

    ALTER INDEX pk_product_ftp1 noparallel logging
/
CREATE UNIQUE INDEX pk_product_ftp_leg1 ON PRODUCT_FTP_LEG ( product_id, effective_date, end_date ) nologging parallel 8
/

    ALTER TABLE PRODUCT_FTP_LEG ADD CONSTRAINT pk_product_ftp_leg1 PRIMARY KEY ( product_id, effective_date, end_date ) USING INDEX
/

    ALTER INDEX pk_product_ftp_leg1 noparallel logging
/
CREATE UNIQUE INDEX pk_objstore_files1 ON OBJSTORE_FILES ( id ) nologging parallel 8
/

    ALTER TABLE OBJSTORE_FILES ADD CONSTRAINT pk_objstore_files1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_objstore_files1 noparallel logging
/
CREATE UNIQUE INDEX pk_objstore_files_co1 ON OBJSTORE_FILES_CONTENT ( id ) nologging parallel 8
/

    ALTER TABLE OBJSTORE_FILES_CONTENT ADD CONSTRAINT pk_objstore_files_co1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_objstore_files_co1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_account_attr1 ON CORE_ACCOUNT_ATTRIBUTE ( id ) nologging parallel 8
/

    ALTER TABLE CORE_ACCOUNT_ATTRIBUTE ADD CONSTRAINT pk_core_account_attr1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_account_attr1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_account_inte1 ON CORE_ACCOUNT_INTEREST_CONFIG ( id ) nologging parallel 8
/

    ALTER TABLE CORE_ACCOUNT_INTEREST_CONFIG ADD CONSTRAINT pk_core_account_inte1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_account_inte1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_bond1 ON CORE_BOND ( id ) nologging parallel 8
/

    ALTER TABLE CORE_BOND ADD CONSTRAINT pk_core_bond1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_bond1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_country1 ON CORE_COUNTRY ( id ) nologging parallel 8
/

    ALTER TABLE CORE_COUNTRY ADD CONSTRAINT pk_core_country1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_country1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_currency1 ON CORE_CURRENCY ( id ) nologging parallel 8
/

    ALTER TABLE CORE_CURRENCY ADD CONSTRAINT pk_core_currency1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_currency1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_currencypair1 ON CORE_CURRENCYPAIR ( id ) nologging parallel 8
/

    ALTER TABLE CORE_CURRENCYPAIR ADD CONSTRAINT pk_core_currencypair1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_currencypair1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_data_policy1 ON CORE_DATA_POLICY ( id ) nologging parallel 8
/

    ALTER TABLE CORE_DATA_POLICY ADD CONSTRAINT pk_core_data_policy1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_data_policy1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_equity1 ON CORE_EQUITY ( id ) nologging parallel 8
/

    ALTER TABLE CORE_EQUITY ADD CONSTRAINT pk_core_equity1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_equity1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_holiday1 ON CORE_HOLIDAY ( id ) nologging parallel 8
/

    ALTER TABLE CORE_HOLIDAY ADD CONSTRAINT pk_core_holiday1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_holiday1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_holiday_even1 ON CORE_HOLIDAY_EVENT ( id ) nologging parallel 8
/

    ALTER TABLE CORE_HOLIDAY_EVENT ADD CONSTRAINT pk_core_holiday_even1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_holiday_even1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_index1 ON CORE_INDEX ( id ) nologging parallel 8
/

    ALTER TABLE CORE_INDEX ADD CONSTRAINT pk_core_index1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_index1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_inflation_in1 ON CORE_INFLATION_INDEX ( id ) nologging parallel 8
/

    ALTER TABLE CORE_INFLATION_INDEX ADD CONSTRAINT pk_core_inflation_in1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_inflation_in1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_interest_con1 ON CORE_INTEREST_CONFIG ( id ) nologging parallel 8
/

    ALTER TABLE CORE_INTEREST_CONFIG ADD CONSTRAINT pk_core_interest_con1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_interest_con1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_le_address1 ON CORE_LE_ADDRESS ( id ) nologging parallel 8
/

    ALTER TABLE CORE_LE_ADDRESS ADD CONSTRAINT pk_core_le_address1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_le_address1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_le_contact1 ON CORE_LE_CONTACT ( id ) nologging parallel 8
/

    ALTER TABLE CORE_LE_CONTACT ADD CONSTRAINT pk_core_le_contact1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_le_contact1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_legal_entity1 ON CORE_LEGAL_ENTITY ( id ) nologging parallel 8
/

    ALTER TABLE CORE_LEGAL_ENTITY ADD CONSTRAINT pk_core_legal_entity1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_legal_entity1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_pf_from_to1 ON CORE_PF_FROM_TO ( id ) nologging parallel 8
/

    ALTER TABLE CORE_PF_FROM_TO ADD CONSTRAINT pk_core_pf_from_to1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_pf_from_to1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_pf_multi_val1 ON CORE_PF_MULTI_VALUE ( pf_multiple_values_id, multiple_values_order ) nologging parallel 8
/

    ALTER TABLE CORE_PF_MULTI_VALUE ADD CONSTRAINT pk_core_pf_multi_val1 PRIMARY KEY ( pf_multiple_values_id, multiple_values_order ) USING INDEX
/

    ALTER INDEX pk_core_pf_multi_val1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_pf_multi_val2 ON CORE_PF_MULTI_VALUES ( id ) nologging parallel 8
/

    ALTER TABLE CORE_PF_MULTI_VALUES ADD CONSTRAINT pk_core_pf_multi_val2 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_pf_multi_val2 noparallel logging
/
CREATE UNIQUE INDEX pk_core_product1 ON CORE_PRODUCT ( id ) nologging parallel 8
/

    ALTER TABLE CORE_PRODUCT ADD CONSTRAINT pk_core_product1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_product1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_product_filt1 ON CORE_PRODUCT_FILTER ( id ) nologging parallel 8
/

    ALTER TABLE CORE_PRODUCT_FILTER ADD CONSTRAINT pk_core_product_filt1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_product_filt1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_put_call_dat1 ON CORE_PUT_CALL_DATE ( id ) nologging parallel 8
/

    ALTER TABLE CORE_PUT_CALL_DATE ADD CONSTRAINT pk_core_put_call_dat1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_put_call_dat1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_quote_defini1 ON CORE_QUOTE_DEFINITION ( id ) nologging parallel 8
/

    ALTER TABLE CORE_QUOTE_DEFINITION ADD CONSTRAINT pk_core_quote_defini1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_quote_defini1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_quote_set1 ON CORE_QUOTE_SET ( id ) nologging parallel 8
/

    ALTER TABLE CORE_QUOTE_SET ADD CONSTRAINT pk_core_quote_set1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_quote_set1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_rate_index1 ON CORE_RATE_INDEX ( id ) nologging parallel 8
/

    ALTER TABLE CORE_RATE_INDEX ADD CONSTRAINT pk_core_rate_index1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_rate_index1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_rating1 ON CORE_RATING ( rating_agn_id, available_ratings_order ) nologging parallel 8
/

    ALTER TABLE CORE_RATING ADD CONSTRAINT pk_core_rating1 PRIMARY KEY ( rating_agn_id, available_ratings_order ) USING INDEX
/

    ALTER INDEX pk_core_rating1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_rating_agenc1 ON CORE_RATING_AGENCY ( id ) nologging parallel 8
/

    ALTER TABLE CORE_RATING_AGENCY ADD CONSTRAINT pk_core_rating_agenc1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_rating_agenc1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_rating_le1 ON CORE_RATING_LE ( id ) nologging parallel 8
/

    ALTER TABLE CORE_RATING_LE ADD CONSTRAINT pk_core_rating_le1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_rating_le1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_security_att1 ON CORE_SECURITY_ATTRIBUTE ( id ) nologging parallel 8
/

    ALTER TABLE CORE_SECURITY_ATTRIBUTE ADD CONSTRAINT pk_core_security_att1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_security_att1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_security_ide1 ON CORE_SECURITY_IDENTIFIER ( id ) nologging parallel 8
/

    ALTER TABLE CORE_SECURITY_IDENTIFIER ADD CONSTRAINT pk_core_security_ide1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_security_ide1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_settlement_a1 ON CORE_SETTLEMENT_ACCOUNT ( id ) nologging parallel 8
/

    ALTER TABLE CORE_SETTLEMENT_ACCOUNT ADD CONSTRAINT pk_core_settlement_a1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_settlement_a1 noparallel logging
/
CREATE UNIQUE INDEX pk_core_split_curren1 ON CORE_SPLIT_CURRENCY ( id ) nologging parallel 8
/

    ALTER TABLE CORE_SPLIT_CURRENCY ADD CONSTRAINT pk_core_split_curren1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_core_split_curren1 noparallel logging
/
CREATE UNIQUE INDEX pk_cls_schedule1 ON CLS_SCHEDULE ( schedule_id ) nologging parallel 8
/

    ALTER TABLE CLS_SCHEDULE ADD CONSTRAINT pk_cls_schedule1 PRIMARY KEY ( schedule_id ) USING INDEX
/

    ALTER INDEX pk_cls_schedule1 noparallel logging
/
CREATE UNIQUE INDEX pk_cls_message1 ON CLS_MESSAGE ( id ) nologging parallel 8
/

    ALTER TABLE CLS_MESSAGE ADD CONSTRAINT pk_cls_message1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cls_message1 noparallel logging
/
CREATE UNIQUE INDEX pk_cls_reco1 ON CLS_RECO ( schedule_id, currency ) nologging parallel 8
/

    ALTER TABLE CLS_RECO ADD CONSTRAINT pk_cls_reco1 PRIMARY KEY ( schedule_id, currency ) USING INDEX
/

    ALTER INDEX pk_cls_reco1 noparallel logging
/
CREATE UNIQUE INDEX pk_cls_trade_info1 ON CLS_TRADE_INFO ( id ) nologging parallel 8
/

    ALTER TABLE CLS_TRADE_INFO ADD CONSTRAINT pk_cls_trade_info1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cls_trade_info1 noparallel logging
/
CREATE UNIQUE INDEX pk_cls_non_repudiati1 ON CLS_NON_REPUDIATION ( snf_ref, snf_session, snf_outout_seq, snf_delivery_time ) nologging parallel 8
/

    ALTER TABLE CLS_NON_REPUDIATION ADD CONSTRAINT pk_cls_non_repudiati1 PRIMARY KEY ( snf_ref, snf_session, snf_outout_seq, snf_delivery_time ) USING INDEX
/

    ALTER INDEX pk_cls_non_repudiati1 noparallel logging
/
CREATE UNIQUE INDEX pk_cls_account_notif1 ON CLS_ACCOUNT_NOTIFICATION ( id ) nologging parallel 8
/

    ALTER TABLE CLS_ACCOUNT_NOTIFICATION ADD CONSTRAINT pk_cls_account_notif1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cls_account_notif1 noparallel logging
/
CREATE UNIQUE INDEX pk_cdsabs_markit_flo3 ON CDSABS_MARKIT_FLOWS_VERSION ( product_id ) nologging parallel 8
/

    ALTER TABLE CDSABS_MARKIT_FLOWS_VERSION ADD CONSTRAINT pk_cdsabs_markit_flo3 PRIMARY KEY ( product_id ) USING INDEX
/

    ALTER INDEX pk_cdsabs_markit_flo3 noparallel logging
/
CREATE UNIQUE INDEX pk_margin_run_info1 ON MARGIN_RUN_INFO ( margin_hierarchy, calculation_set, eod, margin_data_type ) nologging parallel 8
/

    ALTER TABLE MARGIN_RUN_INFO ADD CONSTRAINT pk_margin_run_info1 PRIMARY KEY ( margin_hierarchy, calculation_set, eod, margin_data_type ) USING INDEX
/

    ALTER INDEX pk_margin_run_info1 noparallel logging
/
CREATE UNIQUE INDEX pk_margin_mfm_multip1 ON MARGIN_MFM_MULTIPLIER ( aggregation_key, etl_lower_bound, etl_upper_bound ) nologging parallel 8
/

    ALTER TABLE MARGIN_MFM_MULTIPLIER ADD CONSTRAINT pk_margin_mfm_multip1 PRIMARY KEY ( aggregation_key, etl_lower_bound, etl_upper_bound ) USING INDEX
/

    ALTER INDEX pk_margin_mfm_multip1 noparallel logging
/
CREATE UNIQUE INDEX pk_margin_result2 ON MARGIN_RESULT ( valuation_date, direction, account_id, eod, calculation_set ) nologging parallel 8
/

    ALTER TABLE MARGIN_RESULT ADD CONSTRAINT pk_margin_result2 PRIMARY KEY ( valuation_date, direction, account_id, eod, calculation_set ) USING INDEX
/

    ALTER INDEX pk_margin_result2 noparallel logging
/
CREATE UNIQUE INDEX pk_margin_result_his2 ON MARGIN_RESULT_HIST ( valuation_date, direction, account_id, eod, calculation_set ) nologging parallel 8
/

    ALTER TABLE MARGIN_RESULT_HIST ADD CONSTRAINT pk_margin_result_his2 PRIMARY KEY ( valuation_date, direction, account_id, eod, calculation_set ) USING INDEX
/

    ALTER INDEX pk_margin_result_his2 noparallel logging
/
CREATE UNIQUE INDEX pk_audit_record1 ON AUDIT_RECORD ( id ) nologging parallel 8
/

    ALTER TABLE AUDIT_RECORD ADD CONSTRAINT pk_audit_record1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_audit_record1 noparallel logging
/

CREATE UNIQUE INDEX pk_cm_result1 ON CM_RESULT ( id ) nologging parallel 8
/

    ALTER TABLE CM_RESULT ADD CONSTRAINT pk_cm_result1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_result1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_calculation_su1 ON CM_CALCULATION_SUMMARY ( id ) nologging parallel 8
/

    ALTER TABLE CM_CALCULATION_SUMMARY ADD CONSTRAINT pk_cm_calculation_su1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_calculation_su1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_result_node1 ON CM_RESULT_NODE ( id ) nologging parallel 8
/

    ALTER TABLE CM_RESULT_NODE ADD CONSTRAINT pk_cm_result_node1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_result_node1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_result_hist1 ON CM_RESULT_HIST ( id ) nologging parallel 8
/

    ALTER TABLE CM_RESULT_HIST ADD CONSTRAINT pk_cm_result_hist1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_result_hist1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_calculation_su3 ON CM_CALCULATION_SUMMARY_HIST ( id ) nologging parallel 8
/

    ALTER TABLE CM_CALCULATION_SUMMARY_HIST ADD CONSTRAINT pk_cm_calculation_su3 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_calculation_su3 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_result_node_hi1 ON CM_RESULT_NODE_HIST ( id ) nologging parallel 8
/

    ALTER TABLE CM_RESULT_NODE_HIST ADD CONSTRAINT pk_cm_result_node_hi1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_result_node_hi1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_simm_regulator1 ON CM_SIMM_REGULATOR ( id ) nologging parallel 8
/

    ALTER TABLE CM_SIMM_REGULATOR ADD CONSTRAINT pk_cm_simm_regulator1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_simm_regulator1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_account1 ON CM_ACCOUNT ( id ) nologging parallel 8
/

    ALTER TABLE CM_ACCOUNT ADD CONSTRAINT pk_cm_account1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_account1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_account_detail1 ON CM_ACCOUNT_DETAILS ( id ) nologging parallel 8
/

    ALTER TABLE CM_ACCOUNT_DETAILS ADD CONSTRAINT pk_cm_account_detail1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_account_detail1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_etd_accounts1 ON CM_ETD_ACCOUNTS ( id ) nologging parallel 8
/

    ALTER TABLE CM_ETD_ACCOUNTS ADD CONSTRAINT pk_cm_etd_accounts1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_etd_accounts1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_simm_accounts1 ON CM_SIMM_ACCOUNTS ( id ) nologging parallel 8
/

    ALTER TABLE CM_SIMM_ACCOUNTS ADD CONSTRAINT pk_cm_simm_accounts1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_simm_accounts1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_simm_account1 ON CM_SIMM_ACCOUNT ( id ) nologging parallel 8
/

    ALTER TABLE CM_SIMM_ACCOUNT ADD CONSTRAINT pk_cm_simm_account1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_simm_account1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_simm_regulator3 ON CM_SIMM_REGULATOR_PARAMETERS ( id ) nologging parallel 8
/

    ALTER TABLE CM_SIMM_REGULATOR_PARAMETERS ADD CONSTRAINT pk_cm_simm_regulator3 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_simm_regulator3 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_simm_parameter1 ON CM_SIMM_PARAMETERS ( id ) nologging parallel 8
/

    ALTER TABLE CM_SIMM_PARAMETERS ADD CONSTRAINT pk_cm_simm_parameter1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_simm_parameter1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_flat_simm_para1 ON CM_FLAT_SIMM_PARAM ( id ) nologging parallel 8
/

    ALTER TABLE CM_FLAT_SIMM_PARAM ADD CONSTRAINT pk_cm_flat_simm_para1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_flat_simm_para1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_whatif_result1 ON CM_WHATIF_RESULT ( id, request_id ) nologging parallel 8
/

    ALTER TABLE CM_WHATIF_RESULT ADD CONSTRAINT pk_cm_whatif_result1 PRIMARY KEY ( id, request_id ) USING INDEX
/

    ALTER INDEX pk_cm_whatif_result1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_whatif_result_1 ON CM_WHATIF_RESULT_DETAIL ( id ) nologging parallel 8
/

    ALTER TABLE CM_WHATIF_RESULT_DETAIL ADD CONSTRAINT pk_cm_whatif_result_1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_whatif_result_1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_whatif_result_2 ON CM_WHATIF_RESULT_BEFORE ( result_id, detail_id ) nologging parallel 8
/

    ALTER TABLE CM_WHATIF_RESULT_BEFORE ADD CONSTRAINT pk_cm_whatif_result_2 PRIMARY KEY ( result_id, detail_id ) USING INDEX
/

    ALTER INDEX pk_cm_whatif_result_2 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_whatif_result_3 ON CM_WHATIF_RESULT_AFTER ( result_id, detail_id ) nologging parallel 8
/

    ALTER TABLE CM_WHATIF_RESULT_AFTER ADD CONSTRAINT pk_cm_whatif_result_3 PRIMARY KEY ( result_id, detail_id ) USING INDEX
/

    ALTER INDEX pk_cm_whatif_result_3 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_isda_product_t1 ON CM_ISDA_PRODUCT_TYPE ( id ) nologging parallel 8
/

    ALTER TABLE CM_ISDA_PRODUCT_TYPE ADD CONSTRAINT pk_cm_isda_product_t1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_isda_product_t1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_im_th_monitori1 ON CM_IM_TH_MONITORING_RESULT ( id ) nologging parallel 8
/

    ALTER TABLE CM_IM_TH_MONITORING_RESULT ADD CONSTRAINT pk_cm_im_th_monitori1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_im_th_monitori1 noparallel logging
/
CREATE UNIQUE INDEX pk_reuters_open_dacs1 ON REUTERS_OPEN_DACS_ENTITLEMENT ( feed_name, feed_address ) nologging parallel 8
/

    ALTER TABLE REUTERS_OPEN_DACS_ENTITLEMENT ADD CONSTRAINT pk_reuters_open_dacs1 PRIMARY KEY ( feed_name, feed_address ) USING INDEX
/

    ALTER INDEX pk_reuters_open_dacs1 noparallel logging
/
CREATE UNIQUE INDEX pk_reutersdss_config1 ON REUTERSDSS_CONFIG_NAME ( config_id ) nologging parallel 8
/

    ALTER TABLE REUTERSDSS_CONFIG_NAME ADD CONSTRAINT pk_reutersdss_config1 PRIMARY KEY ( config_id ) USING INDEX
/

    ALTER INDEX pk_reutersdss_config1 noparallel logging
/
CREATE UNIQUE INDEX pk_reutersdss_rpt_te1 ON REUTERSDSS_RPT_TEMPLATES ( rpt_tmplt_id ) nologging parallel 8
/

    ALTER TABLE REUTERSDSS_RPT_TEMPLATES ADD CONSTRAINT pk_reutersdss_rpt_te1 PRIMARY KEY ( rpt_tmplt_id ) USING INDEX
/

    ALTER INDEX pk_reutersdss_rpt_te1 noparallel logging
/
CREATE UNIQUE INDEX pk_reutersdss_schedu1 ON REUTERSDSS_SCHEDULES ( schedules_id ) nologging parallel 8
/

    ALTER TABLE REUTERSDSS_SCHEDULES ADD CONSTRAINT pk_reutersdss_schedu1 PRIMARY KEY ( schedules_id ) USING INDEX
/

    ALTER INDEX pk_reutersdss_schedu1 noparallel logging
/
CREATE UNIQUE INDEX pk_tr_reporting_attr1 ON TR_REPORTING_ATTR ( reporting_attribute_id ) nologging parallel 8
/

    ALTER TABLE TR_REPORTING_ATTR ADD CONSTRAINT pk_tr_reporting_attr1 PRIMARY KEY ( reporting_attribute_id ) USING INDEX
/

    ALTER INDEX pk_tr_reporting_attr1 noparallel logging
/
CREATE UNIQUE INDEX pk_tr_reporting_attr4 ON TR_REPORTING_ATTR_RESTRICTION ( reporting_attribute_id, value ) nologging parallel 8
/

    ALTER TABLE TR_REPORTING_ATTR_RESTRICTION ADD CONSTRAINT pk_tr_reporting_attr4 PRIMARY KEY ( reporting_attribute_id, value ) USING INDEX
/

    ALTER INDEX pk_tr_reporting_attr4 noparallel logging
/
CREATE UNIQUE INDEX pk_tr_regulation1 ON TR_REGULATION ( regulation_id ) nologging parallel 8
/

    ALTER TABLE TR_REGULATION ADD CONSTRAINT pk_tr_regulation1 PRIMARY KEY ( regulation_id ) USING INDEX
/

    ALTER INDEX pk_tr_regulation1 noparallel logging
/
CREATE UNIQUE INDEX pk_tr_supervisor1 ON TR_SUPERVISOR ( supervisor_id ) nologging parallel 8
/

    ALTER TABLE TR_SUPERVISOR ADD CONSTRAINT pk_tr_supervisor1 PRIMARY KEY ( supervisor_id ) USING INDEX
/

    ALTER INDEX pk_tr_supervisor1 noparallel logging
/
CREATE UNIQUE INDEX pk_tr_le_id_source1 ON TR_LE_ID_SOURCE ( source_id ) nologging parallel 8
/

    ALTER TABLE TR_LE_ID_SOURCE ADD CONSTRAINT pk_tr_le_id_source1 PRIMARY KEY ( source_id ) USING INDEX
/

    ALTER INDEX pk_tr_le_id_source1 noparallel logging
/
CREATE UNIQUE INDEX pk_tr_po_role1 ON TR_PO_ROLE ( role_code ) nologging parallel 8
/

    ALTER TABLE TR_PO_ROLE ADD CONSTRAINT pk_tr_po_role1 PRIMARY KEY ( role_code ) USING INDEX
/

    ALTER INDEX pk_tr_po_role1 noparallel logging
/
CREATE UNIQUE INDEX pk_tr_usi_uti1 ON TR_USI_UTI ( trade_id, regulation_id, type ) nologging parallel 8
/

    ALTER TABLE TR_USI_UTI ADD CONSTRAINT pk_tr_usi_uti1 PRIMARY KEY ( trade_id, regulation_id, type ) USING INDEX
/

    ALTER INDEX pk_tr_usi_uti1 noparallel logging
/
CREATE UNIQUE INDEX pk_tr_submission_sta1 ON TR_SUBMISSION_STATE ( trade_id, supervisor_id, purpose_code ) nologging parallel 8
/

    ALTER TABLE TR_SUBMISSION_STATE ADD CONSTRAINT pk_tr_submission_sta1 PRIMARY KEY ( trade_id, supervisor_id, purpose_code ) USING INDEX
/

    ALTER INDEX pk_tr_submission_sta1 noparallel logging
/
CREATE UNIQUE INDEX pk_tr_report_regime1 ON TR_REPORT_REGIME ( trade_id, supervisor_id, po_role_code ) nologging parallel 8
/

    ALTER TABLE TR_REPORT_REGIME ADD CONSTRAINT pk_tr_report_regime1 PRIMARY KEY ( trade_id, supervisor_id, po_role_code ) USING INDEX
/

    ALTER INDEX pk_tr_report_regime1 noparallel logging
/
CREATE UNIQUE INDEX pk_tr_business_unit1 ON TR_BUSINESS_UNIT ( trade_id, bu_role_code ) nologging parallel 8
/

    ALTER TABLE TR_BUSINESS_UNIT ADD CONSTRAINT pk_tr_business_unit1 PRIMARY KEY ( trade_id, bu_role_code ) USING INDEX
/

    ALTER INDEX pk_tr_business_unit1 noparallel logging
/
CREATE UNIQUE INDEX pk_tr_position_uti1 ON TR_POSITION_UTI ( id, account_id, account_type, product_id, liq_config_id ) nologging parallel 8
/

    ALTER TABLE TR_POSITION_UTI ADD CONSTRAINT pk_tr_position_uti1 PRIMARY KEY ( id, account_id, account_type, product_id, liq_config_id ) USING INDEX
/

    ALTER INDEX pk_tr_position_uti1 noparallel logging
/
CREATE UNIQUE INDEX pk_tr_report1 ON TR_REPORT ( trade_id ) nologging parallel 8
/

    ALTER TABLE TR_REPORT ADD CONSTRAINT pk_tr_report1 PRIMARY KEY ( trade_id ) USING INDEX
/

    ALTER INDEX pk_tr_report1 noparallel logging
/
CREATE UNIQUE INDEX pk_tr_usi_uti_hist1 ON TR_USI_UTI_HIST ( trade_id, regulation_id, type ) nologging parallel 8
/

    ALTER TABLE TR_USI_UTI_HIST ADD CONSTRAINT pk_tr_usi_uti_hist1 PRIMARY KEY ( trade_id, regulation_id, type ) USING INDEX
/

    ALTER INDEX pk_tr_usi_uti_hist1 noparallel logging
/
CREATE UNIQUE INDEX pk_tr_submission_sta2 ON TR_SUBMISSION_STATE_HIST ( trade_id, supervisor_id, purpose_code ) nologging parallel 8
/

    ALTER TABLE TR_SUBMISSION_STATE_HIST ADD CONSTRAINT pk_tr_submission_sta2 PRIMARY KEY ( trade_id, supervisor_id, purpose_code ) USING INDEX
/

    ALTER INDEX pk_tr_submission_sta2 noparallel logging
/
CREATE UNIQUE INDEX pk_tr_report_regime_1 ON TR_REPORT_REGIME_HIST ( trade_id, supervisor_id, po_role_code ) nologging parallel 8
/

    ALTER TABLE TR_REPORT_REGIME_HIST ADD CONSTRAINT pk_tr_report_regime_1 PRIMARY KEY ( trade_id, supervisor_id, po_role_code ) USING INDEX
/

    ALTER INDEX pk_tr_report_regime_1 noparallel logging
/
CREATE UNIQUE INDEX pk_tr_business_unit_1 ON TR_BUSINESS_UNIT_HIST ( trade_id, bu_role_code ) nologging parallel 8
/

    ALTER TABLE TR_BUSINESS_UNIT_HIST ADD CONSTRAINT pk_tr_business_unit_1 PRIMARY KEY ( trade_id, bu_role_code ) USING INDEX
/

    ALTER INDEX pk_tr_business_unit_1 noparallel logging
/
CREATE UNIQUE INDEX pk_tr_report_hist1 ON TR_REPORT_HIST ( trade_id ) nologging parallel 8
/

    ALTER TABLE TR_REPORT_HIST ADD CONSTRAINT pk_tr_report_hist1 PRIMARY KEY ( trade_id ) USING INDEX
/

    ALTER INDEX pk_tr_report_hist1 noparallel logging
/
CREATE UNIQUE INDEX pk_trade_filter_po_r1 ON TRADE_FILTER_PO_ROLE_CRITERION ( trade_filter_name ) nologging parallel 8
/

    ALTER TABLE TRADE_FILTER_PO_ROLE_CRITERION ADD CONSTRAINT pk_trade_filter_po_r1 PRIMARY KEY ( trade_filter_name ) USING INDEX
/

    ALTER INDEX pk_trade_filter_po_r1 noparallel logging
/
CREATE UNIQUE INDEX pk_trade_filter_uti_1 ON TRADE_FILTER_UTI_CRITERION ( trade_filter_name ) nologging parallel 8
/

    ALTER TABLE TRADE_FILTER_UTI_CRITERION ADD CONSTRAINT pk_trade_filter_uti_1 PRIMARY KEY ( trade_filter_name ) USING INDEX
/

    ALTER INDEX pk_trade_filter_uti_1 noparallel logging
/
CREATE UNIQUE INDEX pk_incoming_linked_m1 ON INCOMING_LINKED_MSG_IDENTIFIER ( config_id ) nologging parallel 8
/

    ALTER TABLE INCOMING_LINKED_MSG_IDENTIFIER ADD CONSTRAINT pk_incoming_linked_m1 PRIMARY KEY ( config_id ) USING INDEX
/

    ALTER INDEX pk_incoming_linked_m1 noparallel logging
/
CREATE UNIQUE INDEX pk_value_date_contro1 ON VALUE_DATE_CONTROL_CONFIG ( value_date_control_config_id ) nologging parallel 8
/

    ALTER TABLE VALUE_DATE_CONTROL_CONFIG ADD CONSTRAINT pk_value_date_contro1 PRIMARY KEY ( value_date_control_config_id ) USING INDEX
/

    ALTER INDEX pk_value_date_contro1 noparallel logging
/
CREATE UNIQUE INDEX pk_re_quote_rule_def1 ON RE_QUOTE_RULE_DEFINITION ( rule_name ) nologging parallel 8
/

    ALTER TABLE RE_QUOTE_RULE_DEFINITION ADD CONSTRAINT pk_re_quote_rule_def1 PRIMARY KEY ( rule_name ) USING INDEX
/

    ALTER INDEX pk_re_quote_rule_def1 noparallel logging
/
CREATE UNIQUE INDEX idx_cm_calculation_s2 ON CM_CALCULATION_SET ( name ) nologging parallel 8
/

    ALTER INDEX idx_cm_calculation_s2 noparallel logging
/
CREATE UNIQUE INDEX idx_cm_rf_status2 ON CM_RF_STATUS ( tenant_id, source, import_date, calculation_set_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_rf_status2 noparallel logging
/
CREATE UNIQUE INDEX idx_cm_simm_bucket2 ON CM_SIMM_BUCKET ( tenant_id, risk_class, qualifier ) nologging parallel 8
/

    ALTER INDEX idx_cm_simm_bucket2 noparallel logging
/
CREATE UNIQUE INDEX idx_le_settle_delive8 ON LE_SETTLE_DELIVERY_HIST ( reference ) nologging parallel 8
/

    ALTER INDEX idx_le_settle_delive8 noparallel logging
/
CREATE UNIQUE INDEX idx_manual_sdi_hist2 ON MANUAL_SDI_HIST ( reference ) nologging parallel 8
/

    ALTER INDEX idx_manual_sdi_hist2 noparallel logging
/
CREATE UNIQUE INDEX idx_recon_inven_row2 ON RECON_INVEN_ROW ( run_name, run_date, agent_id, account_id, underlyer_key, book_id, sub_account_id ) nologging parallel 8
/

    ALTER INDEX idx_recon_inven_row2 noparallel logging
/
CREATE UNIQUE INDEX idx_official_pl_aggr5 ON OFFICIAL_PL_AGGREGATE ( pl_config_id, book_id, pl_unit_id, effective_product_type, strategy_id ) nologging parallel 8
/

    ALTER INDEX idx_official_pl_aggr5 noparallel logging
/
CREATE UNIQUE INDEX idx_official_plmark_6 ON OFFICIAL_PLMARK_PERM_ADJ ( pl_config_id, trade_id, pl_unit_id, pl_bucket_id, effective_date, reason ) nologging parallel 8
/

    ALTER INDEX idx_official_plmark_6 noparallel logging
/
CREATE UNIQUE INDEX idx_ps_strategy_info2 ON PS_STRATEGY_INFO ( trade_id ) nologging parallel 8
/

    ALTER INDEX idx_ps_strategy_info2 noparallel logging
/
CREATE UNIQUE INDEX idx_ps_strategy_info4 ON PS_STRATEGY_INFO_HIST ( trade_id ) nologging parallel 8
/

    ALTER INDEX idx_ps_strategy_info4 noparallel logging
/
CREATE UNIQUE INDEX idx_accounting_pl_it2 ON ACCOUNTING_PL_ITEM ( accountingpl_config_id, tradereference_id, trade_id, val_date ) nologging parallel 8
/

    ALTER INDEX idx_accounting_pl_it2 noparallel logging
/
CREATE UNIQUE INDEX idx_platform_core_te2 ON PLATFORM_CORE_TENANT_INIT ( tenant_id, app_name ) nologging parallel 8
/

    ALTER INDEX idx_platform_core_te2 noparallel logging
/
CREATE UNIQUE INDEX idx_am_server_config6 ON AM_SERVER_CONFIGURATION ( server_name ) nologging parallel 8
/

    ALTER INDEX idx_am_server_config6 noparallel logging
/
CREATE UNIQUE INDEX idx_am_column_config4 ON AM_COLUMN_CONFIGURATION ( column_name, server_configuration ) nologging parallel 8
/

    ALTER INDEX idx_am_column_config4 noparallel logging
/
CREATE UNIQUE INDEX idx_am_column_profil2 ON AM_COLUMN_PROFILES ( column_id, group_name ) nologging parallel 8
/

    ALTER INDEX idx_am_column_profil2 noparallel logging
/
CREATE UNIQUE INDEX idx_userprefs_templa2 ON USERPREFS_TEMPLATE ( tenant_id, template_type, app, user_id, template_name ) nologging parallel 8
/

    ALTER INDEX idx_userprefs_templa2 noparallel logging
/
CREATE UNIQUE INDEX idx_re_quote_list3 ON RE_QUOTE_LIST ( config_name, display_name ) nologging parallel 8
/

    ALTER INDEX idx_re_quote_list3 noparallel logging
/
CREATE UNIQUE INDEX idx_cls_schedule2 ON CLS_SCHEDULE ( party_id, timestamp ) nologging parallel 8
/

    ALTER INDEX idx_cls_schedule2 noparallel logging
/
CREATE UNIQUE INDEX idx_cls_schedule3 ON CLS_SCHEDULE ( clsb_reference ) nologging parallel 8
/

    ALTER INDEX idx_cls_schedule3 noparallel logging
/
CREATE UNIQUE INDEX idx_cls_trade_info2 ON CLS_TRADE_INFO ( clsb_ref ) nologging parallel 8
/

    ALTER INDEX idx_cls_trade_info2 noparallel logging
/
CREATE UNIQUE INDEX idx_margin_liquidity4 ON MARGIN_LIQUIDITY ( valuation_date, margin_account, pricing_env, bucket, currency, type, eod ) nologging parallel 8
/

    ALTER INDEX idx_margin_liquidity4 noparallel logging
/
CREATE UNIQUE INDEX idx_margin_trade_liq2 ON MARGIN_TRADE_LIQUIDITY ( trade_id, valuation_date, pricing_env, margin_account, bucket, currency, type, eod ) nologging parallel 8
/

    ALTER INDEX idx_margin_trade_liq2 noparallel logging
/
CREATE UNIQUE INDEX idx_margin_trade_vm3 ON MARGIN_TRADE_VM ( trade_id, valuation_date, currency, leg_direction, margin_agreement_name, calculation_set, eod ) nologging parallel 8
/

    ALTER INDEX idx_margin_trade_vm3 noparallel logging
/
CREATE UNIQUE INDEX idx_margin_trade_vm_2 ON MARGIN_TRADE_VM_HIST ( trade_id, valuation_date, currency, leg_direction, calculation_set, eod ) nologging parallel 8
/

    ALTER INDEX idx_margin_trade_vm_2 noparallel logging
/
CREATE UNIQUE INDEX idx_margin_portfolio3 ON MARGIN_PORTFOLIO_VM ( margin_agreement_name, calculation_set, valuation_date, currency, eod ) nologging parallel 8
/

    ALTER INDEX idx_margin_portfolio3 noparallel logging
/
CREATE UNIQUE INDEX idx_margin_portfolio4 ON MARGIN_PORTFOLIO_VM_HIST ( margin_agreement_name, calculation_set, valuation_date, currency, eod ) nologging parallel 8
/

    ALTER INDEX idx_margin_portfolio4 noparallel logging
/
CREATE UNIQUE INDEX idx_margin_portfolio5 ON MARGIN_PORTFOLIO_VM_TEMP ( margin_agreement_name, calculation_set, valuation_date, currency, eod ) nologging parallel 8
/

    ALTER INDEX idx_margin_portfolio5 noparallel logging
/
CREATE UNIQUE INDEX idx_margin_result_no1 ON MARGIN_RESULT_NODE ( id, node_name ) nologging parallel 8
/

    ALTER INDEX idx_margin_result_no1 noparallel logging
/
CREATE UNIQUE INDEX idx_margin_result_no2 ON MARGIN_RESULT_NODE_HIST ( id, node_name ) nologging parallel 8
/

    ALTER INDEX idx_margin_result_no2 noparallel logging
/
CREATE UNIQUE INDEX idx_cm_simm_regulato2 ON CM_SIMM_REGULATOR ( tenant_id, name ) nologging parallel 8
/

    ALTER INDEX idx_cm_simm_regulato2 noparallel logging
/
CREATE UNIQUE INDEX idx_cm_isda_product_2 ON CM_ISDA_PRODUCT_TYPE ( tenant_id, product_type ) nologging parallel 8
/

    ALTER INDEX idx_cm_isda_product_2 noparallel logging
/
CREATE UNIQUE INDEX idx_tr_reporting_att2 ON TR_REPORTING_ATTR ( attribute_name ) nologging parallel 8
/

    ALTER INDEX idx_tr_reporting_att2 noparallel logging
/
CREATE UNIQUE INDEX idx_tr_reporting_att3 ON TR_REPORTING_ATTR ( map_to ) nologging parallel 8
/

    ALTER INDEX idx_tr_reporting_att3 noparallel logging
/
CREATE UNIQUE INDEX idx_tr_regulation2 ON TR_REGULATION ( regulation_code ) nologging parallel 8
/

    ALTER INDEX idx_tr_regulation2 noparallel logging
/
CREATE UNIQUE INDEX idx_tr_regulation3 ON TR_REGULATION ( regulation_name ) nologging parallel 8
/

    ALTER INDEX idx_tr_regulation3 noparallel logging
/
CREATE UNIQUE INDEX idx_tr_supervisor2 ON TR_SUPERVISOR ( supervisor_code ) nologging parallel 8
/

    ALTER INDEX idx_tr_supervisor2 noparallel logging
/
CREATE UNIQUE INDEX idx_tr_le_id_source2 ON TR_LE_ID_SOURCE ( source_code ) nologging parallel 8
/

    ALTER INDEX idx_tr_le_id_source2 noparallel logging
/
CREATE UNIQUE INDEX idx_tr_le_id_source3 ON TR_LE_ID_SOURCE ( fpml_url ) nologging parallel 8
/

    ALTER INDEX idx_tr_le_id_source3 noparallel logging
/
CREATE INDEX idx_cm_rf_source2 ON CM_RF_SOURCE ( source ) nologging parallel 8
/

    ALTER INDEX idx_cm_rf_source2 noparallel logging
/
CREATE INDEX idx_cm_rf_status_err1 ON CM_RF_STATUS_ERRORS ( rf_status_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_rf_status_err1 noparallel logging
/
CREATE INDEX idx_cm_simm_calc_req2 ON CM_SIMM_CALC_REQUEST ( tenant_id, account_id, valuation_date, calculation_set_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_simm_calc_req2 noparallel logging
/
CREATE INDEX idx_cm_simm_what_if_2 ON CM_SIMM_WHAT_IF_REQUEST ( tenant_id, valuation_date ) nologging parallel 8
/

    ALTER INDEX idx_cm_simm_what_if_2 noparallel logging
/
CREATE INDEX idx_cm_simm_what_if_3 ON CM_SIMM_WHAT_IF_REQUEST_ERRORS ( request_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_simm_what_if_3 noparallel logging
/
CREATE INDEX idx_cm_rf_what_if2 ON CM_RF_WHAT_IF ( what_if_request_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_rf_what_if2 noparallel logging
/
CREATE INDEX idx_cm_rf_what_if_co1 ON CM_RF_WHAT_IF_COLLECT_REG ( rf_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_rf_what_if_co1 noparallel logging
/
CREATE INDEX idx_cm_rf_what_if_po1 ON CM_RF_WHAT_IF_POST_REG ( rf_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_rf_what_if_po1 noparallel logging
/
CREATE INDEX idx_cm_rf_trade2 ON CM_RF_TRADE ( valuation_date, account_id, source, calculation_set_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_rf_trade2 noparallel logging
/
CREATE INDEX idx_cm_rf_trade_coll1 ON CM_RF_TRADE_COLLECT_REG ( rf_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_rf_trade_coll1 noparallel logging
/
CREATE INDEX idx_cm_rf_trade_post1 ON CM_RF_TRADE_POST_REG ( rf_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_rf_trade_post1 noparallel logging
/
CREATE INDEX idx_cm_rf_status_his2 ON CM_RF_STATUS_HIST ( import_date ) nologging parallel 8
/

    ALTER INDEX idx_cm_rf_status_his2 noparallel logging
/
CREATE INDEX idx_cm_rf_status_err2 ON CM_RF_STATUS_ERRORS_HIST ( rf_status_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_rf_status_err2 noparallel logging
/
CREATE INDEX idx_cm_rf_trade_hist2 ON CM_RF_TRADE_HIST ( valuation_date ) nologging parallel 8
/

    ALTER INDEX idx_cm_rf_trade_hist2 noparallel logging
/
CREATE INDEX idx_cm_rf_trade_coll2 ON CM_RF_TRADE_COLLECT_REG_HIST ( rf_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_rf_trade_coll2 noparallel logging
/
CREATE INDEX idx_cm_rf_trade_post2 ON CM_RF_TRADE_POST_REG_HIST ( rf_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_rf_trade_post2 noparallel logging
/
CREATE INDEX idx_cm_simm_calc_req4 ON CM_SIMM_CALC_REQUEST_HIST ( valuation_date ) nologging parallel 8
/

    ALTER INDEX idx_cm_simm_calc_req4 noparallel logging
/
CREATE INDEX idx_cm_simm_calc_req6 ON CM_SIMM_CALC_REQUEST_TEMP ( valuation_date ) nologging parallel 8
/

    ALTER INDEX idx_cm_simm_calc_req6 noparallel logging
/
CREATE INDEX idx_cm_im_monitoring2 ON CM_IM_MONITORING_CONFIG ( tenant_id, warning_ccy, variation, max_total_im ) nologging parallel 8
/

    ALTER INDEX idx_cm_im_monitoring2 noparallel logging
/
CREATE INDEX idx_collateral_confi5 ON COLLATERAL_CONFIG ( collateral_group ) nologging parallel 8
/

    ALTER INDEX idx_collateral_confi5 noparallel logging
/
CREATE INDEX idx_margin_call_entr20 ON MARGIN_CALL_ENTRIES ( process_datetime ) nologging parallel 8
/

    ALTER INDEX idx_margin_call_entr20 noparallel logging
/
CREATE INDEX idx_acc_rule2 ON ACC_RULE ( acc_rule_name ) nologging parallel 8
/

    ALTER INDEX idx_acc_rule2 noparallel logging
/
CREATE INDEX idx_bo_posting7 ON BO_POSTING ( linked_id ) nologging parallel 8
/

    ALTER INDEX idx_bo_posting7 noparallel logging
/
CREATE INDEX idx_bo_transfer21 ON BO_TRANSFER ( gl_account_id ) nologging parallel 8
/

    ALTER INDEX idx_bo_transfer21 noparallel logging
/
CREATE INDEX idx_bo_transfer22 ON BO_TRANSFER ( cash_account_id ) nologging parallel 8
/

    ALTER INDEX idx_bo_transfer22 noparallel logging
/
CREATE INDEX idx_bo_transfer_hist6 ON BO_TRANSFER_HIST ( gl_account_id ) nologging parallel 8
/

    ALTER INDEX idx_bo_transfer_hist6 noparallel logging
/
CREATE INDEX idx_bo_transfer_hist7 ON BO_TRANSFER_HIST ( cash_account_id ) nologging parallel 8
/

    ALTER INDEX idx_bo_transfer_hist7 noparallel logging
/
CREATE INDEX idx_curve_point_adj2 ON CURVE_POINT_ADJ ( curve_date ) nologging parallel 8
/

    ALTER INDEX idx_curve_point_adj2 noparallel logging
/
CREATE INDEX idx_curve_quote_adj2 ON CURVE_QUOTE_ADJ ( curve_date ) nologging parallel 8
/

    ALTER INDEX idx_curve_quote_adj2 noparallel logging
/
CREATE INDEX idx_event_type_actio3 ON EVENT_TYPE_ACTION ( action_type ) nologging parallel 8
/

    ALTER INDEX idx_event_type_actio3 noparallel logging
/
CREATE INDEX idx_event_type_actio5 ON EVENT_TYPE_ACTION ( effective_date ) nologging parallel 8
/

    ALTER INDEX idx_event_type_actio5 noparallel logging
/
CREATE INDEX idx_event_type_actio6 ON EVENT_TYPE_ACTION ( creation_date ) nologging parallel 8
/

    ALTER INDEX idx_event_type_actio6 noparallel logging
/
CREATE INDEX idx_file_document2 ON FILE_DOCUMENT ( entity_type ) nologging parallel 8
/

    ALTER INDEX idx_file_document2 noparallel logging
/
CREATE INDEX idx_inv_cash_movemen2 ON INV_CASH_MOVEMENT ( internal_external, position_type, date_type, account_id, config_id ) nologging parallel 8
/

    ALTER INDEX idx_inv_cash_movemen2 noparallel logging
/
CREATE INDEX idx_inv_cash_balance2 ON INV_CASH_BALANCE ( internal_external, position_type, date_type, account_id, config_id ) nologging parallel 8
/

    ALTER INDEX idx_inv_cash_balance2 noparallel logging
/
CREATE INDEX idx_inv_cust_cash_mo2 ON INV_CUST_CASH_MOVEMENT ( internal_external, position_type, date_type, account_id, config_id ) nologging parallel 8
/

    ALTER INDEX idx_inv_cust_cash_mo2 noparallel logging
/
CREATE INDEX idx_inv_cust_cash_ba2 ON INV_CUST_CASH_BALANCE ( internal_external, position_type, date_type, account_id, config_id ) nologging parallel 8
/

    ALTER INDEX idx_inv_cust_cash_ba2 noparallel logging
/
CREATE INDEX idx_inv_sec_balance2 ON INV_SEC_BALANCE ( internal_external, position_type, date_type, account_id, config_id ) nologging parallel 8
/

    ALTER INDEX idx_inv_sec_balance2 noparallel logging
/
CREATE INDEX idx_inv_sec_movement2 ON INV_SEC_MOVEMENT ( internal_external, position_type, date_type, account_id, config_id ) nologging parallel 8
/

    ALTER INDEX idx_inv_sec_movement2 noparallel logging
/
CREATE INDEX idx_inv_cust_sec_bal2 ON INV_CUST_SEC_BALANCE ( internal_external, position_type, date_type, account_id, config_id ) nologging parallel 8
/

    ALTER INDEX idx_inv_cust_sec_bal2 noparallel logging
/
CREATE INDEX idx_inv_cust_sec_mov2 ON INV_CUST_SEC_MOVEMENT ( internal_external, position_type, date_type, account_id, config_id ) nologging parallel 8
/

    ALTER INDEX idx_inv_cust_sec_mov2 noparallel logging
/
CREATE INDEX idx_le_settle_delive7 ON LE_SETTLE_DELIVERY_HIST ( bene_le, le_role ) nologging parallel 8
/

    ALTER INDEX idx_le_settle_delive7 noparallel logging
/
CREATE INDEX idx_liq_position9 ON LIQ_POSITION ( initial_id ) nologging parallel 8
/

    ALTER INDEX idx_liq_position9 noparallel logging
/
CREATE INDEX idx_liq_position10 ON LIQ_POSITION ( liquidated_date, book_id, product_id, is_deleted, liq_agg_id, first_trade ) nologging parallel 8
/

    ALTER INDEX idx_liq_position10 noparallel logging
/
CREATE INDEX idx_liq_position11 ON LIQ_POSITION ( liquidated_date, book_id, product_id, is_deleted, liq_agg_id, second_trade ) nologging parallel 8
/

    ALTER INDEX idx_liq_position11 noparallel logging
/
CREATE INDEX idx_liq_position_his4 ON LIQ_POSITION_HIST ( position_id ) nologging parallel 8
/

    ALTER INDEX idx_liq_position_his4 noparallel logging
/

CREATE INDEX idx_ps_strategy_info1 ON PS_STRATEGY_INFO ( strategy_id ) nologging parallel 8
/

    ALTER INDEX idx_ps_strategy_info1 noparallel logging
/
CREATE INDEX idx_ps_strategy_info3 ON PS_STRATEGY_INFO_HIST ( strategy_id ) nologging parallel 8
/

    ALTER INDEX idx_ps_strategy_info3 noparallel logging
/
CREATE INDEX idx_decsupp_order_hi2 ON DECSUPP_ORDER_HIST ( type ) nologging parallel 8
/

    ALTER INDEX idx_decsupp_order_hi2 noparallel logging
/
CREATE INDEX idx_decsupp_order_hi3 ON DECSUPP_ORDER_HIST ( external_ref ) nologging parallel 8
/

    ALTER INDEX idx_decsupp_order_hi3 noparallel logging
/
CREATE INDEX idx_am_order_executi7 ON AM_ORDER_EXECUTION_ITEM_HIST ( parent_id, parent_version ) nologging parallel 8
/

    ALTER INDEX idx_am_order_executi7 noparallel logging
/
CREATE INDEX idx_activemq_acks2 ON ACTIVEMQ_ACKS ( xid ) nologging parallel 8
/

    ALTER INDEX idx_activemq_acks2 noparallel logging
/
CREATE INDEX idx_activemq_msgs2 ON ACTIVEMQ_MSGS ( container ) nologging parallel 8
/

    ALTER INDEX idx_activemq_msgs2 noparallel logging
/
CREATE INDEX idx_activemq_msgs3 ON ACTIVEMQ_MSGS ( expiration ) nologging parallel 8
/

    ALTER INDEX idx_activemq_msgs3 noparallel logging
/
CREATE INDEX idx_activemq_msgs4 ON ACTIVEMQ_MSGS ( msgid_prod, msgid_seq ) nologging parallel 8
/

    ALTER INDEX idx_activemq_msgs4 noparallel logging
/
CREATE INDEX idx_activemq_msgs5 ON ACTIVEMQ_MSGS ( priority ) nologging parallel 8
/

    ALTER INDEX idx_activemq_msgs5 noparallel logging
/
CREATE INDEX idx_activemq_msgs6 ON ACTIVEMQ_MSGS ( xid ) nologging parallel 8
/

    ALTER INDEX idx_activemq_msgs6 noparallel logging
/
CREATE INDEX idx_am_column_config2 ON AM_COLUMN_CONFIGURATION ( column_id, update_version ) nologging parallel 8
/

    ALTER INDEX idx_am_column_config2 noparallel logging
/
CREATE INDEX idx_am_column_config3 ON AM_COLUMN_CONFIGURATION ( audit_id ) nologging parallel 8
/

    ALTER INDEX idx_am_column_config3 noparallel logging
/
CREATE INDEX idx_am_formula_confi2 ON AM_FORMULA_CONFIGURATION ( audit_id ) nologging parallel 8
/

    ALTER INDEX idx_am_formula_confi2 noparallel logging
/
CREATE INDEX idx_am_formula_confi3 ON AM_FORMULA_CONFIGURATION ( formula_id, update_version ) nologging parallel 8
/

    ALTER INDEX idx_am_formula_confi3 noparallel logging
/
CREATE INDEX idx_am_columnset_con2 ON AM_COLUMNSET_CONFIGURATION ( audit_id ) nologging parallel 8
/

    ALTER INDEX idx_am_columnset_con2 noparallel logging
/
CREATE INDEX idx_am_columnset_con3 ON AM_COLUMNSET_CONFIGURATION ( columnset_id, update_version ) nologging parallel 8
/

    ALTER INDEX idx_am_columnset_con3 noparallel logging
/
CREATE INDEX idx_am_columnset_mai1 ON AM_COLUMNSET_MAIN_COLUMNS ( columnset_id, column_id ) nologging parallel 8
/

    ALTER INDEX idx_am_columnset_mai1 noparallel logging
/
CREATE INDEX idx_am_columnset_piv1 ON AM_COLUMNSET_PIVOT_COLUMNS ( columnset_id, column_id ) nologging parallel 8
/

    ALTER INDEX idx_am_columnset_piv1 noparallel logging
/
CREATE INDEX idx_am_columnset_gro1 ON AM_COLUMNSET_GROUP_COLUMNS ( columnset_id, column_id ) nologging parallel 8
/

    ALTER INDEX idx_am_columnset_gro1 noparallel logging
/
CREATE INDEX idx_am_columnset_bre1 ON AM_COLUMNSET_BREAKDOWN_COLUMNS ( columnset_id, column_id ) nologging parallel 8
/

    ALTER INDEX idx_am_columnset_bre1 noparallel logging
/
CREATE INDEX idx_am_unit_configur2 ON AM_UNIT_CONFIGURATION ( audit_id ) nologging parallel 8
/

    ALTER INDEX idx_am_unit_configur2 noparallel logging
/
CREATE INDEX idx_am_unit_configur3 ON AM_UNIT_CONFIGURATION ( unit_id, update_version ) nologging parallel 8
/

    ALTER INDEX idx_am_unit_configur3 noparallel logging
/
CREATE INDEX idx_am_unit_denomina1 ON AM_UNIT_DENOMINATOR_COLUMN ( unit_id, analysis_id ) nologging parallel 8
/

    ALTER INDEX idx_am_unit_denomina1 noparallel logging
/
CREATE INDEX idx_am_grouping_conf2 ON AM_GROUPING_CONFIGURATION ( audit_id ) nologging parallel 8
/

    ALTER INDEX idx_am_grouping_conf2 noparallel logging
/
CREATE INDEX idx_am_grouping_conf3 ON AM_GROUPING_CONFIGURATION ( grouping_id, update_version ) nologging parallel 8
/

    ALTER INDEX idx_am_grouping_conf3 noparallel logging
/
CREATE INDEX idx_am_grouping_colu1 ON AM_GROUPING_COLUMNS ( grouping_id, column_name ) nologging parallel 8
/

    ALTER INDEX idx_am_grouping_colu1 noparallel logging
/
CREATE INDEX idx_am_widget_config2 ON AM_WIDGET_CONFIGURATION ( audit_id ) nologging parallel 8
/

    ALTER INDEX idx_am_widget_config2 noparallel logging
/
CREATE INDEX idx_am_widget_config3 ON AM_WIDGET_CONFIGURATION ( widget_id, update_version ) nologging parallel 8
/

    ALTER INDEX idx_am_widget_config3 noparallel logging
/
CREATE INDEX idx_am_layout_config2 ON AM_LAYOUT_CONFIGURATION ( audit_id ) nologging parallel 8
/

    ALTER INDEX idx_am_layout_config2 noparallel logging
/
CREATE INDEX idx_am_layout_config3 ON AM_LAYOUT_CONFIGURATION ( layout_id, update_version ) nologging parallel 8
/

    ALTER INDEX idx_am_layout_config3 noparallel logging
/
CREATE INDEX idx_am_filtering_con2 ON AM_FILTERING_CONFIGURATION ( audit_id ) nologging parallel 8
/

    ALTER INDEX idx_am_filtering_con2 noparallel logging
/
CREATE INDEX idx_am_filtering_con3 ON AM_FILTERING_CONFIGURATION ( filtering_id, update_version ) nologging parallel 8
/

    ALTER INDEX idx_am_filtering_con3 noparallel logging
/
CREATE INDEX idx_am_filtering_col1 ON AM_FILTERING_COLUMNS ( filtering_id, column_id ) nologging parallel 8
/

    ALTER INDEX idx_am_filtering_col1 noparallel logging
/
CREATE INDEX idx_am_coloring_conf2 ON AM_COLORING_CONFIGURATION ( audit_id ) nologging parallel 8
/

    ALTER INDEX idx_am_coloring_conf2 noparallel logging
/
CREATE INDEX idx_am_coloring_conf3 ON AM_COLORING_CONFIGURATION ( coloring_id, update_version ) nologging parallel 8
/

    ALTER INDEX idx_am_coloring_conf3 noparallel logging
/
CREATE INDEX idx_userprefs_templa4 ON USERPREFS_TEMPLATE_2_CRIT ( template_id ) nologging parallel 8
/

    ALTER INDEX idx_userprefs_templa4 noparallel logging
/
CREATE INDEX idx_re_quote_list2 ON RE_QUOTE_LIST ( config_name ) nologging parallel 8
/

    ALTER INDEX idx_re_quote_list2 noparallel logging
/
CREATE INDEX idx_re_quote_rules2 ON RE_QUOTE_RULES ( config_name ) nologging parallel 8
/

    ALTER INDEX idx_re_quote_rules2 noparallel logging
/
CREATE INDEX idx_re_quote_rules_p2 ON RE_QUOTE_RULES_PARAMS ( rule_id ) nologging parallel 8
/

    ALTER INDEX idx_re_quote_rules_p2 noparallel logging
/
CREATE INDEX idx_core_account_att2 ON CORE_ACCOUNT_ATTRIBUTE ( tenant_id, account_id, name ) nologging parallel 8
/

    ALTER INDEX idx_core_account_att2 noparallel logging
/
CREATE INDEX idx_core_country2 ON CORE_COUNTRY ( tenant_id, code ) nologging parallel 8
/

    ALTER INDEX idx_core_country2 noparallel logging
/
CREATE INDEX idx_core_currency2 ON CORE_CURRENCY ( tenant_id, code ) nologging parallel 8
/

    ALTER INDEX idx_core_currency2 noparallel logging
/
CREATE INDEX idx_core_currencypai2 ON CORE_CURRENCYPAIR ( tenant_id, primary_currency, quoting_currency ) nologging parallel 8
/

    ALTER INDEX idx_core_currencypai2 noparallel logging
/
CREATE INDEX idx_core_data_policy2 ON CORE_DATA_POLICY ( tenant_id, data_type ) nologging parallel 8
/

    ALTER INDEX idx_core_data_policy2 noparallel logging
/
CREATE INDEX idx_core_equity2 ON CORE_EQUITY ( equity_name ) nologging parallel 8
/

    ALTER INDEX idx_core_equity2 noparallel logging
/
CREATE INDEX idx_core_holiday2 ON CORE_HOLIDAY ( tenant_id, data_source_id ) nologging parallel 8
/

    ALTER INDEX idx_core_holiday2 noparallel logging
/
CREATE INDEX idx_core_holiday3 ON CORE_HOLIDAY ( tenant_id, code ) nologging parallel 8
/

    ALTER INDEX idx_core_holiday3 noparallel logging
/
CREATE INDEX idx_core_holiday_eve2 ON CORE_HOLIDAY_EVENT ( tenant_id, hol_date, holiday_id, description ) nologging parallel 8
/

    ALTER INDEX idx_core_holiday_eve2 noparallel logging
/
CREATE INDEX idx_core_junc_intere1 ON CORE_JUNC_INTEREST_CONFIG ( interest_config_id1 ) nologging parallel 8
/

    ALTER INDEX idx_core_junc_intere1 noparallel logging
/
CREATE INDEX idx_core_le_contact2 ON CORE_LE_CONTACT ( tenant_id, legal_entity_id ) nologging parallel 8
/

    ALTER INDEX idx_core_le_contact2 noparallel logging
/
CREATE INDEX idx_core_le_contact3 ON CORE_LE_CONTACT ( tenant_id, last_name ) nologging parallel 8
/

    ALTER INDEX idx_core_le_contact3 noparallel logging
/
CREATE INDEX idx_core_le_contact4 ON CORE_LE_CONTACT ( tenant_id, email ) nologging parallel 8
/

    ALTER INDEX idx_core_le_contact4 noparallel logging
/
CREATE INDEX idx_core_legal_entit2 ON CORE_LEGAL_ENTITY ( tenant_id, legal_name ) nologging parallel 8
/

    ALTER INDEX idx_core_legal_entit2 noparallel logging
/
CREATE INDEX idx_core_legal_entit3 ON CORE_LEGAL_ENTITY ( tenant_id, legal_short_name ) nologging parallel 8
/

    ALTER INDEX idx_core_legal_entit3 noparallel logging
/
CREATE INDEX idx_core_legal_entit4 ON CORE_LEGAL_ENTITY ( legaladdress_id ) nologging parallel 8
/

    ALTER INDEX idx_core_legal_entit4 noparallel logging
/
CREATE INDEX idx_core_pf_from_to_1 ON CORE_PF_FROM_TO_MAP ( pf_criterion_from_to_id ) nologging parallel 8
/

    ALTER INDEX idx_core_pf_from_to_1 noparallel logging
/
CREATE INDEX idx_core_pf_from_to_2 ON CORE_PF_FROM_TO_MAP ( pf_id ) nologging parallel 8
/

    ALTER INDEX idx_core_pf_from_to_2 noparallel logging
/
CREATE INDEX idx_core_pf_multi_va3 ON CORE_PF_MULTI_VALUES_MAP ( pf_criterion_multi_val_id ) nologging parallel 8
/

    ALTER INDEX idx_core_pf_multi_va3 noparallel logging
/
CREATE INDEX idx_core_pf_multi_va4 ON CORE_PF_MULTI_VALUES_MAP ( pf_id ) nologging parallel 8
/

    ALTER INDEX idx_core_pf_multi_va4 noparallel logging
/
CREATE INDEX idx_core_product_put1 ON CORE_PRODUCT_PUT_CALL_SCHEDULE ( put_call_date_id1 ) nologging parallel 8
/

    ALTER INDEX idx_core_product_put1 noparallel logging
/
CREATE INDEX idx_core_product_sec1 ON CORE_PRODUCT_SEC_ATTRIBUTE ( security_attribute_id3 ) nologging parallel 8
/

    ALTER INDEX idx_core_product_sec1 noparallel logging
/
CREATE INDEX idx_core_product_sec2 ON CORE_PRODUCT_SEC_ID ( security_identifier_id1 ) nologging parallel 8
/

    ALTER INDEX idx_core_product_sec2 noparallel logging
/
CREATE INDEX idx_core_quote_defin2 ON CORE_QUOTE_DEFINITION ( tenant_id, quote_name ) nologging parallel 8
/

    ALTER INDEX idx_core_quote_defin2 noparallel logging
/
CREATE INDEX idx_core_quote_set2 ON CORE_QUOTE_SET ( tenant_id, quote_set_name ) nologging parallel 8
/

    ALTER INDEX idx_core_quote_set2 noparallel logging
/
CREATE INDEX idx_core_rating_le2 ON CORE_RATING_LE ( tenant_id, agency_id ) nologging parallel 8
/

    ALTER INDEX idx_core_rating_le2 noparallel logging
/
CREATE INDEX idx_core_rating_le3 ON CORE_RATING_LE ( tenant_id, seniority ) nologging parallel 8
/

    ALTER INDEX idx_core_rating_le3 noparallel logging
/
CREATE INDEX idx_core_rating_le4 ON CORE_RATING_LE ( tenant_id, legal_entity_id ) nologging parallel 8
/

    ALTER INDEX idx_core_rating_le4 noparallel logging
/
CREATE INDEX idx_core_settlement_2 ON CORE_SETTLEMENT_ACCOUNT ( tenant_id, name ) nologging parallel 8
/

    ALTER INDEX idx_core_settlement_2 noparallel logging
/
CREATE INDEX idx_core_settlement_3 ON CORE_SETTLEMENT_ACCOUNT ( tenant_id, account_identifier ) nologging parallel 8
/

    ALTER INDEX idx_core_settlement_3 noparallel logging
/
CREATE INDEX idx_core_split_curre2 ON CORE_SPLIT_CURRENCY ( tenant_id, primary_currency, quoting_currency ) nologging parallel 8
/

    ALTER INDEX idx_core_split_curre2 noparallel logging
/
CREATE INDEX idx_cls_schedule_ite1 ON CLS_SCHEDULE_ITEM ( schedule_id ) nologging parallel 8
/

    ALTER INDEX idx_cls_schedule_ite1 noparallel logging
/

CREATE INDEX idx_margin_trade_vm4 ON MARGIN_TRADE_VM ( trade_id, im_portfolio_name, calculation_set, valuation_date, eod ) nologging parallel 8
/

    ALTER INDEX idx_margin_trade_vm4 noparallel logging
/
CREATE INDEX idx_margin_result_er1 ON MARGIN_RESULT_ERRORS ( tree_id ) nologging parallel 8
/

    ALTER INDEX idx_margin_result_er1 noparallel logging
/
CREATE INDEX idx_audit_record2 ON AUDIT_RECORD ( tenant_id, capture_time ) nologging parallel 8
/

    ALTER INDEX idx_audit_record2 noparallel logging
/
CREATE INDEX idx_audit_record3 ON AUDIT_RECORD ( tenant_id, app ) nologging parallel 8
/

    ALTER INDEX idx_audit_record3 noparallel logging
/
CREATE INDEX idx_audit_record4 ON AUDIT_RECORD ( tenant_id, acting_user_id ) nologging parallel 8
/

    ALTER INDEX idx_audit_record4 noparallel logging
/
CREATE INDEX idx_audit_record5 ON AUDIT_RECORD ( tenant_id, acting_user_type ) nologging parallel 8
/

    ALTER INDEX idx_audit_record5 noparallel logging
/
CREATE INDEX idx_audit_record6 ON AUDIT_RECORD ( tenant_id, class_name ) nologging parallel 8
/

    ALTER INDEX idx_audit_record6 noparallel logging
/
CREATE INDEX idx_cm_result2 ON CM_RESULT ( tenant_id, valuation_date, account_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_result2 noparallel logging
/
CREATE INDEX idx_cm_result3 ON CM_RESULT ( calculationsummary_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_result3 noparallel logging
/
CREATE INDEX idx_cm_result4 ON CM_RESULT ( tenant_id, account_id, direction, totalimusd ) nologging parallel 8
/

    ALTER INDEX idx_cm_result4 noparallel logging
/
CREATE INDEX idx_cm_result_errors1 ON CM_RESULT_ERRORS ( tree_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_result_errors1 noparallel logging
/
CREATE INDEX idx_cm_calculation_s4 ON CM_CALCULATION_SUMMARY ( tenant_id, service, calculation_set_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_calculation_s4 noparallel logging
/
CREATE INDEX idx_cm_result_node2 ON CM_RESULT_NODE ( tenant_id, tree_id, node_index ) nologging parallel 8
/

    ALTER INDEX idx_cm_result_node2 noparallel logging
/
CREATE INDEX idx_cm_result_hist2 ON CM_RESULT_HIST ( calculationsummary_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_result_hist2 noparallel logging
/
CREATE INDEX idx_cm_result_errors2 ON CM_RESULT_ERRORS_HIST ( tree_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_result_errors2 noparallel logging
/
CREATE INDEX idx_cm_result_node_h2 ON CM_RESULT_NODE_HIST ( tree_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_result_node_h2 noparallel logging
/
CREATE INDEX idx_cm_simm_post_reg1 ON CM_SIMM_POST_REGULATORS ( simmmarginaccount_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_simm_post_reg1 noparallel logging
/
CREATE INDEX idx_cm_simm_collect_1 ON CM_SIMM_COLLECT_REGULATORS ( simmmarginaccount_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_simm_collect_1 noparallel logging
/
CREATE INDEX idx_cm_simm_paramete2 ON CM_SIMM_PARAMETERS ( regulatorparameter_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_simm_paramete2 noparallel logging
/
CREATE INDEX idx_cm_flat_simm_par2 ON CM_FLAT_SIMM_PARAM ( accountdetails_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_flat_simm_par2 noparallel logging
/
CREATE INDEX idx_cm_flat_simm_par3 ON CM_FLAT_SIMM_PARAM ( regulator ) nologging parallel 8
/

    ALTER INDEX idx_cm_flat_simm_par3 noparallel logging
/
CREATE INDEX idx_cm_whatif_result2 ON CM_WHATIF_RESULT ( tenant_id, request_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_whatif_result2 noparallel logging
/
CREATE INDEX idx_cm_im_th_monitor2 ON CM_IM_TH_MONITORING_RESULT ( tenant_id, calculation_set_id, account_id, tree_id, direction, currency, csa_status, threshold_status ) nologging parallel 8
/

    ALTER INDEX idx_cm_im_th_monitor2 noparallel logging
/
CREATE INDEX idx_tr_reporting_att5 ON TR_REPORTING_ATTR_RESTRICTION ( reporting_attribute_id ) nologging parallel 8
/

    ALTER INDEX idx_tr_reporting_att5 noparallel logging
/
CREATE INDEX idx_trade_filter_po_2 ON TRADE_FILTER_PO_ROLE_ELEMENT ( trade_filter_name ) nologging parallel 8
/

    ALTER INDEX idx_trade_filter_po_2 noparallel logging
/
CREATE INDEX idx_trade_filter_uti2 ON TRADE_FILTER_UTI_ELEMENT ( trade_filter_name ) nologging parallel 8
/

    ALTER INDEX idx_trade_filter_uti2 noparallel logging
/


/* Applying Stored Procedures - start */

CREATE OR REPLACE FUNCTION custom_rule_discriminator (name IN varchar2) RETURN varchar2
IS
BEGIN
IF instr(name,'MessageRule') <> 0 THEN
RETURN 'MessageRule';
ELSIF instr(name,'TradeRule') <> 0 THEN
RETURN 'TradeRule';
ELSIF instr(name,'TransferRule') <> 0 THEN
RETURN 'TransferRule';
ELSIF instr(name,'WorkflowRule') <> 0 THEN
RETURN 'WorkflowRule';
ELSE
RETURN 'error';
END IF;
END custom_rule_discriminator;
/
CREATE OR REPLACE PROCEDURE drop_function ( proc_name IN user_tab_columns.table_name%TYPE) AS
 x number;
BEGIN
   BEGIN
   SELECT count(*) into x FROM user_objects WHERE object_name=UPPER(proc_name) and object_type= 'FUNCTION';
   exception
        when NO_DATA_FOUND THEN
        x:=0;
        when others then
        null;
    end;
    IF x > 0 THEN
       EXECUTE IMMEDIATE 'drop function '|| proc_name;
    END IF;
END drop_function;
/
begin
 drop_function ('rate_index_string_value');
end;
/
create or replace view rate_index_string_value as select rate_index_id,
replace(substr(quote_name, instr(quote_name, '.', 1, 1) + 1), '.', '/') string_value
from rate_index
/
create or replace procedure sp_trunc_temp_tables
as
begin
execute immediate 'truncate table TRADE_FILTER_PAGE' ;
execute immediate 'truncate table TF_TEMP_TABLE' ;
end;
/
CREATE OR REPLACE PROCEDURE sp_analysis_out_permp (arg_id   IN NUMBER )
AS BEGIN
UPDATE analysis_output_perm_pages p1 
SET page_number = ( SELECT rnum FROM ( SELECT page_id, row_number() 
OVER (ORDER BY page_id) -1 rnum 
FROM analysis_output_perm_pages 
WHERE id = arg_id AND page_number<>-1) 
p2 WHERE p1.page_id = p2.page_id ) 
where p1.id = arg_id AND p1.page_number <> -1;
END;
/
CREATE OR REPLACE PROCEDURE SP_INSERT_OFFICIAL_PL_BUCKET
     ( 
        p_PL_BUCKET_ID        IN  OFFICIAL_PL_BUCKET.PL_BUCKET_ID%TYPE,                
        p_LEG                 IN  OFFICIAL_PL_BUCKET.LEG%TYPE,                  
        p_LOCATION            IN  OFFICIAL_PL_BUCKET.LOCATION%TYPE, 
        p_STRIP_DATE          IN  OFFICIAL_PL_BUCKET.STRIP_DATE%TYPE, 
        p_SUBPRODUCT_ID       IN  OFFICIAL_PL_BUCKET.SUBPRODUCT_ID%TYPE, 
        p_SUBPRODUCT_TYPE     IN  OFFICIAL_PL_BUCKET.SUBPRODUCT_TYPE%TYPE,                
        p_SUBPRODUCT_SUB_TYPE IN  OFFICIAL_PL_BUCKET.SUBPRODUCT_SUB_TYPE%TYPE,                
        p_SUBPRODUCT_EXTENDED_TYPE IN  OFFICIAL_PL_BUCKET.SUBPRODUCT_EXTENDED_TYPE%TYPE,
        p_EXISTING_PL_BUCKET_ID OUT OFFICIAL_PL_BUCKET.PL_BUCKET_ID%TYPE
     )
AS 
BEGIN  
	
	INSERT INTO OFFICIAL_PL_BUCKET 
		(PL_BUCKET_ID,LEG,LOCATION,STRIP_DATE,
		SUBPRODUCT_ID,SUBPRODUCT_TYPE,SUBPRODUCT_SUB_TYPE,SUBPRODUCT_EXTENDED_TYPE) 
	VALUES 
		(p_PL_BUCKET_ID,p_LEG,p_LOCATION,p_STRIP_DATE,
		p_SUBPRODUCT_ID,p_SUBPRODUCT_TYPE,p_SUBPRODUCT_SUB_TYPE,p_SUBPRODUCT_EXTENDED_TYPE) ;
	
	COMMIT;
	
	p_EXISTING_PL_BUCKET_ID := p_PL_BUCKET_ID;
	RETURN;
	
EXCEPTION 
        WHEN DUP_VAL_ON_INDEX THEN
			SELECT  
			      PL_BUCKET_ID
			INTO
			      p_EXISTING_PL_BUCKET_ID
			FROM   	OFFICIAL_PL_BUCKET
			WHERE (LEG = p_LEG OR ((LEG IS NULL) AND (p_LEG IS NULL)))
			AND		(LOCATION = p_LOCATION OR ((LOCATION IS NULL) AND (p_LOCATION IS NULL)))
			AND		(STRIP_DATE = p_STRIP_DATE OR ((STRIP_DATE IS NULL) AND (p_STRIP_DATE IS NULL)))
			AND		(SUBPRODUCT_ID = p_SUBPRODUCT_ID OR ((SUBPRODUCT_ID IS NULL) AND (p_SUBPRODUCT_ID IS NULL)))
			AND		(SUBPRODUCT_TYPE = p_SUBPRODUCT_TYPE OR ((SUBPRODUCT_TYPE IS NULL) AND (p_SUBPRODUCT_TYPE IS NULL)))
			AND		(SUBPRODUCT_SUB_TYPE = p_SUBPRODUCT_SUB_TYPE OR ((SUBPRODUCT_SUB_TYPE IS NULL) AND (p_SUBPRODUCT_SUB_TYPE IS NULL)))
			AND		(SUBPRODUCT_EXTENDED_TYPE = p_SUBPRODUCT_EXTENDED_TYPE OR ((SUBPRODUCT_EXTENDED_TYPE IS NULL) AND (p_SUBPRODUCT_EXTENDED_TYPE IS NULL)));
  
			RETURN;
        WHEN OTHERS THEN
             RAISE_APPLICATION_ERROR (-20001, 
                                     'Error while inserting new plBucket.  PL_BUCKET_ID=' 
                                     || p_PL_BUCKET_ID || ':$:' || SQLERRM, TRUE) ; 
END SP_INSERT_OFFICIAL_PL_BUCKET ;
/
CREATE OR REPLACE PROCEDURE SP_INSERT_OFFICIAL_PL_UNIT
     ( 
        p_PL_UNIT_ID          IN  OFFICIAL_PL_UNIT.PL_UNIT_ID%TYPE,                
        p_BOOK_ID             IN  OFFICIAL_PL_UNIT.BOOK_ID%TYPE,                  
        p_STRATEGY            IN  OFFICIAL_PL_UNIT.STRATEGY%TYPE, 
        p_TRADER              IN  OFFICIAL_PL_UNIT.TRADER%TYPE, 
        p_DESK                IN  OFFICIAL_PL_UNIT.DESK%TYPE, 
        p_CURRENCY            IN  OFFICIAL_PL_UNIT.CURRENCY%TYPE,                
        p_CURRENCY_PAIR       IN  OFFICIAL_PL_UNIT.CURRENCY_PAIR%TYPE,                
        p_PO_ID               IN  OFFICIAL_PL_UNIT.PO_ID%TYPE,                
        p_IS_BY_TRADE         IN  OFFICIAL_PL_UNIT.IS_BY_TRADE%TYPE,
        p_EXISTING_PL_UNIT_ID OUT OFFICIAL_PL_UNIT.PL_UNIT_ID%TYPE
     )
AS 
BEGIN  
	
	INSERT INTO OFFICIAL_PL_UNIT 
		(PL_UNIT_ID,BOOK_ID,STRATEGY,TRADER,DESK,
		CURRENCY,CURRENCY_PAIR,PO_ID,IS_BY_TRADE) 
	VALUES 
		(p_PL_UNIT_ID,p_BOOK_ID,p_STRATEGY,p_TRADER,p_DESK,
		p_CURRENCY,p_CURRENCY_PAIR,p_PO_ID,p_IS_BY_TRADE);
	
	COMMIT;
	
	p_EXISTING_PL_UNIT_ID := p_PL_UNIT_ID;
	RETURN ;
EXCEPTION 
        WHEN DUP_VAL_ON_INDEX THEN
          SELECT  
              PL_UNIT_ID
          INTO
                p_EXISTING_PL_UNIT_ID
          FROM   	OFFICIAL_PL_UNIT
          WHERE 	(BOOK_ID = p_BOOK_ID OR ((BOOK_ID IS NULL) AND (p_BOOK_ID IS NULL)))
          AND		(STRATEGY = p_STRATEGY OR ((STRATEGY IS NULL) AND (p_STRATEGY IS NULL)))
          AND		(TRADER = p_TRADER OR ((TRADER IS NULL) AND (p_TRADER IS NULL)))
          AND		(DESK = p_DESK OR ((DESK IS NULL) AND (p_DESK IS NULL)))
          AND  		CURRENCY = p_CURRENCY
          AND		(CURRENCY_PAIR = p_CURRENCY_PAIR OR ((CURRENCY_PAIR IS NULL) AND (p_CURRENCY_PAIR IS NULL)))
          AND		PO_ID = p_PO_ID
          AND		IS_BY_TRADE = p_IS_BY_TRADE;
          
          RETURN;
        WHEN OTHERS THEN
             RAISE_APPLICATION_ERROR (-20001, 
                                     'Error while inserting new plUnit.  PL_UNIT_ID=' 
                                     || p_PL_UNIT_ID || ':$:' || SQLERRM, TRUE) ; 
END SP_INSERT_OFFICIAL_PL_UNIT ;
/
CREATE OR REPLACE PROCEDURE SP_INS_OFFICIAL_PL_AGGREGATE
     ( 
        p_AGG_ID              IN  OFFICIAL_PL_AGGREGATE.AGG_ID%TYPE,                
        p_PL_CONFIG_ID        IN  OFFICIAL_PL_AGGREGATE.PL_CONFIG_ID%TYPE, 
        p_BOOK_ID             IN  OFFICIAL_PL_AGGREGATE.BOOK_ID%TYPE,                  
        p_PL_UNIT_ID          IN  OFFICIAL_PL_AGGREGATE.PL_UNIT_ID%TYPE, 
        p_ACTION_DATETIME     IN  OFFICIAL_PL_AGGREGATE.ACTION_DATETIME%TYPE, 
        p_EFFECTIVE_PRODUCT_TYPE  IN  OFFICIAL_PL_AGGREGATE.EFFECTIVE_PRODUCT_TYPE%TYPE,
        p_STRATEGY_ID         IN  OFFICIAL_PL_AGGREGATE.STRATEGY_ID%TYPE, 
        p_EXISTING_AGG_ID OUT OFFICIAL_PL_AGGREGATE.AGG_ID%TYPE
     )
AS 
BEGIN  
	
	INSERT INTO OFFICIAL_PL_AGGREGATE 
		(AGG_ID,PL_CONFIG_ID,BOOK_ID,PL_UNIT_ID,ACTION_DATETIME,
		EFFECTIVE_PRODUCT_TYPE,STRATEGY_ID) 
	VALUES 
		(p_AGG_ID,p_PL_CONFIG_ID,p_BOOK_ID,p_PL_UNIT_ID,p_ACTION_DATETIME,
		p_EFFECTIVE_PRODUCT_TYPE,p_STRATEGY_ID);
	
	COMMIT;
	
	p_EXISTING_AGG_ID := p_AGG_ID;
	RETURN ;
EXCEPTION 
        WHEN DUP_VAL_ON_INDEX THEN
          SELECT  
              AGG_ID
          INTO
                p_EXISTING_AGG_ID
          FROM   	OFFICIAL_PL_AGGREGATE
          WHERE PL_CONFIG_ID = p_PL_CONFIG_ID 	
          AND		BOOK_ID = p_BOOK_ID
          AND		PL_UNIT_ID = p_PL_UNIT_ID
          AND  	EFFECTIVE_PRODUCT_TYPE = p_EFFECTIVE_PRODUCT_TYPE
          AND	STRATEGY_ID = p_STRATEGY_ID;
          
          RETURN;
        WHEN OTHERS THEN
             RAISE_APPLICATION_ERROR (-20001, 
                                     'Error while inserting new opl aggregate.  AGG_ID=' 
                                     || p_AGG_ID || ':$:' || SQLERRM, TRUE) ; 
END SP_INS_OFFICIAL_PL_AGGREGATE ;
/
/* add all new stored procs above this line. The following will compile all invalid objects */

DECLARE
begin
  FOR c1_rec IN (SELECT 'ALTER ' || decode(a.object_type,   'PACKAGE BODY',   'PACKAGE',   'TYPE BODY',   'TYPE', a.object_type) 
  || ' ' || a.object_name || decode(a.object_type,   'JAVA CLASS',   ' RESOLVE',   ' COMPILE') 
  || decode(a.object_type, 'PACKAGE BODY',' BODY', 'TYPE BODY','BODY') FullSql
          FROM user_objects a,(SELECT MAX(LEVEL) mylevel, object_id
             FROM public_dependency START WITH object_id IN
				(SELECT object_id FROM user_objects WHERE status = 'INVALID' and    object_type <> 'SYNONYM' )
				CONNECT BY object_id = PRIOR referenced_object_id
				GROUP BY object_id)b
			WHERE a.object_id = b.object_id(+) 
			AND a.status = 'INVALID'
			AND object_type <> 'SYNONYM' ORDER BY b.mylevel DESC,a.object_name ASC )
  LOOP
  begin
    execute immediate c1_rec.FullSql;
    exception
		when others then
					null;
  end;    
  end LOOP;
end;
/
begin
   execute immediate 'drop procedure sp_mcc_housekeeping';
exception when others then
   if sqlcode != -4043 then
      raise;
   end if;
end;
/

/* Applying Stored Procedures - end */