    ALTER TABLE CALYPSO_INFO MODIFY (MAJOR_VERSION numeric,MINOR_VERSION numeric,SUB_VERSION numeric)
/

    delete 
    FROM
        calypso_info
/

    INSERT 
    INTO
        calypso_info
        ( major_version, minor_version, patch_version, ref_time_zone, sub_version, version_date ) 
    VALUES
        (16,1,'53','GMT',0,TIMESTAMP'2020-08-07 00:00:00.0' )
/

    UPDATE
        calypso_info 
    SET
        ref_time_zone = 'GMT'
/