--Eliminar las Additional Legal Entities 1SEN (id 97955) de todos los contratos
DELETE FROM mrgcall_config_le WHERE le_id=97955;