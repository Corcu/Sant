DELETE FROM USER_MAX_PERM_ATTR where USER_NAME <> 'calypso_user' and USER_NAME <> 'admin' and TYPE = 'Max.BOAudit';
commit;
insert into USER_MAX_PERM_ATTR (user_name, type, value) select distinct USER_NAME, 'Max.BOAudit' as TYPE, 100000 as VALUE from user_name where user_name <> 'calypso_user' and user_name <> 'admin';