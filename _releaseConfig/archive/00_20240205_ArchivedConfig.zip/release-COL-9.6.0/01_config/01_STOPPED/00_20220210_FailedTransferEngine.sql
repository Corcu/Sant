delete from domain_values where name = 'eventClass' and value='PSEventResetCustomBOCache';
Insert into DOMAIN_VALUES (NAME,VALUE,DESCRIPTION) values ('eventClass','PSEventResetCustomBOCache','Type of custom event to reset Custom BOCache');

DELETE FROM PS_EVENT_CONFIG WHERE ENGINE_NAME='FailedTransferEngine';
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventTrade','FailedTransferEngine');
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventTransfer','FailedTransferEngine');
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventMessage','FailedTransferEngine');
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventInventorySecPosition','FailedTransferEngine');
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventResetCustomBOCache','FailedTransferEngine');
