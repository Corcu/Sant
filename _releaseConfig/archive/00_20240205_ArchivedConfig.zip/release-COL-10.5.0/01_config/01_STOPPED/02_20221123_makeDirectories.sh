#!/bin/sh

$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="lago/mtm/CO2"
$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="lago/mtm/rv"
