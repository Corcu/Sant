INSERT INTO PS_EVENT_FILTER (EVENT_CONFIG_NAME,ENGINE_NAME,EVENT_FILTER) VALUES ('Back-Office','TransferEngine','SantExcludeEquityTradeStatusEventFilter')
/
INSERT INTO PS_EVENT_FILTER (EVENT_CONFIG_NAME,ENGINE_NAME,EVENT_FILTER) VALUES ('Back-Office','LiquidationEngine','SantExcludeEquityStatusEventFilter')
/
INSERT INTO PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventLiquidatedPosition','CreEngine')
/
INSERT INTO PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventPositionReclassification','CreEngine')
/
INSERT INTO PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventUnliquidatedPosition','CreEngine')
/
ALTER TABLE TASK_ENRICHMENT ADD product_type varchar2 (255)  NULL
/
ALTER TABLE TASK_ENRICHMENT_HIST ADD product_type varchar2 (255)  NULL
/
INSERT INTO task_enrichment_field_config (field_display_name,field_db_name,data_source_class_name,workflow_type,data_source_getter_name,db_type,db_scale,field_domain_finder) VALUES
('Product Type','product_type','com.calypso.tk.core.Trade','Trade','getProductType','string','255','DomainValueDomain|productType')
/