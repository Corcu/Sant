ALTER TABLE TASK_ENRICHMENT ADD msg_template_name varchar2 (255)  NULL
/
ALTER TABLE TASK_ENRICHMENT_HIST ADD msg_template_name varchar2 (255)  NULL
/

INSERT INTO task_enrichment_field_config (field_display_name,field_db_name,data_source_class_name,workflow_type,data_source_getter_name,db_type,db_scale) VALUES
('Msg Template Name','msg_template_name','com.calypso.tk.bo.BOMessage','Message','getTemplateName','string','64')
/
