#!/bin/sh

$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="bond/mtm"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="bond/reports/export/processed"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="ecms/export/processed"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="ecms/import/processed"