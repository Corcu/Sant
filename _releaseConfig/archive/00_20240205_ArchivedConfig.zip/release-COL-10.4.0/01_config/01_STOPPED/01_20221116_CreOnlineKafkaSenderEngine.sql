DELETE FROM CALYPSO.ENGINE_CONFIG WHERE ENGINE_NAME='CreOnlineKafkaSenderEngine';
Insert into CALYPSO.ENGINE_CONFIG (ENGINE_ID,ENGINE_NAME,ENGINE_COMMENT,VERSION_NUM) values ((select max(ENGINE_ID)+1 from CALYPSO.ENGINE_CONFIG),'CreOnlineKafkaSenderEngine','Starts and stops CreOnlineKafkaSenderEngine','500');

-- Cargando engine params
DELETE FROM ENGINE_PARAM WHERE ENGINE_NAME='CreOnlineKafkaSenderEngine';
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('CreOnlineKafkaSenderEngine','DISPLAY_NAME','CreOnlineKafkaSenderEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('CreOnlineKafkaSenderEngine','CLASS_NAME','calypsox.engine.accounting.CreOnlineKafkaSenderEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('CreOnlineKafkaSenderEngine','STARTUP','true');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('CreOnlineKafkaSenderEngine','INSTANCE_NAME','GEN_engineserver');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('CreOnlineKafkaSenderEngine','config','mickafka.connection.properties');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('CreOnlineKafkaSenderEngine','REVERSAL_CRE','Y');

DELETE FROM PS_EVENT_CONFIG WHERE ENGINE_NAME='CreOnlineKafkaSenderEngine';
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventCre','CreOnlineKafkaSenderEngine');

DELETE FROM PS_EVENT_FILTER WHERE ENGINE_NAME='CreOnlineKafkaSenderEngine';
Insert into CALYPSO.PS_EVENT_FILTER (EVENT_CONFIG_NAME,ENGINE_NAME,EVENT_FILTER) values ('Back-Office','CreOnlineSenderEngine','BlockBOCreKafkaEventFilter');
Insert into CALYPSO.PS_EVENT_FILTER (EVENT_CONFIG_NAME,ENGINE_NAME,EVENT_FILTER) values ('Back-Office','CreOnlineKafkaSenderEngine','BlockBOCreKafkaEventFilter');
Insert into CALYPSO.PS_EVENT_FILTER (EVENT_CONFIG_NAME,ENGINE_NAME,EVENT_FILTER) values ('Back-Office','CreOnlineKafkaSenderEngine','SantCREsAccountingEventFilter');

