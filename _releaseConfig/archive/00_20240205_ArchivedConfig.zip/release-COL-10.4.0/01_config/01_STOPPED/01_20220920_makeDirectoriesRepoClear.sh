#!/bin/sh

$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="repoclear/lchltd/madrid"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="repoclear/lchltd/slb"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="repoclear/lchsa"
