#!/bin/sh

##########################################################################################################
##
## DESCRIPTION
## ------------------
## Scritp to create folders and subfolders
##
## USAGE
## ------------------
## PARAMS
##
## EXAMPLE
##
## MODIFICATIONS
## ------------------
## USER         DATE            DESCRIPTION
## x280846      03-07-2019      Create interfaces directories
##
##########################################################################################################

function getArgs (){

    echo "Parsing args:"
    #echo "$@"

    for ARGUMENT in "$@"
    do
        KEY=$(echo $ARGUMENT | cut -f1 -d=)
        VALUE=$(echo $ARGUMENT | cut -f2 -d=)

        case "$KEY" in
                --system)       SYSTEM=${VALUE} ;;
                --environ)      ENV_NAME=${VALUE} ;;
                *)              echo "[WARN-`date +"%Y%m%d-%T"`] Invalid or unused param ${KEY}" ;;
        esac
    done

    echo "[INFO-`date +"%Y%m%d-%T"`] --system ${SYSTEM}"
    echo "[INFO-`date +"%Y%m%d-%T"`] --environ ${ENV_NAME}"

}

#MAIN
getArgs "$@"

export BUILDANDFILTER_DIR="${OCD_HOME}/buildConfigurationManagement/src/main/config/${SYSTEM}/${ENV_NAME}"
export BUILDANDFILTER_FILE="${BUILDANDFILTER_DIR}/buildAndFilter.properties"
SERVICE_STRING="SCH_SERVER_HOST"

STRING_TO_FIND=`echo ${SERVICE_STRING:0:3} | tr '[:lower:]' '[:upper:]'`
HOST_NAME=`cat ${BUILDANDFILTER_FILE} | grep -i ${STRING_TO_FIND} | grep SERVER_HOST | grep -v "#" | cut -d '=' -f2 | cut -d '.' -f1`

if [ "${HOST_NAME}" == "" ]
	then
		echo "[ERROR-`date +"%Y%m%d-%T"`] Not host found for ${SERVICE_STRING} in calypso@${HOSTNAME}:${BUILDANDFILTER_FILE}"
	else
		echo "[INFO-`date +"%Y%m%d-%T"`] Creating dirs in calypso@${HOST_NAME}"
	fi


ssh calypso@${HOST_NAME} "cd /calypso_interfaces;
mkdir -pv pdv/mis/;
mkdir -pv pdv/mis/export/;
mkdir -pv pdv/mis/export/processed/"


