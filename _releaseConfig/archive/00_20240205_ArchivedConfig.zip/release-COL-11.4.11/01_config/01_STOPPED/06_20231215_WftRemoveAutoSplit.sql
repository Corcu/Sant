DELETE FROM wfw_rule_additional_info
WHERE
    workflow_id IN (
        SELECT
            workflow_id
        FROM
            wfw_transition
        WHERE
                event_class = 'PSEventTransfer'
            AND status = 'VERIFIED'
            AND possible_action = 'AUTO_SPLIT'
            AND resulting_status = 'TO_BE_SPLIT'
            AND product_type IN (
                'Repo',
                'G.Bonds',
                'ALL'
            )
    );

DELETE FROM wfw_rule_additional_info
WHERE
    workflow_id IN (
        SELECT
            workflow_id
        FROM
            wfw_transition
        WHERE
                event_class = 'PSEventTransfer'
            AND status = 'TO_BE_SPLIT'
            AND possible_action = 'SPLIT'
            AND resulting_status = 'SPLIT'
            AND product_type IN (
                'Repo',
                'G.Bonds',
                'ALL'
            )
    );

DELETE FROM bo_workflow_rule
WHERE
    id IN (
        SELECT
            workflow_id
        FROM
            wfw_transition
        WHERE
                event_class = 'PSEventTransfer'
            AND status = 'VERIFIED'
            AND possible_action = 'AUTO_SPLIT'
            AND resulting_status = 'TO_BE_SPLIT'
            AND product_type IN (
                'Repo',
                'G.Bonds',
                'ALL'
            )
    );

DELETE FROM bo_workflow_rule
WHERE
    id IN (
        SELECT
            workflow_id
        FROM
            wfw_transition
        WHERE
                event_class = 'PSEventTransfer'
            AND status = 'TO_BE_SPLIT'
            AND possible_action = 'SPLIT'
            AND resulting_status = 'SPLIT'
            AND product_type IN (
                'Repo',
                'G.Bonds',
                'ALL'
            )
    );

DELETE FROM wfw_transition
WHERE
        event_class = 'PSEventTransfer'
    AND status = 'VERIFIED'
    AND possible_action = 'AUTO_SPLIT'
    AND resulting_status = 'TO_BE_SPLIT'
    AND product_type IN (
        'Repo',
        'G.Bonds',
        'ALL'
    );

DELETE FROM wfw_transition
WHERE
        event_class = 'PSEventTransfer'
    AND status = 'TO_BE_SPLIT'
    AND possible_action = 'SPLIT'
    AND resulting_status = 'SPLIT'
    AND product_type IN (
        'Repo',
        'G.Bonds',
        'ALL'
    );

COMMIT;
