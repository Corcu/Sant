$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="lago/import/merge"
$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="swapone/import"
$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="swapone/import/ok"
