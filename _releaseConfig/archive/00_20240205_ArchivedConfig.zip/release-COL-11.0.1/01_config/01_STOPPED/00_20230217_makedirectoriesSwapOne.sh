$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="swapone/export"
$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="swapone/export/processed"