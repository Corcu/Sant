$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="disponible/reports/export"
$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="disponible/mic/export"
$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="disponible/mis/export"