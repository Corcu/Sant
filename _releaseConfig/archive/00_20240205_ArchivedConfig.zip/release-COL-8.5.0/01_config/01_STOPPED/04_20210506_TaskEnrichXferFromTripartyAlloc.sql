ALTER TABLE TASK_ENRICHMENT ADD Xfer_From_Triparty_Allocation varchar2 (128)  NULL
/
ALTER TABLE TASK_ENRICHMENT_HIST ADD Xfer_From_Triparty_Allocation varchar2 (128)  NULL
/
INSERT INTO TASK_ENRICHMENT_FIELD_CONFIG (DATA_SOURCE_CLASS_NAME,DATA_SOURCE_GETTER_NAME,FIELD_DISPLAY_NAME,FIELD_DB_NAME,WORKFLOW_TYPE,EXTRA_ARGUMENTS,CUSTOM_CLASS_NAME,FIELD_DOMAIN_FINDER,FIELD_SOURCE,FIELD_CONVERSION_CLASS,LINK_DB_NAME,SQL_EXPRESSION,DB_TYPE,DB_SCALE) VALUES 
('com.calypso.tk.bo.BOTransfer','getTransferFromTripartyAllocationKwd','Xfer From Triparty Allocation','xfer_from_triparty_allocation','Transfer',null,'calypsox.util.TaskEnrichment',null,null,null,null,null,'string','128');
/
COMMIT
/