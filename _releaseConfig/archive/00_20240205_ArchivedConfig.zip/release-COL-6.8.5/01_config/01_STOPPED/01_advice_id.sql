UPDATE advice_document 
set advice_id = -1
where advice_id  = 0;