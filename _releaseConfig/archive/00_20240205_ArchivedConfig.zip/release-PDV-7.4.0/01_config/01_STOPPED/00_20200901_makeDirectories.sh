#!/bin/sh

$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="repo"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="repo/mis"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="repo/mis/export"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="repo/mis/export/processed"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="repo/mtm"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="repo/mtm/ok"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="repo/mtm/fail"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="repo/alm"