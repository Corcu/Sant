ALTER TABLE TASK_ENRICHMENT ADD Counterparty varchar2(128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD Counterparty varchar(128);

DELETE FROM task_enrichment_field_config where field_display_name = 'Counterparty';
INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale, extra_arguments)
	VALUES ('Counterparty', 'Counterparty', null, 'com.calypso.tk.bo.BOMessage', 'Message', 'getAttribute', null, 'string', '128', 'Counterparty');
	
ALTER TABLE TASK_ENRICHMENT ADD MSG_ISIN varchar2(128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD MSG_ISIN varchar2(128);

DELETE FROM task_enrichment_field_config where field_display_name = 'MSG_ISIN';
INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale, extra_arguments)
	VALUES ('MSG_ISIN', 'MSG_ISIN', null, 'com.calypso.tk.bo.BOMessage', 'Message', 'getAttribute', null, 'string', '128', 'ISIN');
	
ALTER TABLE TASK_ENRICHMENT ADD Msg_trade_date varchar2(128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD Msg_trade_date varchar2(128);

DELETE FROM task_enrichment_field_config where field_display_name = 'Msg trade date';
INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale, extra_arguments)
	VALUES ('Msg trade date', 'Msg_trade_date', null, 'com.calypso.tk.bo.BOMessage', 'Message', 'getAttribute', null, 'string', '128', 'TradeDate');
	
ALTER TABLE TASK_ENRICHMENT ADD Msg_settle_date varchar2(128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD Msg_settle_date varchar2(128);

DELETE FROM task_enrichment_field_config where field_display_name = 'Msg Settle date';
INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale, extra_arguments)
	VALUES ('Msg Settle date', 'Msg_settle_date', null, 'com.calypso.tk.bo.BOMessage', 'Message', 'getAttribute', null, 'string', '128', 'SettleDate');
	
ALTER TABLE TASK_ENRICHMENT ADD Mess_BlockTradeDetail varchar2(128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD Mess_BlockTradeDetail varchar2(128);

DELETE FROM task_enrichment_field_config where field_display_name = 'Mess_BlockTradeDetail';
INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale, extra_arguments)
	VALUES ('Mess_BlockTradeDetail', 'Mess_BlockTradeDetail', null, 'com.calypso.tk.bo.BOMessage', 'Message', 'getAttribute', null, 'string', '128', 'BlockTradeDetail');
	
ALTER TABLE TASK_ENRICHMENT ADD Mess_GLCSBlockTrade varchar2(128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD Mess_GLCSBlockTrade varchar2(128);

DELETE FROM task_enrichment_field_config where field_display_name = 'Mess_GLCSBlockTrade';
INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale, extra_arguments)
	VALUES ('Mess_GLCSBlockTrade', 'Mess_GLCSBlockTrade', null, 'com.calypso.tk.bo.BOMessage', 'Message', 'getAttribute', null, 'string', '128', 'GLCSBlockTrade');
	
ALTER TABLE TASK_ENRICHMENT ADD MessageSource varchar2(128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD MessageSource varchar2(128);

DELETE FROM task_enrichment_field_config where field_display_name = 'MessageSource';
INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale, extra_arguments)
	VALUES ('MessageSource', 'MessageSource', null, 'com.calypso.tk.bo.BOMessage', 'Message', 'getGateway', null, 'string', '128', null);
	
ALTER TABLE TASK_ENRICHMENT ADD Trade_BlockTradeDetail varchar2(128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD Trade_BlockTradeDetail varchar2(128);

DELETE FROM task_enrichment_field_config where field_display_name = 'Trade_BlockTradeDetail';
INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale, extra_arguments)
	VALUES ('Trade_BlockTradeDetail', 'Trade_BlockTradeDetail', null, 'com.calypso.tk.core.Trade', 'Trade', 'getKeywordValue', null, 'string', '128', 'BlockTradeDetail');
	
ALTER TABLE TASK_ENRICHMENT ADD Trade_GLCSBlockTrade varchar2(128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD Trade_GLCSBlockTrade varchar2(128);

DELETE FROM task_enrichment_field_config where field_display_name = 'Trade_GLCSBlockTrade';
INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale, extra_arguments)
	VALUES ('Trade_GLCSBlockTrade', 'Trade_GLCSBlockTrade', null, 'com.calypso.tk.core.Trade', 'Trade', 'getKeywordValue', null, 'string', '128', 'GLCSBlockTrade');
	
ALTER TABLE TASK_ENRICHMENT ADD GESTORA_PREMIUM varchar2(128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD GESTORA_PREMIUM varchar2(128);

DELETE FROM task_enrichment_field_config where field_display_name = 'GESTORA_PREMIUM';
INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale, extra_arguments)
	VALUES ('GESTORA_PREMIUM', 'GESTORA_PREMIUM', null, 'com.calypso.tk.core.Trade', 'Trade', 'getLEAttributeBool', 'calypsox.util.TaskEnrichment', 'string', '128', 'GESTORA_PREMIUM');
	
ALTER TABLE TASK_ENRICHMENT ADD GESTORA_PREAUTORIZADA varchar2(128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD GESTORA_PREAUTORIZADA varchar2(128);

DELETE FROM task_enrichment_field_config where field_display_name = 'GESTORA_PREAUTORIZADA';
INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale, extra_arguments)
	VALUES ('GESTORA_PREAUTORIZADA', 'GESTORA_PREAUTORIZADA', null, 'com.calypso.tk.core.Trade', 'Trade', 'getLEAttributeBool', 'calypsox.util.TaskEnrichment', 'string', '128', 'GESTORA_PREAUTORIZADA');