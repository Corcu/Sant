DELETE FROM ENGINE_CONFIG WHERE ENGINE_NAME='LiquidationEngine';
Insert into ENGINE_CONFIG (ENGINE_ID,ENGINE_NAME,ENGINE_COMMENT,VERSION_NUM) values ((select max(ENGINE_ID)+1 from ENGINE_CONFIG),'LiquidationEngine',null,'722');

DELETE FROM ENGINE_PARAM WHERE ENGINE_NAME='LiquidationEngine';
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('LiquidationEngine','PricingEnv','DirtyPrice');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('LiquidationEngine','CLASS_NAME','com.calypso.engine.position.LiquidationEngine');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('LiquidationEngine','STARTUP','true');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('LiquidationEngine','INSTANCE_NAME','gen_engineserver');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('LiquidationEngine','DISPLAY_NAME','LiquidationEngine');


DELETE FROM PS_EVENT_CONFIG WHERE ENGINE_NAME='LiquidationEngine';
Insert into PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) values ('Back-Office','PSEventTrade','LiquidationEngine');
Insert into PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) values ('Back-Office','PSEventProcessTrade','LiquidationEngine');