#!/bin/sh

$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="rv"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="rv/broker"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="rv/broker/import"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="rv/broker/import/ok"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="rv/broker/import/fail"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="rv/mis"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="rv/mis/export"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="rv/mis/export/processed"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="rv/mtm"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="rv/mtm/ok"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="rv/mtm/fail"