ALTER TABLE TASK_ENRICHMENT ADD msg_function varchar2 (255)  NULL;

ALTER TABLE TASK_ENRICHMENT_HIST ADD msg_function varchar2 (255)  NULL;


INSERT INTO task_enrichment_field_config (field_display_name,field_db_name,data_source_class_name,workflow_type,data_source_getter_name,extra_arguments,db_type,db_scale) VALUES
('Msg Function','msg_function','com.calypso.tk.bo.BOMessage','Message','getAttribute','Message_Function','string','255');
