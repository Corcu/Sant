Delete FROM  triparty_allocation_records WHERE triparty_allocation_records.pledge_id = 46794929;
Delete FROM  triparty_allocation_attributes WHERE entity_id = 46794929;
Delete FROM  TRIPARTY_ALLOC_ATTRIBUTES_HIST WHERE entity_id = 46794929;