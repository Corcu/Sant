#!/bin/sh

$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="bond"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="bond/mis"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="bond/mis/export"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="bond/mis/export/processed"
