DELETE FROM CALYPSO.ENGINE_CONFIG WHERE ENGINE_NAME='PledgeDataExportEngine';
Insert into CALYPSO.ENGINE_CONFIG (ENGINE_ID,ENGINE_NAME,ENGINE_COMMENT,VERSION_NUM) values ((select max(ENGINE_ID)+1 from CALYPSO.ENGINE_CONFIG),'PledgeDataExportEngine','Starts and stops PledgeDataExportEngine','500');

-- Cargando engine params
DELETE FROM ENGINE_PARAM WHERE ENGINE_NAME='PledgeDataExportEngine';
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('PledgeDataExportEngine','DISPLAY_NAME','PledgeDataExportEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('PledgeDataExportEngine','CLASS_NAME','calypsox.engine.PledgeExportEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('PledgeDataExportEngine','STARTUP','true');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('PledgeDataExportEngine','INSTANCE_NAME','IMP_engineserver');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('PledgeDataExportEngine','EVENT_POOL_POLICY','FIFO');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('PledgeDataExportEngine','PricingEnv','OFFICIAL');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('PledgeDataExportEngine','config','pledgeexporter.properties');

DELETE FROM PS_EVENT_CONFIG WHERE ENGINE_NAME='PledgeDataExportEngine';
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventDataUploaderAck','PledgeDataExportEngine');
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventMessage','PledgeDataExportEngine');

DELETE FROM PS_EVENT_FILTER WHERE ENGINE_NAME='PledgeDataExportEngine';
Insert into CALYPSO.PS_EVENT_FILTER (EVENT_CONFIG_NAME,ENGINE_NAME,EVENT_FILTER) values ('Back-Office','PledgeDataExportEngine','PledgeDataExporterAckEngineEventFilter');