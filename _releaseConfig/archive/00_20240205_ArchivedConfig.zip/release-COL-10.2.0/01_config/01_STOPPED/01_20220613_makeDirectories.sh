#!/bin/sh

$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="csdr/six/import/processed"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="csdr/six/export/sent"
