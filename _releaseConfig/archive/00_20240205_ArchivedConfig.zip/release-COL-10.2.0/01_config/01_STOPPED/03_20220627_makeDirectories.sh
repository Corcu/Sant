#!/bin/sh

$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="bond"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="bond/extracontable"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="bond/extracontable/export"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="bond/extracontable/export/processed"
