DECLARE
  PROCEDURE CUSTOM_SGT_DROP_IF_EXISTS(p_tablename VARCHAR, p_columnName VARCHAR)
  IS
  BEGIN
      EXECUTE IMMEDIATE 'Alter table '||p_tableName||' DROP COLUMN '||p_columnName;
      DBMS_Output.Put_Line(' table dropped');
  EXCEPTION WHEN OTHERS THEN
      IF SQLCODE = -942 THEN
          DBMS_Output.Put_Line(' table not exists');
      ELSE
          DBMS_Output.Put_Line(' Unknown exception while dropping table');
      END IF;
  END;



BEGIN
  CUSTOM_SGT_DROP_IF_EXISTS('TASK_ENRICHMENT', 'msg_process_issue');
  CUSTOM_SGT_DROP_IF_EXISTS('TASK_ENRICHMENT_HIST', 'msg_process_issue');
  delete from task_enrichment_field_config where field_db_name = 'msg_process_issue';
  
  CUSTOM_SGT_DROP_IF_EXISTS('TASK_ENRICHMENT', 'msg_template_name');
  CUSTOM_SGT_DROP_IF_EXISTS('TASK_ENRICHMENT_HIST', 'msg_template_name');
  delete from task_enrichment_field_config where field_db_name = 'msg_template_name';
  
  CUSTOM_SGT_DROP_IF_EXISTS('TASK_ENRICHMENT', 'swift_event_code');
  CUSTOM_SGT_DROP_IF_EXISTS('TASK_ENRICHMENT_HIST', 'swift_event_code');
  delete from task_enrichment_field_config where field_db_name = 'swift_event_code';
  
    CUSTOM_SGT_DROP_IF_EXISTS('TASK_ENRICHMENT', 'ca_reference');
  CUSTOM_SGT_DROP_IF_EXISTS('TASK_ENRICHMENT_HIST', 'ca_reference');
  delete from task_enrichment_field_config where field_db_name = 'ca_reference';
END;
/




--Insercion de columnas y datos
INSERT INTO TASK_ENRICHMENT_FIELD_CONFIG (DATA_SOURCE_CLASS_NAME,DATA_SOURCE_GETTER_NAME,FIELD_DISPLAY_NAME,FIELD_DB_NAME,WORKFLOW_TYPE,EXTRA_ARGUMENTS,CUSTOM_CLASS_NAME,FIELD_DOMAIN_FINDER,FIELD_SOURCE,FIELD_CONVERSION_CLASS,LINK_DB_NAME,SQL_EXPRESSION,DB_TYPE,DB_SCALE) VALUES ('com.calypso.tk.bo.BOMessage','getAttribute','Msg Process Issue','msg_process_issue','Message','Process Issue',null,null,null,null,null,null,'string','255');

ALTER TABLE TASK_ENRICHMENT ADD (msg_process_issue VARCHAR2(255));
ALTER TABLE TASK_ENRICHMENT_HIST ADD (msg_process_issue VARCHAR2(255));




INSERT INTO TASK_ENRICHMENT_FIELD_CONFIG (DATA_SOURCE_CLASS_NAME,DATA_SOURCE_GETTER_NAME,FIELD_DISPLAY_NAME,FIELD_DB_NAME,WORKFLOW_TYPE,EXTRA_ARGUMENTS,CUSTOM_CLASS_NAME,FIELD_DOMAIN_FINDER,FIELD_SOURCE,FIELD_CONVERSION_CLASS,LINK_DB_NAME,SQL_EXPRESSION,DB_TYPE,DB_SCALE) VALUES ('com.calypso.tk.bo.BOMessage','getTemplateName','Msg Template Name','msg_template_name','Message',null,null,null,null,null,null,null,'string','64');

ALTER TABLE TASK_ENRICHMENT ADD (msg_template_name VARCHAR2(64));
ALTER TABLE TASK_ENRICHMENT_HIST ADD (msg_template_name VARCHAR2(64));



INSERT INTO TASK_ENRICHMENT_FIELD_CONFIG (DATA_SOURCE_CLASS_NAME,DATA_SOURCE_GETTER_NAME,FIELD_DISPLAY_NAME,FIELD_DB_NAME,WORKFLOW_TYPE,EXTRA_ARGUMENTS,CUSTOM_CLASS_NAME,FIELD_DOMAIN_FINDER,FIELD_SOURCE,FIELD_CONVERSION_CLASS,LINK_DB_NAME,SQL_EXPRESSION,DB_TYPE,DB_SCALE) VALUES ('com.calypso.tk.bo.BOMessage','getAttribute','Swift Event Code','swift_event_code','Message','Swift_Event_Code',null,null,null,null,null,null,'string','255');

ALTER TABLE TASK_ENRICHMENT ADD (swift_event_code VARCHAR2(255));
ALTER TABLE TASK_ENRICHMENT_HIST ADD (swift_event_code VARCHAR2(255));



INSERT INTO TASK_ENRICHMENT_FIELD_CONFIG (DATA_SOURCE_CLASS_NAME,DATA_SOURCE_GETTER_NAME,FIELD_DISPLAY_NAME,FIELD_DB_NAME,WORKFLOW_TYPE,EXTRA_ARGUMENTS,CUSTOM_CLASS_NAME,FIELD_DOMAIN_FINDER,FIELD_SOURCE,FIELD_CONVERSION_CLASS,LINK_DB_NAME,SQL_EXPRESSION,DB_TYPE,DB_SCALE) VALUES ('com.calypso.tk.bo.BOMessage','getAttribute','CAReference','ca_reference','Message','CAReference',null,null,null,null,null,null,'string','64');

ALTER TABLE TASK_ENRICHMENT ADD (ca_reference VARCHAR2(64));
ALTER TABLE TASK_ENRICHMENT_HIST ADD (ca_reference VARCHAR2(64));

commit;