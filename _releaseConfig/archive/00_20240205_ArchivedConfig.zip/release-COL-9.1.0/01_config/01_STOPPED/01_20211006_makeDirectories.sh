#!/bin/sh

$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="triparty/atributos"
$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="ca/reports/export"