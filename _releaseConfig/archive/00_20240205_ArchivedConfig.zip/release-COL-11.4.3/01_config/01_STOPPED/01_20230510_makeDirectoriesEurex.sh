$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="repoclear/eurex"
$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="repoclear/eurex/backup"