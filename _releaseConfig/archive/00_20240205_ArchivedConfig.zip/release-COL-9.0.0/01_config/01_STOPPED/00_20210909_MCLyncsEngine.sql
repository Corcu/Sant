DELETE FROM ENGINE_CONFIG WHERE ENGINE_NAME='MCLyncsImportMessageEngine';
Insert into CALYPSO.ENGINE_CONFIG (ENGINE_ID,ENGINE_NAME,ENGINE_COMMENT,VERSION_NUM) values ((select max(ENGINE_ID)+1 from CALYPSO.ENGINE_CONFIG),'MCLyncsImportMessageEngine','Starts and stops MCLyncsImportMessageEngine','500');


DELETE FROM ENGINE_PARAM WHERE ENGINE_NAME='MCLyncsImportMessageEngine';
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MCLyncsImportMessageEngine','DISPLAY_NAME','MCLyncsImportMessageEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MCLyncsImportMessageEngine','CLASS_NAME','com.calypso.tk.engine.UploadImportMessageEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MCLyncsImportMessageEngine','STARTUP','true');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MCLyncsImportMessageEngine','INSTANCE_NAME','exp_engineserver');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MCLyncsImportMessageEngine','PricingEnv','OFFICIAL');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MCLyncsImportMessageEngine','config','MCLyncs');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MCLyncsImportMessageEngine','EVENT_POOL_POLICY','UploaderImportMessageEngine');

DELETE FROM PS_EVENT_CONFIG WHERE ENGINE_NAME='MCLyncsImportMessageEngine';
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventUpload','MCLyncsImportMessageEngine');


DELETE FROM PS_EVENT_FILTER WHERE ENGINE_NAME='MCLyncsImportMessageEngine';
Insert into CALYPSO.PS_EVENT_FILTER (EVENT_CONFIG_NAME,ENGINE_NAME,EVENT_FILTER) values ('Back-Office','MCLyncsImportMessageEngine','PSEventUploadMCLyncsEventFilter');


