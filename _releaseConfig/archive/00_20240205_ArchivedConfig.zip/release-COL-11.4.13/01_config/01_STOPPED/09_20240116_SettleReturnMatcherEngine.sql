DELETE FROM CALYPSO.ENGINE_CONFIG WHERE ENGINE_NAME = 'SettleReturnMatcherEngine';
DELETE FROM CALYPSO.ENGINE_PARAM WHERE  ENGINE_NAME = 'SettleReturnMatcherEngine';
DELETE FROM CALYPSO.PS_EVENT_FILTER WHERE  ENGINE_NAME = 'SettleReturnMatcherEngine';
DELETE FROM CALYPSO.PS_EVENT_CONFIG WHERE  ENGINE_NAME = 'SettleReturnMatcherEngine';

INSERT INTO CALYPSO.ENGINE_CONFIG VALUES ((SELECT MAX(ENGINE_ID)+1 FROM ENGINE_CONFIG), 'SettleReturnMatcherEngine', 'Matched transfers witrh incoming messages.',(SELECT MAX(VERSION_NUM)  FROM ENGINE_CONFIG));

INSERT INTO CALYPSO.ENGINE_PARAM VALUES ('SettleReturnMatcherEngine','CLASS_NAME','com.calypso.engine.lifecycle.LifeCycleEngine');
INSERT INTO CALYPSO.ENGINE_PARAM VALUES ('SettleReturnMatcherEngine','DISPLAY_NAME','SettleReturnMatcherEngine');
INSERT INTO CALYPSO.ENGINE_PARAM VALUES ('SettleReturnMatcherEngine','INSTANCE_NAME','gen_engineserver');
INSERT INTO CALYPSO.ENGINE_PARAM VALUES ('SettleReturnMatcherEngine','STARTUP','true');
INSERT INTO CALYPSO.ENGINE_PARAM VALUES ('SettleReturnMatcherEngine','config','TransferIndexer');
INSERT INTO CALYPSO.ENGINE_PARAM VALUES ('SettleReturnMatcherEngine','PricingEnv','OFFICIAL_ACCOUNTING');


INSERT INTO CALYPSO.PS_EVENT_FILTER VALUES ('Back-Office','SettleReturnMatcherEngine','TransferIndexerLifeCycleEngineEventFilter');

INSERT INTO CALYPSO.PS_EVENT_CONFIG VALUES ('Back-Office','PSEventTransfer','SettleReturnMatcherEngine');
INSERT INTO CALYPSO.PS_EVENT_CONFIG VALUES ('Back-Office','PSEventProcessTransfer','SettleReturnMatcherEngine');

commit;