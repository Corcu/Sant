BEGIN
	DECLARE
		cnt  NUMBER(32);
	BEGIN
    
        -- Msg Nominal Amount --
        SELECT count(*) into cnt from task_enrichment_field_config where field_db_name ='msg_nominal_amount';
        
        IF cnt <= 0 THEN
            INSERT INTO task_enrichment_field_config (
                workflow_type,
                data_source_class_name,
                data_source_getter_name,
                custom_class_name,
                field_source,
                field_conversion_class,
                extra_arguments,
                field_display_name,
                field_db_name,
                link_db_name,
                field_domain_finder,
                sql_expression,
                db_type,
                db_scale
            ) VALUES (
                'Message',                      --workflow_type
                'com.calypso.tk.bo.BOMessage',  --data_source_class_name
                'getAttribute',                 --data_source_getter_name
                NULL,                           --custom_class_name
                NULL,                           --field_source
                NULL,                           --field_conversion_class
                'Nominal Amount',               --extra_arguments
                'Msg Nominal Amount',           --field_display_name
                'msg_nominal_amount',           --field_db_name
                NULL,                           --link_db_name
                NULL,                           --field_domain_finder
                NULL,                           --sql_expression
                'string',                       --DB_TYPE
                32                              --DB_SCALE
            );
         
            EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT ADD msg_nominal_amount VARCHAR2(32)';
         
        
            EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT_HIST ADD msg_nominal_amount VARCHAR2(32)';
        
        END IF;  
        
        -- Msg Cash Amount --
        SELECT count(*) into cnt from task_enrichment_field_config where field_db_name ='msg_cash_amount';
        
        IF cnt <= 0 THEN
            
            INSERT INTO task_enrichment_field_config (
            workflow_type,
            data_source_class_name,
            data_source_getter_name,
            custom_class_name,
            field_source,
            field_conversion_class,
            extra_arguments,
            field_display_name,
            field_db_name,
            link_db_name,
            field_domain_finder,
            sql_expression,
            db_type,
            db_scale
            ) VALUES (
            'Message',                      --workflow_type
            'com.calypso.tk.bo.BOMessage',  --data_source_class_name
            'getAttribute',                 --data_source_getter_name
            NULL,                           --custom_class_name
            NULL,                           --field_source
            NULL,                           --field_conversion_class
            'Cash Amount',                  --extra_arguments
            'Msg Cash Amount',              --field_display_name
            'msg_cash_amount',             --field_db_name
            NULL,                           --link_db_name
            NULL,                           --field_domain_finder
            NULL,                           --sql_expression
            'string',                       --DB_TYPE
            32                              --DB_SCALE
            );
      
            EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT ADD msg_cash_amount VARCHAR2(32)';
            EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT_HIST ADD msg_cash_amount VARCHAR2(32)';
            
        END IF;
        
        -- Msg Security Code --
        SELECT count(*) into cnt from task_enrichment_field_config where field_db_name ='msg_security_code';
         
        IF cnt <= 0 THEN
            INSERT INTO task_enrichment_field_config (
                workflow_type,
                data_source_class_name,
                data_source_getter_name,
                custom_class_name,
                field_source,
                field_conversion_class,
                extra_arguments,
                field_display_name,
                field_db_name,
                link_db_name,
                field_domain_finder,
                sql_expression,
                db_type,
                db_scale
            ) VALUES (
                'Message',                      --workflow_type
                'com.calypso.tk.bo.BOMessage',  --data_source_class_name
                'getAttribute',                 --data_source_getter_name
                NULL,                           --custom_class_name
                NULL,                           --field_source
                NULL,                           --field_conversion_class
                'Security Code',                --extra_arguments
                'Msg Security Code',            --field_display_name
                'msg_security_code',            --field_db_name
                NULL,                           --link_db_name
                NULL,                           --field_domain_finder
                NULL,                           --sql_expression
                'string',                       --DB_TYPE
                32                              --DB_SCALE
            );
            
            EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT ADD msg_security_code VARCHAR2(32)';
            EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT_HIST ADD msg_security_code VARCHAR2(32)';
        
        END IF;
        
         -- Msg Security Code --
        SELECT count(*) into cnt from task_enrichment_field_config where field_db_name ='msg_processing_status';
         
        IF cnt <= 0 THEN
            INSERT INTO task_enrichment_field_config (
                workflow_type,
                data_source_class_name,
                data_source_getter_name,
                custom_class_name,
                field_source,
                field_conversion_class,
                extra_arguments,
                field_display_name,
                field_db_name,
                link_db_name,
                field_domain_finder,
                sql_expression,
                db_type,
                db_scale
            ) VALUES (
                'Message',                      --workflow_type
                'com.calypso.tk.bo.BOMessage',  --data_source_class_name
                'getAttribute',                 --data_source_getter_name
                NULL,                           --custom_class_name
                NULL,                           --field_source
                NULL,                           --field_conversion_class
                'ProcessingStatus',             --extra_arguments
                'Msg Processing Status',        --field_display_name
                'msg_processing_status',        --field_db_name
                NULL,                           --link_db_name
                NULL,                           --field_domain_finder
                NULL,                           --sql_expression
                'string',                       --DB_TYPE
                32                              --DB_SCALE
            );
            
            EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT ADD msg_processing_status VARCHAR2(32)';
            EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT_HIST ADD msg_processing_status VARCHAR2(32)';
        
        END IF;
        
         -- Msg Currency Attr  --
        SELECT count(*) into cnt from task_enrichment_field_config where field_db_name ='msg_currency';
        
        IF cnt <= 0 THEN
            INSERT INTO task_enrichment_field_config (
                workflow_type,
                data_source_class_name,
                data_source_getter_name,
                custom_class_name,
                field_source,
                field_conversion_class,
                extra_arguments,
                field_display_name,
                field_db_name,
                link_db_name,
                field_domain_finder,
                sql_expression,
                db_type,
                db_scale
            ) VALUES (
                'Message',                      --workflow_type
                'com.calypso.tk.bo.BOMessage',  --data_source_class_name
                'getAttribute',                 --data_source_getter_name
                NULL,                           --custom_class_name
                NULL,                           --field_source
                NULL,                           --field_conversion_class
                'Ccy',                          --extra_arguments
                'Msg Currency',                 --field_display_name
                'msg_currency',                 --field_db_name
                NULL,                           --link_db_name
                NULL,                           --field_domain_finder
                NULL,                           --sql_expression
                'string',                       --DB_TYPE
                3                               --DB_SCALE
            );
         
            EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT ADD msg_currency VARCHAR2(3)';
         
            EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT_HIST ADD msg_currency VARCHAR2(3)';
        
        END IF;  
        
        
           -- Msg Delivering Agent  --
        SELECT count(*) into cnt from task_enrichment_field_config where field_db_name ='msg_deag';
        
        IF cnt <= 0 THEN
            INSERT INTO task_enrichment_field_config (
                workflow_type,
                data_source_class_name,
                data_source_getter_name,
                custom_class_name,
                field_source,
                field_conversion_class,
                extra_arguments,
                field_display_name,
                field_db_name,
                link_db_name,
                field_domain_finder,
                sql_expression,
                db_type,
                db_scale
            ) VALUES (
                'Message',                      --workflow_type
                'com.calypso.tk.bo.BOMessage',  --data_source_class_name
                'getAttribute',                 --data_source_getter_name
                NULL,                           --custom_class_name
                NULL,                           --field_source
                NULL,                           --field_conversion_class
                'CounterParty',                 --extra_arguments
                'Msg Delivering Agent',         --field_display_name
                'msg_deag',                     --field_db_name
                NULL,                           --link_db_name
                NULL,                           --field_domain_finder
                NULL,                           --sql_expression
                'string',                       --DB_TYPE
                32                              --DB_SCALE
            );
         
            EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT ADD msg_deag VARCHAR2(32)';
         
            EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT_HIST ADD msg_deag VARCHAR2(32)';
        
        END IF;  
        
       -- UPDATE task_enrichment_field_config SET field_db_name ='msg_settle_date' WHERE field_db_name ='Msg_settle_date';
       -- UPDATE task_enrichment_field_config SET field_db_name ='msg_trade_date' WHERE field_db_name ='Msg_trade_date';
        
        commit;

    END;
END;

/
