delete from trade_open_qty where trade_id IN (46447137,46447138);
COMMIT;
delete from LIQ_POSITION where SECOND_TRADE IN (46447137,46447138);
COMMIT;