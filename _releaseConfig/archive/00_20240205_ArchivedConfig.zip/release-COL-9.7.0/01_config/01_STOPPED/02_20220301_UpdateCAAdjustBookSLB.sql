update  book_attr_value set attribute_value = 'CA_BOOK_SLB' where attribute_name = 'CAAdjustBook' and book_id in (select book.book_id  from book WHERE legal_entity_id = 47819);
COMMIT;
