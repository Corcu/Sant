#!/bin/sh

$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="balanzadepagos"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="balanzadepagos/export"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="balanzadepagos/host"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="balanzadepagos/host/archive"
