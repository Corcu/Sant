DELETE FROM CALYPSO.PS_EVENT_CONFIG WHERE event_config_name='Back-Office' AND engine_name='MessageEngine' AND event_class='PSEventProcessTransfer';

INSERT INTO CALYPSO.PS_EVENT_CONFIG (event_config_name, event_class, engine_name) VALUES ('Back-Office','PSEventProcessTransfer','MessageEngine');

commit;