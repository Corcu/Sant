#!/bin/sh

$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="trlyncs/export"