$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="disponible/mic/import"
$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="disponible/alm/export"
