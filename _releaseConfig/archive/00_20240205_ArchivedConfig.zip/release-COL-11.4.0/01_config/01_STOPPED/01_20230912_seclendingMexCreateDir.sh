$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="mexico/presval/marginCalls"
$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="mexico/presval/marginCalls/copy"
$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="mexico/presval/marginCalls/logs"
