update product_equity set equity_name = TO_CHAR(product_equity.product_id) || '_' || product_equity.currency where equity_name is null;
update product_equity set exchange_code = 'NONE' where exchange_code is null;
commit;
