#!/bin/sh

$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="reports/export/pdv/"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="mis/pdv/export/"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="pdv/extracontable"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="pdv/alm"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="repo/mis/"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="repo/mis/export/"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="brs/extracontable"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="repo/mtm"