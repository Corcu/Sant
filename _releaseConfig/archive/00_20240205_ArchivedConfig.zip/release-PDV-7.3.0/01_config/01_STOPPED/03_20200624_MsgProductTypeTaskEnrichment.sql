ALTER TABLE TASK_ENRICHMENT ADD msg_product_type varchar2 (255)  NULL
/
ALTER TABLE TASK_ENRICHMENT_HIST ADD msg_product_type varchar2 (255)  NULL
/

ALTER TABLE TASK_ENRICHMENT ADD msg_murex_id varchar2 (255)  NULL
/
ALTER TABLE TASK_ENRICHMENT_HIST ADD msg_murex_id varchar2 (255)  NULL
/


INSERT INTO task_enrichment_field_config (field_display_name,field_db_name,data_source_class_name,workflow_type,data_source_getter_name,extra_arguments,db_type,db_scale) VALUES
('Msg Product Type','msg_product_type','com.calypso.tk.bo.BOMessage','Message','getAttribute','ProductType','string','255')
/

INSERT INTO task_enrichment_field_config (field_display_name,field_db_name,data_source_class_name,workflow_type,data_source_getter_name,extra_arguments,db_type,db_scale) VALUES
('Msg Murex Id','msg_murex_id','com.calypso.tk.bo.BOMessage','Message','getAttribute','UploadObjectExternalRef','string','255')
/