#!/bin/sh

$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="rv/broker/export"
$OCD_HOME/buildConfigurationManagement/src/main/config/scripts/common/createDir.sh --dir="rv/broker/export/processed"
