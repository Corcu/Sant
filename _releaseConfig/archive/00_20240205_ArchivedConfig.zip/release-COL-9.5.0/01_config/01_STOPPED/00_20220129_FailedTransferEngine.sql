delete from domain_values where name = 'eventFilter' and value='SantExcludeTradeTypesFallidasEventFilter';
Insert into DOMAIN_VALUES (NAME,VALUE,DESCRIPTION) values ('eventFilter','SantExcludeTradeTypesFallidasEventFilter','Excludes some types for Trades Xfer and Messages events');

DELETE FROM PS_EVENT_FILTER WHERE ENGINE_NAME='FailedTransferEngine';
Insert into CALYPSO.PS_EVENT_FILTER (EVENT_CONFIG_NAME,ENGINE_NAME,EVENT_FILTER) values ('Back-Office','FailedTransferEngine','SantExcludeTradeTypesFallidasEventFilter');


