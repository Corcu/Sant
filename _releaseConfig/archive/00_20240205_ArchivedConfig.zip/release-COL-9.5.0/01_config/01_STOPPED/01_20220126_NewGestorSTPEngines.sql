DELETE FROM ENGINE_CONFIG WHERE ENGINE_NAME='GestorSTPIncomingPSEventEngine';
Insert into CALYPSO.ENGINE_CONFIG (ENGINE_ID,ENGINE_NAME,ENGINE_COMMENT,VERSION_NUM) values ((select max(ENGINE_ID)+1 from CALYPSO.ENGINE_CONFIG),'GestorSTPIncomingPSEventEngine','Starts and stops GestorSTPIncomingPSEventEngine','500');


DELETE FROM ENGINE_PARAM WHERE ENGINE_NAME='GestorSTPIncomingPSEventEngine';
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('GestorSTPIncomingPSEventEngine','DISPLAY_NAME','GestorSTPIncomingPSEventEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('GestorSTPIncomingPSEventEngine','CLASS_NAME','calypsox.engine.gestorstp.GestorSTPIncomingPSEventEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('GestorSTPIncomingPSEventEngine','STARTUP','true');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('GestorSTPIncomingPSEventEngine','INSTANCE_NAME','imp_engineserver');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('GestorSTPIncomingPSEventEngine','config','GenericJMSQueue');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('GestorSTPIncomingPSEventEngine','type','gstp.in');



DELETE FROM ENGINE_CONFIG WHERE ENGINE_NAME='GestorSTPSwiftMessageEngine';
Insert into CALYPSO.ENGINE_CONFIG (ENGINE_ID,ENGINE_NAME,ENGINE_COMMENT,VERSION_NUM) values ((select max(ENGINE_ID)+1 from CALYPSO.ENGINE_CONFIG),'GestorSTPSwiftMessageEngine','Starts and stops GestorSTPSwiftMessageEngine','500');


DELETE FROM ENGINE_PARAM WHERE ENGINE_NAME='GestorSTPSwiftMessageEngine';
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('GestorSTPSwiftMessageEngine','DISPLAY_NAME','GestorSTPSwiftMessageEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('GestorSTPSwiftMessageEngine','CLASS_NAME','calypsox.engine.gestorstp.GestorSTPSwiftMessageEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('GestorSTPSwiftMessageEngine','STARTUP','true');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('GestorSTPSwiftMessageEngine','INSTANCE_NAME','imp_engineserver');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('GestorSTPSwiftMessageEngine','THREAD_COUNT','5');


DELETE FROM PS_EVENT_CONFIG WHERE ENGINE_NAME='GestorSTPSwiftMessageEngine';
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventMTSwiftMessage','GestorSTPSwiftMessageEngine');
