delete  from acc_book_rule_link
where product_type ='G.Bonds' and sd_filter='WF_TRF_XferTypeIsWRITE_OFF'
and acc_rule_id = (select acc_rule_id from acc_rule where acc_rule_name='RF_WriteOff')
and acc_book_id = (select acc_book_id from acc_book where acc_book_name='Inversion a vencimiento');

delete  from acc_book_rule_link
where product_type ='G.Bonds' and sd_filter='WF_TRF_XferTypeIsWRITE_OFF'
and acc_rule_id = (select acc_rule_id from acc_rule where acc_rule_name='RF_WriteOff')
and acc_book_id = (select acc_book_id from acc_book where acc_book_name='Inversion crediticia');

delete  from acc_book_rule_link
where product_type ='G.Bonds' and sd_filter='WF_TRF_XferTypeIsWRITE_OFF'
and acc_rule_id = (select acc_rule_id from acc_rule where acc_rule_name='RF_WriteOff')
and acc_book_id = (select acc_book_id from acc_book where acc_book_name='Otros a valor razonable');

delete  from acc_book_rule_link
where product_type ='G.Bonds' and sd_filter='WF_TRF_XferTypeIsWRITE_OFF'
and acc_rule_id = (select acc_rule_id from acc_rule where acc_rule_name='RF_WriteOff')
and acc_book_id = (select acc_book_id from acc_book where acc_book_name='Disponible para la venta');

delete  from acc_book_rule_link
where product_type ='G.Bonds' and sd_filter='WF_TRF_XferTypeIsWRITE_OFF'
and acc_rule_id = (select acc_rule_id from acc_rule where acc_rule_name='RF_WriteOff')
and acc_book_id = (select acc_book_id from acc_book where acc_book_name='Inventario Terceros');

delete  from acc_book_rule_link
where product_type ='G.Bonds' and sd_filter='WF_TRF_XferTypeIsWRITE_OFF'
and acc_rule_id = (select acc_rule_id from acc_rule where acc_rule_name='RF_WriteOff')
and acc_book_id = (select acc_book_id from acc_book where acc_book_name='Negociacion');

insert into acc_book_rule_link
(acc_link_id, acc_book_id, product_type, acc_rule_id, sd_filter, version_num) values(
(select last_id + 1 from calypso_seed where seed_name = 'refdata'),
(select acc_book_id from acc_book where acc_book_name='Inversion a vencimiento'),
'G.Bonds',
(select acc_rule_id from acc_rule where acc_rule_name='RF_WriteOff'),
'WF_TRF_XferTypeIsWRITE_OFF',0);

insert into acc_book_rule_link
(acc_link_id, acc_book_id, product_type, acc_rule_id, sd_filter, version_num) values(
(select last_id + 2 from calypso_seed where seed_name = 'refdata'),
(select acc_book_id from acc_book where acc_book_name='Inversion crediticia'),
'G.Bonds',
(select acc_rule_id from acc_rule where acc_rule_name='RF_WriteOff'),
'WF_TRF_XferTypeIsWRITE_OFF',0);

insert into acc_book_rule_link
(acc_link_id, acc_book_id, product_type, acc_rule_id, sd_filter, version_num) values(
(select last_id + 3 from calypso_seed where seed_name = 'refdata'),
(select acc_book_id from acc_book where acc_book_name='Otros a valor razonable'),
'G.Bonds',
(select acc_rule_id from acc_rule where acc_rule_name='RF_WriteOff'),
'WF_TRF_XferTypeIsWRITE_OFF',0);

insert into acc_book_rule_link
(acc_link_id, acc_book_id, product_type, acc_rule_id, sd_filter, version_num) values(
(select last_id + 4 from calypso_seed where seed_name = 'refdata'),
(select acc_book_id from acc_book where acc_book_name='Disponible para la venta'),
'G.Bonds',
(select acc_rule_id from acc_rule where acc_rule_name='RF_WriteOff'),
'WF_TRF_XferTypeIsWRITE_OFF',0);

insert into acc_book_rule_link
(acc_link_id, acc_book_id, product_type, acc_rule_id, sd_filter, version_num) values(
(select last_id + 5 from calypso_seed where seed_name = 'refdata'),
(select acc_book_id from acc_book where acc_book_name='Inventario Terceros'),
'G.Bonds',
(select acc_rule_id from acc_rule where acc_rule_name='RF_WriteOff'),
'WF_TRF_XferTypeIsWRITE_OFF',0);

insert into acc_book_rule_link
(acc_link_id, acc_book_id, product_type, acc_rule_id, sd_filter, version_num) values(
(select last_id + 6 from calypso_seed where seed_name = 'refdata'),
(select acc_book_id from acc_book where acc_book_name='Negociacion'),
'G.Bonds',
(select acc_rule_id from acc_rule where acc_rule_name='RF_WriteOff'),
'WF_TRF_XferTypeIsWRITE_OFF',0);

update calypso_seed set last_id = last_id + 10 where seed_name = 'refdata'; 

commit;