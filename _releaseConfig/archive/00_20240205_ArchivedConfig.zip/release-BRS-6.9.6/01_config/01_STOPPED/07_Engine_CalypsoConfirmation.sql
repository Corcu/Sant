Insert into CALYPSO.ENGINE_CONFIG (ENGINE_ID,ENGINE_NAME,ENGINE_COMMENT,VERSION_NUM) values ('421087','CalypsoConfirmationConnectionEngine',null,'530');

Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('CalypsoConfirmationConnectionEngine','DISPLAY_NAME','CalypsoConfirmationConnectionEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('CalypsoConfirmationConnectionEngine','INSTANCE_NAME','exp_engineserver');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('CalypsoConfirmationConnectionEngine','CLASS_NAME','calypsox.tk.engine.confirmation.CalypsoConfirmationConnectionEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('CalypsoConfirmationConnectionEngine','PricingEnv','DirtyPrice');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('CalypsoConfirmationConnectionEngine','config','cal_confirm.connection.properties');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('CalypsoConfirmationConnectionEngine','STARTUP','true');

Insert into CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) values ('Back-Office','PSEventMessage','CalypsoConfirmationConnectionEngine');

Insert into CALYPSO.PS_EVENT_FILTER (EVENT_CONFIG_NAME,ENGINE_NAME,EVENT_FILTER) values ('Back-Office','CalypsoConfirmationConnectionEngine','CalConfirmationFIBOMessageEventFilter');