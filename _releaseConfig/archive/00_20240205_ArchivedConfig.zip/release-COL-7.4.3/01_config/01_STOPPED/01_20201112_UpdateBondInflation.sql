update product_bond set notional_index=null, notl_guaranteed=0, notl_index_value=0 where notional_index is not null
/