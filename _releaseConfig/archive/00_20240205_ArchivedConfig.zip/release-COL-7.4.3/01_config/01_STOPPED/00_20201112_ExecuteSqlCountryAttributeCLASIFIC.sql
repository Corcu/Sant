insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'AD'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'AE'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'AF'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'AG'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'AI'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'AL'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'AM'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'AO'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'AQ'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'AR'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'AS'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'AT'),'Country', 'CLASIFICACION_CONTABLE','String', 'UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'AU'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'AW'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'AZ'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BA'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BB'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BD'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BE'),'Country', 'CLASIFICACION_CONTABLE','String', 'UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BF'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BG'),'Country', 'CLASIFICACION_CONTABLE','String', 'UE no UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BH'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BI'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BJ'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BM'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BN'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BO'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BQ'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BR'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BS'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BT'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BV'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BW'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BY'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'BZ'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'CA'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'CD'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'CF'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'CG'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'CH'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'CI'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'CK'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'CL'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'CM'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'CN'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'CO'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'CR'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'CU'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'CV'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'CW'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'CY'),'Country', 'CLASIFICACION_CONTABLE','String', 'UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'CZ'),'Country', 'CLASIFICACION_CONTABLE','String', 'UE no UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'DE'),'Country', 'CLASIFICACION_CONTABLE','String', 'UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'DJ'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'DK'),'Country', 'CLASIFICACION_CONTABLE','String', 'UE no UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'DM'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'DO'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'DZ'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'EC'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'EE'),'Country', 'CLASIFICACION_CONTABLE','String', 'UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'EG'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/

insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'ER'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'ES'),'Country', 'CLASIFICACION_CONTABLE','String', 'ESPAÑA')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'ET'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/

insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'FI'),'Country', 'CLASIFICACION_CONTABLE','String', 'UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'FJ'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'FK'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'FM'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'FO'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'FR'),'Country', 'CLASIFICACION_CONTABLE','String', 'UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'GA'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'GB'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'GD'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'GE'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/

insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'GG'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'GH'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'GI'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'GL'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'GM'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'GN'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'GQ'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'GR'),'Country', 'CLASIFICACION_CONTABLE','String', 'UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'GS'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'GT'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'GU'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'GW'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'GY'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'HK'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'HN'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'HR'),'Country', 'CLASIFICACION_CONTABLE','String', 'UE no UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'HT'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'HU'),'Country', 'CLASIFICACION_CONTABLE','String', 'UE no UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'ID'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'IE'),'Country', 'CLASIFICACION_CONTABLE','String', 'UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'IL'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'IM'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'IN'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'IO'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'IQ'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'IR'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'IS'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'IT'),'Country', 'CLASIFICACION_CONTABLE','String', 'UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'JE'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'JM'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'JO'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'JP'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'KE'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'KG'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'KH'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'KI'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'KM'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'KN'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'KP'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'KR'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'KW'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'KY'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'KZ'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'LA'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'LB'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'LC'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'LI'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'LK'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'LR'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'LS'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'LT'),'Country', 'CLASIFICACION_CONTABLE','String', 'UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'LU'),'Country', 'CLASIFICACION_CONTABLE','String', 'UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'LV'),'Country', 'CLASIFICACION_CONTABLE','String', 'UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'LY'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'MA'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'MD'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'ME'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'MG'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'MH'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'MK'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'ML'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'MM'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'MN'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'MO'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'MP'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'MR'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'MS'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'MT'),'Country', 'CLASIFICACION_CONTABLE','String', 'UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'MU'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'MV'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'MW'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'MX'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'MY'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'MZ'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'NA'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'NC'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'NE'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'NG'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'NI'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'NL'),'Country', 'CLASIFICACION_CONTABLE','String', 'UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'NO'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'NP'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'NR'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'OM'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'PA'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'PE'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'PF'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'PG'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'PH'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'PK'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'PL'),'Country', 'CLASIFICACION_CONTABLE','String', 'UE no UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'PN'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'PR'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'PS'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'PT'),'Country', 'CLASIFICACION_CONTABLE','String', 'UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'PW'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'PY'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'QA'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'RO'),'Country', 'CLASIFICACION_CONTABLE','String', 'UE no UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'RS'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'RU'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'RW'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'SA'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'SB'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'SC'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'SD'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'SE'),'Country', 'CLASIFICACION_CONTABLE','String', 'UE no UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'SG'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'SH'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'SI'),'Country', 'CLASIFICACION_CONTABLE','String', 'UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'SK'),'Country', 'CLASIFICACION_CONTABLE','String', 'UEM')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'SL'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'SM'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'SN'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'SO'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'SR'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'SS'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'ST'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'SV'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'SY'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'SZ'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'TC'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'TD'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'TF'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'TG'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'TH'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'TJ'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'TK'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'TL'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'TM'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'TN'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'TO'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'TR'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'TT'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'TV'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'TW'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'TZ'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'UA'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'UG'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'UM'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'US'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'UY'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'UZ'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'VA'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'VC'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'VE'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'VG'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'VI'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'VN'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'VU'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'WF'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'WS'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'YE'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'ZA'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
insert into entity_attributes (entity_id, entity_Type, attr_name,attr_type,attr_value) values ((select country_id from country where iso_code = 'ZM'),'Country', 'CLASIFICACION_CONTABLE','String', 'N/A')
/
