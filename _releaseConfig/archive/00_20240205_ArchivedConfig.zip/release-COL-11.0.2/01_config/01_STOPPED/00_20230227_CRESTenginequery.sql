Delete from ENGINE_CONFIG where ENGINE_NAME='SANT_CREST_GestorSTPIncomingMessageEngine';
Delete from ENGINE_CONFIG where ENGINE_NAME='SANT_CREST_ImportGestorSTPMessageEngine';

Insert into ENGINE_CONFIG (ENGINE_ID,ENGINE_NAME,ENGINE_COMMENT,VERSION_NUM) values ((SELECT MAX (ENGINE_ID)+1 FROM ENGINE_CONFIG),'SANT_CREST_GestorSTPIncomingMessageEngine','Recibe mensajes de SWIFT desde CREST','401');
Insert into ENGINE_CONFIG (ENGINE_ID,ENGINE_NAME,ENGINE_COMMENT,VERSION_NUM) values ((SELECT MAX (ENGINE_ID)+1 FROM ENGINE_CONFIG),'SANT_CREST_ImportGestorSTPMessageEngine','Recibe mensaje ACK/NACK de CREST','401');

Delete from ENGINE_PARAM where ENGINE_NAME ='SANT_CREST_GestorSTPIncomingMessageEngine';
Delete from ENGINE_PARAM where ENGINE_NAME ='SANT_CREST_ImportGestorSTPMessageEngine';

Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SANT_CREST_GestorSTPIncomingMessageEngine','CLASS_NAME','calypsox.engine.gestorstp.CRESTGestorSTPIncomingMessageEngine');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SANT_CREST_GestorSTPIncomingMessageEngine','DISPLAY_NAME','SANT_CREST_GestorSTPIncomingMessageEngine');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SANT_CREST_GestorSTPIncomingMessageEngine','INSTANCE_NAME','imp_engineserver');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SANT_CREST_GestorSTPIncomingMessageEngine','STARTUP','true');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SANT_CREST_GestorSTPIncomingMessageEngine','type','gstpcrest.in');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SANT_CREST_GestorSTPIncomingMessageEngine','config','GenericJMSQueue');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SANT_CREST_ImportGestorSTPMessageEngine','DISPLAY_NAME','SANT_CREST_ImportGestorSTPMessageEngine');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SANT_CREST_ImportGestorSTPMessageEngine','CLASS_NAME','calypsox.engine.gestorstp.CRESTImportGestorSTPMessageEngine');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SANT_CREST_ImportGestorSTPMessageEngine','INSTANCE_NAME','imp_engineserver');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SANT_CREST_ImportGestorSTPMessageEngine','config','GenericJMSQueue');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SANT_CREST_ImportGestorSTPMessageEngine','STARTUP','true');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SANT_CREST_ImportGestorSTPMessageEngine','type','gstpcrest.ack');

commit;