$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="bond/dmo"
$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="bond/dmo/backup"