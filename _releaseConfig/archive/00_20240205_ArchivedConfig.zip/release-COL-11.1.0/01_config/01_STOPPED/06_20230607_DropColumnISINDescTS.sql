BEGIN
	DECLARE
		column_count NUMBER;
		COLUMN_NAME VARCHAR(128);
	BEGIN
		COLUMN_NAME := UPPER('isin_description');
		-- Verificar si la columna existe en la tabla
		SELECT COUNT(*)
		INTO column_count
		FROM USER_TAB_COLUMNS
		WHERE TABLE_NAME = 'TASK_ENRICHMENT'
		AND COLUMN_NAME = COLUMN_NAME;
	
		-- Si la columna existe, ejecutar el DROP COLUMN
		IF column_count > 0 THEN
			EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT DROP COLUMN ' || COLUMN_NAME;
			DBMS_OUTPUT.PUT_LINE('La columna ha sido eliminada.');
		ELSE
			DBMS_OUTPUT.PUT_LINE('La columna no existe en la tabla.');
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
	END;
	
	DECLARE
		column_count NUMBER;
		COLUMN_NAME VARCHAR(128);
	BEGIN
		COLUMN_NAME := UPPER('isin_description');
		-- Verificar si la columna existe en la tabla
		SELECT COUNT(*)
		INTO column_count
		FROM USER_TAB_COLUMNS
		WHERE TABLE_NAME = 'TASK_ENRICHMENT_HIST'
		AND COLUMN_NAME = COLUMN_NAME;
	
		-- Si la columna existe, ejecutar el DROP COLUMN
		IF column_count > 0 THEN
			EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT_HIST DROP COLUMN ' || COLUMN_NAME;
			DBMS_OUTPUT.PUT_LINE('La columna ha sido eliminada.');
		ELSE
			DBMS_OUTPUT.PUT_LINE('La columna no existe en la tabla.');
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
	END;

commit;
END;
/
