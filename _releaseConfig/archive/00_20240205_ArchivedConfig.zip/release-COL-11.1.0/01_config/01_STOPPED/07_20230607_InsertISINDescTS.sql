ALTER TABLE TASK_ENRICHMENT ADD isin_description varchar2 (128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD isin_description varchar2 (128);

DELETE FROM task_enrichment_field_config WHERE field_display_name='ISIN Description';
INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale) VALUES ('ISIN Description', 'isin_description', null, 'com.calypso.tk.core.Trade', 'Trade', 'getISINDescription', 'calypsox.util.TaskEnrichment', 'string', '128');