DELETE FROM ENGINE_CONFIG WHERE ENGINE_NAME = 'SANT_Sailpoint_ImportMessageEngine';
Insert into ENGINE_CONFIG (ENGINE_ID,ENGINE_NAME,ENGINE_COMMENT,VERSION_NUM) values ((select max(ENGINE_ID)+1 from ENGINE_CONFIG),'SANT_Sailpoint_ImportMessageEngine',null,'1');

DELETE FROM ENGINE_PARAM WHERE ENGINE_NAME='SANT_Sailpoint_ImportMessageEngine';
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SANT_Sailpoint_ImportMessageEngine','CLASS_NAME','com.calypso.tk.engine.UploadImportMessageEngine');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SANT_Sailpoint_ImportMessageEngine','STARTUP','false');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SANT_Sailpoint_ImportMessageEngine','INSTANCE_NAME','imp_engineserver');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SANT_Sailpoint_ImportMessageEngine','EVENT_POOL_POLICY','UploaderImportMessageEngine');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SANT_Sailpoint_ImportMessageEngine','DISPLAY_NAME','SANT_Sailpoint_ImportMessageEngine');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SANT_Sailpoint_ImportMessageEngine','PricingEnv','OFFICIAL');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SANT_Sailpoint_ImportMessageEngine','config','Sailpoint');

DELETE FROM PS_EVENT_CONFIG WHERE ENGINE_NAME = 'SANT_Sailpoint_ImportMessageEngine';
Insert into PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) values ('Back-Office','PSEventUpload','SANT_Sailpoint_ImportMessageEngine');

DELETE FROM PS_EVENT_FILTER WHERE ENGINE_NAME = 'SANT_Sailpoint_ImportMessageEngine';
INSERT INTO PS_EVENT_FILTER (EVENT_CONFIG_NAME, ENGINE_NAME, EVENT_FILTER) VALUES('Back-Office', 'SANT_Sailpoint_ImportMessageEngine', 'PSEventUploadSailpointEventFilter');

DELETE FROM DOMAIN_VALUES WHERE NAME='eventFilter' AND VALUE='PSEventUploadSailpointEventFilter';
DELETE FROM DOMAIN_VALUES WHERE NAME='engineName' AND VALUE='SANT_Sailpoint_ImportMessageEngine';
INSERT INTO DOMAIN_VALUES (NAME, VALUE, DESCRIPTION) VALUES('eventFilter', 'PSEventUploadSailpointEventFilter', NULL);
INSERT INTO DOMAIN_VALUES (NAME, VALUE, DESCRIPTION) VALUES('engineName', 'SANT_Sailpoint_ImportMessageEngine', NULL);
