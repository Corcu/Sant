

DELETE FROM ENGINE_CONFIG WHERE ENGINE_NAME = 'CreOnlineCCCTSenderEngine';
DELETE FROM ENGINE_PARAM WHERE  ENGINE_NAME = 'CreOnlineCCCTSenderEngine';
DELETE FROM PS_EVENT_FILTER WHERE  ENGINE_NAME = 'CreOnlineCCCTSenderEngine';
DELETE FROM PS_EVENT_CONFIG WHERE  ENGINE_NAME = 'CreOnlineCCCTSenderEngine';

INSERT INTO ENGINE_CONFIG VALUES ((SELECT MAX(ENGINE_ID)+1 FROM ENGINE_CONFIG), 'CreOnlineCCCTSenderEngine', 'null',1);

INSERT INTO ENGINE_PARAM VALUES ('CreOnlineCCCTSenderEngine','CLASS_NAME','calypsox.engine.accounting.CreOnlineCCCTSenderEngine');
INSERT INTO ENGINE_PARAM VALUES ('CreOnlineCCCTSenderEngine','DISPLAY_NAME','CreOnlineCCCTSenderEngine');
INSERT INTO ENGINE_PARAM VALUES ('CreOnlineCCCTSenderEngine','INSTANCE_NAME','exp_engineserver');
INSERT INTO ENGINE_PARAM VALUES ('CreOnlineCCCTSenderEngine','REVERSAL_CRE','Y');
INSERT INTO ENGINE_PARAM VALUES ('CreOnlineCCCTSenderEngine','STARTUP','true');
INSERT INTO ENGINE_PARAM VALUES ('CreOnlineCCCTSenderEngine','config','ccct.connection.properties');

DELETE FROM PS_EVENT_FILTER WHERE ENGINE_NAME = 'CreOnlineKafkaSenderEngine' AND EVENT_FILTER = 'BlockBOCreCCCTEventFilter';
DELETE FROM PS_EVENT_FILTER WHERE ENGINE_NAME = 'CreOnlineSenderEngine' AND EVENT_FILTER = 'BlockBOCreCCCTEventFilter';

INSERT INTO PS_EVENT_FILTER VALUES ('Back-Office','CreOnlineKafkaSenderEngine','BlockBOCreCCCTEventFilter');
INSERT INTO PS_EVENT_FILTER VALUES ('Back-Office','CreOnlineSenderEngine','BlockBOCreCCCTEventFilter');

INSERT INTO PS_EVENT_FILTER VALUES ('Back-Office','CreOnlineCCCTSenderEngine','BlockBOCreCCCTEventFilter');
INSERT INTO PS_EVENT_FILTER VALUES ('Back-Office','CreOnlineCCCTSenderEngine','BlockBOCreKafkaEventFilter');
INSERT INTO PS_EVENT_FILTER VALUES ('Back-Office','CreOnlineCCCTSenderEngine','SantCREsCCCTAcountingEventFilter');

INSERT INTO PS_EVENT_CONFIG VALUES ('Back-Office','PSEventCre','CreOnlineCCCTSenderEngine');

commit;