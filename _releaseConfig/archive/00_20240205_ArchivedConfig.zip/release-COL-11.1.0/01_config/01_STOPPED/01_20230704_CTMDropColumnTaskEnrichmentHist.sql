BEGIN
    DECLARE
        column_count NUMBER;
        COLUMN_NAME VARCHAR(128);
	BEGIN
		COLUMN_NAME := UPPER('Counterparty');
		-- Verificar si la columna existe en la tabla
		SELECT COUNT(*)
		INTO column_count
		FROM USER_TAB_COLUMNS
		WHERE TABLE_NAME = 'TASK_ENRICHMENT_HIST'
		AND COLUMN_NAME = COLUMN_NAME;
		
		-- Si la columna existe, ejecutar el DROP COLUMN
		IF column_count > 0 THEN
			EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT_HIST DROP COLUMN ' || COLUMN_NAME;
			DBMS_OUTPUT.PUT_LINE('La columna ha sido eliminada');
		ELSE
			DBMS_OUTPUT.PUT_LINE('La columna no existe en la tabla');
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
	END;

	DECLARE
        column_count NUMBER;
        COLUMN_NAME VARCHAR(128);
	BEGIN
		COLUMN_NAME := UPPER('ISIN');
		-- Verificar si la columna existe en la tabla
		SELECT COUNT(*)
		INTO column_count
		FROM USER_TAB_COLUMNS
		WHERE TABLE_NAME = 'TASK_ENRICHMENT_HIST'
		AND COLUMN_NAME = COLUMN_NAME;
		
		-- Si la columna existe, ejecutar el DROP COLUMN
		IF column_count > 0 THEN
			EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT_HIST DROP COLUMN ' || COLUMN_NAME;
			DBMS_OUTPUT.PUT_LINE('La columna ha sido eliminada');
		ELSE
			DBMS_OUTPUT.PUT_LINE('La columna no existe en la tabla');
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
	END;
	
	DECLARE
        column_count NUMBER;
        COLUMN_NAME VARCHAR(128);
	BEGIN
		COLUMN_NAME := UPPER('Msg_trade_date');
		-- Verificar si la columna existe en la tabla
		SELECT COUNT(*)
		INTO column_count
		FROM USER_TAB_COLUMNS
		WHERE TABLE_NAME = 'TASK_ENRICHMENT_HIST'
		AND COLUMN_NAME = COLUMN_NAME;
		
		-- Si la columna existe, ejecutar el DROP COLUMN
		IF column_count > 0 THEN
			EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT_HIST DROP COLUMN ' || COLUMN_NAME;
			DBMS_OUTPUT.PUT_LINE('La columna ha sido eliminada');
		ELSE
			DBMS_OUTPUT.PUT_LINE('La columna no existe en la tabla');
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
	END;
	
	DECLARE
        column_count NUMBER;
        COLUMN_NAME VARCHAR(128);
	BEGIN
		COLUMN_NAME := UPPER('Msg_settle_date');
		-- Verificar si la columna existe en la tabla
		SELECT COUNT(*)
		INTO column_count
		FROM USER_TAB_COLUMNS
		WHERE TABLE_NAME = 'TASK_ENRICHMENT_HIST'
		AND COLUMN_NAME = COLUMN_NAME;
		
		-- Si la columna existe, ejecutar el DROP COLUMN
		IF column_count > 0 THEN
			EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT_HIST DROP COLUMN ' || COLUMN_NAME;
			DBMS_OUTPUT.PUT_LINE('La columna ha sido eliminada');
		ELSE
			DBMS_OUTPUT.PUT_LINE('La columna no existe en la tabla');
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
	END;
	
	DECLARE
        column_count NUMBER;
        COLUMN_NAME VARCHAR(128);
	BEGIN
		COLUMN_NAME := UPPER('Mess_BlockTradeDetail');
		-- Verificar si la columna existe en la tabla
		SELECT COUNT(*)
		INTO column_count
		FROM USER_TAB_COLUMNS
		WHERE TABLE_NAME = 'TASK_ENRICHMENT_HIST'
		AND COLUMN_NAME = COLUMN_NAME;
		
		-- Si la columna existe, ejecutar el DROP COLUMN
		IF column_count > 0 THEN
			EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT_HIST DROP COLUMN ' || COLUMN_NAME;
			DBMS_OUTPUT.PUT_LINE('La columna ha sido eliminada');
		ELSE
			DBMS_OUTPUT.PUT_LINE('La columna no existe en la tabla');
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
	END;
	
	DECLARE
        column_count NUMBER;
        COLUMN_NAME VARCHAR(128);
	BEGIN
		COLUMN_NAME := UPPER('Mess_GLCSBlockTrade');
		-- Verificar si la columna existe en la tabla
		SELECT COUNT(*)
		INTO column_count
		FROM USER_TAB_COLUMNS
		WHERE TABLE_NAME = 'TASK_ENRICHMENT_HIST'
		AND COLUMN_NAME = COLUMN_NAME;
		
		-- Si la columna existe, ejecutar el DROP COLUMN
		IF column_count > 0 THEN
			EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT_HIST DROP COLUMN ' || COLUMN_NAME;
			DBMS_OUTPUT.PUT_LINE('La columna ha sido eliminada');
		ELSE
			DBMS_OUTPUT.PUT_LINE('La columna no existe en la tabla');
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
	END;
	
	DECLARE
        column_count NUMBER;
        COLUMN_NAME VARCHAR(128);
	BEGIN
		COLUMN_NAME := UPPER('MessageSource');
		-- Verificar si la columna existe en la tabla
		SELECT COUNT(*)
		INTO column_count
		FROM USER_TAB_COLUMNS
		WHERE TABLE_NAME = 'TASK_ENRICHMENT_HIST'
		AND COLUMN_NAME = COLUMN_NAME;
		
		-- Si la columna existe, ejecutar el DROP COLUMN
		IF column_count > 0 THEN
			EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT_HIST DROP COLUMN ' || COLUMN_NAME;
			DBMS_OUTPUT.PUT_LINE('La columna ha sido eliminada');
		ELSE
			DBMS_OUTPUT.PUT_LINE('La columna no existe en la tabla');
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
	END;
	
	DECLARE
        column_count NUMBER;
        COLUMN_NAME VARCHAR(128);
	BEGIN
		COLUMN_NAME := UPPER('Trade_BlockTradeDetail');
		-- Verificar si la columna existe en la tabla
		SELECT COUNT(*)
		INTO column_count
		FROM USER_TAB_COLUMNS
		WHERE TABLE_NAME = 'TASK_ENRICHMENT_HIST'
		AND COLUMN_NAME = COLUMN_NAME;
		
		-- Si la columna existe, ejecutar el DROP COLUMN
		IF column_count > 0 THEN
			EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT_HIST DROP COLUMN ' || COLUMN_NAME;
			DBMS_OUTPUT.PUT_LINE('La columna ha sido eliminada');
		ELSE
			DBMS_OUTPUT.PUT_LINE('La columna no existe en la tabla');
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
	END;
	
	DECLARE
        column_count NUMBER;
        COLUMN_NAME VARCHAR(128);
	BEGIN
		COLUMN_NAME := UPPER('Trade_GLCSBlockTrade');
		-- Verificar si la columna existe en la tabla
		SELECT COUNT(*)
		INTO column_count
		FROM USER_TAB_COLUMNS
		WHERE TABLE_NAME = 'TASK_ENRICHMENT_HIST'
		AND COLUMN_NAME = COLUMN_NAME;
		
		-- Si la columna existe, ejecutar el DROP COLUMN
		IF column_count > 0 THEN
			EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT_HIST DROP COLUMN ' || COLUMN_NAME;
			DBMS_OUTPUT.PUT_LINE('La columna ha sido eliminada');
		ELSE
			DBMS_OUTPUT.PUT_LINE('La columna no existe en la tabla');
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
	END;
	
	DECLARE
        column_count NUMBER;
        COLUMN_NAME VARCHAR(128);
	BEGIN
		COLUMN_NAME := UPPER('GESTORA_PREMIUM');
		-- Verificar si la columna existe en la tabla
		SELECT COUNT(*)
		INTO column_count
		FROM USER_TAB_COLUMNS
		WHERE TABLE_NAME = 'TASK_ENRICHMENT_HIST'
		AND COLUMN_NAME = COLUMN_NAME;
		
		-- Si la columna existe, ejecutar el DROP COLUMN
		IF column_count > 0 THEN
			EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT_HIST DROP COLUMN ' || COLUMN_NAME;
			DBMS_OUTPUT.PUT_LINE('La columna ha sido eliminada');
		ELSE
			DBMS_OUTPUT.PUT_LINE('La columna no existe en la tabla');
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
	END;
	
	DECLARE
        column_count NUMBER;
        COLUMN_NAME VARCHAR(128);
	BEGIN
		COLUMN_NAME := UPPER('GESTORA_PREAUTORIZADA');
		-- Verificar si la columna existe en la tabla
		SELECT COUNT(*)
		INTO column_count
		FROM USER_TAB_COLUMNS
		WHERE TABLE_NAME = 'TASK_ENRICHMENT_HIST'
		AND COLUMN_NAME = COLUMN_NAME;
		
		-- Si la columna existe, ejecutar el DROP COLUMN
		IF column_count > 0 THEN
			EXECUTE IMMEDIATE 'ALTER TABLE TASK_ENRICHMENT_HIST DROP COLUMN ' || COLUMN_NAME;
			DBMS_OUTPUT.PUT_LINE('La columna ha sido eliminada');
		ELSE
			DBMS_OUTPUT.PUT_LINE('La columna no existe en la tabla');
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
	END;
	
	commit;
END;
/