$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="BondDefICExportEngine/export_to_send"
$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="BondDefICExportEngine/export_sent"
