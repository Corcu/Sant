ALTER TABLE TASK_ENRICHMENT ADD CSDRPotencialPenaltyDaily varchar2 (128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD CSDRPotencialPenaltyDaily varchar2 (128);

DELETE FROM task_enrichment_field_config where field_display_name = 'CSDRPotencialPenaltyDaily';

INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale, extra_arguments) VALUES ('CSDRPotencialPenaltyDaily', 'CSDRPotencialPenaltyDaily', null, 'com.calypso.tk.bo.BOTransfer', 'Transfer', 'getAttribute', null, 'string', '128', 'CSDRPotencialPenaltyDaily');

ALTER TABLE TASK_ENRICHMENT ADD Settlement_Reason varchar2 (128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD Settlement_Reason varchar2 (128);

DELETE FROM task_enrichment_field_config where field_display_name = 'Settlement_Reason';

INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale, extra_arguments) VALUES ('Settlement_Reason', 'Settlement_Reason', null, 'com.calypso.tk.bo.BOTransfer', 'Transfer', 'getAttribute', null, 'string', '128', 'Settlement_Reason');

ALTER TABLE TASK_ENRICHMENT ADD Settlement_Status varchar2 (128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD Settlement_Status varchar2 (128);

DELETE FROM task_enrichment_field_config where field_display_name = 'Settlement_Status';

INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale, extra_arguments) VALUES ('Settlement_Status', 'Settlement_Status', null, 'com.calypso.tk.bo.BOTransfer', 'Transfer', 'getAttribute', null, 'string', '128', 'Settlement_Status');

ALTER TABLE TASK_ENRICHMENT ADD SDI_Receiver varchar2 (128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD SDI_Receiver varchar2 (128);

DELETE FROM task_enrichment_field_config where field_display_name = 'SDI Receiver';
INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale) VALUES ('SDI Receiver', 'SDI_Receiver', null, 'com.calypso.tk.bo.Task', 'CrossWorkflows', 'getSDIReceiver', 'calypsox.util.TaskEnrichment', 'string', '128');

ALTER TABLE TASK_ENRICHMENT ADD SDI_Payer varchar2 (128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD SDI_Payer varchar2 (128);

DELETE FROM task_enrichment_field_config where field_display_name = 'SDI Payer';
INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale) VALUES ('SDI Payer', 'SDI_Payer', null, 'com.calypso.tk.bo.Task', 'CrossWorkflows', 'getSDIPayer', 'calypsox.util.TaskEnrichment', 'string', '128');

ALTER TABLE TASK_ENRICHMENT ADD Comment_Fallidas varchar2 (512);
ALTER TABLE TASK_ENRICHMENT_HIST ADD Comment_Fallidas varchar2 (512);

DELETE FROM task_enrichment_field_config where field_display_name = 'Comment Fallidas';
INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale, extra_arguments) VALUES ('Comment Fallidas', 'Comment_Fallidas', null, 'com.calypso.tk.bo.BOTransfer', 'Transfer', 'getGenericComment', 'calypsox.util.TaskEnrichment', 'string', '512', 'Fallidas');

ALTER TABLE TASK_ENRICHMENT ADD Comment_Supporting_Documentation varchar2 (512);
ALTER TABLE TASK_ENRICHMENT_HIST ADD Comment_Supporting_Documentation varchar2 (512);

DELETE FROM task_enrichment_field_config where field_display_name = 'Comment Supporting Documentation';
INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale, extra_arguments) VALUES ('Comment Supporting Documentation', 'Comment_Supporting_Documentation', null, 'com.calypso.tk.bo.BOTransfer', 'Transfer', 'getGenericComment', 'calypsox.util.TaskEnrichment', 'string', '512', 'Supporting Documentation');

ALTER TABLE TASK_ENRICHMENT ADD murex_id varchar2 (128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD murex_id varchar2 (128);

DELETE FROM task_enrichment_field_config where field_display_name = 'Mx Global ID';
INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale) VALUES ('Mx Global ID', 'murex_id', null, 'com.calypso.tk.core.Trade', 'Trade', 'getMurexIdTkw', 'calypsox.util.TaskEnrichment', 'string', '128');

ALTER TABLE TASK_ENRICHMENT ADD settle_date varchar2 (128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD settle_date varchar2 (128);

DELETE FROM task_enrichment_field_config where field_display_name = 'Settle Date';
INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale) VALUES ('Settle Date', 'settle_date', null, 'com.calypso.tk.core.Trade', 'Trade', 'getSettleDate', 'calypsox.util.TaskEnrichment', 'string', '128');

ALTER TABLE TASK_ENRICHMENT ADD dual_ccy varchar2 (128);
ALTER TABLE TASK_ENRICHMENT_HIST ADD dual_ccy varchar2 (128);

DELETE FROM task_enrichment_field_config where field_display_name = 'dual_ccy';
INSERT INTO task_enrichment_field_config (field_display_name, field_db_name, field_domain_finder, data_source_class_name, workflow_type, data_source_getter_name, custom_class_name, db_type, db_scale) VALUES ('dual_ccy', 'dual_ccy', null, 'com.calypso.tk.core.Trade', 'Trade', 'getDualCcyTkw', 'calypsox.util.TaskEnrichment', 'string', '128');

commit;

