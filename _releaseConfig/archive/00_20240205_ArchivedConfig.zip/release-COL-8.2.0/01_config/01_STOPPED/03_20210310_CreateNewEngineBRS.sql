DELETE FROM ENGINE_CONFIG WHERE ENGINE_NAME='SenderEngineBRS_Psystem';
Insert into ENGINE_CONFIG (ENGINE_ID,ENGINE_NAME,ENGINE_COMMENT,VERSION_NUM) values ((select max(ENGINE_ID)+1 from ENGINE_CONFIG),'SenderEngineBRS_Psystem',null,'722');

DELETE FROM ENGINE_PARAM WHERE ENGINE_NAME='SenderEngineBRS_Psystem';
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SenderEngineBRS_Psystem','PricingEnv','DirtyPrice');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SenderEngineBRS_Psystem','CLASS_NAME','com.calypso.engine.advice.SenderEngine');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SenderEngineBRS_Psystem','STARTUP','true');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SenderEngineBRS_Psystem','INSTANCE_NAME','gen_engineserver');
Insert into ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SenderEngineBRS_Psystem','DISPLAY_NAME','SenderEngineBRS_Psystem');


DELETE FROM PS_EVENT_CONFIG WHERE ENGINE_NAME='SenderEngineBRS_Psystem';
Insert into PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) values ('Back-Office','PSEventTrade','SenderEngineBRS_Psystem');

DELETE FROM PS_EVENT_FILTER WHERE ENGINE_NAME='SenderEngineBRS_Psystem';
Insert into CALYPSO.PS_EVENT_FILTER (EVENT_CONFIG_NAME,ENGINE_NAME,EVENT_FILTER) values ('Back-Office','SenderEngineBRS_Psystem','P37SenderEngineEventFilter');
