-- Actualiza el campo payment_holidays para eliminar los que sean 'PORTUGAL ' y sustituirlos por 'PORTUGAL' (sin el espacio final)
UPDATE product_cash SET payment_holidays='PORTUGAL,TARGET' WHERE payment_holidays LIKE 'PORTUGAL ,TARGET';
UPDATE product_cash SET payment_holidays='PORTUGAL' WHERE payment_holidays LIKE 'PORTUGAL ';
