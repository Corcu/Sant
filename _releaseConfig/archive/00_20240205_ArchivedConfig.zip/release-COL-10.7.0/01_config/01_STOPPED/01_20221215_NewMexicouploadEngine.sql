DELETE FROM CALYPSO.ENGINE_CONFIG WHERE ENGINE_NAME='MexUploadImportMessageEngine';
Insert into CALYPSO.ENGINE_CONFIG (ENGINE_ID,ENGINE_NAME,ENGINE_COMMENT,VERSION_NUM) values ((select max(ENGINE_ID)+1 from CALYPSO.ENGINE_CONFIG),'MexUploadImportMessageEngine','Starts and stops MexUploadImportMessageEngine','500');

-- Cargando engine params
DELETE FROM ENGINE_PARAM WHERE ENGINE_NAME='MexUploadImportMessageEngine';
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MexUploadImportMessageEngine','DISPLAY_NAME','MexUploadImportMessageEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MexUploadImportMessageEngine','CLASS_NAME','calypsox.engine.MexicoUploadImportMessageEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MexUploadImportMessageEngine','STARTUP','true');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MexUploadImportMessageEngine','INSTANCE_NAME','imp_engineserver');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MexUploadImportMessageEngine','config','calypso_mexico_config.properties');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MexUploadImportMessageEngine','sendResponse','true');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MexUploadImportMessageEngine','type','Mexico');


DELETE FROM PS_EVENT_CONFIG WHERE ENGINE_NAME='MexUploadImportMessageEngine';
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventUpload','MexUploadImportMessageEngine');

DELETE FROM PS_EVENT_FILTER WHERE ENGINE_NAME='MexUploadImportMessageEngine';
Insert into CALYPSO.PS_EVENT_FILTER (EVENT_CONFIG_NAME,ENGINE_NAME,EVENT_FILTER) values ('Back-Office','MexUploadImportMessageEngine','PSEventUploadMexicoEventFilter');
