UPDATE INV_SEC_BALANCE SET TOTAL_SECURITY = 0, TOTAL_MARGIN_CALL_REHYPO=0
WHERE (inv_sec_balance.internal_external = 'MARGIN_CALL' AND inv_sec_balance.position_type = 'ACTUAL' AND inv_sec_balance.date_type = 'SETTLE')
AND inv_sec_balance.mcc_id = 12081778 AND inv_sec_balance.config_id = 0 AND inv_sec_balance.security_id = 11677;

UPDATE INV_SEC_BALANCE SET TOTAL_SECURITY = 0, TOTAL_MARGIN_CALL_REHYPO=0
WHERE (inv_sec_balance.internal_external = 'MARGIN_CALL' AND inv_sec_balance.position_type = 'ACTUAL' AND inv_sec_balance.date_type = 'SETTLE')
AND inv_sec_balance.mcc_id = 18140976 AND inv_sec_balance.config_id = 0 AND inv_sec_balance.security_id IN (10475598,71335,16125,13630,13619,13666,9710);

UPDATE INV_SEC_BALANCE SET TOTAL_SECURITY = 0, TOTAL_MARGIN_CALL_REHYPO=0
WHERE (inv_sec_balance.internal_external = 'MARGIN_CALL' AND inv_sec_balance.position_type = 'ACTUAL' AND inv_sec_balance.date_type = 'SETTLE')
AND inv_sec_balance.mcc_id = 10715652 AND inv_sec_balance.config_id = 0 AND inv_sec_balance.security_id IN (630015, 18050);

UPDATE INV_SEC_BALANCE SET TOTAL_SECURITY = 0, TOTAL_MARGIN_CALL_REHYPO=0
WHERE (inv_sec_balance.internal_external = 'MARGIN_CALL' AND inv_sec_balance.position_type = 'ACTUAL' AND inv_sec_balance.date_type = 'SETTLE')
AND inv_sec_balance.mcc_id = 14756871 AND inv_sec_balance.config_id = 0 AND inv_sec_balance.security_id = 12694;