DELETE FROM CALYPSO.ENGINE_CONFIG WHERE ENGINE_NAME='MailingAlertEngine';
Insert into CALYPSO.ENGINE_CONFIG (ENGINE_ID,ENGINE_NAME,ENGINE_COMMENT,VERSION_NUM) values ((select max(ENGINE_ID)+1 from CALYPSO.ENGINE_CONFIG),'MailingAlertEngine','Starts and stops MailingAlertEngine','500');

-- Cargando engine params
DELETE FROM ENGINE_PARAM WHERE ENGINE_NAME='MailingAlertEngine';
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MailingAlertEngine','DISPLAY_NAME','MailingAlertEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MailingAlertEngine','CLASS_NAME','calypsox.tk.engine.mail.MailingAlertEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MailingAlertEngine','STARTUP','true');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MailingAlertEngine','INSTANCE_NAME','exp_engineserver');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MailingAlertEngine','EVENT_POOL_POLICY','FIFO');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MailingAlertEngine','PricingEnv','OFFICIAL_ACCOUNTING');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('MailingAlertEngine','THREAD_COUNT','1');


DELETE FROM PS_EVENT_CONFIG WHERE ENGINE_NAME='MailingAlertEngine';
INSERT INTO CALYPSO.PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventMailingAlert','MailingAlertEngine');