$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="lago/backup"
$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="swapone/backup"