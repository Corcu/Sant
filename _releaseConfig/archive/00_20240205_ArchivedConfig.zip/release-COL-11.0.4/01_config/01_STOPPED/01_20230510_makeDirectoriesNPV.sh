$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="bond/npv"
$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="bond/npv/export"
$OCD_SCRIPTS_HOME/utils/unix/createDir.sh --dir="bond/npv/export/processed"