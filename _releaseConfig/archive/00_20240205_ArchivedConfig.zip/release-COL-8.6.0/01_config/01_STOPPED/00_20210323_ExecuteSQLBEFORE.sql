WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK;

declare
    v_count integer := 0;
begin
    select count(*) into v_count from calypso_info where major_version = 16 and minor_version = 1 and patch_version = '53';
    
    IF (v_count=0) THEN
       RAISE_APPLICATION_ERROR(-20000, 'Test failed'); 
    END IF;
END;
/

WHENEVER SQLERROR CONTINUE NONE;

set define off;



-- Remove index so that Calypso can recreate it with other numeration and assign it
DECLARE index_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO index_count
    FROM USER_INDEXES
    WHERE INDEX_NAME = 'IDX_FX_FLEXI_FORWARD2';

    IF index_count > 0 THEN
    EXECUTE IMMEDIATE 'DROP INDEX IDX_FX_FLEXI_FORWARD2';
    END IF;
END;
/

-- Remove index so that Calypso can recreate it with other numeration and assign it
DECLARE index_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO index_count
    FROM USER_INDEXES
    WHERE INDEX_NAME = 'IDX_FX_FLEXI_FORWARD3';

    IF index_count > 0 THEN
    EXECUTE IMMEDIATE 'DROP INDEX IDX_FX_FLEXI_FORWARD3';
    END IF;
END;
/

-- Remove index so that Calypso can recreate it with other numeration and assign it
DECLARE index_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO index_count
    FROM USER_INDEXES
    WHERE INDEX_NAME = 'IDX_FX_FLEXI_FORWARD4';

    IF index_count > 0 THEN
    EXECUTE IMMEDIATE 'DROP INDEX IDX_FX_FLEXI_FORWARD4';
    END IF;
END;
/

-- Remove index so that Calypso can recreate it with other numeration and assign it
DECLARE index_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO index_count
    FROM USER_INDEXES
    WHERE INDEX_NAME = 'IDX_FX_FLEXI_FORWARD7';

    IF index_count > 0 THEN
    EXECUTE IMMEDIATE 'DROP INDEX IDX_FX_FLEXI_FORWARD7';
    END IF;
END;
/

-- Remove index so that Calypso can recreate it with other numeration and assign it
DECLARE index_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO index_count
    FROM USER_INDEXES
    WHERE INDEX_NAME = 'IDX_FX_FLEXI_FORWARD20';

    IF index_count > 0 THEN
    EXECUTE IMMEDIATE 'DROP INDEX IDX_FX_FLEXI_FORWARD20';
    END IF;
END;
/

-- Remove index so that Calypso can recreate it with other numeration and assign it
DECLARE index_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO index_count
    FROM USER_INDEXES
    WHERE INDEX_NAME = 'IDX_FX_FLEXI_FORWARD32';

    IF index_count > 0 THEN
    EXECUTE IMMEDIATE 'DROP INDEX IDX_FX_FLEXI_FORWARD32';
    END IF;
END;
/

-- Remove index so that Calypso can recreate it with other numeration and assign it
DECLARE index_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO index_count
    FROM USER_INDEXES
    WHERE INDEX_NAME = 'IDX_FX_FLEXI_FORWARD22';

    IF index_count > 0 THEN
    EXECUTE IMMEDIATE 'DROP INDEX IDX_FX_FLEXI_FORWARD22';
    END IF;
END;
/

-- Remove index so that Calypso can recreate it with other numeration and assign it
DECLARE index_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO index_count
    FROM USER_INDEXES
    WHERE INDEX_NAME = 'IDX_FX_FLEXI_FORWARD34';

    IF index_count > 0 THEN
    EXECUTE IMMEDIATE 'DROP INDEX IDX_FX_FLEXI_FORWARD34';
    END IF;
END;
/

-- Calypso always tries to add this engine again
DELETE FROM engine_config WHERE ENGINE_NAME = 'ACADIAMessageEngine';

