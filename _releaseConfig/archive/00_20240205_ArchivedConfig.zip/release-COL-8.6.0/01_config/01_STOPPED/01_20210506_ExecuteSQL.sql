WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK;

declare
    v_count integer := 0;
begin
    select count(*) into v_count from calypso_info where major_version = 16 and minor_version = 1 and patch_version = '53';
    
    IF (v_count=0) THEN
       RAISE_APPLICATION_ERROR(-20000, 'Test failed, Calypso version is not correct for migration.'); 
    END IF;
END;
/

WHENEVER SQLERROR CONTINUE NONE;

set define off;



/* Applying Schema Statements - start */


    ALTER TABLE collateral_config ADD (default_optim_currency varchar2 (3)  NULL,triparty_trade_id numeric DEFAULT 0 NOT NULL)
/

    ALTER TABLE exposure_group_definition ADD triparty_trade_id numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE margin_call_entries ADD (cpty_act_tot_mrg float NULL,cpty_nonset_tot_mrg float NULL,cpty_total_prev_mrg float NULL)
/

    ALTER TABLE pending_margin_call_entries ADD (cpty_act_tot_mrg float NULL,cpty_nonset_tot_mrg float NULL,cpty_total_prev_mrg float NULL)
/

    ALTER TABLE mrgcall_entries_hist ADD (cpty_act_tot_mrg float NULL,cpty_nonset_tot_mrg float NULL,cpty_total_prev_mrg float NULL)
/

    CREATE TABLE posting_position (
        posting_position_id numeric  NOT NULL,
         trade_id numeric  DEFAULT 0 NOT NULL,
         second_trade_id numeric  DEFAULT 0 NOT NULL,
         posting_type varchar2 (8) DEFAULT 'trade' NOT NULL,
         book_id numeric  DEFAULT 0 NOT NULL,
         matching_criteria_id numeric  NOT NULL,
         pl_config_id numeric  DEFAULT 0 NOT NULL,
         event_type varchar2 (64) NOT NULL,
         amount float  NOT NULL,
         currency varchar2 (8) NOT NULL,
         original_currency varchar2 (8) NOT NULL,
         product_type varchar2 (64) NOT NULL,
         val_date timestamp  NULL,
         date_type varchar2 (32) DEFAULT 'EffectiveDate' NULL,
         account_id numeric  NULL,
         account_name varchar2 (64) NOT NULL,
         opl_measure varchar2 (64) NOT NULL,
         pl_position_id float  NOT NULL 
    ) 
/

    CREATE TABLE matching_criteria (
        id numeric  NOT NULL,
         config_id numeric  NOT NULL,
         product_type varchar2 (64) NOT NULL,
         accounting_book_id numeric  NOT NULL,
         account_id numeric  NOT NULL,
         event varchar2 (64) NOT NULL,
         currency varchar2 (64) DEFAULT 'ANY' NOT NULL,
         opl_category varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE pl_acc_matching_config (
        id numeric  NOT NULL,
         opl_config_id numeric  NOT NULL 
    ) 
/

    CREATE TABLE posting_processing_info (
        external_pk numeric  NOT NULL,
         pl_position_id numeric  DEFAULT 0 NOT NULL,
         is_credit numeric  NOT NULL,
         is_deleted numeric  DEFAULT 0 NOT NULL 
    ) 
/

    ALTER TABLE margin_addon ADD calculation_set varchar2 (255)  DEFAULT 'Default' NOT NULL
/

    ALTER TABLE margin_addon_hist ADD calculation_set varchar2 (255)  DEFAULT 'Default' NOT NULL
/

    ALTER TABLE margin_addon_temp ADD calculation_set varchar2 (255)  DEFAULT 'Default' NOT NULL
/

    ALTER TABLE value_date_control_config ADD timezone varchar2 (32)  NULL
/

    CREATE TABLE outgoing_message_identifier (
        config_id numeric  NOT NULL,
         version_num numeric  NULL,
         template varchar2 (64) NOT NULL,
         method varchar2 (32) NOT NULL,
         object_identifier varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE iso_20022_external_code (
        iso_20022_external_code_id numeric  NOT NULL,
         version_num numeric  NULL,
         type varchar2 (32) NOT NULL,
         code varchar2 (4) NOT NULL,
         name varchar2 (255) NOT NULL,
         definition varchar2 (1000) NOT NULL 
    ) 
/

    ALTER TABLE margin_regulator ADD (post_currency varchar2 (100)  NULL,collect_currency varchar2 (100)  NULL)
/

    ALTER TABLE margin_regulator_schedule ADD direction varchar2 (16)  NULL
/

    ALTER TABLE margin_local_simm_regulator ADD direction varchar2 (16)  NULL
/

    ALTER TABLE margin_regulator_multiplier ADD direction varchar2 (16)  NULL
/

    ALTER TABLE margin_regulator_addon ADD direction varchar2 (16)  NULL
/

    ALTER TABLE margin_regulator_fixed_amount ADD direction varchar2 (16)  NULL
/

    CREATE TABLE cm_ia_input_status (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         status varchar2 (255) NOT NULL,
         import_date numeric  NOT NULL 
    ) 
/

    CREATE TABLE cm_ia_status_errors (
        ia_status_id varchar2 (64) NOT NULL,
         errors varchar2 (4000) NOT NULL 
    ) 
/

    CREATE TABLE cm_ia_input (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         valuation_date numeric  NOT NULL,
         trade_id varchar2 (255) NOT NULL,
         account_id varchar2 (255) NOT NULL,
         product_type varchar2 (64) NOT NULL,
         currency varchar2 (3) NOT NULL,
         mtm float  NOT NULL,
         notional float  NOT NULL,
         maturity_tenor varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_calc_request (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         client_request_id varchar2 (255) NULL,
         valuation_date numeric  NOT NULL,
         pricing_env_name varchar2 (255) NULL,
         save_results numeric  DEFAULT 1 NOT NULL,
         status varchar2 (255) NOT NULL,
         methodology varchar2 (10) NOT NULL,
         request_time numeric  NOT NULL 
    ) 
/

    CREATE TABLE cm_calc_request_simm (
        id varchar2 (64) NOT NULL,
         time_horizon varchar2 (255) NOT NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_calc_request_ia (
        id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_calc_request_etd (
        id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_account_calc_request (
        id varchar2 (64) NOT NULL,
         account_id varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_account_calc_request_ia (
        id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_account_calc_request_etd (
        id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_account_calc_request_simm (
        id varchar2 (64) NOT NULL,
         time_horizon varchar2 (255) NOT NULL,
         calculation_set_id varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_calc_request_simm_acc_id (
        client_request_id varchar2 (255) NOT NULL,
         account_ids varchar2 (4000) NOT NULL,
         account_ids_order numeric  NOT NULL 
    ) 
/

    CREATE TABLE cm_calc_request_errors (
        request_id varchar2 (255) NOT NULL,
         error_messages varchar2 (4000) NOT NULL,
         error_messages_order numeric  NOT NULL 
    ) 
/

    CREATE TABLE pfs_lifecycle (
        id numeric  NOT NULL,
         contract_id numeric  NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         term_date timestamp  NULL,
         rollover_date timestamp  NULL,
         rollover_contract numeric  NULL 
    ) 
/

    CREATE TABLE fx_avg_forward_action (
        action_id numeric  NOT NULL,
         related_trade_id numeric  NULL,
         action_type varchar2 (32) NOT NULL,
         product_id numeric  NOT NULL,
         action_datetime timestamp  NOT NULL,
         action_date timestamp  NOT NULL,
         trader varchar2 (32) NULL,
         trade_version numeric  NULL,
         version numeric  NULL 
    ) 
/

    CREATE TABLE fx_avg_forward_action_h (
        action_id numeric  NOT NULL,
         related_trade_id numeric  NULL,
         action_type varchar2 (32) NOT NULL,
         product_id numeric  NOT NULL,
         action_datetime timestamp  NOT NULL,
         action_date timestamp  NOT NULL,
         trader varchar2 (32) NULL,
         trade_version numeric  NULL,
         version numeric  NULL 
    ) 
/

    CREATE TABLE fx_avg_forward_action_data (
        action_id numeric  NOT NULL,
         primary_cur varchar2 (32) NOT NULL,
         quoting_cur varchar2 (32) NOT NULL,
         is_primary_neg_b numeric  DEFAULT 1 NOT NULL,
         settle_date timestamp  NOT NULL,
         alt_settle_date timestamp  NULL,
         negotiated_amount float  NULL,
         non_negotiated_amount float  NULL,
         mkt_spot float  NULL,
         mkt_points_at_orig_mat float  NULL,
         mkt_points_at_action_mat float  NULL 
    ) 
/

    CREATE TABLE fx_avg_forward_action_data_h (
        action_id numeric  NOT NULL,
         primary_cur varchar2 (32) NOT NULL,
         quoting_cur varchar2 (32) NOT NULL,
         is_primary_neg_b numeric  DEFAULT 1 NOT NULL,
         settle_date timestamp  NOT NULL,
         alt_settle_date timestamp  NULL,
         negotiated_amount float  NULL,
         non_negotiated_amount float  NULL,
         mkt_spot float  NULL,
         mkt_points_at_orig_mat float  NULL,
         mkt_points_at_action_mat float  NULL 
    ) 
/

    CREATE TABLE fx_avg_forward_action_attr (
        action_id numeric  NOT NULL,
         action_attr_name varchar2 (255) NOT NULL,
         action_attr_value varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE fx_avg_forward_action_attr_h (
        action_id numeric  NOT NULL,
         action_attr_name varchar2 (255) NOT NULL,
         action_attr_value varchar2 (255) NOT NULL,
         archived_date timestamp  NULL 
    ) 
/
CREATE GLOBAL TEMPORARY TABLE inv_book_id_temp ( query_id numeric  NOT NULL,  book_id numeric  NOT NULL ) ON COMMIT PRESERVE ROWS
/

    ALTER TABLE product_bond ADD (cutoff_lag_holidays varchar2 (128)  NULL,cutoff_lag_for_last_cpn_b numeric NULL,include_ex_div_date_b numeric NULL)
/

    ALTER TABLE product_cap_floor ADD (compound_freq varchar2 (12)  DEFAULT 'NON' NULL,compound_b numeric DEFAULT 0 NOT NULL,cmp_with_spread varchar2 (32)  DEFAULT 'NoCompound' NULL,compound_spread float DEFAULT 0.0 NOT NULL,sample_timing varchar2 (18)  DEFAULT 'BEG_PER' NOT NULL,cmp_cutoff_lag numeric DEFAULT 0 NOT NULL,cmp_cutoff_lag_b numeric DEFAULT 1 NOT NULL,sample_period_shift_b numeric DEFAULT 0 NOT NULL,cut_off_holidays varchar2 (128)  NULL)
/

    CREATE TABLE product_deferred_pl (
        product_id numeric  DEFAULT 0 NOT NULL,
         daycount varchar2 (128) NOT NULL,
         original_contract varchar2 (128) NOT NULL,
         nominal float  DEFAULT 0 NULL 
    ) 
/

    CREATE TABLE product_fx_avg_fwd (
        product_id numeric  NOT NULL,
         spot_rate float  NULL,
         principal_rate float  NULL,
         quoting_rate float  NULL,
         margin float  NULL,
         spot_margin float  NULL,
         forward_margin float  NULL,
         points float  NULL,
         final_rate float  NULL,
         fixing_start timestamp  NULL,
         fixing_end timestamp  NULL,
         fixing_freq varchar2 (12) NULL,
         fixing_holidays varchar2 (128) NULL,
         primary_outstanding float  NULL,
         quoting_outstanding float  NULL,
         custom numeric  NOT NULL,
         unadjusted numeric  NOT NULL,
         day_to_roll_on numeric  NULL,
         roll_on_day numeric  NOT NULL,
         roll_on_end_date numeric  NOT NULL,
         weighted numeric  DEFAULT 0 NOT NULL,
         weight_by_notional numeric  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE fx_fixing_reset_dates (
        product_id numeric  NOT NULL,
         fx_reset numeric  NOT NULL,
         weight float  NULL,
         sample_date_time timestamp  NOT NULL 
    ) 
/

    CREATE TABLE product_fx_opt_swp (
        product_id numeric  NOT NULL,
         pricing_date timestamp  NULL,
         os_primary_amount float  NULL,
         os_quoting_amount float  NULL,
         takeup_start_date timestamp  NULL 
    ) 
/

    ALTER TABLE product_structured_flows ADD (direction_type_principal_b numeric DEFAULT 0 NOT NULL,open_term_bus_day_b numeric DEFAULT 1 NOT NULL)
/

    CREATE TABLE liq_pos_amort_trade_link (
        liquidated_position_id numeric  NOT NULL,
         trade_id numeric  NOT NULL,
         liquidation_date timestamp  NOT NULL 
    ) 
/

    CREATE TABLE swap_amort_trade_link (
        swap_trade_id numeric  NOT NULL,
         trade_id numeric  NOT NULL,
         termination_date timestamp  NOT NULL,
         fee_type varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cashflow_amort_trade_link (
        amort_trade_id numeric  NOT NULL,
         trade_id numeric  NOT NULL,
         cashflow_type varchar2 (64) NOT NULL,
         cashflow_value_date timestamp  NOT NULL 
    ) 
/

    CREATE TABLE user_secret (
        user_name varchar2 (32) NOT NULL,
         secret varchar2 (50) NOT NULL 
    ) 
/

    ALTER TABLE cliquet_formula ADD local_buffer float NULL
/

    ALTER TABLE model_calibration_instrument ADD (swap1_maturity_tenor numeric DEFAULT 0 NOT NULL,swap2_maturity_tenor numeric DEFAULT 0 NOT NULL,swap1_rate float DEFAULT 0.0 NOT NULL,swap2_rate float DEFAULT 0.0 NOT NULL,relative_strike_swap1 numeric DEFAULT 0 NOT NULL,relative_strike_swap2 numeric DEFAULT 0 NOT NULL)
/

    ALTER TABLE model_calibration_inst_hist ADD (swap1_maturity_tenor numeric DEFAULT 0 NOT NULL,swap2_maturity_tenor numeric DEFAULT 0 NOT NULL,swap1_rate float DEFAULT 0.0 NOT NULL,swap2_rate float DEFAULT 0.0 NOT NULL,relative_strike_swap1 numeric DEFAULT 0 NOT NULL,relative_strike_swap2 numeric DEFAULT 0 NOT NULL)
/

    ALTER TABLE module_deployment ADD version numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE ha_hedge_relationship ADD (is_portfolio_cfh numeric DEFAULT 0 NOT NULL,is_portfolio_fvh numeric DEFAULT 0 NOT NULL,automatic_expiration numeric DEFAULT 0 NOT NULL)
/

    ALTER TABLE ha_eff_analysis_filter ADD tag_id numeric DEFAULT 0 NOT NULL
/

    ALTER TABLE ha_portfolio_hedge_def ADD (hedging_instr_both_dir varchar2 (32)  NULL,hedging_trade_filter_name varchar2 (255)  NULL,base_currency varchar2 (3)  NULL,capacity_testing_type varchar2 (64)  NULL,day1_basis_diff float DEFAULT 0 NOT NULL,in_use numeric DEFAULT 0 NOT NULL)
/

    CREATE TABLE ha_pcfh_tag (
        tag_id numeric  NOT NULL,
         portfolio_id numeric  NOT NULL,
         test_mode varchar2 (255) NOT NULL,
         datetime timestamp  NOT NULL,
         test_successful numeric  DEFAULT 0 NOT NULL,
         rank numeric  NOT NULL 
    ) 
/

    CREATE TABLE ha_pcfh_tag_hr_list (
        tag_id numeric  DEFAULT 0 NOT NULL,
         trade_ratio_conf_id numeric  DEFAULT 0 NOT NULL,
         hedge_rel_id numeric  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE ha_trade_ratio_config (
        id numeric  DEFAULT 0 NOT NULL,
         portfolio_id numeric  DEFAULT 0 NOT NULL,
         trade_id numeric  DEFAULT 0 NOT NULL,
         ratio float  DEFAULT 1 NOT NULL,
         classification varchar2 (255) DEFAULT ' ' NOT NULL,
         hypo_trade_date timestamp  NULL,
         hedge_rel_id numeric  DEFAULT 0 NOT NULL,
         rti_id numeric  DEFAULT 0 NOT NULL,
         start_date timestamp  NULL,
         end_date timestamp  NULL 
    ) 
/

    ALTER TABLE decsupp_order ADD (trader_name varchar2 (32)  NULL,bundle_id numeric NULL)
/

    ALTER TABLE decsupp_order_hist ADD bundle_id numeric NULL
/

    CREATE TABLE am_server_config_grouping_map (
        config_name varchar2 (256) NOT NULL,
         grouping_id numeric  NOT NULL 
    ) 
/

    ALTER TABLE accounting_pl_config ADD aplvalues_source varchar2 (32)  NULL
/

    ALTER TABLE accounting_pl_item ADD (original_ccy varchar2 (4)  NULL,book_value decimal (38,15)  NULL,notional_ccy varchar2 (4)  NULL)
/

    CREATE TABLE accounting_pl_item_hist (
        id numeric  NOT NULL,
         version numeric  NOT NULL,
         accountingpl_config_id numeric  NOT NULL,
         tradereference_id varchar2 (255) NOT NULL,
         trade_id numeric  NOT NULL,
         trade_version numeric  NOT NULL,
         is_trade numeric  NOT NULL,
         security_id numeric  NULL,
         book_id numeric  NOT NULL,
         val_date timestamp  NOT NULL,
         val_datetime timestamp  NOT NULL,
         run_name varchar2 (64) NULL,
         accountingpl_ccy varchar2 (4) NOT NULL,
         original_ccy varchar2 (4) NULL,
         asset_value decimal (38,15) NULL,
         unrealized_mtm decimal (38,15) NULL,
         realized_mtm decimal (38,15) NULL,
         unrealized_accretion decimal (38,15) NULL,
         realized_accretion decimal (38,15) NULL,
         unrealized_accrual decimal (38,15) NULL,
         realized_accrual decimal (38,15) NULL,
         unrealized_otherpl decimal (38,15) NULL,
         realized_otherpl decimal (38,15) NULL,
         unsettled_cash decimal (38,15) NULL,
         settled_cash decimal (38,15) NULL,
         nominal_change decimal (38,15) NULL,
         principal_change decimal (38,15) NULL,
         term_mtm decimal (38,15) NULL,
         term_accrual_real_paid decimal (38,15) NULL,
         term_accrual_real_received decimal (38,15) NULL,
         upfront_mtm decimal (38,15) NULL,
         upfront_accrual_payleg decimal (38,15) NULL,
         upfront_accrual_recleg decimal (38,15) NULL,
         upfront_amort_unreal decimal (38,15) NULL,
         upfront_amort_real decimal (38,15) NULL,
         accrual_bought_sold decimal (38,15) NULL,
         write_down decimal (38,15) NULL,
         bought_sold_inflation decimal (38,15) NULL,
         unrealized_inflation decimal (38,15) NULL,
         realized_inflation decimal (38,15) NULL,
         realized_inflation_mtm decimal (38,15) NULL,
         pay_down decimal (38,15) NULL,
         book_value decimal (38,15) NULL,
         notional_ccy varchar2 (4) NULL,
         original_notional decimal (38,15) NULL,
         reported_notional decimal (38,15) NULL,
         current_notional decimal (38,15) NULL,
         reporting_date timestamp  NOT NULL,
         closing_date timestamp  NULL,
         trade_date timestamp  NULL,
         settle_date timestamp  NULL,
         trade_subtype varchar2 (32) NULL,
         sub_type varchar2 (32) NULL,
         open_price decimal (38,15) NULL,
         archived_date timestamp  NULL 
    ) 
/

    CREATE TABLE accounting_pl_item_attr_hist (
        entity_id numeric  NOT NULL,
         entity_type varchar2 (32) NOT NULL,
         attr_name varchar2 (255) NOT NULL,
         attr_type varchar2 (50) DEFAULT 'String' NOT NULL,
         attr_value varchar2 (255) NULL,
         attr_numeric_value float  NULL,
         attr_date_value timestamp  NULL,
         attr_blob blob  NULL,
         archived_date timestamp  NULL 
    ) 
/

    CREATE TABLE ers_a_hierarchy (
        audit_date timestamp  NOT NULL,
         hierarchy_name varchar2 (255) NOT NULL,
         version numeric  NOT NULL,
         node_id numeric  NOT NULL,
         parent_id numeric  NOT NULL,
         node_name varchar2 (255) NOT NULL,
         node_data varchar2 (255) NULL,
         node_key numeric  NOT NULL,
         node_action varchar2 (25) NULL,
         node_type varchar2 (25) NULL 
    ) 
/

    CREATE TABLE ers_a_hierarchy_attribute (
        audit_date timestamp  NOT NULL,
         hierarchy_name varchar2 (255) NOT NULL,
         underlying_id varchar2 (32) NOT NULL,
         underlying_type numeric  NOT NULL,
         version numeric  NOT NULL,
         hierarchy_date timestamp  NOT NULL,
         latest_version numeric  NOT NULL,
         hierarchy_type varchar2 (32) NOT NULL 
    ) 
/

    CREATE TABLE ers_a_hierarchy_node_attribute (
        audit_date timestamp  NOT NULL,
         hierarchy_name varchar2 (255) NOT NULL,
         version numeric  NOT NULL,
         node_id numeric  NOT NULL,
         attribute_name varchar2 (64) NOT NULL,
         attribute_value varchar2 (255) NULL 
    ) 
/

    ALTER TABLE am_columnset_group_columns ADD totals numeric NULL
/

    ALTER TABLE am_widget_columns ADD (widget_column_id varchar2 (256)  NULL,item_index numeric NULL)
/

    CREATE TABLE hc_subsystem (
        subsystem_type varchar2 (100) NOT NULL,
         subsystem_name varchar2 (100) DEFAULT 'NONE' NOT NULL,
         priority varchar2 (25) DEFAULT 'CRITICAL' NOT NULL,
         enabled numeric  DEFAULT 1 NOT NULL 
    ) 
/

    CREATE TABLE hc_sensor (
        subsystem_type varchar2 (100) NOT NULL,
         subsystem_name varchar2 (100) DEFAULT 'NONE' NOT NULL,
         sensor_name varchar2 (100) NOT NULL,
         description varchar2 (255) NULL,
         amber_threshold varchar2 (20) NULL,
         red_threshold varchar2 (20) NULL,
         priority varchar2 (25) DEFAULT 'CRITICAL' NOT NULL,
         enabled numeric  DEFAULT 1 NOT NULL,
         refresh_period numeric  NULL,
         refresh_period_unit varchar2 (10) DEFAULT 'SECONDS' NOT NULL 
    ) 
/

    CREATE TABLE order_bundle (
        bundle_id numeric  NOT NULL,
         bundle_type varchar2 (32) NULL,
         bundle_name varchar2 (255) NULL,
         user_name varchar2 (32) NULL,
         comments varchar2 (255) NULL,
         one_message numeric  NOT NULL,
         version_num numeric  DEFAULT 0 NOT NULL 
    ) 
/

    CREATE TABLE attribute_configuration (
        id numeric  NOT NULL,
         event_class varchar2 (64) NOT NULL,
         att_level numeric  NOT NULL,
         sequence numeric  NOT NULL,
         name varchar2 (64) NOT NULL,
         sd_filter varchar2 (64) NOT NULL,
         value varchar2 (64) NOT NULL,
         version_num numeric  NULL 
    ) 
/

    CREATE TABLE product_code_configuration (
        id numeric  NOT NULL,
         event_class varchar2 (64) NOT NULL,
         att_level numeric  NOT NULL,
         sequence numeric  NOT NULL,
         name varchar2 (64) NOT NULL,
         sd_filter varchar2 (64) NOT NULL,
         value varchar2 (64) NOT NULL,
         version_num numeric  NULL 
    ) 
/

    ALTER TABLE cm_result ADD totalia float NULL
/

    ALTER TABLE cm_result_hist ADD totalia float NULL
/

    ALTER TABLE cm_result_temp ADD totalia float NULL
/

    ALTER TABLE cm_account ADD tradeinclusiondetails_id varchar2 (64)  NULL
/

    ALTER TABLE cm_csa_account_details ADD (external_reference_pay varchar2 (255)  NULL,external_reference_receive varchar2 (255)  NULL)
/

    CREATE TABLE cm_trade_incl_details (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL 
    ) 
/

    CREATE TABLE cm_simm_trade_incl_details (
        id varchar2 (64) NOT NULL,
         start_date numeric  NULL 
    ) 
/

    CREATE TABLE cm_simm_trade_incl_po_map (
        simm_trade_incl_details_id varchar2 (64) NOT NULL,
         processing_org_ids varchar2 (64) NULL 
    ) 
/

    CREATE TABLE cm_simm_trade_incl_cp_map (
        simm_trade_incl_details_id varchar2 (64) NOT NULL,
         counterparty_ids varchar2 (64) NULL 
    ) 
/

    CREATE TABLE cm_ia_account (
        id varchar2 (64) NOT NULL,
         postiaelementdetails_id varchar2 (36) NULL,
         collectiaelementdetails_id varchar2 (36) NOT NULL 
    ) 
/

    CREATE TABLE cm_ia_element_details (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         percentage_basis varchar2 (255) NOT NULL,
         exposure_management varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_ia_element_link (
        ia_element_details_id varchar2 (36) NOT NULL,
         ia_element_id varchar2 (36) NOT NULL 
    ) 
/

    CREATE TABLE cm_ia_element (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         priority numeric  NOT NULL,
         product_type varchar2 (255) NOT NULL,
         currency varchar2 (3) NOT NULL,
         maturity_tenor_from varchar2 (255) NOT NULL,
         maturity_tenor_to varchar2 (255) NOT NULL,
         factor float  NOT NULL 
    ) 
/

    CREATE TABLE cm_acadia_imem_integration (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         tree_id varchar2 (64) NOT NULL,
         crif_file_transaction_id varchar2 (64) NULL,
         exposure_file_transaction_id varchar2 (64) NULL,
         status varchar2 (255) NOT NULL,
         error_file_id varchar2 (64) NULL,
         message varchar2 (255) NULL 
    ) 
/

    CREATE TABLE cm_account_group (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         name varchar2 (255) NOT NULL 
    ) 
/

    CREATE TABLE cm_account_group_ids (
        account_id varchar2 (64) NOT NULL,
         account_group_ids varchar2 (64) NOT NULL 
    ) 
/

    CREATE TABLE cm_product_mapping (
        id varchar2 (64) NOT NULL,
         tenant_id numeric  DEFAULT 0 NOT NULL,
         version numeric  DEFAULT 0 NOT NULL,
         creation_user varchar2 (255) NOT NULL,
         creation_user_type varchar2 (255) NOT NULL,
         creation_date numeric  NOT NULL,
         last_update_user varchar2 (255) NOT NULL,
         last_update_user_type varchar2 (255) NOT NULL,
         last_update_date numeric  NOT NULL,
         product_class varchar2 (255) NOT NULL,
         product_type varchar2 (255) NOT NULL,
         source varchar2 (255) NOT NULL 
    ) 
/


/* Applying Schema Statements - end */



/* Applying xtra statements - start */



/* Applying xtra statements - end */



/* one time install statements - start */



/* one time install statements - end */

/* Pre Upgrade - Start */
CREATE OR REPLACE PROCEDURE add_column_if_not_exists
    (tab_name IN user_tab_columns.table_name%TYPE,
     col_name IN user_tab_columns.column_name%TYPE,
     data_type IN varchar2)
AS
    x number;
BEGIN
    begin
    select count(*) INTO x FROM user_tab_columns WHERE table_name=UPPER(tab_name) and column_name=upper(col_name);
    exception
        when NO_DATA_FOUND THEN
        x:=0;
        when others then
        null;
    end;
    IF x = 0 THEN
        EXECUTE IMMEDIATE 'alter table ' || tab_name || ' add '||col_name||' '||data_type;
    END IF;
END;
/

CREATE OR REPLACE PROCEDURE drop_function ( proc_name IN user_tab_columns.table_name%TYPE) AS
 x number;
BEGIN
   BEGIN
   SELECT count(*) into x FROM user_objects WHERE object_name=UPPER(proc_name) and object_type= 'FUNCTION';
   exception
        when NO_DATA_FOUND THEN
        x:=0;
        when others then
        null;
    end;
    IF x > 0 THEN
       EXECUTE IMMEDIATE 'drop function '|| proc_name;
    END IF;
END drop_function;
/

CREATE OR REPLACE PROCEDURE drop_column_if_exists
    (tab_name IN user_tab_columns.table_name%TYPE,
     col_name IN user_tab_columns.column_name%TYPE)
AS
    x number;
BEGIN
    begin
    select count(*) INTO x FROM user_tab_columns WHERE table_name=UPPER(tab_name) and column_name=upper(col_name);
    exception
        when NO_DATA_FOUND THEN
        x:=0;
        when others then
        null;
    end;
    IF x > 0 THEN
        EXECUTE IMMEDIATE 'alter table ' || tab_name || ' drop column '||col_name;
    END IF;
END;
/

CREATE OR REPLACE PROCEDURE add_domain_values (dname IN varchar2, dvalue in varchar2, ddescription in varchar2) AS
x number :=0 ;
BEGIN
   BEGIN
   SELECT count(*) INTO x FROM domain_values WHERE name= dname and value= dvalue;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:=0;
      WHEN others THEN
         null;
    END;
        if x = 1 then
                execute immediate 'delete from domain_values where name='||chr(39)||dname||chr(39)||' and value ='||chr(39)||dvalue||chr(39);
                execute immediate 'insert into domain_values ( name, value, description )
                VALUES ('||chr(39)||dname||chr(39)||','||chr(39)||dvalue||chr(39)||','||chr(39)||ddescription||chr(39)||')';
        elsif x=0 THEN
	        execute immediate 'insert into domain_values ( name, value, description ) 
                VALUES ('||chr(39)||dname||chr(39)||','||chr(39)||dvalue||chr(39)||','||chr(39)||ddescription||chr(39)||')';
    END IF;
END add_domain_values;
/

CREATE OR REPLACE PROCEDURE delete_domain_values (dname IN varchar2, dvalue in varchar2) AS
x number :=0 ;
BEGIN
   BEGIN
   SELECT count(*) INTO x FROM domain_values WHERE name= dname and value= dvalue;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:=0;
      WHEN others THEN
         null;
    END;
        if x = 1 then
                execute immediate 'delete from domain_values where name='||chr(39)||dname||chr(39)||' and value ='||chr(39)||dvalue||chr(39);
        
    END IF;
END delete_domain_values;
/

CREATE OR REPLACE PROCEDURE drop_fk_on_table (tab_name IN varchar2) AS
BEGIN
   DECLARE cursor c1 IS 
      SELECT table_name, constraint_name FROM user_constraints WHERE constraint_type = 'R' AND table_name=UPPER(tab_name);
   v_sql varchar2(128);
   BEGIN
      FOR c1_rec IN c1 LOOP 
         v_sql := 'ALTER TABLE '||c1_rec.table_name||' DROP CONSTRAINT '||c1_rec.constraint_name;
         EXECUTE IMMEDIATE v_sql;
      END LOOP;
   END;
END;
/

CREATE OR REPLACE PROCEDURE drop_pk_if_exists (tab_name IN varchar2) AS
x number :=0 ;
BEGIN
   BEGIN
   SELECT count(*) INTO x FROM user_constraints WHERE table_name=UPPER(tab_name) and constraint_type= 'P';
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:=0;
      WHEN others THEN
         null;
    END;
    IF x > 0 THEN
       EXECUTE IMMEDIATE 'ALTER TABLE ' ||tab_name||' DROP PRIMARY KEY DROP INDEX';
    END IF;
END drop_pk_if_exists;
/

CREATE OR REPLACE PROCEDURE drop_uk_if_exists (tab_name IN varchar2) AS
x varchar2(100) ;
BEGIN
   BEGIN
   SELECT  c.constraint_name INTO x FROM user_constraints c, user_tables t WHERE t.table_name=UPPER(tab_name) 
   and c.constraint_type= 'U' and t.table_name=c.table_name;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:='0';
      WHEN others THEN
         null;
    END;
    IF x != '0' THEN
       EXECUTE IMMEDIATE 'ALTER TABLE ' ||tab_name||' DROP constraint '||x;
    END IF;
END drop_uk_if_exists;
/

CREATE OR REPLACE PROCEDURE drop_procedure_if_exists

    (proc_name IN user_objects.object_name%TYPE)

AS

    x number;

BEGIN

    begin

    select count(*) INTO x FROM user_objects WHERE object_name=UPPER(proc_name) and object_type = 'PROCEDURE';

    exception

        when NO_DATA_FOUND THEN

        x:=0;

        when others then

        null;

    end;

    IF x > 0 THEN

        EXECUTE IMMEDIATE 'drop procedure ' || UPPER(proc_name);

    END IF;

END drop_procedure_if_exists;
/

CREATE OR REPLACE PROCEDURE drop_uq_on_table (tab_name IN varchar2) AS
BEGIN
   DECLARE cursor c1 IS 
      SELECT table_name, constraint_name FROM user_constraints WHERE constraint_type = 'U' AND table_name=UPPER(tab_name);
   v_sql varchar2(128);
   BEGIN
      FOR c1_rec IN c1 LOOP 
         v_sql := 'ALTER TABLE '||c1_rec.table_name||' DROP CONSTRAINT '||c1_rec.constraint_name;
         EXECUTE IMMEDIATE v_sql;
      END LOOP;
   END;
END;
/

CREATE OR REPLACE PROCEDURE drop_unique_if_exists (tab_name IN varchar2) AS
constraint_name varchar2(255);
BEGIN
   BEGIN
   SELECT constraint_name INTO constraint_name FROM user_constraints WHERE table_name=UPPER(tab_name) and constraint_type= 'U';
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         constraint_name := NULL;
      WHEN others THEN
         null;
    END;
    IF constraint_name IS NOT NULL THEN
       EXECUTE IMMEDIATE 'ALTER TABLE ' ||tab_name||' DROP CONSTRAINT ' || constraint_name || ' DROP INDEX';
    END IF;
END drop_unique_if_exists;
/

CREATE OR REPLACE PROCEDURE drop_table_if_exists
    (tab_name IN varchar2)
AS
    x number :=0 ;
BEGIN
begin
select count(*) INTO x FROM user_tables WHERE table_name=UPPER(tab_name) ;
exception
when NO_DATA_FOUND THEN
x:=0;
when others then null;
end;
IF x > 0 THEN
EXECUTE IMMEDIATE 'drop table ' ||tab_name;
END IF;
END drop_table_if_exists;
/

CREATE OR REPLACE PROCEDURE add_pk_if_not_exists (tab_name IN varchar2, pk_name in varchar2, c_name in varchar2) AS
x number :=0 ;
BEGIN
   BEGIN
   SELECT count(*) INTO x FROM user_constraints WHERE table_name=UPPER(tab_name) and constraint_type= 'P';
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
         x:=0;
      WHEN others THEN
         null;
    END;
    IF x = 0 THEN
       EXECUTE IMMEDIATE 'ALTER TABLE ' ||tab_name||' add constraint '||pk_name||' primary key ('||c_name||')';
    END IF;
END add_pk_if_not_exists;
/

CREATE OR REPLACE
TYPE list_of_names_t IS  
   TABLE of VARCHAR2(100);
/

CREATE OR REPLACE
PROCEDURE run_query_if_tables_exist
    (tab_names IN list_of_names_t, query IN varchar2)
AS
    x number :=0 ;
    y number :=0 ;
BEGIN
	BEGIN
		select count(*) INTO x FROM table(tab_names);
		select count(*) INTO y FROM user_tables WHERE table_name in (select * from table(tab_names));
	END;
	IF x = y THEN
		EXECUTE IMMEDIATE query;
	END IF;
END run_query_if_tables_exist;
/

CREATE OR REPLACE PROCEDURE rename_column_if_exists
    (tab_name IN user_tab_columns.table_name%TYPE,
     col_name IN user_tab_columns.column_name%TYPE,
     new_col_name IN varchar2)
AS
    x number;
	y number;
BEGIN
    begin 
    select count(*) INTO x FROM user_tab_columns WHERE table_name=UPPER(tab_name) and column_name=upper(col_name);
    exception
        when NO_DATA_FOUND THEN
        x:=0;
        when others then
        null;
    end;
    IF x = 1 THEN
        EXECUTE IMMEDIATE 'alter table ' || tab_name || ' rename  column '||col_name||' to '||new_col_name;
    END IF;
END;
/

/* Pre Upgrade - End */
/* Start of the SQL statements from file:MCHFW-1368-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('matching','MCHFW-1368',1,CURRENT_TIMESTAMP,'started')
/

update engine_config set engine_name='MatchingEngine' where engine_name='MatchingEnginePhilippe'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MCHFW-1368' and version=1 and module='matching'
/

/* End of the SQL statements from file:MCHFW-1368-1.sql */
/* Start of the SQL statements from file:MCHFW-1367-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('matching','MCHFW-1367',1,CURRENT_TIMESTAMP,'started')
/

delete from domain_values where name='MessageAttributeCopier' and value='BONYMatching'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MCHFW-1367' and version=1 and module='matching'
/

/* End of the SQL statements from file:MCHFW-1367-1.sql */
/* Start of the SQL statements from file:MGNC-432-ACC-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-432-ACC',1,CURRENT_TIMESTAMP,'started')
/

/* 
  Microservice Account Migration Script - This script needs to evolve to allow new clients to be able to migrate from the 
  old model MGNC 3.x to the latest microservice model)
   
*/

create or replace function current_time_since_epoch return number is
  n_current_time number(38, 0);
begin
  select (to_date(to_char(sysdate, 'MM/DD/YYYY HH24:MI:SS'), 'MM/DD/YYYY HH24:MI:SS') - to_date('19700101', 'YYYYMMDD')) * 24 * 60 * 60 * 1000 into n_current_time from dual;
  return n_current_time;
end current_time_since_epoch;
/

create or replace function random_uuid return VARCHAR2 is
  v_uuid VARCHAR2(40);
begin
  select lower(regexp_replace(rawtohex(sys_guid()), '([A-F0-9]{8})([A-F0-9]{4})([A-F0-9]{4})([A-F0-9]{4})([A-F0-9]{12})', '\1-\2-\3-\4-\5')) into v_uuid from dual;
  return v_uuid;
end random_uuid;
/

/* 
  Create cm_missing_account. This table will contain the currency, the csa status and threshold
*/
create table cm_missing_account 
 AS (select margin_agreement_name name, CAST('PRE_CSA' AS VARCHAR2(64)) csa_status, (CASE WHEN margin_regulator.post_currency is null THEN 'XXX' ELSE margin_regulator.post_currency END) currency, 
  (CASE WHEN margin_regulator.post_currency is null THEN 'XXX' ELSE margin_regulator.post_currency END) post_currency, 
  (CASE WHEN margin_regulator.collect_currency is null THEN 'XXX' ELSE margin_regulator.collect_currency  END) collect_currency,   50000000 post_threshold, 50000000 collect_threshold 
  from margin_regulator
  where margin_agreement_name not in (select name from cm_account)
  and (active_to is null or active_to > CURRENT_DATE) and source = 'INTERNAL')
/

/* 
 Create a Mapping between account and currency
 First - use sensitivities pricing to extract the pe base currency - These account are considered CSA_IN_PLACE
*/
create table cm_account_ref as 
select ms.margin_agreement_name name, pe.base_currency currency, CAST('CSA_IN_PLACE' AS VARCHAR2(64)) csa_status
from
(select margin_agreement_name, pricing_env, row_number() over(partition  by margin_agreement_name order by valuation_date desc) as rn  from margin_sensitivity)  ms, pricing_env pe
where ms.rn = 1 and pe.pricing_env_name = ms.pricing_env
/

/* 
 Add extra record to the mapping table
 Second - use a custom IM_PRICING_ENV attribute of the Collateral Contract 
*/
insert into cm_account_ref(name, currency, csa_status) 
(select ma.name, pe.base_currency, case when regexp_like(im_name.mcc_value, '_PHASE[0-9]+_') 
									then 'PRE_CSA'
									else 'CSA_IN_PLACE'
								   end
	from pricing_env pe, collateral_config_field ccf, cm_missing_account ma, collateral_config_field im_name
	where ccf.mcc_id in (select mcc_id from collateral_config_field where mcc_field = 'IM_PORTFOLIO_NAME' and regexp_replace(mcc_value, '_PHASE[0-9]+_', '_') = ma.name
	and ma.name not in (select name from cm_account_ref))
	and im_name.mcc_id = ccf.mcc_id
	and im_name.mcc_field = 'IM_PORTFOLIO_NAME'
	and pe.pricing_env_name = ccf.mcc_value
	and ccf.mcc_field = 'IM_PRICING_ENV')
/

/* 
  Now update the currency, post_currency, collect_currency of the cm_missing_account table from the cm_account_ref
*/
update cm_missing_account 
set currency = (select currency from cm_account_ref where cm_account_ref.name = cm_missing_account.name)
where currency = 'XXX' and cm_missing_account.name in (select name from cm_account_ref)
/

update cm_missing_account set post_currency = currency, collect_currency = currency 
where post_currency = 'XXX'
/

/* 
  Now update the csa_status of the cm_missing_account table from the cm_account_ref
*/
update cm_missing_account 
set csa_status = (select csa_status from cm_account_ref where cm_account_ref.name = cm_missing_account.name)
where cm_missing_account.name in (select name from cm_account_ref)
/

/* 
  Create cm_account for accounts which where not migrated yet. Picked up the Margin Currency from the Pricing Env Base ccy of the IM_PRICING_ENV Addiitonal Info of the Contract with IM_PORTFOLIO_NAME attribute
  equal to the margin_agreement_name
*/
insert into cm_account (id, tenant_id, version, creation_user, creation_user_type, creation_date, last_update_user, last_update_user_type, last_update_date, 
                        name, currency, methodology, accountdetails_id, csadetails_id, calculator_type)
select RANDOM_UUID(), 0, 0, '00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', CURRENT_TIME_SINCE_EPOCH(),'00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', CURRENT_TIME_SINCE_EPOCH(), 
       cm_missing_account.name, cm_missing_account.currency, 'SIMM', RANDOM_UUID(), RANDOM_UUID(), null 
from cm_missing_account
/

/* Create cm_account_details for newly created accounts */
insert into cm_account_details (id, tenant_id, version, creation_user, creation_user_type, creation_date, last_update_user, last_update_user_type, last_update_date)
(select accountdetails_id, 0, 0, '00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', CURRENT_TIME_SINCE_EPOCH(),'00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', CURRENT_TIME_SINCE_EPOCH() 
 from cm_account a, cm_missing_account ma 
 where  ma.name = a.name and accountdetails_id not in (select id from cm_account_details))
/

/* Create cm_simm_account for newly created accounts */
INSERT INTO cm_simm_account (id, post_currency, collect_currency, post_threshold, collect_threshold)
(select accountdetails_id, ma.post_currency, ma.collect_currency, ma.post_threshold, ma.collect_threshold
 from cm_account a, cm_missing_account ma 
 where ma.name = a.name and accountdetails_id not in (select id from cm_simm_account))
/

/* Create cm_csa_account_details for newly created accounts */
INSERT INTO cm_csa_account_details(id, tenant_id, version, creation_user, creation_user_type, creation_date, last_update_user, last_update_user_type, last_update_date, csa_status) 
(SELECT a.csadetails_id, a.tenant_id, a.version, a.creation_user, a.creation_user_type, a.creation_date, a.last_update_user, a.last_update_user_type, a.last_update_date, ma.csa_status
 from cm_simm_account s, cm_account a, cm_missing_account ma 
 where s.id=a.accountdetails_id  and ma.name = a.name and a.csadetails_id not in (select id from cm_csa_account_details))
/

/* Create Post/Collect regulators, augmenting their meta from the account details*/ 
INSERT INTO cm_flat_simm_param (id, tenant_id, version, creation_date, creation_user,
		  creation_user_type, last_update_date, last_update_user, last_update_user_type, regulator,
		  accountdetails_id, direction, parameter_type, value, criteria)
		  (SELECT random_uuid() id, cm.tenant_id, cm.version,
		  cm.creation_date, cm.creation_user, cm.creation_user_type,
		  cm.last_update_date, cm.last_update_user, cm.last_update_user_type,
		  regexp_substr(mr.post_regulations, '[^,]+', 1, commas.column_value), cm.accountdetails_id, 'Pay', null, null, null
		  from margin_regulator mr, cm_account cm, table(cast(multiset(select level from dual connect by  level <= length (regexp_replace(mr.post_regulations, '[^,]+'))  + 1) as sys.OdciNumberList)) commas 
		  where mr.margin_agreement_name = cm.name and (mr.active_to is null or mr.active_to > CURRENT_DATE) and source = 'INTERNAL' and post_regulations is not null
		  and cm.name in (select name from cm_missing_account))
/

INSERT INTO cm_flat_simm_param (id, tenant_id, version, creation_date, creation_user,
		  creation_user_type, last_update_date, last_update_user, last_update_user_type, regulator,
		  accountdetails_id, direction, parameter_type, value, criteria)
		  (SELECT random_uuid() id, cm.tenant_id, cm.version,
		  cm.creation_date, cm.creation_user, cm.creation_user_type,
		  cm.last_update_date, cm.last_update_user, cm.last_update_user_type,
		  regexp_substr(mr.collect_regulations, '[^,]+', 1, commas.column_value), cm.accountdetails_id, 'Receive', null, null, null
		  from margin_regulator mr, cm_account cm, table(cast(multiset(select level from dual connect by  level <= length (regexp_replace(mr.collect_regulations, '[^,]+'))  + 1) as sys.OdciNumberList)) commas 
		  where mr.margin_agreement_name = cm.name and (mr.active_to is null or mr.active_to > CURRENT_DATE) and source = 'INTERNAL' and collect_regulations is not null
		  and cm.name in (select name from cm_missing_account))
/

/* Actual parameters: Notional Factors */
INSERT INTO cm_flat_simm_param (id, tenant_id, version, creation_date, creation_user,
		  creation_user_type, last_update_date, last_update_user, last_update_user_type, regulator,
		  accountdetails_id, direction, parameter_type, value, criteria)
		  (SELECT random_uuid() id, cm.tenant_id, cm.version,
		  cm.creation_date, cm.creation_user, cm.creation_user_type,
		  cm.last_update_date, cm.last_update_user, cm.last_update_user_type,
		  p.regulator, cm.accountdetails_id, (CASE p.direction WHEN 'PAY' THEN 'Pay' ELSE 'Receive' END), 'NotionalFactor', p.factor, p.isda_product
		  from margin_regulator_addon p, cm_account cm 
		  where p.margin_agreement_name = cm.name and (p.active_to is null or p.active_to > CURRENT_DATE) and source = 'INTERNAL' 
		  and cm.name in (select name from cm_missing_account))
/

/* Actual parameters: Fixed Amount */
INSERT INTO cm_flat_simm_param (id, tenant_id, version, creation_date, creation_user,
		  creation_user_type, last_update_date, last_update_user, last_update_user_type, regulator,
		  accountdetails_id, direction, parameter_type, value, criteria)
		  (SELECT random_uuid() id, cm.tenant_id, cm.version,
		  cm.creation_date, cm.creation_user, cm.creation_user_type,
		  cm.last_update_date, cm.last_update_user, cm.last_update_user_type,
		  p.regulator, cm.accountdetails_id, (CASE p.direction WHEN 'PAY' THEN 'Pay' ELSE 'Receive' END), 'FixedAmount', p.fixed_amount, p.currency
		  from margin_regulator_fixed_amount p, cm_account cm 
		  where p.margin_agreement_name = cm.name and (p.active_to is null or p.active_to > CURRENT_DATE) and source = 'INTERNAL' 
		  and cm.name in (select name from cm_missing_account))
/

/* Actual parameters: Fixed Multiplier */
INSERT INTO cm_flat_simm_param (id, tenant_id, version, creation_date, creation_user,
		  creation_user_type, last_update_date, last_update_user, last_update_user_type, regulator,
		  accountdetails_id, direction, parameter_type, value, criteria)
		  (SELECT random_uuid() id, cm.tenant_id, cm.version,
		  cm.creation_date, cm.creation_user, cm.creation_user_type,
		  cm.last_update_date, cm.last_update_user, cm.last_update_user_type,
		  p.regulator, cm.accountdetails_id, (CASE p.direction WHEN 'PAY' THEN 'Pay' ELSE 'Receive' END), 'Multiplier', p.multiplier, p.product_class
		  from margin_regulator_multiplier p, cm_account cm 
		  where p.margin_agreement_name = cm.name and (p.active_to is null or p.active_to > CURRENT_DATE) and source = 'INTERNAL' 
		  and cm.name in (select name from cm_missing_account))
/

/* Actual parameters: Schedule */
INSERT INTO cm_flat_simm_param (id, tenant_id, version, creation_date, creation_user,
		  creation_user_type, last_update_date, last_update_user, last_update_user_type, regulator,
		  accountdetails_id, direction, parameter_type, criteria)
		  (SELECT random_uuid() id, cm.tenant_id, cm.version,
		  cm.creation_date, cm.creation_user, cm.creation_user_type,
		  cm.last_update_date, cm.last_update_user, cm.last_update_user_type,
		  p.regulator, cm.accountdetails_id, (CASE p.direction WHEN 'PAY' THEN 'Pay' ELSE 'Receive' END), 'ScheduleProduct', p.isda_product
		  from margin_regulator_schedule p, cm_account cm 
		  where p.margin_agreement_name = cm.name and (p.active_to is null or p.active_to > CURRENT_DATE) and source = 'INTERNAL' 
		  and cm.name in (select name from cm_missing_account))
/

/* Actual parameters: LocalReg */
INSERT INTO cm_flat_simm_param (id, tenant_id, version, creation_date, creation_user,
		  creation_user_type, last_update_date, last_update_user, last_update_user_type, regulator,
		  accountdetails_id, direction, parameter_type, criteria)
		  (SELECT random_uuid() id, cm.tenant_id, cm.version,
		  cm.creation_date, cm.creation_user, cm.creation_user_type,
		  cm.last_update_date, cm.last_update_user, cm.last_update_user_type,
		  p.regulator, cm.accountdetails_id, (CASE p.direction WHEN 'PAY' THEN 'Pay' ELSE 'Receive' END), 'LocalRegSIMM', p.isda_product
		  from margin_local_simm_regulator p, cm_account cm 
		  where p.margin_agreement_name = cm.name and (p.active_to is null or p.active_to > CURRENT_DATE) and source = 'INTERNAL' 
		  and cm.name in (select name from cm_missing_account))
/

/* Global parameters: Notional Factors */
INSERT INTO cm_flat_simm_param (id, tenant_id, version, creation_date, creation_user, creation_user_type, last_update_date, 
		  last_update_user, last_update_user_type, regulator, accountdetails_id, direction, parameter_type, value, criteria)
		  (SELECT random_uuid(), 0, 0, CURRENT_TIME_SINCE_EPOCH(), '00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', CURRENT_TIME_SINCE_EPOCH(),
		  '00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', p.regulator, null, null, 'NotionalFactor', p.factor, p.isda_product
		  from margin_regulator_addon p 
		  where p.margin_agreement_name is null and (p.active_to is null or p.active_to > CURRENT_DATE) and source = 'INTERNAL' 
		  )
/

/* Global parameters: Fixed Amount */
INSERT INTO cm_flat_simm_param (id, tenant_id, version, creation_date, creation_user,
		  creation_user_type, last_update_date, last_update_user, last_update_user_type, regulator,
		  accountdetails_id, direction, parameter_type, value, criteria)
		  (SELECT random_uuid(), 0, 0, CURRENT_TIME_SINCE_EPOCH(), '00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', CURRENT_TIME_SINCE_EPOCH(),
		  '00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', 
		  p.regulator, null, null, 'FixedAmount', p.fixed_amount, p.currency
		  from margin_regulator_fixed_amount p
		  where p.margin_agreement_name is null and (p.active_to is null or p.active_to > CURRENT_DATE) and source = 'INTERNAL' 
		  )
/

/* Global parameters: Fixed Multiplier */
INSERT INTO cm_flat_simm_param (id, tenant_id, version, creation_date, creation_user,
		  creation_user_type, last_update_date, last_update_user, last_update_user_type, regulator,
		  accountdetails_id, direction, parameter_type, value, criteria)
		  (SELECT random_uuid(), 0, 0, CURRENT_TIME_SINCE_EPOCH(), '00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', CURRENT_TIME_SINCE_EPOCH(),
		  '00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', 
		  p.regulator, null, null, 'Multiplier', p.multiplier, p.product_class
		  from margin_regulator_multiplier p
		  where p.margin_agreement_name is null and (p.active_to is null or p.active_to > CURRENT_DATE) and source = 'INTERNAL' 
		  )
/

/* Global parameters: Schedule */
INSERT INTO cm_flat_simm_param (id, tenant_id, version, creation_date, creation_user,
		  creation_user_type, last_update_date, last_update_user, last_update_user_type, regulator,
		  accountdetails_id, direction, parameter_type, criteria)
		  (SELECT random_uuid(), 0, 0, CURRENT_TIME_SINCE_EPOCH(), '00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', CURRENT_TIME_SINCE_EPOCH(),
		  '00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', 
		  p.regulator, null, null, 'ScheduleProduct', p.isda_product
		  from margin_regulator_schedule p
		  where p.margin_agreement_name is null and (p.active_to is null or p.active_to > CURRENT_DATE) and source = 'INTERNAL' 
		  )
/

/* Global parameters: LocalReg */
INSERT INTO cm_flat_simm_param (id, tenant_id, version, creation_date, creation_user,
		  creation_user_type, last_update_date, last_update_user, last_update_user_type, regulator,
		  accountdetails_id, direction, parameter_type, criteria)
		  (SELECT random_uuid(), 0, 0, CURRENT_TIME_SINCE_EPOCH(), '00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', CURRENT_TIME_SINCE_EPOCH(),
		  '00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', 
		  p.regulator, null, null, 'LocalRegSIMM', p.isda_product
		  from margin_local_simm_regulator p
		  where p.margin_agreement_name is null and (p.active_to is null or p.active_to > CURRENT_DATE) and source = 'INTERNAL' 
		  )
/

/* Global parameters: Keep only one per regulator, parameter_type and criteria */
DELETE from cm_flat_simm_param
WHERE rowid IN
  (SELECT rid
  FROM
    (SELECT rowid rid,
      row_number() over (partition BY regulator, parameter_type, criteria order by regulator) rn
    FROM cm_flat_simm_param
	WHERE accountdetails_id is null
    )
  WHERE rn <> 1
  )
/

/* Global parameters: Create the cm_simm_regulator */
INSERT INTO cm_simm_regulator (id, tenant_id, version, creation_date, creation_user,
          creation_user_type, last_update_date, last_update_user, last_update_user_type, name)
          (SELECT random_uuid(), 0, 0, CURRENT_TIME_SINCE_EPOCH(), '00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', CURRENT_TIME_SINCE_EPOCH(),
		  '00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', p.regulator
          FROM (select distinct regulator from cm_flat_simm_param where accountdetails_id is null or parameter_type is null) p)
/

drop table cm_missing_account
/

drop function random_uuid
/

drop function current_time_since_epoch
/

drop table cm_account_ref
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-432-ACC' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-432-ACC-1.sql */
/* Start of the SQL statements from file:MGNC-432-RF-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-432-RF',1,CURRENT_TIMESTAMP,'started')
/

/* 
  Microservice Risk Factor Migration Script - This script needs to evolve to allow new clients to be able to migrate from the 
  old model MGNC 3.x to the latest microservice model) 
*/
create or replace function current_days_since_input_date(input_date timestamp) return number is
  n_current_days number(38, 0);
begin
  select (to_date(to_char(input_date, 'MM/DD/YYYY'), 'MM/DD/YYYY') - to_date('19700101', 'YYYYMMDD')) into n_current_days from dual;
  return n_current_days;
end current_days_since_input_date;
/

create or replace function current_time_since_epoch return number is
  n_current_time number(38, 0);
begin
  select (to_date(to_char(sysdate, 'MM/DD/YYYY HH24:MI:SS'), 'MM/DD/YYYY HH24:MI:SS') - to_date('19700101', 'YYYYMMDD')) * 24 * 60 * 60 * 1000 into n_current_time from dual;
  return n_current_time;
end current_time_since_epoch;
/

create or replace function random_uuid return VARCHAR2 is
  v_uuid VARCHAR2(40);
begin
  select lower(regexp_replace(rawtohex(sys_guid()), '([A-F0-9]{8})([A-F0-9]{4})([A-F0-9]{4})([A-F0-9]{4})([A-F0-9]{12})', '\1-\2-\3-\4-\5')) into v_uuid from dual;
  return v_uuid;
end random_uuid;
/

/* 
   Create one calculation set for each pricing env in the system 
*/
INSERT INTO cm_calculation_set (id, tenant_id, version, creation_user, creation_user_type, creation_date, last_update_user, last_update_user_type, last_update_date, name, official)
SELECT RANDOM_UUID(), 0, 0, '00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', CURRENT_TIME_SINCE_EPOCH(),'00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', CURRENT_TIME_SINCE_EPOCH(),
pricing_env_name, 0
FROM pricing_env
/

/* 
   Create Source for margin-sensitivities 
*/
INSERT INTO cm_rf_source (id, tenant_id, version, creation_user, creation_user_type, creation_date, last_update_user, last_update_user_type, last_update_date, source)
select  RANDOM_UUID(), 0, 0, '00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', CURRENT_TIME_SINCE_EPOCH(),'00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', CURRENT_TIME_SINCE_EPOCH(),
(CASE source WHEN 'CALCULATE' THEN 'Calypso' ELSE source END) from margin_trade_sensitivity group by source
/

/* 
   Create risk factors  
*/
INSERT INTO cm_rf_trade (id, tenant_id, version, calculation_set_id, creation_user, creation_user_type, creation_date, last_update_user, last_update_user_type, last_update_date, trade_id, trade_sub_id, valuation_date,  party_id, counterparty_id, account_id, im_model, risk_type, product_class, qualifier, bucket, label1, label2, currency, amount, amount_base, source, pricing_env, uti, end_date)
select  RANDOM_UUID(), 0, 0, nvl(cm_calculation_set.id, '00000000-0000-0000-0000-000000000000'), nvl(collect_regulations,' ') , nvl(post_regulations, ' '), CURRENT_TIME_SINCE_EPOCH(),'00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', CURRENT_TIME_SINCE_EPOCH(), 
trade_id, trade_sub_id, current_days_since_input_date(from_tz( cast(margin_trade_sensitivity.valuation_date as timestamp),'GMT') at time zone (SELECT nvl(time_zone, (SELECT DBTIMEZONE FROM DUAL)) s FROM pricing_env where pricing_env_name = pricing_env)), party_id, cp_id, cm_account.id, im_model, risk_type, product_class, qualifier, bucket, label1, label2, amount_ccy, amount, amount_base, 
(CASE source WHEN 'CALCULATE' THEN 'Calypso' ELSE source END), pricing_env, uti, end_date 
from cm_account, margin_trade_sensitivity left join cm_calculation_set on pricing_env = cm_calculation_set.name
where margin_trade_sensitivity.margin_agreement_name = cm_account.name
/

INSERT INTO cm_rf_trade_collect_reg(rf_id, collect_regulators)
select t.id, regexp_substr(t.creation_user, '[^,]+', 1, commas1.column_value)  as regulator from cm_rf_trade t, table(cast(multiset(select level from dual connect by  level <= length (regexp_replace(t.creation_user, '[^,]+'))  + 1) as sys.OdciNumberList)) commas1 where regexp_substr(t.creation_user, '[^,]+', 1, commas1.column_value) is not NULL
/

INSERT INTO cm_rf_trade_post_reg (rf_id, post_regulators)
select t.id, regexp_substr(t.creation_user_type, '[^,]+', 1, commas.column_value)  as regulator from cm_rf_trade t, table(cast(multiset(select level from dual connect by  level <= length (regexp_replace(t.creation_user_type, '[^,]+'))  + 1) as sys.OdciNumberList)) commas where regexp_substr(t.creation_user_type, '[^,]+', 1, commas.column_value) is not NULL
/

update cm_rf_trade set creation_user = '00000000-0000-0000-0000-000000000000', creation_user_type = 'urn:calypso:cloud:platform:iam:model:User'
/

/* 
   Create risk factors status 
*/
INSERT INTO cm_rf_status (id, tenant_id, version, creation_user, creation_user_type, creation_date, last_update_user, last_update_user_type, last_update_date, source, status, import_date, calculation_set_id)
select  RANDOM_UUID(), 0, 0, '00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', CURRENT_TIME_SINCE_EPOCH(),'00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', CURRENT_TIME_SINCE_EPOCH(),
source, 'Imported', valuation_date, calculation_set_id from cm_rf_trade group by source, valuation_date, calculation_set_id
/

/*    
 Create historical risk factors  
*/
INSERT INTO cm_rf_trade_hist (id, tenant_id, version, calculation_set_id, creation_user, creation_user_type, creation_date, last_update_user, last_update_user_type, last_update_date, trade_id, trade_sub_id, valuation_date,  party_id, counterparty_id, account_id, im_model, risk_type, product_class, qualifier, bucket, label1, label2, currency, amount, amount_base, source, pricing_env, uti, end_date)
select  RANDOM_UUID(), 0, 0, nvl(cm_calculation_set.id, '00000000-0000-0000-0000-000000000000'), nvl(collect_regulations,' ') , nvl(post_regulations, ' '), CURRENT_TIME_SINCE_EPOCH(),'00000000-0000-0000-0000-000000000000', 'urn:calypso:cloud:platform:iam:model:User', CURRENT_TIME_SINCE_EPOCH(), 
trade_id, trade_sub_id, current_days_since_input_date(from_tz( cast(margin_trade_sensitivity_hist.valuation_date as timestamp),'GMT') at time zone (SELECT nvl(time_zone, (SELECT DBTIMEZONE FROM DUAL)) s FROM pricing_env where pricing_env_name = pricing_env)), party_id, cp_id, cm_account.id, im_model, risk_type, product_class, qualifier, bucket, label1, label2, amount_ccy, amount, amount_base, 
(CASE source WHEN 'CALCULATE' THEN 'Calypso' ELSE source END), pricing_env, uti, end_date 
from cm_account, margin_trade_sensitivity_hist left join cm_calculation_set on pricing_env = cm_calculation_set.name 
where margin_trade_sensitivity_hist.margin_agreement_name = cm_account.name and margin_trade_sensitivity_hist.pricing_env = cm_calculation_set.name
/

INSERT INTO cm_rf_trade_collect_reg_hist(rf_id, collect_regulators)
select t.id, regexp_substr(t.creation_user, '[^,]+', 1, commas1.column_value)  as regulator from cm_rf_trade_hist t, table(cast(multiset(select level from dual connect by  level <= length (regexp_replace(t.creation_user, '[^,]+'))  + 1) as sys.OdciNumberList)) commas1 where regexp_substr(t.creation_user, '[^,]+', 1, commas1.column_value) is not NULL
/

INSERT INTO cm_rf_trade_post_reg_hist (rf_id, post_regulators)
select t.id, regexp_substr(t.creation_user_type, '[^,]+', 1, commas.column_value)  as regulator from cm_rf_trade_hist t, table(cast(multiset(select level from dual connect by  level <= length (regexp_replace(t.creation_user_type, '[^,]+'))  + 1) as sys.OdciNumberList)) commas where regexp_substr(t.creation_user_type, '[^,]+', 1, commas.column_value) is not NULL
/

update cm_rf_trade_hist set creation_user = '00000000-0000-0000-0000-000000000000', creation_user_type = 'urn:calypso:cloud:platform:iam:model:User'
/

/* Create official flag based of Generate Exposure Trade of the Scheduled Task MARGIN_CALCULATOR*/
UPDATE cm_calculation_set
SET official = 1
WHERE name  IN
  (SELECT DISTINCT pricing_env
  FROM quartz_sched_task
  WHERE task_id IN
    (SELECT task_id FROM quartz_sched_task WHERE task_type = 'MARGIN_CALCULATOR'
    )
  AND task_id IN
    (SELECT task_id
    FROM quartz_sched_task_attr
    WHERE attr_name = 'Generate Exposure Trades'
    AND lower(attr_value)  = 'true'
    )
  )
/

/* Create new Calculation Set attribute derived from calculationSetName = pricingEnv  */
INSERT INTO quartz_sched_task_attr
  (task_id, attr_name, attr_value
  )
SELECT task_id,
  'Calculation Set Id',
  (SELECT id
  FROM cm_calculation_set
  WHERE name = quartz_sched_task.pricing_env
  )
FROM quartz_sched_task
WHERE task_type IN ('MARGIN_CALCULATOR','MARGIN_INPUT')
/

drop function random_uuid
/

drop function current_time_since_epoch
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-432-RF' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-432-RF-1.sql */
/* Start of the SQL statements from file:MGNC-1699-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-1699',1,CURRENT_TIMESTAMP,'started')
/

create or replace function current_time_since_epoch return number is
  n_current_time number(38, 0);
begin
  select (to_date(to_char(sysdate, 'MM/DD/YYYY HH24:MI:SS'), 'MM/DD/YYYY HH24:MI:SS') - to_date('19700101', 'YYYYMMDD')) * 24 * 60 * 60 * 1000 into n_current_time from dual;
  return n_current_time;
end current_time_since_epoch;
/

create or replace function random_uuid return VARCHAR2 is
  v_uuid VARCHAR2(40);
begin
  select lower(regexp_replace(rawtohex(sys_guid()), '([A-F0-9]{8})([A-F0-9]{4})([A-F0-9]{4})([A-F0-9]{4})([A-F0-9]{12})', '\1-\2-\3-\4-\5')) into v_uuid from dual;
  return v_uuid;
end random_uuid;
/

/*  Account Group creation */
/*  Create a temp table account cm_hierarchy_account_map - Populate hierarchy_name and tf column*/
CREATE TABLE cm_hierarchy_account_map AS
SELECT hierarchy_name,
  node_data                    AS tf,
  CAST('ACT_GRP_ID' AS VARCHAR2(64))  AS account_group_id,
  CAST('PORTFOLIO_NAME' AS VARCHAR2(255)) AS portfolio_name
FROM ers_hierarchy
WHERE node_data    IS NOT NULL
AND hierarchy_name IN
  (SELECT attr_value
  FROM quartz_sched_task_attr
  WHERE attr_name in ('Hierarchy Name','Hierarchy')
  AND task_id    IN
    (SELECT task_id
    FROM quartz_sched_task
    WHERE task_type IN ('MARGIN_CALCULATOR', 'MARGIN_INPUT')
    )
  AND attr_value not in (select name from cm_account_group)    
  GROUP BY attr_value
  )
/

/*  Create a account group for each Hierarchy in the cm_hierarchy_account_map */
INSERT
INTO cm_account_group
  (
    id,
    tenant_id,
    version,
    creation_user,
    creation_user_type,
    creation_date,
    last_update_user,
    last_update_user_type,
    last_update_date,
    name
  )
SELECT RANDOM_UUID(),
  0,
  0,
  '00000000-0000-0000-0000-000000000000',
  'urn:calypso:cloud:platform:iam:model:User',
  CURRENT_TIME_SINCE_EPOCH(),
  '00000000-0000-0000-0000-000000000000',
  'urn:calypso:cloud:platform:iam:model:User',
  CURRENT_TIME_SINCE_EPOCH(),
  attr_value
FROM quartz_sched_task_attr
WHERE attr_name in ('Hierarchy Name','Hierarchy')
AND task_id    IN
  (SELECT task_id
  FROM quartz_sched_task
  WHERE task_type IN ('MARGIN_CALCULATOR', 'MARGIN_INPUT')
  )
AND attr_value in (select hierarchy_name from cm_hierarchy_account_map)
GROUP BY attr_value
/

/*  Update the account_group_id column in the mapping table from the cm_account_group */
UPDATE cm_hierarchy_account_map
SET account_group_id =
  (SELECT id
  FROM cm_account_group
  WHERE cm_hierarchy_account_map.hierarchy_name = cm_account_group.name
  )
/

/*  Update the portfolio_name column in the mapping table when criteria is old keyword Criteria */
UPDATE cm_hierarchy_account_map
SET portfolio_name =
  (SELECT criterion_value
  FROM trade_filter_crit
  WHERE criterion_name  = 'keyword.IM_PORTFOLIO_NAME'
  AND trade_filter_name = cm_hierarchy_account_map.tf
  )
WHERE EXISTS
  (SELECT criterion_value
  FROM trade_filter_crit
  WHERE criterion_name  = 'keyword.IM_PORTFOLIO_NAME'
  AND trade_filter_name = cm_hierarchy_account_map.tf
  )
/

/*  Update the portfolio_name column in the mapping table when criteria is new keyword Criteria */
UPDATE cm_hierarchy_account_map
SET portfolio_name =
  (SELECT regexp_replace(condition_tree, '.*?<string>IM_PORTFOLIO_NAME<\/string>.*?<string>_operands<\/string>.*?<object-array>.*?<string>([^<]*)<\/string>.*?<\/com.calypso.ui.component.condition.ConditionTree>', '\1', 1, 1, 'n')
  FROM trade_filter
  WHERE condition_tree IS NOT NULL
  AND trade_filter_name = cm_hierarchy_account_map.tf
  )
WHERE NOT EXISTS
  (SELECT criterion_value
  FROM trade_filter_crit
  WHERE criterion_name  = 'keyword.IM_PORTFOLIO_NAME'
  AND trade_filter_name = cm_hierarchy_account_map.tf
  )
/

/* Add a the AccountGroup ref to the account group mapping table of the account */
INSERT
INTO cm_account_group_ids
  (
    account_id,
    account_group_ids
  )
SELECT DISTINCT
  (SELECT id
  FROM cm_account
  WHERE name = cm_hierarchy_account_map.portfolio_name
  ),
  account_group_id
FROM cm_hierarchy_account_map
WHERE exists (SELECT id
  FROM cm_account
  WHERE name = cm_hierarchy_account_map.portfolio_name)
/

/* Add new Account Group Ids attribute on the MARGIN_INPUT and MARGIN_CALCULATOR ST which had a Hierarchy attribute */
INSERT INTO quartz_sched_task_attr
  (task_id, attr_name, attr_value
  )
SELECT task_id,
  'Account Group Ids',
  (SELECT id
  FROM cm_account_group
  WHERE name = quartz_sched_task_attr.attr_value 
  and quartz_sched_task_attr.attr_name in ('Hierarchy Name','Hierarchy')
  )
FROM quartz_sched_task_attr
WHERE attr_name in ('Hierarchy Name','Hierarchy')
AND task_id IN (SELECT task_id
  FROM quartz_sched_task
  WHERE task_type IN ('MARGIN_CALCULATOR', 'MARGIN_INPUT')
)
/

/* Cleanup TradeFilter on ALL MARGIN UMR ST to make sure the scheduled Task will keep using Hierarchy post migration */
update quartz_sched_task set trade_filter = null WHERE task_type IN ('MARGIN_CALCULATOR', 'MARGIN_INPUT')
/

/* Clean up */
drop table cm_hierarchy_account_map
/

drop function random_uuid
/

drop function current_time_since_epoch
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-1699' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-1699-1.sql */
/* Start of the SQL statements from file:MGNC-1937-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('margin-calculator-unrestricted','MGNC-1937',1,CURRENT_TIMESTAMP,'started')
/

create or replace function current_time_since_epoch return number is
  n_current_time number(38, 0);
begin
  select (to_date(to_char(sysdate, 'MM/DD/YYYY HH24:MI:SS'), 'MM/DD/YYYY HH24:MI:SS') - to_date('19700101', 'YYYYMMDD')) * 24 * 60 * 60 * 1000 into n_current_time from dual;
  return n_current_time;
end current_time_since_epoch;
/

create or replace function random_uuid return VARCHAR2 is
  v_uuid VARCHAR2(40);
begin
  select lower(regexp_replace(rawtohex(sys_guid()), '([A-F0-9]{8})([A-F0-9]{4})([A-F0-9]{4})([A-F0-9]{4})([A-F0-9]{12})', '\1-\2-\3-\4-\5')) into v_uuid from dual;
  return v_uuid;
end random_uuid;
/

/*  Insert values from the domain value MarginInput.SCHEDULE.ProductClass into product mapping */
INSERT
INTO cm_product_mapping
  (
    id,
    tenant_id,
    version,
    creation_user,
    creation_user_type,
    creation_date,
    last_update_user,
    last_update_user_type,
    last_update_date,
    product_type,
    product_class,
    source
  )
SELECT RANDOM_UUID(),
  0,
  0,
  '00000000-0000-0000-0000-000000000000',
  'urn:calypso:cloud:platform:iam:model:User',
  CURRENT_TIME_SINCE_EPOCH(),
  '00000000-0000-0000-0000-000000000000',
  'urn:calypso:cloud:platform:iam:model:User',
  CURRENT_TIME_SINCE_EPOCH(),
  value,
  UPPER(description),
  'CUSTOM'
FROM domain_values
WHERE name = 'MarginInput.SCHEDULE.ProductClass'
and value not in ('CDSABSIndex',
'CDSABSIndexTranche',
'CDSIndex',
'CDSIndexDefinition',
'CDSIndexOption',
'CDSIndexTranche',
'CDSIndexTrancheOption',
'CDSNthDefault',
'CDSNthLoss',
'CFDConvertibleArbitrage',
'CFDDirectional',
'CFDPairTrading',
'CFDRiskArbitrage',
'CancellableCDS',
'CancellableCDSNthDefault',
'CancellableCDSNthLoss',
'CancellableSwap',
'CancellableXCCYSwap',
'CapFloor',
'CappedSwap',
'CappedSwapNonDeliverable',
'Commodity',
'CommodityCertificate',
'CommodityForward',
'CommodityIndexSwap',
'CommodityOTCOption2',
'CommoditySwap',
'CommoditySwap2',
'CommoditySwaption',
'ContingentCreditDefaultSwap',
'CreditDefaultSwap',
'CreditDefaultSwapABS',
'CreditDefaultSwapLoan',
'CreditDefaultSwaption',
'EquityCliquetOption',
'EquityForward',
'EquityIndex',
'EquityLinkedSwap',
'EquityStructuredOption',
'ExoticCapFloor',
'ExtendibleCDS',
'ExtendibleCDSNthDefault',
'ExtendibleCDSNthLoss',
'FRA',
'FRAInArrear',
'FRAStandard',
'FXCompoundOption',
'FXNDF',
'FXNDFSwap',
'FXOption',
'FXOptionForward',
'FXOptionStrategy',
'FXOptionStrip',
'FXOptionSwap',
'FxSwap',
'IRStructuredOption',
'OTCCommodityOption','OTCEquityOption',
'OTCEquityOptionVanilla',
'PerformanceSwap',
'PortfolioSwap',
'PortfolioSwapPosition',
'PositionFXExposure',
'PositionFXNDF',
'PreciousMetalDepositLease',
'PreciousMetalLeaseRateSwap',
'QuotableStructuredOption',
'ScriptableOTCProduct',
'SingleSwapLeg',
'SpreadCapFloor',
'SpreadLock',
'SpreadSwap',
'StructureProduct',
'StructuredTranche',
'Swap',
'SwapCrossCUrrency',
'SwapNonDeliverable',
'Swaption',
'TRSBasket',
'TotalReturnSwap',
'TriggerSwaption',
'VarianceOption',
'VarianceSwap',
'VolatilityIndex',
'Warrant',
'WarrantIssuance',
'XCCYSwap')
and not exists (select 1 from cm_product_mapping
where product_type = value)
/

drop function random_uuid
/

drop function current_time_since_epoch
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='MGNC-1937' and version=1 and module='margin-calculator-unrestricted'
/

/* End of the SQL statements from file:MGNC-1937-1.sql */
/* Start of the SQL statements from file:CAL-402506-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-402506',1,CURRENT_TIMESTAMP,'started')
/

delete from vol_quote_adj where adj_value=0
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-402506' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-402506-1.sql */
/* Start of the SQL statements from file:CAL-398553-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-398553',1,CURRENT_TIMESTAMP,'started')
/

update product_swap set opt_cal_offset =(select settlement_lag from product_call_info where product_call_info.product_id = product_swap.product_id)
/

update product_swap set opt_cal_bus_b =(select settlement_lag_bus_day_b from product_call_info where product_call_info.product_id = product_swap.product_id)
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-398553' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-398553-1.sql */
/* Start of the SQL statements from file:CAL-387751-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-387751',1,CURRENT_TIMESTAMP,'started')
/

UPDATE  DECSUPP_ORDER SET trader_name = portfolio_manager
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-387751' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-387751-1.sql */
/* Start of the SQL statements from file:CAL-385115-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-385115',1,CURRENT_TIMESTAMP,'started')
/

/* A function generating random alphanumeric strings */
create or replace function random_alnum(v_length number) return varchar2 is
    my_str varchar2(4000);
begin
    for i in 1..v_length loop
        my_str := my_str || dbms_random.string(
            case when dbms_random.value(0, 1) < 0.42 then 'l' else 'x' end, 1);
    end loop;
    return my_str;
end;
/

/* Creates a user_secret row for any user_name row which is not yet represented in user_secret */
INSERT INTO user_secret
    select user_name, random_alnum(50) from user_name where user_name not in (select user_name from user_secret)
/

drop function random_alnum
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-385115' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-385115-1.sql */
/* Start of the SQL statements from file:CAL-385115-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-385115',1,CURRENT_TIMESTAMP,'started')
/

/* A function generating random alphanumeric strings */
create or replace function random_alnum(v_length number) return varchar2 is
    my_str varchar2(4000);
begin
    for i in 1..v_length loop
        my_str := my_str || dbms_random.string(
            case when dbms_random.value(0, 1) < 0.42 then 'l' else 'x' end, 1);
    end loop;
    return my_str;
end;
/

/* Creates a user_secret row for any user_name row which is not yet represented in user_secret */
INSERT INTO user_secret
    select user_name, random_alnum(50) from user_name where user_name not in (select user_name from user_secret)
/

drop function random_alnum
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-385115' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-385115-1.sql */
/* Start of the SQL statements from file:CAL-395095-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-395095',1,CURRENT_TIMESTAMP,'started')
/

delete from DOMAIN_VALUES where name = 'Structured_Flows_Forward_Settle_Notional' and value = 'false'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-395095' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-395095-1.sql */
/* Start of the SQL statements from file:CAL-396804-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-396804',1,CURRENT_TIMESTAMP,'started')
/

update pricer_measure set measure_id='535' where measure_name='FX_PL'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-396804' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-396804-1.sql */
/* Start of the SQL statements from file:CAL-392498-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-392498',1,CURRENT_TIMESTAMP,'started')
/

delete from domain_values where name = 'eventType' and value= 'EX_ERS_SEM_INFORMATION'
/

delete from domain_values where name = 'eventType' and value= 'EX_ERS_SEM_EXCEPTION'
/

delete from domain_values where name = 'eventType' and value= 'EX_ERS_ANALYSIS_EXCEPTION'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-392498' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-392498-1.sql */
/* Start of the SQL statements from file:CAL-400687-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-400687',1,CURRENT_TIMESTAMP,'started')
/

/* Remove all the references to the DataWarehouseRiskEngine engine  */
DECLARE
   cnt_engine_config_rows INT;
  cnt_engine_param_rows INT; 
BEGIN
	SELECT COUNT(*) INTO cnt_engine_config_rows FROM engine_config where engine_name in ('DataWarehouseRiskEngine');
    SELECT COUNT(*) INTO cnt_engine_param_rows FROM engine_param where engine_name in ('DataWarehouseRiskEngine');
    
	IF ( cnt_engine_config_rows > 0 or cnt_engine_param_rows > 0 ) THEN
		delete from ps_event_filter where engine_name in ('DataWarehouseRiskEngine');
		delete from ps_event_config where engine_name in ('DataWarehouseRiskEngine');
		delete from engine_param where engine_name in ('DataWarehouseRiskEngine');
		delete from engine_config where engine_name in ('DataWarehouseRiskEngine');
	END IF;
END;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-400687' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-400687-1.sql */
/* Start of the SQL statements from file:CAL-390866-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-390866',1,CURRENT_TIMESTAMP,'started')
/

/* RPM-2857 - Support OPL and other position valuation after position archiving */
/* FutureOption and ETO trades will have a TOQ per EXERCISE_FEE linked to the product position. */
/* We want to start tracking the total fees amount separately from total position realized, in the "total_interest" column. */
/* This update statement intializes total_interest for existing positions using an "updatable view". */
/* The updatable view query must unambiguously return each row of the modified table (pl_position) only one time. This is assured with 'group by position_id'. */
/* The query must also be “key preserved�?, i.e. Oracle must be able to use a primary key or unique constraint to ensure that each row is only modified once.   */
/* The pl_position table does have a unique constraint on position_id. */

/* Update 1 : initialize fee total from primary TOQ table */
update 
(select pl_position.total_interest, feetoq.totalfee
from pl_position,

(select position_id, sum(price) as totalfee 
from trade_open_qty 
where product_family='REALIZED' and (product_type like 'FutureOption%' or product_type like 'ETO%')
group by position_id
) feetoq

where pl_position.position_id = feetoq.position_id
) pl_position_view

set pl_position_view.total_interest = pl_position_view.totalfee
/

/* Update 2 : update fee total from TOQ history in case archiving has already been done (note pl_position_hist table is not used!) */
update 
(select pl_position.total_interest, feetoq_hist.totalfee
from pl_position,

(select position_id, sum(price) as totalfee 
from trade_openqty_hist
where product_family='REALIZED' and (product_type like 'FutureOption%' or product_type like 'ETO%')
group by position_id
) feetoq_hist

where pl_position.position_id = feetoq_hist.position_id
) pl_position_view

set pl_position_view.total_interest = pl_position_view.total_interest + pl_position_view.totalfee
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-390866' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-390866-1.sql */
/* Start of the SQL statements from file:CAL-400980-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-400980',1,CURRENT_TIMESTAMP,'started')
/

delete from domain_values where name = 'eventType' and value= 'EX_ERS_SEM_INFORMATION'
/

delete from domain_values where name = 'eventType' and value= 'EX_ERS_SEM_EXCEPTION'
/

delete from domain_values where name = 'eventType' and value= 'EX_ERS_ANALYSIS_EXCEPTION'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-400980' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-400980-1.sql */
/* Start of the SQL statements from file:CAL-402589-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-402589',1,CURRENT_TIMESTAMP,'started')
/

update am_widget_columns set widget_column_id = widget_id || '#' || column_name
/

CREATE OR REPLACE PROCEDURE PWS_WIDGET_ITEMS_ORDER AS 
BEGIN

  FOR widget_record IN (SELECT widget_id, column_name, (ROW_NUMBER() OVER (PARTITION BY widget_id ORDER BY widget_id))-1 as idx FROM am_widget_columns) 
  LOOP
  update am_widget_columns set item_index=widget_record.idx where widget_id = widget_record.widget_id and column_name = widget_record.column_name;
  END LOOP;
  
END PWS_WIDGET_ITEMS_ORDER;
/

BEGIN
PWS_WIDGET_ITEMS_ORDER;
END;
/

DROP PROCEDURE PWS_WIDGET_ITEMS_ORDER
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-402589' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-402589-1.sql */
/* Start of the SQL statements from file:CAL-401880-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-401880',1,CURRENT_TIMESTAMP,'started')
/

update entity_attributes set attr_name = 'Discount Currency' where entity_type = 'ReportTemplate' and attr_name = 'Discount Curency'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-401880' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-401880-1.sql */
/* Start of the SQL statements from file:CAL-402965-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-402965',1,CURRENT_TIMESTAMP,'started')
/

insert into user_layout_data (data_name, data_key, data_user, data_version, data_list, data_layout)
select data_name, data_key, '@@ALL@@' as data_user,data_version, data_list, data_layout from 
(select * from user_layout_data where data_name = '@@ColumnsSetsUI@@' and data_key = '@@PWSConfig@@' order by data_version desc) 
where not EXISTS(select * from user_layout_data where data_name = '@@ColumnsSetsUI@@' and data_key = '@@PWSConfig@@' and data_user = '@@ALL@@') and ROWNUM <=1
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-402965' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-402965-1.sql */
/* Start of the SQL statements from file:CAL-403559-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('core','CAL-403559',1,CURRENT_TIMESTAMP,'started')
/

declare

x number;
y number;

begin
	select vsize(attr_column_name) into x from attribute_config;
	select count(*) into y from attribute_config;
	exception WHEN NO_DATA_FOUND THEN
	x:=0;
	y:=0;
	execute immediate 'alter table attribute_config modify attr_column_name varchar2(30)';
	WHEN OTHERS THEN 
	x:=0;
	y:=0;
	if (x <= 30 or y = 0) then
		execute immediate 'alter table attribute_config modify attr_column_name varchar2(30)';
	end if;

end;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-403559' and version=1 and module='core'
/

/* End of the SQL statements from file:CAL-403559-1.sql */
/* Start of the SQL statements from file:CAL-385655-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('middleofficeam','CAL-385655',1,CURRENT_TIMESTAMP,'started')
/

insert into group_access select distinct(group_name),56,'__ALL__',1 from group_access
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-385655' and version=1 and module='middleofficeam'
/

/* End of the SQL statements from file:CAL-385655-1.sql */
/* Start of the SQL statements from file:CAL-400864-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('middleofficeam','CAL-400864',1,CURRENT_TIMESTAMP,'started')
/

delete from trade_keyword where keyword_name ='CreatedFromOrder' and keyword_value ='0'
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-400864' and version=1 and module='middleofficeam'
/

/* End of the SQL statements from file:CAL-400864-1.sql */
/* Start of the SQL statements from file:CAL-401038-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('middleofficeam','CAL-401038',1,CURRENT_TIMESTAMP,'started')
/

CREATE OR REPLACE PROCEDURE SP_INSERT_CONFIG_GROUPING_MAP
IS
  CURSOR config_curosr
  IS
    SELECT config_id,grouping_id FROM am_analysis_startup_grouping;
  config_id   NUMBER;
  grouping_id NUMBER;
  config_name VARCHAR(255);
BEGIN
  FOR config_grouping IN config_curosr
  LOOP
    BEGIN
      SELECT config_name
      INTO config_name
      FROM am_server_config_id_map
      WHERE config_id = config_grouping.config_id;
      INSERT
      INTO am_server_config_grouping_map
        (
          config_name,
          grouping_id
        )
        VALUES
        (
          config_name,
          config_grouping.grouping_id
        );
    EXCEPTION
    WHEN OTHERS THEN
      NULL;
    END;
  END LOOP;
END;

BEGIN
SP_INSERT_CONFIG_GROUPING_MAP;
END;

BEGIN
DROP SP_INSERT_CONFIG_GROUPING_MAP;
END;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='CAL-401038' and version=1 and module='middleofficeam'
/

/* End of the SQL statements from file:CAL-401038-1.sql */
/* Start of the SQL statements from file:COLT-14269-1.sql */
insert into calypso_database_upgrade_audit (module,name,version,startedts,status) values('collateral','COLT-14269',1,CURRENT_TIMESTAMP,'started')
/

DECLARE        
        v_rows_exists number := 0;
		v_table_exists number := 0;
 
BEGIN	
		select count(*) into v_table_exists from user_tables where table_name = 'PRICER_MEASURE';
		
		if (v_table_exists > 0) then
		   select count(*) into v_rows_exists from PRICER_MEASURE where measure_name in ('PM_SIMM','PM_SCHEDULE');		
			if (v_rows_exists < 1) then		
				execute immediate 'INSERT INTO pricer_measure(measure_name, measure_class_name, measure_id,measure_comment) 
				values(''PM_SIMM'',''tk.core.PricerMeasure'',(select max(measure_id)+1 from pricer_measure),''PM_SIMM for margin'')';
				
				execute immediate 'INSERT INTO pricer_measure(measure_name, measure_class_name, measure_id,measure_comment) 
				values(''PM_SCHEDULE'',''tk.core.PricerMeasure'',(select max(measure_id)+1 from pricer_measure),''PM_SCHEDULE for margin'')';		
			end if;
		end if;
		
END;
/

update calypso_database_upgrade_audit set updatedts=CURRENT_TIMESTAMP, status='success' where name='COLT-14269' and version=1 and module='collateral'
/

/* End of the SQL statements from file:COLT-14269-1.sql */
/* Post Upgrade - Start */
drop procedure add_column_if_not_exists
/

drop procedure drop_column_if_exists
/

drop procedure add_domain_values
/

drop procedure drop_fk_on_table
/

drop procedure drop_pk_if_exists
/

drop procedure drop_uk_if_exists
/

drop procedure drop_procedure_if_exists
/

drop procedure drop_uq_on_table
/

drop procedure drop_unique_if_exists
/

drop procedure drop_table_if_exists
/

drop procedure add_pk_if_not_exists
/

drop procedure run_query_if_tables_exist
/

drop type list_of_names_t
/

drop procedure rename_column_if_exists
/

/* Post Upgrade - End */


/* Applying Schema Statements - start */


    DROP INDEX idx_margin_call_entr2
/

    DROP INDEX san_idx_collat_custom1
/

    DROP INDEX idx_margin_trade_vm2
/

    DROP INDEX idx_margin_regulator2
/

    DROP INDEX idx_margin_local_sim1
/

    DROP INDEX idx_margin_regulator3
/

    DROP INDEX idx_margin_regulator4
/

    DROP INDEX idx_margin_regulator5
/

    DROP INDEX idx_custom_cre
/

    DROP INDEX idx_custom_bom
/

    DROP INDEX idx_inv_sec_query1
/

    DROP INDEX idx_inv_cash_query1
/

    DROP INDEX san_idx_collat_custom2
/

    DROP INDEX san_idx_collat_custom3
/

    DROP INDEX idx_trade9
/

    DROP INDEX idx_pl_markx
/

    DROP INDEX idx_margin_addon1
/

    DROP INDEX idx_margin_addon_his1
/

    DROP INDEX idx_margin_liquidity2
/

    DROP INDEX idx_margin_trade_liq1
/

    DROP INDEX idx_margin_trade_vm1
/

    DROP INDEX idx_margin_trade_vm_1
/

    DROP INDEX idx_margin_portfolio1
/

    DROP INDEX idx_margin_portfolio2
/

    DROP INDEX idx_recon_inven_row4
/

    DROP INDEX idx_official_pl_aggr2
/

    DROP INDEX idx_accounting_pl_it2
/

    ALTER TABLE MODEL_CALIBRATION_INSTRUMENT DROP CONSTRAINT pk_model_calibration7 CASCADE DROP INDEX
/

    ALTER TABLE MODEL_CALIBRATION_INST_HIST DROP CONSTRAINT pk_model_calibration8 CASCADE DROP INDEX
/

    ALTER TABLE AM_WIDGET_COLUMNS DROP CONSTRAINT pk_am_widget_columns1 CASCADE DROP INDEX
/

    ALTER TABLE objstore_files MODIFY (app_name VARCHAR(64))
/

    ALTER TABLE objstore_files_content MODIFY (app_name VARCHAR(64))
/

    ALTER TABLE LE_LEGAL_AGREEMENT MODIFY CURRENCY_LIST varchar2 (1024)
/

    ALTER TABLE PERM_BOOK_PRODUCT MODIFY PRODUCT_FAMILY varchar2 (64)
/

    UPDATE
        DECSUPP_ORDER 
    SET
        BUNDLE_ID = 0 
    WHERE
        BUNDLE_ID IS NULL
/

    ALTER TABLE DECSUPP_ORDER MODIFY BUNDLE_ID NOT NULL
/

    UPDATE
        DECSUPP_ORDER_HIST 
    SET
        BUNDLE_ID = 0 
    WHERE
        BUNDLE_ID IS NULL
/

    ALTER TABLE DECSUPP_ORDER_HIST MODIFY BUNDLE_ID NOT NULL
/

    UPDATE
        ATTRIBUTE_CONFIG 
    SET
        ATTR_COLUMN_NAME = ' ' 
    WHERE
        ATTR_COLUMN_NAME IS NULL
/

    ALTER TABLE ATTRIBUTE_CONFIG MODIFY ATTR_COLUMN_NAME NOT NULL
/

    UPDATE
        AM_COLUMNSET_GROUP_COLUMNS 
    SET
        TOTALS = 0 
    WHERE
        TOTALS IS NULL
/

    ALTER TABLE AM_COLUMNSET_GROUP_COLUMNS MODIFY TOTALS NOT NULL
/

    UPDATE
        AM_WIDGET_COLUMNS 
    SET
        WIDGET_COLUMN_ID = ' ' 
    WHERE
        WIDGET_COLUMN_ID IS NULL
/

    ALTER TABLE AM_WIDGET_COLUMNS MODIFY WIDGET_COLUMN_ID NOT NULL
/

    ALTER TABLE AM_WIDGET_COLUMNS MODIFY WIDGET_ID NULL
/

    UPDATE
        CM_RESULT 
    SET
        TOTALIA = 0 
    WHERE
        TOTALIA IS NULL
/

    ALTER TABLE CM_RESULT MODIFY TOTALIA NOT NULL
/

    ALTER TABLE CM_CALCULATION_SUMMARY MODIFY CALCULATION_SET_ID NULL
/

    UPDATE
        CM_RESULT_HIST 
    SET
        TOTALIA = 0 
    WHERE
        TOTALIA IS NULL
/

    ALTER TABLE CM_RESULT_HIST MODIFY TOTALIA NOT NULL
/

    UPDATE
        CM_RESULT_TEMP 
    SET
        TOTALIA = 0 
    WHERE
        TOTALIA IS NULL
/

    ALTER TABLE CM_RESULT_TEMP MODIFY TOTALIA NOT NULL
/

    ALTER TABLE CM_CALCULATION_SUMMARY_HIST MODIFY CALCULATION_SET_ID NULL
/
CREATE UNIQUE INDEX pk_posting_position1 ON POSTING_POSITION ( posting_position_id ) nologging parallel 8
/

    ALTER TABLE POSTING_POSITION ADD CONSTRAINT pk_posting_position1 PRIMARY KEY ( posting_position_id ) USING INDEX
/

    ALTER INDEX pk_posting_position1 noparallel logging
/
CREATE UNIQUE INDEX pk_matching_criteria1 ON MATCHING_CRITERIA ( id ) nologging parallel 8
/

    ALTER TABLE MATCHING_CRITERIA ADD CONSTRAINT pk_matching_criteria1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_matching_criteria1 noparallel logging
/
CREATE UNIQUE INDEX pk_pl_acc_matching_c1 ON PL_ACC_MATCHING_CONFIG ( id ) nologging parallel 8
/

    ALTER TABLE PL_ACC_MATCHING_CONFIG ADD CONSTRAINT pk_pl_acc_matching_c1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_pl_acc_matching_c1 noparallel logging
/
CREATE UNIQUE INDEX pk_posting_processin1 ON POSTING_PROCESSING_INFO ( external_pk, is_credit, is_deleted ) nologging parallel 8
/

    ALTER TABLE POSTING_PROCESSING_INFO ADD CONSTRAINT pk_posting_processin1 PRIMARY KEY ( external_pk, is_credit, is_deleted ) USING INDEX
/

    ALTER INDEX pk_posting_processin1 noparallel logging
/
CREATE UNIQUE INDEX pk_outgoing_message_1 ON OUTGOING_MESSAGE_IDENTIFIER ( config_id ) nologging parallel 8
/

    ALTER TABLE OUTGOING_MESSAGE_IDENTIFIER ADD CONSTRAINT pk_outgoing_message_1 PRIMARY KEY ( config_id ) USING INDEX
/

    ALTER INDEX pk_outgoing_message_1 noparallel logging
/
CREATE UNIQUE INDEX pk_iso_20022_externa1 ON ISO_20022_EXTERNAL_CODE ( iso_20022_external_code_id ) nologging parallel 8
/

    ALTER TABLE ISO_20022_EXTERNAL_CODE ADD CONSTRAINT pk_iso_20022_externa1 PRIMARY KEY ( iso_20022_external_code_id ) USING INDEX
/

    ALTER INDEX pk_iso_20022_externa1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_ia_input_statu1 ON CM_IA_INPUT_STATUS ( id ) nologging parallel 8
/

    ALTER TABLE CM_IA_INPUT_STATUS ADD CONSTRAINT pk_cm_ia_input_statu1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_ia_input_statu1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_ia_input1 ON CM_IA_INPUT ( id ) nologging parallel 8
/

    ALTER TABLE CM_IA_INPUT ADD CONSTRAINT pk_cm_ia_input1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_ia_input1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_calc_request1 ON CM_CALC_REQUEST ( id ) nologging parallel 8
/

    ALTER TABLE CM_CALC_REQUEST ADD CONSTRAINT pk_cm_calc_request1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_calc_request1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_calc_request_s1 ON CM_CALC_REQUEST_SIMM ( id ) nologging parallel 8
/

    ALTER TABLE CM_CALC_REQUEST_SIMM ADD CONSTRAINT pk_cm_calc_request_s1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_calc_request_s1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_calc_request_i1 ON CM_CALC_REQUEST_IA ( id ) nologging parallel 8
/

    ALTER TABLE CM_CALC_REQUEST_IA ADD CONSTRAINT pk_cm_calc_request_i1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_calc_request_i1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_calc_request_e1 ON CM_CALC_REQUEST_ETD ( id ) nologging parallel 8
/

    ALTER TABLE CM_CALC_REQUEST_ETD ADD CONSTRAINT pk_cm_calc_request_e1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_calc_request_e1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_account_calc_r1 ON CM_ACCOUNT_CALC_REQUEST ( id ) nologging parallel 8
/

    ALTER TABLE CM_ACCOUNT_CALC_REQUEST ADD CONSTRAINT pk_cm_account_calc_r1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_account_calc_r1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_account_calc_r2 ON CM_ACCOUNT_CALC_REQUEST_IA ( id ) nologging parallel 8
/

    ALTER TABLE CM_ACCOUNT_CALC_REQUEST_IA ADD CONSTRAINT pk_cm_account_calc_r2 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_account_calc_r2 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_account_calc_r3 ON CM_ACCOUNT_CALC_REQUEST_ETD ( id ) nologging parallel 8
/

    ALTER TABLE CM_ACCOUNT_CALC_REQUEST_ETD ADD CONSTRAINT pk_cm_account_calc_r3 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_account_calc_r3 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_account_calc_r4 ON CM_ACCOUNT_CALC_REQUEST_SIMM ( id ) nologging parallel 8
/

    ALTER TABLE CM_ACCOUNT_CALC_REQUEST_SIMM ADD CONSTRAINT pk_cm_account_calc_r4 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_account_calc_r4 noparallel logging
/
CREATE UNIQUE INDEX pk_pfs_lifecycle1 ON PFS_LIFECYCLE ( id ) nologging parallel 8
/

    ALTER TABLE PFS_LIFECYCLE ADD CONSTRAINT pk_pfs_lifecycle1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_pfs_lifecycle1 noparallel logging
/
CREATE UNIQUE INDEX pk_fx_flexi_forward_1 ON FX_FLEXI_FORWARD_TAKEUP_SCH ( flexi_forward_product_id ) nologging parallel 8
/

    ALTER TABLE FX_FLEXI_FORWARD_TAKEUP_SCH ADD CONSTRAINT pk_fx_flexi_forward_1 PRIMARY KEY ( flexi_forward_product_id ) USING INDEX
/

    ALTER INDEX pk_fx_flexi_forward_1 noparallel logging
/
CREATE UNIQUE INDEX pk_fx_flexi_forward_3 ON FX_FLEXI_FORWARD_TAKEUP_SCH_H ( flexi_forward_product_id ) nologging parallel 8
/

    ALTER TABLE FX_FLEXI_FORWARD_TAKEUP_SCH_H ADD CONSTRAINT pk_fx_flexi_forward_3 PRIMARY KEY ( flexi_forward_product_id ) USING INDEX
/

    ALTER INDEX pk_fx_flexi_forward_3 noparallel logging
/
CREATE UNIQUE INDEX pk_fx_avg_forward_ac1 ON FX_AVG_FORWARD_ACTION ( action_id, product_id ) nologging parallel 8
/

    ALTER TABLE FX_AVG_FORWARD_ACTION ADD CONSTRAINT pk_fx_avg_forward_ac1 PRIMARY KEY ( action_id, product_id ) USING INDEX
/

    ALTER INDEX pk_fx_avg_forward_ac1 noparallel logging
/
CREATE UNIQUE INDEX pk_fx_avg_forward_ac5 ON FX_AVG_FORWARD_ACTION_H ( action_id, product_id ) nologging parallel 8
/

    ALTER TABLE FX_AVG_FORWARD_ACTION_H ADD CONSTRAINT pk_fx_avg_forward_ac5 PRIMARY KEY ( action_id, product_id ) USING INDEX
/

    ALTER INDEX pk_fx_avg_forward_ac5 noparallel logging
/
CREATE UNIQUE INDEX pk_fx_avg_forward_ac9 ON FX_AVG_FORWARD_ACTION_DATA ( action_id ) nologging parallel 8
/

    ALTER TABLE FX_AVG_FORWARD_ACTION_DATA ADD CONSTRAINT pk_fx_avg_forward_ac9 PRIMARY KEY ( action_id ) USING INDEX
/

    ALTER INDEX pk_fx_avg_forward_ac9 noparallel logging
/
CREATE UNIQUE INDEX pk_fx_avg_forward_ac10 ON FX_AVG_FORWARD_ACTION_DATA_H ( action_id ) nologging parallel 8
/

    ALTER TABLE FX_AVG_FORWARD_ACTION_DATA_H ADD CONSTRAINT pk_fx_avg_forward_ac10 PRIMARY KEY ( action_id ) USING INDEX
/

    ALTER INDEX pk_fx_avg_forward_ac10 noparallel logging
/
CREATE UNIQUE INDEX pk_fx_avg_forward_ac11 ON FX_AVG_FORWARD_ACTION_ATTR ( action_id, action_attr_name ) nologging parallel 8
/

    ALTER TABLE FX_AVG_FORWARD_ACTION_ATTR ADD CONSTRAINT pk_fx_avg_forward_ac11 PRIMARY KEY ( action_id, action_attr_name ) USING INDEX
/

    ALTER INDEX pk_fx_avg_forward_ac11 noparallel logging
/
CREATE UNIQUE INDEX pk_fx_avg_forward_ac12 ON FX_AVG_FORWARD_ACTION_ATTR_H ( action_id, action_attr_name ) nologging parallel 8
/

    ALTER TABLE FX_AVG_FORWARD_ACTION_ATTR_H ADD CONSTRAINT pk_fx_avg_forward_ac12 PRIMARY KEY ( action_id, action_attr_name ) USING INDEX
/

    ALTER INDEX pk_fx_avg_forward_ac12 noparallel logging
/
CREATE UNIQUE INDEX pk_fx_flexi_forward_25 ON FX_FLEXI_FORWARD_MERCHANTFX ( flexi_forward_product_id ) nologging parallel 8
/

    ALTER TABLE FX_FLEXI_FORWARD_MERCHANTFX ADD CONSTRAINT pk_fx_flexi_forward_25 PRIMARY KEY ( flexi_forward_product_id ) USING INDEX
/

    ALTER INDEX pk_fx_flexi_forward_25 noparallel logging
/
CREATE UNIQUE INDEX pk_fx_flexi_forward_27 ON FX_FLEXI_FORWARD_MERCHANTFX_H ( flexi_forward_product_id ) nologging parallel 8
/

    ALTER TABLE FX_FLEXI_FORWARD_MERCHANTFX_H ADD CONSTRAINT pk_fx_flexi_forward_27 PRIMARY KEY ( flexi_forward_product_id ) USING INDEX
/

    ALTER INDEX pk_fx_flexi_forward_27 noparallel logging
/
CREATE UNIQUE INDEX pk_product_deferred_1 ON PRODUCT_DEFERRED_PL ( product_id ) nologging parallel 8
/

    ALTER TABLE PRODUCT_DEFERRED_PL ADD CONSTRAINT pk_product_deferred_1 PRIMARY KEY ( product_id ) USING INDEX
/

    ALTER INDEX pk_product_deferred_1 noparallel logging
/
CREATE UNIQUE INDEX pk_product_fx_avg_fw1 ON PRODUCT_FX_AVG_FWD ( product_id ) nologging parallel 8
/

    ALTER TABLE PRODUCT_FX_AVG_FWD ADD CONSTRAINT pk_product_fx_avg_fw1 PRIMARY KEY ( product_id ) USING INDEX
/

    ALTER INDEX pk_product_fx_avg_fw1 noparallel logging
/
CREATE UNIQUE INDEX pk_fx_fixing_reset_d1 ON FX_FIXING_RESET_DATES ( product_id, fx_reset, sample_date_time ) nologging parallel 8
/

    ALTER TABLE FX_FIXING_RESET_DATES ADD CONSTRAINT pk_fx_fixing_reset_d1 PRIMARY KEY ( product_id, fx_reset, sample_date_time ) USING INDEX
/

    ALTER INDEX pk_fx_fixing_reset_d1 noparallel logging
/
CREATE UNIQUE INDEX pk_product_fx_opt_sw1 ON PRODUCT_FX_OPT_SWP ( product_id ) nologging parallel 8
/

    ALTER TABLE PRODUCT_FX_OPT_SWP ADD CONSTRAINT pk_product_fx_opt_sw1 PRIMARY KEY ( product_id ) USING INDEX
/

    ALTER INDEX pk_product_fx_opt_sw1 noparallel logging
/
CREATE UNIQUE INDEX pk_tf_temp_table1 ON TF_TEMP_TABLE ( request_id, row_number )
/

    ALTER TABLE TF_TEMP_TABLE ADD CONSTRAINT pk_tf_temp_table1 PRIMARY KEY ( request_id, row_number ) USING INDEX
/
CREATE UNIQUE INDEX pk_liq_pos_amort_tra1 ON LIQ_POS_AMORT_TRADE_LINK ( liquidated_position_id, trade_id ) nologging parallel 8
/

    ALTER TABLE LIQ_POS_AMORT_TRADE_LINK ADD CONSTRAINT pk_liq_pos_amort_tra1 PRIMARY KEY ( liquidated_position_id, trade_id ) USING INDEX
/

    ALTER INDEX pk_liq_pos_amort_tra1 noparallel logging
/
CREATE UNIQUE INDEX pk_swap_amort_trade_1 ON SWAP_AMORT_TRADE_LINK ( swap_trade_id, fee_type, termination_date, trade_id ) nologging parallel 8
/

    ALTER TABLE SWAP_AMORT_TRADE_LINK ADD CONSTRAINT pk_swap_amort_trade_1 PRIMARY KEY ( swap_trade_id, fee_type, termination_date, trade_id ) USING INDEX
/

    ALTER INDEX pk_swap_amort_trade_1 noparallel logging
/
CREATE UNIQUE INDEX pk_cashflow_amort_tr1 ON CASHFLOW_AMORT_TRADE_LINK ( amort_trade_id, trade_id, cashflow_type, cashflow_value_date ) nologging parallel 8
/

    ALTER TABLE CASHFLOW_AMORT_TRADE_LINK ADD CONSTRAINT pk_cashflow_amort_tr1 PRIMARY KEY ( amort_trade_id, trade_id, cashflow_type, cashflow_value_date ) USING INDEX
/

    ALTER INDEX pk_cashflow_amort_tr1 noparallel logging
/
CREATE UNIQUE INDEX pk_user_secret1 ON USER_SECRET ( user_name ) nologging parallel 8
/

    ALTER TABLE USER_SECRET ADD CONSTRAINT pk_user_secret1 PRIMARY KEY ( user_name ) USING INDEX
/

    ALTER INDEX pk_user_secret1 noparallel logging
/
CREATE UNIQUE INDEX pk_model_calibration16 ON MODEL_CALIBRATION_INSTRUMENT ( model_calibration_id, model_calibration_datetime, mdi_param_name, category, underlying, expiry_datetime, strike, relative_strike, swap1_maturity_tenor, swap2_maturity_tenor, swap1_rate, swap2_rate, relative_strike_swap1, relative_strike_swap2 ) nologging parallel 8
/

    ALTER TABLE MODEL_CALIBRATION_INSTRUMENT ADD CONSTRAINT pk_model_calibration16 PRIMARY KEY ( model_calibration_id, model_calibration_datetime, mdi_param_name, category, underlying, expiry_datetime, strike, relative_strike, swap1_maturity_tenor, swap2_maturity_tenor, swap1_rate, swap2_rate, relative_strike_swap1, relative_strike_swap2 ) USING INDEX
/

    ALTER INDEX pk_model_calibration16 noparallel logging
/
CREATE UNIQUE INDEX pk_model_calibration17 ON MODEL_CALIBRATION_INST_HIST ( model_calibration_id, model_calibration_datetime, mdi_param_name, category, underlying, expiry_datetime, strike, relative_strike, swap1_maturity_tenor, swap2_maturity_tenor, swap1_rate, swap2_rate, relative_strike_swap1, relative_strike_swap2 ) nologging parallel 8
/

    ALTER TABLE MODEL_CALIBRATION_INST_HIST ADD CONSTRAINT pk_model_calibration17 PRIMARY KEY ( model_calibration_id, model_calibration_datetime, mdi_param_name, category, underlying, expiry_datetime, strike, relative_strike, swap1_maturity_tenor, swap2_maturity_tenor, swap1_rate, swap2_rate, relative_strike_swap1, relative_strike_swap2 ) USING INDEX
/

    ALTER INDEX pk_model_calibration17 noparallel logging
/
CREATE UNIQUE INDEX pk_ha_pcfh_tag1 ON HA_PCFH_TAG ( tag_id ) nologging parallel 8
/

    ALTER TABLE HA_PCFH_TAG ADD CONSTRAINT pk_ha_pcfh_tag1 PRIMARY KEY ( tag_id ) USING INDEX
/

    ALTER INDEX pk_ha_pcfh_tag1 noparallel logging
/
CREATE UNIQUE INDEX pk_ha_trade_ratio_co1 ON HA_TRADE_RATIO_CONFIG ( id ) nologging parallel 8
/

    ALTER TABLE HA_TRADE_RATIO_CONFIG ADD CONSTRAINT pk_ha_trade_ratio_co1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_ha_trade_ratio_co1 noparallel logging
/
CREATE UNIQUE INDEX pk_am_server_config_2 ON AM_SERVER_CONFIG_GROUPING_MAP ( config_name, grouping_id ) nologging parallel 8
/

    ALTER TABLE AM_SERVER_CONFIG_GROUPING_MAP ADD CONSTRAINT pk_am_server_config_2 PRIMARY KEY ( config_name, grouping_id ) USING INDEX
/

    ALTER INDEX pk_am_server_config_2 noparallel logging
/
CREATE UNIQUE INDEX pk_accounting_pl_ite5 ON ACCOUNTING_PL_ITEM_HIST ( id ) nologging parallel 8
/

    ALTER TABLE ACCOUNTING_PL_ITEM_HIST ADD CONSTRAINT pk_accounting_pl_ite5 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_accounting_pl_ite5 noparallel logging
/
CREATE UNIQUE INDEX pk_accounting_pl_ite8 ON ACCOUNTING_PL_ITEM_ATTR_HIST ( entity_id, entity_type, attr_name ) nologging parallel 8
/

    ALTER TABLE ACCOUNTING_PL_ITEM_ATTR_HIST ADD CONSTRAINT pk_accounting_pl_ite8 PRIMARY KEY ( entity_id, entity_type, attr_name ) USING INDEX
/

    ALTER INDEX pk_accounting_pl_ite8 noparallel logging
/
CREATE UNIQUE INDEX pk_hc_subsystem1 ON HC_SUBSYSTEM ( subsystem_type, subsystem_name ) nologging parallel 8
/

    ALTER TABLE HC_SUBSYSTEM ADD CONSTRAINT pk_hc_subsystem1 PRIMARY KEY ( subsystem_type, subsystem_name ) USING INDEX
/

    ALTER INDEX pk_hc_subsystem1 noparallel logging
/
CREATE UNIQUE INDEX pk_hc_sensor1 ON HC_SENSOR ( subsystem_type, subsystem_name, sensor_name ) nologging parallel 8
/

    ALTER TABLE HC_SENSOR ADD CONSTRAINT pk_hc_sensor1 PRIMARY KEY ( subsystem_type, subsystem_name, sensor_name ) USING INDEX
/

    ALTER INDEX pk_hc_sensor1 noparallel logging
/
CREATE UNIQUE INDEX pk_order_bundle1 ON ORDER_BUNDLE ( bundle_id ) nologging parallel 8
/

    ALTER TABLE ORDER_BUNDLE ADD CONSTRAINT pk_order_bundle1 PRIMARY KEY ( bundle_id ) USING INDEX
/

    ALTER INDEX pk_order_bundle1 noparallel logging
/
CREATE UNIQUE INDEX pk_attribute_configu1 ON ATTRIBUTE_CONFIGURATION ( id ) nologging parallel 8
/

    ALTER TABLE ATTRIBUTE_CONFIGURATION ADD CONSTRAINT pk_attribute_configu1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_attribute_configu1 noparallel logging
/
CREATE UNIQUE INDEX pk_product_code_conf1 ON PRODUCT_CODE_CONFIGURATION ( id ) nologging parallel 8
/

    ALTER TABLE PRODUCT_CODE_CONFIGURATION ADD CONSTRAINT pk_product_code_conf1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_product_code_conf1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_trade_incl_det1 ON CM_TRADE_INCL_DETAILS ( id ) nologging parallel 8
/

    ALTER TABLE CM_TRADE_INCL_DETAILS ADD CONSTRAINT pk_cm_trade_incl_det1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_trade_incl_det1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_simm_trade_inc1 ON CM_SIMM_TRADE_INCL_DETAILS ( id ) nologging parallel 8
/

    ALTER TABLE CM_SIMM_TRADE_INCL_DETAILS ADD CONSTRAINT pk_cm_simm_trade_inc1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_simm_trade_inc1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_ia_account1 ON CM_IA_ACCOUNT ( id ) nologging parallel 8
/

    ALTER TABLE CM_IA_ACCOUNT ADD CONSTRAINT pk_cm_ia_account1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_ia_account1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_ia_element1 ON CM_IA_ELEMENT ( id ) nologging parallel 8
/

    ALTER TABLE CM_IA_ELEMENT ADD CONSTRAINT pk_cm_ia_element1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_ia_element1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_acadia_imem_in1 ON CM_ACADIA_IMEM_INTEGRATION ( id ) nologging parallel 8
/

    ALTER TABLE CM_ACADIA_IMEM_INTEGRATION ADD CONSTRAINT pk_cm_acadia_imem_in1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_acadia_imem_in1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_account_group1 ON CM_ACCOUNT_GROUP ( id ) nologging parallel 8
/

    ALTER TABLE CM_ACCOUNT_GROUP ADD CONSTRAINT pk_cm_account_group1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_account_group1 noparallel logging
/
CREATE UNIQUE INDEX pk_cm_product_mappin1 ON CM_PRODUCT_MAPPING ( id ) nologging parallel 8
/

    ALTER TABLE CM_PRODUCT_MAPPING ADD CONSTRAINT pk_cm_product_mappin1 PRIMARY KEY ( id ) USING INDEX
/

    ALTER INDEX pk_cm_product_mappin1 noparallel logging
/
CREATE UNIQUE INDEX idx_matching_criteri2 ON MATCHING_CRITERIA ( config_id, product_type, accounting_book_id, account_id, event, currency ) nologging parallel 8
/

    ALTER INDEX idx_matching_criteri2 noparallel logging
/
CREATE UNIQUE INDEX idx_cm_ia_input_stat2 ON CM_IA_INPUT_STATUS ( tenant_id, import_date ) nologging parallel 8
/

    ALTER INDEX idx_cm_ia_input_stat2 noparallel logging
/
CREATE UNIQUE INDEX idx_cm_ia_input2 ON CM_IA_INPUT ( tenant_id, trade_id, valuation_date, account_id, product_type, currency, maturity_tenor ) nologging parallel 8
/

    ALTER INDEX idx_cm_ia_input2 noparallel logging
/
CREATE UNIQUE INDEX idx_accounting_pl_it3 ON ACCOUNTING_PL_ITEM ( accountingpl_config_id, tradereference_id, trade_id, accountingpl_ccy, original_ccy, val_date ) nologging parallel 8
/

    ALTER INDEX idx_accounting_pl_it3 noparallel logging
/
CREATE UNIQUE INDEX idx_accounting_pl_it5 ON ACCOUNTING_PL_ITEM_HIST ( accountingpl_config_id, tradereference_id, trade_id, accountingpl_ccy, original_ccy, val_date ) nologging parallel 8
/

    ALTER INDEX idx_accounting_pl_it5 noparallel logging
/
CREATE UNIQUE INDEX idx_cm_simm_trade_in2 ON CM_SIMM_TRADE_INCL_PO_MAP ( simm_trade_incl_details_id, processing_org_ids ) nologging parallel 8
/

    ALTER INDEX idx_cm_simm_trade_in2 noparallel logging
/
CREATE UNIQUE INDEX idx_cm_simm_trade_in3 ON CM_SIMM_TRADE_INCL_CP_MAP ( simm_trade_incl_details_id, counterparty_ids ) nologging parallel 8
/

    ALTER INDEX idx_cm_simm_trade_in3 noparallel logging
/
CREATE UNIQUE INDEX idx_cm_acadia_imem_i2 ON CM_ACADIA_IMEM_INTEGRATION ( tree_id, tenant_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_acadia_imem_i2 noparallel logging
/
CREATE UNIQUE INDEX idx_cm_account_group2 ON CM_ACCOUNT_GROUP ( name, tenant_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_account_group2 noparallel logging
/
CREATE UNIQUE INDEX idx_cm_account_group3 ON CM_ACCOUNT_GROUP_IDS ( account_id, account_group_ids ) nologging parallel 8
/

    ALTER INDEX idx_cm_account_group3 noparallel logging
/
CREATE UNIQUE INDEX idx_cm_product_mappi2 ON CM_PRODUCT_MAPPING ( product_type, tenant_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_product_mappi2 noparallel logging
/
CREATE INDEX idx_posting_position2 ON POSTING_POSITION ( matching_criteria_id ) nologging parallel 8
/

    ALTER INDEX idx_posting_position2 noparallel logging
/
CREATE INDEX idx_margin_addon2 ON MARGIN_ADDON ( valuation_date, margin_agreement_name, add_on_type ) nologging parallel 8
/

    ALTER INDEX idx_margin_addon2 noparallel logging
/
CREATE INDEX idx_margin_addon_his2 ON MARGIN_ADDON_HIST ( valuation_date, margin_agreement_name, add_on_type ) nologging parallel 8
/

    ALTER INDEX idx_margin_addon_his2 noparallel logging
/
CREATE INDEX idx_margin_regulator7 ON MARGIN_REGULATOR_SCHEDULE ( margin_agreement_name, direction, source ) nologging parallel 8
/

    ALTER INDEX idx_margin_regulator7 noparallel logging
/
CREATE INDEX idx_margin_local_sim2 ON MARGIN_LOCAL_SIMM_REGULATOR ( margin_agreement_name, direction, source ) nologging parallel 8
/

    ALTER INDEX idx_margin_local_sim2 noparallel logging
/
CREATE INDEX idx_margin_regulator8 ON MARGIN_REGULATOR_MULTIPLIER ( margin_agreement_name, direction, source ) nologging parallel 8
/

    ALTER INDEX idx_margin_regulator8 noparallel logging
/
CREATE INDEX idx_margin_regulator9 ON MARGIN_REGULATOR_ADDON ( margin_agreement_name, direction, source ) nologging parallel 8
/

    ALTER INDEX idx_margin_regulator9 noparallel logging
/
CREATE INDEX idx_margin_regulator10 ON MARGIN_REGULATOR_FIXED_AMOUNT ( margin_agreement_name, direction, source ) nologging parallel 8
/

    ALTER INDEX idx_margin_regulator10 noparallel logging
/
CREATE INDEX idx_cm_ia_status_err1 ON CM_IA_STATUS_ERRORS ( ia_status_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_ia_status_err1 noparallel logging
/
CREATE INDEX idx_fx_avg_forward_a2 ON FX_AVG_FORWARD_ACTION ( product_id ) nologging parallel 8
/

    ALTER INDEX idx_fx_avg_forward_a2 noparallel logging
/
CREATE INDEX idx_fx_avg_forward_a3 ON FX_AVG_FORWARD_ACTION ( action_id ) nologging parallel 8
/

    ALTER INDEX idx_fx_avg_forward_a3 noparallel logging
/
CREATE INDEX idx_fx_avg_forward_a4 ON FX_AVG_FORWARD_ACTION ( action_type ) nologging parallel 8
/

    ALTER INDEX idx_fx_avg_forward_a4 noparallel logging
/
CREATE INDEX idx_fx_avg_forward_a6 ON FX_AVG_FORWARD_ACTION_H ( product_id ) nologging parallel 8
/

    ALTER INDEX idx_fx_avg_forward_a6 noparallel logging
/
CREATE INDEX idx_fx_avg_forward_a7 ON FX_AVG_FORWARD_ACTION_H ( action_id ) nologging parallel 8
/

    ALTER INDEX idx_fx_avg_forward_a7 noparallel logging
/
CREATE INDEX idx_fx_avg_forward_a8 ON FX_AVG_FORWARD_ACTION_H ( action_type ) nologging parallel 8
/

    ALTER INDEX idx_fx_avg_forward_a8 noparallel logging
/
CREATE INDEX idx_tf_temp_table2 ON TF_TEMP_TABLE ( trade_id )
/
CREATE INDEX idx_ha_pcfh_tag2 ON HA_PCFH_TAG ( portfolio_id ) nologging parallel 8
/

    ALTER INDEX idx_ha_pcfh_tag2 noparallel logging
/
CREATE INDEX idx_ha_pcfh_tag_hr_l1 ON HA_PCFH_TAG_HR_LIST ( tag_id ) nologging parallel 8
/

    ALTER INDEX idx_ha_pcfh_tag_hr_l1 noparallel logging
/
CREATE INDEX idx_ha_trade_ratio_c2 ON HA_TRADE_RATIO_CONFIG ( portfolio_id ) nologging parallel 8
/

    ALTER INDEX idx_ha_trade_ratio_c2 noparallel logging
/
CREATE INDEX idx_ha_trade_ratio_c3 ON HA_TRADE_RATIO_CONFIG ( trade_id ) nologging parallel 8
/

    ALTER INDEX idx_ha_trade_ratio_c3 noparallel logging
/
CREATE INDEX idx_ha_trade_ratio_c4 ON HA_TRADE_RATIO_CONFIG ( classification ) nologging parallel 8
/

    ALTER INDEX idx_ha_trade_ratio_c4 noparallel logging
/
CREATE INDEX idx_ha_trade_ratio_c5 ON HA_TRADE_RATIO_CONFIG ( hedge_rel_id ) nologging parallel 8
/

    ALTER INDEX idx_ha_trade_ratio_c5 noparallel logging
/
CREATE INDEX idx_ha_trade_ratio_c6 ON HA_TRADE_RATIO_CONFIG ( start_date ) nologging parallel 8
/

    ALTER INDEX idx_ha_trade_ratio_c6 noparallel logging
/
CREATE INDEX idx_ha_trade_ratio_c7 ON HA_TRADE_RATIO_CONFIG ( end_date ) nologging parallel 8
/

    ALTER INDEX idx_ha_trade_ratio_c7 noparallel logging
/
CREATE INDEX idx_am_widget_column1 ON AM_WIDGET_COLUMNS ( widget_id, column_name ) nologging parallel 8
/

    ALTER INDEX idx_am_widget_column1 noparallel logging
/
CREATE INDEX idx_order_bundle2 ON ORDER_BUNDLE ( bundle_type, bundle_name ) nologging parallel 8
/

    ALTER INDEX idx_order_bundle2 noparallel logging
/
CREATE INDEX idx_attribute_config5 ON ATTRIBUTE_CONFIGURATION ( event_class, att_level, sequence, name ) nologging parallel 8
/

    ALTER INDEX idx_attribute_config5 noparallel logging
/
CREATE INDEX idx_product_code_con2 ON PRODUCT_CODE_CONFIGURATION ( event_class, att_level, sequence, name ) nologging parallel 8
/

    ALTER INDEX idx_product_code_con2 noparallel logging
/
CREATE INDEX idx_bo_matchable2 ON BO_MATCHABLE ( object_id, object_class ) nologging parallel 8
/

    ALTER INDEX idx_bo_matchable2 noparallel logging
/
CREATE INDEX idx_cm_ia_account2 ON CM_IA_ACCOUNT ( postiaelementdetails_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_ia_account2 noparallel logging
/
CREATE INDEX idx_cm_ia_account3 ON CM_IA_ACCOUNT ( collectiaelementdetails_id ) nologging parallel 8
/

    ALTER INDEX idx_cm_ia_account3 noparallel logging
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'PRICE','Measure','Collateral',1 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_SECURITY_ACCRUAL','Measure','Collateral',2 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_SECURITY_VALUE','Measure','Collateral',3 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_SECURITY_CLEAN_VALUE','Measure','Collateral',4 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'PRICE','Measure','Repo',1 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_SECURITY_ACCRUAL','Measure','Repo',2 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_SECURITY_VALUE','Measure','Repo',3 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_SECURITY_CLEAN_VALUE','Measure','Repo',4 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_LIABILITY','Measure','Repo',5 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'DIRTY_PRICE','Measure','Repo',6 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'ACCRUAL','Measure','Repo',7 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'PRICE','Measure','SecLending',1 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_SECURITY_ACCRUAL','Measure','SecLending',2 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_SECURITY_VALUE','Measure','SecLending',3 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_SECURITY_CLEAN_VALUE','Measure','SecLending',4 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'SEC_FIN_LIABILITY','Measure','SecLending',5 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'DIRTY_PRICE','Measure','SecLending',6 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'ACCRUAL','Measure','SecLending',7 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'Pay Leg Floating Rate','Property','Swap',1 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'Pay Leg Rate Index Spread','Property','Swap',2 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'Pay Leg Fixed Rate','Property','Swap',3 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'Pay Leg Principal','Property','Swap',4 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'Pay Leg Principal Ccy','Property','Swap',5 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'Rcv Floating Rate','Property','Swap',6 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'Rcv Rate Index Spread','Property','Swap',7 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'Rcv Fixed Rate','Property','Swap',8 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'Rcv Principal','Property','Swap',9 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'Rcv Principal Ccy','Property','Swap',1 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'Ccy Pair','Property','FX',1 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'Prim Amt','Property','FX',2 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'Prim Cur','Property','FX',3 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'Ccy Pair','Property','FXForward',1 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'Prim Amt','Property','FXForward',2 )
/

    INSERT 
    INTO
        collateral_product_definition
        ( context_id, data, data_type, product_type, sort_id ) 
    VALUES
        (1,'Prim Cur','Property','FXForward',3 )
/

    INSERT 
    INTO
        allocation_validator
        ( collateral_context_id, dto_id, name, type ) 
    VALUES
        (1,1,'AllocationPriceValidator','AllocationPriceValidator' )
/

    INSERT 
    INTO
        allocation_validator
        ( collateral_context_id, dto_id, name, type ) 
    VALUES
        (1,3,'EligibilityAllocationValidator','EligibilityAllocationValidator' )
/

    INSERT 
    INTO
        allocation_validator_kv
        ( id, name, type, value ) 
    VALUES
        (1,'Allocation-Types','TYPE_ENUM_LIST','2' )
/

    INSERT 
    INTO
        allocation_validator_kv
        ( id, name, type, value ) 
    VALUES
        (1,'Type','TYPE_STRING','AllocationPriceValidator' )
/

    INSERT 
    INTO
        allocation_validator_kv
        ( id, name, type, value ) 
    VALUES
        (1,'Warning-Type','TYPE_ENUM','HARD' )
/

    INSERT 
    INTO
        allocation_validator_kv
        ( id, name, type, value ) 
    VALUES
        (2,'0','TYPE_STRING','Margin' )
/

    INSERT 
    INTO
        allocation_validator_kv
        ( id, name, type, value ) 
    VALUES
        (2,'1','TYPE_STRING','Substitution' )
/

    INSERT 
    INTO
        allocation_validator_kv
        ( id, name, type, value ) 
    VALUES
        (2,'2','TYPE_STRING','Return' )
/

    INSERT 
    INTO
        allocation_validator_kv
        ( id, name, type, value ) 
    VALUES
        (2,'3','TYPE_STRING','Remaining position' )
/

    INSERT 
    INTO
        allocation_validator_kv
        ( id, name, type, value ) 
    VALUES
        (3,'Allocation-Types','TYPE_ENUM_LIST','4' )
/

    INSERT 
    INTO
        allocation_validator_kv
        ( id, name, type, value ) 
    VALUES
        (3,'Type','TYPE_STRING','EligibilityAllocationValidator' )
/

    INSERT 
    INTO
        allocation_validator_kv
        ( id, name, type, value ) 
    VALUES
        (3,'Warning-Type','TYPE_ENUM','HARD' )
/

    INSERT 
    INTO
        allocation_validator_kv
        ( id, name, type, value ) 
    VALUES
        (4,'0','TYPE_STRING','Margin' )
/

    INSERT 
    INTO
        allocation_validator_kv
        ( id, name, type, value ) 
    VALUES
        (4,'1','TYPE_STRING','Substitution' )
/

    INSERT 
    INTO
        allocation_validator_kv
        ( id, name, type, value ) 
    VALUES
        (4,'2','TYPE_STRING','Return' )
/

    INSERT 
    INTO
        allocation_validator_kv
        ( id, name, type, value ) 
    VALUES
        (4,'3','TYPE_STRING','Remaining position' )
/

    INSERT 
    INTO
        arch_registry
        ( table_size, table_type ) 
    VALUES
        (0,'entry' )
/

    INSERT 
    INTO
        arch_registry
        ( table_size, table_type ) 
    VALUES
        (0,'concentration' )
/

    INSERT 
    INTO
        arch_registry
        ( table_size, table_type ) 
    VALUES
        (0,'position' )
/

    INSERT 
    INTO
        arch_registry
        ( table_size, table_type ) 
    VALUES
        (0,'detailEntry' )
/

    INSERT 
    INTO
        arch_registry
        ( table_size, table_type ) 
    VALUES
        (0,'allocation' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('XML','Uploader','data',0,'UBSFieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('XML','Uploader','dataType',0,'UBSFieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('data','Uploader','sourceRootElement',0,'UBSFieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('row','Uploader','sourceRowElement',0,'UBSFieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('data','Uploader','templateRootElement',0,'UBSFieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('row','Uploader','templateRowElement',0,'UBSFieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('AvgPriceB','UBS','APS_Trade',0,'FieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('Account','UBS','Account',0,'FieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('ClientRef','UBS','Client_Ref',0,'FieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('Quantity','UBS','Contracts',0,'FieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('DecimalPricePremium','UBS','Decimal_Price_Premium',0,'FieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('GMIProduct','UBS','GMI_Product',0,'FieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('ExternalReference','UBS','ID',0,'FieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('Exchange','UBS','Market',0,'FieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('PricePremium','UBS','Price_Premium',0,'FieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('ClearingExchangeTicker','UBS','Product',0,'FieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('Expiration_Date','UBS','Prompt_Date',0,'FieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('Run_Date','UBS','Run_date',0,'FieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('StrikePrice','UBS','Strike_Price',0,'FieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('TradeType','UBS','Trade_Type',0,'FieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('Trade_Date','UBS','Trade_date',0,'FieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('Currency','UBS','Traded_Currency_Code',0,'FieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('TraderName','UBS','Trader',0,'FieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('Action','UBS','Transaction_Type',0,'FieldMapping' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('NEW','UBS','NEWF',0,'TradeAction' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('NEW','UBS','NEWO',0,'TradeAction' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('CANCEL','UBS','DELF',0,'TradeAction' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('CANCEL','UBS','DELO',0,'TradeAction' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('EXERCISE','UBS','EXER',0,'TradeAction' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('ASSIGN','UBS','ASSN',0,'TradeAction' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('PUT','UBS','P',0,'OptionType' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('CALL','UBS','C',0,'OptionType' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('Option','UBS','C',0,'TradeType' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('Option','UBS','P',0,'TradeType' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('Future','UBS','F',0,'TradeType' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('yyyyMMdd','UBS','DateFormat',0,'Translator' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('CalypsoTrade/Product/Bond/ProductCodeType','Uploader','Bond-SecCodeNameXpath',0,'BloombergRequestProducts' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('CalypsoTrade/Product/Bond/ProductCodeValue','Uploader','Bond-SecCodeValueXpath',0,'BloombergRequestProducts' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('CalypsoTrade/Product/EquityStructuredOption/UnderlyingDetails/ProductCodeType','Uploader','EquityStructuredOption-SecCodeNameXpath',0,'BloombergRequestProducts' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('CalypsoTrade/Product/EquityStructuredOption/UnderlyingDetails/ProductCodeValue','Uploader','EquityStructuredOption-SecCodeValueXpath',0,'BloombergRequestProducts' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('CalypsoTrade/Product/Equity/ProductCodeType','Uploader','Equity-SecCodeNameXpath',0,'BloombergRequestProducts' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('CalypsoTrade/Product/Equity/ProductCodeValue','Uploader','Equity-SecCodeValueXpath',0,'BloombergRequestProducts' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('CalypsoTrade/Product/EquitySwap/ProductCodeType','Uploader','EquitySwap-SecCodeNameXpath',0,'BloombergRequestProducts' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        ('CalypsoTrade/Product/EquitySwap/ProductCodeValue','Uploader','EquitySwap-SecCodeValueXpath',0,'BloombergRequestProducts' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        (null,'FpML','SkipFpMLVersionValidation',0,'Translator' )
/

    INSERT 
    INTO
        calypso_mapping
        ( calypso_value, interface_name, interface_value, reverse_b, type_name ) 
    VALUES
        (null,'FpML','UseResetAdjustmentsTag',0,'Translator' )
/

    INSERT 
    INTO
        advice_config
        ( address_method, advice_config_id, always_send, default_language, event_type, format_type, gateway, inactive, matching, message_type, po_id, product_type, rec_contact_type, receiver_id, receiver_role, sd_filter, send_contact_type, template_name ) 
    VALUES
        ('ACADIA',7315,0,'English','NOTIF_CANCEL_COLLATERAL','ACADIA','ACADIA',0,0,'MC_NOTIFICATION',0,'ALL','Default',0,'CounterParty','NONE','Default','CancelExpectedMarginCall' )
/

    delete 
    FROM
        calypso_info
/

    INSERT 
    INTO
        calypso_info
        ( major_version, minor_version, patch_version, ref_time_zone, sub_version, version_date ) 
    VALUES
        (16,1,'71','GMT',0,TIMESTAMP'2021-05-03 00:00:00.0' )
/

    UPDATE
        calypso_info 
    SET
        ref_time_zone = 'GMT'
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('DataExportServiceEngine','CLASS_NAME','com.calypso.tk.engine.DataExportServiceEngine' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('DataExportServiceEngine','DISPLAY_NAME','DataExporterServiceEngine' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('DataExportServiceEngine','INSTANCE_NAME','engineserver' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('DataExportServiceEngine','STARTUP','false' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('DataExportServiceEngine','config','dataexporter.properties' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('MatchingEngine','TIMEOUT_RESTART','5' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('MatchableBuilderEngine','TIMEOUT_RESTART','5' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('KPIEngine','CLASS_NAME','com.calypso.kpi.KPIEngine' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('KPIEngine','DISPLAY_NAME','KPI Engine' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('KPIEngine','INSTANCE_NAME','kpiserver' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('KPIEngine','STARTUP','false' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('UpdateManagerEngine','CLASS_NAME','com.calypso.tk.engine.UpdateManagerEngine' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('UpdateManagerEngine','DISPLAY_NAME','Update Manager Engine' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('UpdateManagerEngine','INSTANCE_NAME','engineserver' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('UpdateManagerEngine','STARTUP','false' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('FIXEngine','CLASS_NAME','com.calypso.tk.engine.FIXEngine' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('FIXEngine','DISPLAY_NAME','FIX Engine' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('FIXEngine','INSTANCE_NAME','engineserver' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('FIXEngine','STARTUP','false' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('FIXEngine','config','fix.properties' )
/

    INSERT 
    INTO
        engine_param
        ( engine_name, param_name, param_value ) 
    VALUES
        ('FIXEngine','EVENT_POOL_POLICY','FIXEngine' )
/

    INSERT 
    INTO
        pricing_param_name
        ( default_value, is_global_b, param_comment, param_domain, param_name, param_type ) 
    VALUES
        ('false',1,'Pricer cost to close to use market haircut','true,false','CTC_MARKET_HAIRCUT','java.lang.Boolean' )
/

    INSERT 
    INTO
        pricing_param_name
        ( default_value, display_name, is_global_b, param_comment, param_domain, param_name, param_type ) 
    VALUES
        ('false','MC_FROM_TRADE_DATE',1,'Compute Margin Call measures from trade date','true,false','MC_FROM_TRADE_DATE','java.lang.Boolean' )
/

    INSERT 
    INTO
        pricing_param_name
        ( default_value, is_global_b, param_comment, param_domain, param_name, param_type ) 
    VALUES
        ('false',1,'Fee Amortizations','true,false','FEE_AM_DISCOUNT','java.lang.Boolean' )
/

    INSERT 
    INTO
        pricing_param_name
        ( default_value, is_global_b, param_comment, param_domain, param_name, param_type ) 
    VALUES
        ('false',1,'If true Accrual and perm_disc is in Quoting ccy else in primary ccy','true,false','IS_UNEVENFXSWAP_ACCRUAL_QUOTING','java.lang.Boolean' )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('DataExportServiceEngine','PSEventProcessOrder','Back-Office' )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('MatchableBuilderEngine','PSEventMessage','Back-Office' )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('MatchableBuilderEngine','PSEventProcessMessage','Back-Office' )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('MatchableBuilderEngine','PSEventProcessTransfer','Back-Office' )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('MatchableBuilderEngine','PSEventProcessTrade','Back-Office' )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('MatchableBuilderEngine','PSEventTrade','Back-Office' )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('MatchableBuilderEngine','PSEventTransfer','Back-Office' )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('MatchingEngine','PSEventMatchable','Back-Office' )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('MatchingEngine','PSEventDomainChange','Back-Office' )
/

    INSERT 
    INTO
        ps_event_config
        ( engine_name, event_class, event_config_name ) 
    VALUES
        ('FIXEngine','PSEventFIXMessage','Back-Office' )
/

    INSERT 
    INTO
        ps_event_filter
        ( engine_name, event_config_name, event_filter ) 
    VALUES
        ('DataExportServiceEngine','Back-Office','DataExportServiceEngineEventFilter' )
/

    INSERT 
    INTO
        ps_event_filter
        ( engine_name, event_config_name, event_filter ) 
    VALUES
        ('MatchableBuilderEngine','Back-Office','MatchableBuilderEventFilter' )
/

    INSERT 
    INTO
        ps_event_filter
        ( engine_name, event_config_name, event_filter ) 
    VALUES
        ('MatchingEngine','Back-Office','MatchingEventFilter' )
/

    INSERT 
    INTO
        ps_event_filter
        ( engine_name, event_config_name, event_filter ) 
    VALUES
        ('FIXEngine','Back-Office','FIXEngineEventFilter' )
/

    INSERT 
    INTO
        report_win_def
        ( def_name, use_book_hrchy, use_color, use_pricing_env, win_def_id ) 
    VALUES
        ('PLMarkPermanentAdjustment',0,0,0,3551 )
/

    INSERT 
    INTO
        report_win_def
        ( def_name, use_book_hrchy, use_color, use_pricing_env, win_def_id ) 
    VALUES
        ('PLMarkPermanentAdjustmentDrillDown',0,0,0,3552 )
/

    INSERT 
    INTO
        hc_subsystem
        ( priority, subsystem_name, subsystem_type ) 
    VALUES
        ('CRITICAL','NONE','System' )
/

    INSERT 
    INTO
        hc_subsystem
        ( enabled, priority, subsystem_name, subsystem_type ) 
    VALUES
        (1,'CRITICAL','NONE','Calypso' )
/

    INSERT 
    INTO
        hc_subsystem
        ( priority, subsystem_name, subsystem_type ) 
    VALUES
        ('CRITICAL','NONE','Engine' )
/

    INSERT 
    INTO
        hc_subsystem
        ( priority, subsystem_name, subsystem_type ) 
    VALUES
        ('CRITICAL','CalypsoDatabase','Database' )
/

    INSERT 
    INTO
        hc_subsystem
        ( priority, subsystem_name, subsystem_type ) 
    VALUES
        ('CRITICAL','MiddleTierDatabase','Database' )
/

    INSERT 
    INTO
        hc_subsystem
        ( enabled, priority, subsystem_name, subsystem_type ) 
    VALUES
        (1,'CRITICAL','NONE','CalypsoScheduler' )
/

    INSERT 
    INTO
        hc_sensor
        ( description, priority, red_threshold, sensor_name, subsystem_name, subsystem_type ) 
    VALUES
        ('Check connectivity to main Calypso database by executing a query','CRITICAL','false','database-check','CalypsoDatabase','Database' )
/

    INSERT 
    INTO
        hc_sensor
        ( amber_threshold, description, priority, red_threshold, sensor_name, subsystem_name, subsystem_type ) 
    VALUES
        ('95','Monitor memory usage','NON_CRITICAL','98','memory-check','NONE','System' )
/

    INSERT 
    INTO
        hc_sensor
        ( description, priority, red_threshold, sensor_name, subsystem_name, subsystem_type ) 
    VALUES
        ('Check connectivity to MiddleTier database','CRITICAL','false','risk-database-check','MiddleTierDatabase','Database' )
/

    INSERT 
    INTO
        hc_sensor
        ( description, priority, red_threshold, sensor_name, subsystem_name, subsystem_type ) 
    VALUES
        ('Check that current process has a valid DSConnection','CRITICAL','false','DS-connection','NONE','Calypso' )
/

    INSERT 
    INTO
        hc_sensor
        ( amber_threshold, description, priority, red_threshold, sensor_name, subsystem_name, subsystem_type ) 
    VALUES
        ('10000','Monitor engine unconsumed events','CRITICAL','20000','engine-unconsumed-events','NONE','Engine' )
/

    INSERT 
    INTO
        hc_sensor
        ( description, priority, red_threshold, sensor_name, subsystem_name, subsystem_type ) 
    VALUES
        ('Check that related engine is actually running','NON_CRITICAL','false','engine-running','NONE','Engine' )
/

    INSERT 
    INTO
        hc_sensor
        ( amber_threshold, description, priority, red_threshold, sensor_name, subsystem_name, subsystem_type ) 
    VALUES
        ('98','Monitor scheduler memory','CRITICAL','100','scheduler-memory-check','NONE','CalypsoScheduler' )
/

    INSERT 
    INTO
        engine_config
        ( engine_comment, engine_id, engine_name ) 
    VALUES
        (null,509,'ACADIAMessageEngine' )
/

    INSERT 
    INTO
        engine_config
        ( engine_comment, engine_id, engine_name ) SELECT
            null,
            coalesce(max(engine_id)+1,
            100),
            'DataExportServiceEngine' 
        FROM
            engine_config 
        WHERE
            1=1
/

    INSERT 
    INTO
        engine_config
        ( engine_comment, engine_id, engine_name ) SELECT
            null,
            coalesce(max(engine_id)+1,
            100),
            'KPIEngine' 
        FROM
            engine_config 
        WHERE
            1=1
/

    INSERT 
    INTO
        engine_config
        ( engine_comment, engine_id, engine_name ) SELECT
            null,
            max(engine_id)+1,
            'UpdateManagerEngine' 
        FROM
            engine_config 
        WHERE
            1=1
/

    INSERT 
    INTO
        engine_config
        ( engine_comment, engine_id, engine_name ) SELECT
            null,
            max(engine_id)+1,
            'DataUploaderEngine' 
        FROM
            engine_config 
        WHERE
            1=1
/

    INSERT 
    INTO
        engine_config
        ( engine_comment, engine_id, engine_name ) SELECT
            null,
            coalesce(max(engine_id)+1,
            100),
            'FIXEngine' 
        FROM
            engine_config 
        WHERE
            1=1
/

    INSERT 
    INTO
        engine_config
        ( engine_comment, engine_id, engine_name ) SELECT
            'MatchingEngine',
            coalesce(max(engine_id)+1,
            100),
            'MatchingEngine' 
        FROM
            engine_config 
        WHERE
            1=1
/

    INSERT 
    INTO
        engine_config
        ( engine_comment, engine_id, engine_name ) SELECT
            'MatchableBuilderEngine',
            coalesce(max(engine_id)+1,
            100),
            'MatchableBuilderEngine' 
        FROM
            engine_config 
        WHERE
            1=1
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','00632a8a-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','FX','FXCompoundOption','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','b4bcc85e-40d0-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','FX','FXNDF','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','c6d1c06c-40d0-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','FX','FXNDFSwap','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','e3d4bf2a-40d0-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','FX','FXOption','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','f054f742-40d0-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','FX','FXOptionForward','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','ffc8431e-40d0-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','FX','FXOptionStrategy','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','11dee954-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','FX','FXOptionStrip','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','1c1a502a-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','FX','FXOptionSwap','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','20f77122-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','FX','FXSwap','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','25384af4-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','FX','PositionFXExposure','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','29db7fcc-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','FX','PositionFXNDF','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','2f083418-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','CancellableSwap','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','39ea7530-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','CancellableXCCySwap','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','3e2905e4-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','CapFloor','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','42bd002e-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','CappedSwap','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','4ab6713e-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','CappedSwapNonDeliverable','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','4f818fa0-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','ExoticCapFloor','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','54eca024-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','FRA','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','59bd1016-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','FRAInArrear','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','5da286e8-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','FRAStandard','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','62dab068-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','PreciousMetalDepositLease','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','042a3956-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','PreciousMetalLeaseRateSwap','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','d3eb224c-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','ScriptableOTCProduct','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','da40179c-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','SingleSwapLeg','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','e0a71496-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','SpreadCapFloor','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','e63d7418-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','SpreadLock','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','078e661c-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','SpreadSwap','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','ed6a9c66-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','StructuredProduct','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','0b2ce1e0-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','Swap','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','f3e6268c-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','SwapCrossCurrency','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','fa4aa99e-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','SwapNonDeliverable','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','ff9575fa-40d1-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','Swaption','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','0338ff6a-40d2-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','TriggerSwaption','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','0760d8b0-40d2-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','VarianceSwap','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','0b6b7b86-40d2-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','XCCySwap','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','105fddbc-40d2-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','RATES','IRStructuredOption','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','13fc5a9a-40d2-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','CancellableCDS','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','192ac90c-40d2-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','CancellableCDSNthDefault','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','1f32e852-40d2-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','CancellableCDSNthLoss','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','25cd43ce-40d2-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','CDSABSIndex','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','0e79bb02-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','CDSABSIndexTranche','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','12090746-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','CDSIndex','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','1588bf56-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','CDSIndexDefinition','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','18c9da74-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','CDSIndexOption','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','1c61a98c-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','CDSIndexTranche','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','200875e8-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','CDSIndexTrancheOption','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','9782f6a2-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','CDSNthDefault','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','9d9e02ac-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','CDSNthLoss','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','baad385e-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','ContingentCreditDefaultSwap','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','be7d0ce8-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','CreditDefaultSwap','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','c2c2c1ee-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','CreditDefaultSwapABS','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','c6573010-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','CreditDefaultSwapLoan','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','caddcfcc-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','CreditDefaultSwaption','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','ce72816e-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','ExtendibleCDS','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','d234cab4-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','ExtendibleCDSNthDefault','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','d5b9f376-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','ExtendibleCDSNthLoss','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','d96c9aa0-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','CREDIT','StructuredTranche','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','dcc1e462-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','COMMODITY','Commodity','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','e09619e6-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','COMMODITY','CommodityCertificate','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','e4603688-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','COMMODITY','CommodityForward','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','e8066e38-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','COMMODITY','CommodityIndexSwap','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','eb38d5b4-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','COMMODITY','CommodityOTCOption2','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','ee6fe4e8-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','COMMODITY','CommoditySwap','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','aa7a545c-40d4-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','COMMODITY','CommoditySwap2','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','60c0fe9a-40db-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','COMMODITY','CommoditySwaption','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','f3f1ed08-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','COMMODITY','OTCCommodityOption','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','f90b57a2-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','CFDConvertibleArbitrage','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','fd24b978-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','CFDDirectional','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','fff0ce3a-40d3-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','CFDPairTrading','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','0326cbb8-40d4-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','CFDRiskArbitrage','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','060e2cae-40d4-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','EquityCliquetOption','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','09859ffc-40d4-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','EquityForward','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','127104da-40d4-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','EquityIndex','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','15edab0e-40d4-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','EquityLinkedSwap','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','19568770-40d4-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','EquityStructuredOption','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','2ef1344a-40d4-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','OTCEquityOption','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','b25aedb2-40d4-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','OTCEquityOptionVanilla','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','b6cadfec-40d4-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','PerformanceSwap','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','bb5809a4-40d4-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','PortfolioSwap','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','c094ce02-40d4-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','PortfolioSwapPosition','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','d065dbc0-40d2-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','QuotableStructuredOption','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','e0a847ac-40d2-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','TotalReturnSwap','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','e814e00e-40d2-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','TRSBasket','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','eda147e2-40d2-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','VarianceOption','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','f1892226-40d2-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','VolatilityIndex','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','f72abdfc-40d2-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','Warrant','SYSTEM',0,0 )
/

    INSERT 
    INTO
        cm_product_mapping
        ( creation_date, creation_user, creation_user_type, id, last_update_date, last_update_user, last_update_user_type, product_class, product_type, source, tenant_id, version ) 
    VALUES
        (1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','fb4b9438-40d2-11eb-b378-0242ac130002',1608249902,'00000000-0000-0000-0000-000000000000','urn:calypso:cloud:platform:iam:model:User','EQUITY','WarrantIssuance','SYSTEM',0,0 )
/

    INSERT 
    INTO
        calypso_seed
        ( last_id, seed_alloc_size, seed_name ) 
    VALUES
        (0,500,'ScheduledTaskExecutionID' )
/

    INSERT 
    INTO
        calypso_seed
        ( last_id, seed_alloc_size, seed_name ) 
    VALUES
        (0,1,'PortfolioCFHTag' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Role function','function','MARGIN_ADMINRole' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Role function','function','MARGIN_USERRole' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'CollateralType','Acadiasoft Expected' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'eventType','PLEDGE_COLLATERAL' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'eventType','NOTIF_CANCEL_COLLATERAL' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('Collateral.AcadiaMarginCallType','Regulatory Netted' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('mccAdditionalField.ACADIA_MASTER_TYPE','Regulatory Netted' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Types of Acadia call for NotificationTime','domainName','Collateral.AcadiaNotificationTimeType' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('Collateral.AcadiaNotificationTimeType','No STP' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('Collateral.AcadiaNotificationTimeType','Auto Dispute' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If true, triggering systematically a ''Yellow transfer'' on Bond redemption date=Repo end date. If false, the ''Yellow transfer'' must not be created. Note that this blocker must also work if the matured Bond is just one piece of a multi-collateral trade','CA.generateSecFinanceClaimIdXfer','true' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'SecFinance.FillType','MONEY FILL' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'SecFinance.FillType','NONE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'scheduledTask','MARGIN_IMPORT_SCENARIO_SHIFTS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'scheduledTask','MARGIN_SIMULATION' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'scheduledTask','MARGIN_IA_INPUT' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'scheduledTask','MARGIN_IA_CALCULATOR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'securityCode','ISDA_SIMM_QUALIFIER' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','UMR_TAGGING' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'systemKeyword','UMR_TAGGING_TRADE_VERSION' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'nonCopiableKeyword','UMR_TAGGING_TRADE_VERSION' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'PricingSheetKeywordsToClearUponCopy','UMR_TAGGING_TRADE_VERSION' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'keyword.UMR_TAGGING','false' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('List of currencies for which to treat as XCcyBasis risk during MSA','domainName','ISDASIMM.treatIRCurveAsXccyBasis.Currencies' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('List of currencies for which to treat as XCcyBasis risk during MSA','domainName','ISDASIMM.flipXccyBasisRisk.Currencies' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Trade Status for which the UMR Tagging will be attempted','domainName','Margin.UMR.TradeTaggingEligibleStatus' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('gateway','MX.T2' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('domainName','MX.DisplayAppHeader' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('domainName','MX.Templates.COV' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('domainName','SWIFT.Templates.GPI' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('domainName','MX.BAH.Versions' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('domainName','MX.BAH.BusinessService.Versions' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','SecuritiesSettlementTransactionInstructionT2S.selector' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','sese.023.001.T2S' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','sese.030.001.T2S' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('07','MX.Versions','sese.023.001.T2S' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('07','MX.Versions','sese.030.001.T2S' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','DataExporterMessageComplete' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'engineName','DataExportServiceEngine' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Data Exporter Engine Event Filter','eventFilter','DataExportServiceEngineEventFilter' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('DataExportServiceEngine','applicationName','DataExportServiceEngine' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Scheduled Task for Exporting trades','scheduledTask','DATA_EXPORTER' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Objects configured in this domain will not be exported by the DataExporter engine','domainName','DataExportServiceEngine.excludedStaticData' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Scheduled Task for Exporting Portfolio Swap Contracts','scheduledTask','PFS_CONTRACT_EXPORT' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Used by MT9xx integration process when retrieve GL Account. Permits to define the LEContact type we are looking for','domainName','MappingIncomingWithContact' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('specify the rating agencies investment grade','domainName','Investment_Grade' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Contains all custom rules for which exception messages are displayed','domainName','KeepCustomWorkflowRuleMessages' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Moody''s','Investment_Grade','Aaa' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Moody''s','Investment_Grade','Aa1' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Moody''s','Investment_Grade','Aa2' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Moody''s','Investment_Grade','Aa3' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Moody''s','Investment_Grade','A1' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Moody''s','Investment_Grade','A2' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Moody''s','Investment_Grade','A3' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Moody''s','Investment_Grade','Baa1' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Moody''s','Investment_Grade','Baa2' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Moody''s','Investment_Grade','Baa3' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Fitch / Standard & Poor''s','Investment_Grade','AAA' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Fitch / Standard & Poor''s','Investment_Grade','AA+' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Fitch / Standard & Poor''s','Investment_Grade','AA' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Fitch / Standard & Poor''s','Investment_Grade','AA-' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Fitch / Standard & Poor''s','Investment_Grade','A+' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Fitch / Standard & Poor''s','Investment_Grade','A' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Fitch / Standard & Poor''s','Investment_Grade','A-' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Fitch / Standard & Poor''s','Investment_Grade','BBB+' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Fitch / Standard & Poor''s','Investment_Grade','BBB' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Fitch / Standard & Poor''s','Investment_Grade','BBB-' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','ABS.PrepayTypes' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ABS.PrepayTypes','CPR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ABS.PrepayTypes','PSA' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ABS.PrepayTypes','SMM' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ABS.PrepayTypes','PPC' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ABS.PrepayTypes','ABS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ABS.PrepayTypes','CPY' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ABS.PrepayTypes','CPP' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ABS.PrepayTypes','CPB' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ABS.PrepayTypes','CPJ' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'accountProperty','IB_MISSING_RATE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','CurrencyLockInNetting.tradeActionsSupported' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'CurrencyLockInNetting.tradeActionsSupported','NEW' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'CurrencyLockInNetting.tradeActionsSupported','AMEND' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'CurrencyLockInNetting.tradeActionsSupported','ASSIGN' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'CurrencyLockInNetting.tradeActionsSupported','BO_AMEND' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'CurrencyLockInNetting.tradeActionsSupported','BO_CANCEL' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','CurrencyLockInNetting.tradeAmendActions' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'CurrencyLockInNetting.tradeAmendActions','AMEND' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'CurrencyLockInNetting.tradeAmendActions','BO_AMEND' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('List of rate curve usages which will be used by Scenario/Sensitivity/Simulation analysis','domainName','ScenarioMarketDataSet.Rates' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('feeDefinitionAttributes.ETD.InventoryBucket','NFA' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('feeDefinitionAttributes.ETD.InventoryBucket','Brokerage' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('feeDefinitionAttributes','UseFeeDiscountRate' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('feeDefinitionAttributes.UseFeeDiscountRate','true' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('feeDefinitionAttributes.UseFeeDiscountRate','false' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('AFR for US, published by ISR','tradeKeyword','FeeDiscountingRate' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Sets FeeDiscountRate as trade Keyword','workflowRuleTrade','SetFeeDiscountRateFromAFR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'FutureContractAttributes','Source Contract Name' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'FutureOptionContractAttributes','Source Contract Name' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ETOContractAttributes','Source Contract Name' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'FutureContractAttributes','GMIProduct' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'FutureOptionContractAttributes','GMIProduct' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ETOContractAttributes','GMIProduct' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'FutureContractAttributes','ClearingExchangeTicker' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'FutureOptionContractAttributes','ClearingExchangeTicker' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ETOContractAttributes','ClearingExchangeTicker' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'FutureContractAttributes','CAClearingExchangeTicker' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'FutureOptionContractAttributes','CAClearingExchangeTicker' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ETOContractAttributes','CAClearingExchangeTicker' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('domainName','InterpolateOnPaymentPeriod' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('InterpolateOnPaymentPeriod','False' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('domainName','ApplyPmtLagtoPrincipalFlows' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('ApplyPmtLagtoPrincipalFlows','True' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('domainName','exerciseDoInterestCleanUp' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('exerciseDoInterestCleanUp','True' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('domainName','InterpolateIgnoreEOMRoll' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('InterpolateIgnoreEOMRoll','False' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('domainName','LadderPL_LinearProducts' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('PricerMeasureFromDB measures that are not amounts','domainName','PricerMeasureFromDB_NOCONVERT' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','ReferenceRates.FX' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','ReferenceRates.FXForward' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','ReferenceRates.FXSwap' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','ReferenceRates.FXNDF' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','ReferenceRates.FXNDFSwap' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','ReferenceRates.FXFlexiForward' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','ReferenceRates.FXFlexiForwardWindowForward' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','ReferenceRates.FXMerchantFX' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','ReferenceRates.FXForwardStart' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','BondAssetBacked.DC30_360_SpecialDiscountingFor31' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Locale for Bond quotes','LocaleForBondQuotes','English' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Default Base Precious Metal Unit - Ounces','currencyDefaultAttribute','PreciousMetalBaseUnit' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleMessage','CheckNettingMatchingConfirm' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleMessage','CreatePenaltyTrade' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'currencyPairAttribute','DefaultPositionSplitCcy' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Allow User to save current TaskStation Layout','function','AuthorizeTSCreateLayout' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Allow User to save current TaskStation Layout','function','AuthorizeTSDeleteLayout' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Allow User to save current TaskStation Layout','function','AuthorizeTSSaveLayout' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Allow User to activate Catalog Auto Task Count','function','TS_Auto_Task_Count' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Restrict Filter of TaskStation Report','function','RestrictTSTabFilteringFilter' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Restrict Filter of TaskStation Report','restriction','RestrictTSTabFilteringFilter' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Domain to specify the different number formatting used in formatter','domainName','FormatNumber' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'FormatNumber','CALYPSO' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'FormatNumber','SWIFT' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'FormatNumber','MATH' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('PFS Contract Underlying Product Type','domainName','PFSContractUnderlying' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('List of contract fields to check for duplicate PFS contract','domainName','duplicateContractFields' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'sdiAttribute','IBAN.Agent' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'sdiAttribute','IBAN.Intermediary' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'sdiAttribute','IBAN.Intermediary2' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'function','CreatePLMarkPermanentAdjustment' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'function','ModifyPLMarkPermanentAdjustment' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('tk.util.TradeCustodyLiquidationSequencePolicy','engineEventPoolPolicyAliases','CustodyLiquidation' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Sequence Policy for Custody Trades in the LiquidationEngine (optional)','engineEventPoolPolicies','tk.util.TradeCustodyLiquidationSequencePolicy' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'classAuditMode','AmColoringConfiguration' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'classAuditMode','AmColumnConfiguration' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'classAuditMode','AmColumnSetConfiguration' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'classAuditMode','AmFilteringConfiguration' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'classAuditMode','AmFormulaConfiguration' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'classAuditMode','AmGroupingConfiguration' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'classAuditMode','AmLayoutConfiguration' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'classAuditMode','AmUnitConfiguration' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'classAuditMode','AmWidgetConfiguration' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'classAuditMode','AmServerConfiguration' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('function name for Auhorizing SD Filter','function','CheckPermForSDFilter' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('restriction name for Auhorizing SD Filter','restriction','CheckPermForSDFilter' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Hull-White Model correlations','correlationType','HW' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Display Notional before settle date','domainName','Cash_Forward_Settle_Notional' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (' ','Cash_Forward_Settle_Notional','true' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Compliance Result Report','REPORT.Types','ComplianceResult' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('PremiumFee','domainName','capitalizePremiumFeeType' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','ptfHedgeCyclePhase' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Types of FXAveragingForward','domainName','FXAveragingForward.subtype' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Sigmas Model Calibrator','ModelCalibrator','LGMMNFSigmas' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Backbone Model Calibrator','ModelCalibrator','LGMMNFBackbone' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('FX Model Calibrator','ModelCalibrator','LGMMNFFX' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('FX Model Calibrator','ModelCalibrator','LGMMNFEquity' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Future Dividend Index product','PositionBasedProducts','FutureDividendIndex' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('FutureOption Dividend Index product','PositionBasedProducts','FutureOptionDividendIndex' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('domainName','bookAttribute.Include WHT In OPL' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('bookAttribute.Include WHT In OPL','true' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('bookAttribute.Include WHT In OPL','false' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'systemKeyword','SecondTradeId' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'systemKeyword','FirstTradeId' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'systemKeyword','OriginalEvent' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'systemKeyword','LiqConfigName' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'systemKeyword','LiquidationAggregation' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The exercised amount stored on the parent trade after full or partial termination or exercise','systemKeyword','ExerciseAmount' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('OfficialPLAnalysis PL Explain Export Report.','scheduledTask','OFFICIALPLEXPLAINEXPORT' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('OfficialPL Permanent Adjustments Process.','scheduledTask','OFFICIALPLPERMANENTADJUSTMENTS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Override AssetValue and UnrealizedMTM mark values.  For block trades, adjustment will be done proportionally on the allocated trades.','scheduledTask','OFFICIALPLVALUEOVERRIDE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Rerates applicable trades.','scheduledTask','UPD_TRADES_PFS_RERATE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','TriangleShifts_Daily' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','TriangleShifts_Weekly' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('DeferredPL','productType','DeferredPL' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CLIQUET option Product subtype','EquityStructuredOption.subtype','CLIQUET MULTIPLICATIVE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleTrade','IBBulkChaser' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Max number of PendingModificationAudit allowed','userAccessPermAttributes','Max.PendingModif' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('domainName','OfficialPL Permanent Adjustment Reason' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'accEventProperty','PRINCIPAL' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'accEventProperty','COLLAT_REC_REHYPO' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'accEventProperty','COLLAT_REC_N_REHYPO' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'accEventProperty','MC_REC_REHYPO' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'accEventProperty','MC_REC_N_REHYPO' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'accEventProperty','COLLAT_GIV_REHYPO' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'accEventProperty','COLLAT_GIV_N_REHYPO' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'accEventProperty','MC_GIV_REHYPO' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'accEventProperty','MC_GIV_N_REHYPO' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'accEventType','PTF_HEDGED_MTM_CHG' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'feeGridAttribute','FeeSettleCurrency' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'feeGridAttribute','FeeSettleCurrency.PricingEnv' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'feeGridAttribute','FeeSettleCurrency.FXRateName' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'feeGridAttribute','FeeSettleCurrency.FixingDate' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'feeGridAttribute.FeeSettleCurrency.FixingDate','TradeDate' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'feeGridAttribute.FeeSettleCurrency.FixingDate','FeeDate' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'DeferredPL.Pricer','PricerDeferredPL' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'FXAveragingForward.Pricer','PricerFXAveragingForward' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Pricer for variance swap by replication on an equity/index underlying','VarianceSwap.Pricer','PricerCarrLeeVolatilityDerivative' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('List of products with Physical Settlement that are allowed for realized PL generation ','domainName','IncludeRealizedPLProductsPhysical' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'IncludeRealizedPLProductsPhysical','FutureBond' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'IncludeRealizedPLProductsPhysical','FutureCommodity' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'IncludeRealizedPLProductsPhysical','FutureEquity' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'IncludeRealizedPLProductsPhysical','FutureEquityIndex' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'IncludeRealizedPLProductsPhysical','FutureFX' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'IncludeRealizedPLProductsPhysical','FutureMM' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Brazilian Bonds','Bond.subtype','NTN-C' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Price calculated using individual fixing notionals','FXAveragingForward.subtype','SettleByIndividualFixing' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Price calculated as the average of the fixing rates','FXAveragingForward.subtype','SettleByAverageRate' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'SimpleTransfer.subtype','PENALTY' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'Swap.subtype','ArrearConvexityAdj' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'eventClass','PSEventCollateralValuation' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'eventClass','PSEventOrderBundle' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Generic Object on Object Event','eventClass','PSEventGenericOnObject' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'eventType','TRADE_COLLATERAL_VALUATION' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'eventType','EX_ANONYMIZING' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'eventType','EX_OUT_OF_SEQUENCE_EVENT' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'exceptionType','ANONYMIZING' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Trade Seed Allocation','exceptionType','TRADE_SEED_ALLOCATION' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to open Bloomberg Connect Window.','function','AccessBloombergConnect' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to create feed parameters','function','CreateFeedParams' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to remove feed parameters','function','RemoveFeedParams' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to read feed parameters','function','ReadFeedParams' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'exceptionType','OUT_OF_SEQUENCE_EVENT' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to authorize anonymizing LE Attributes','function','AuthorizeLEAttributeAnonymity' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to authorize anonymizing LE Contact','function','AuthorizeLEContactAnonymity' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to authorize anonymizing LegalEntity','function','AuthorizeLegalEntityAnonymity' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access Permission to AddEquityReset','function','AddEquityReset' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access Permission to RemoveEquityReset','function','RemoveEquityReset' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to Add/Modify Template in DB','function','AddModifyTemplateInDB' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to Delete Template in DB','function','DeleteTemplateInDB' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Permission for read only access to WebAdmin','function','WebAdminAccess' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Permission to Amend CWS Report Collection','function','ModifyCWSReportCollection' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'PFSContractUnderlying','Equity' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'PFSContractUnderlying','Equity Index' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'PFSContractUnderlying','Future Equity Index' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'productFamily','FXAveragingForward' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'productType','FXAveragingForward' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'riskAnalysis','FOLivePL' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'riskAnalysis','LadderLivePL' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'scheduledTask','ARCHIVE_ORDERS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'scheduledTask','ARCHIVE_COMPLIANCE_OBJECTS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'scheduledTask','EOD_AMORTIZATION_TRADE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'scheduledTask','EOD_AMORTIZATION_PL' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Generate TransferAgent trades from transfers linked to CA trades','scheduledTask','CA_TRANSFER_AGENT' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'scheduledTask','SECFINANCE_COLLATERAL_VALUATION' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'scheduledTask','PROCESS_TRIPARTY_DUMMY' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('New Argentine Yield Method','yieldMethod','ARS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','SecondTradeId' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','FirstTradeId' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','OriginalEvent' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','LiqConfigName' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','LiquidationAggregation' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','CAProductId' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('QuartzTaskRunner','applicationName','QuartzTaskRunner' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Message length exceeded','MsgAttributes.NackReason','M50' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Non-SWIFT character encountered (a character not included in the character sets. Also see error code T32.)','MsgAttributes.NackReason','M60' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Unable to determine the reason for NAK. Please contact your CSC immediately for advice.','MsgAttributes.NackReason','T02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T06' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T07' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T08' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T09' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The repetitive sequence occurred more than the maximum number of times permitted.','MsgAttributes.NackReason','T10' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The repetitive sequence occurred less than the minimum number of times required.','MsgAttributes.NackReason','T11' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Field, line, subfield, or component content error.','MsgAttributes.NackReason','T12' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The field tag is not expected at this location in this MT. Either a mandatory field is missing or the specified field is not a defined SWIFT field.','MsgAttributes.NackReason','T13' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Subfield[N] (negative indicator) must not be used when the amount, number, or number count component is equal to zero.','MsgAttributes.NackReason','T14' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Sign is not valid. SIGN must be either  +  or  - .','MsgAttributes.NackReason','T15' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Time offset is not valid. OFFSET has the same format as time HHMM.','MsgAttributes.NackReason','T16' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Field, line, subfield, or component consists of blanks, CRLF, or it is missing a mandatory line, subfield, or component.','MsgAttributes.NackReason','T17' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Component is not in the format 3!n and/or it is not within the range 100-999.','MsgAttributes.NackReason','T18' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T19' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in subfield 1, component 3, of field 32K or 33K.','MsgAttributes.NackReason','T20' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('(Available).','MsgAttributes.NackReason','T21' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('A common reference mismatch exists between field 22, subfield 2, component 2 and one of the following:','MsgAttributes.NackReason','T22' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Subfield 8 in field 61, subfield 5 in field 66A, or subfield 6 in field 26C is too long or contains only  // , or subfield 2 in fields 26A or 26B is too long or contains only  / .','MsgAttributes.NackReason','T23' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Subfield 7 in field 61, subfield 4 in field 66A, subfield 5 in field 26C, subfield 1 in fields 26A or 26B is missing or is too long.','MsgAttributes.NackReason','T24' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Subfields 7 or 8 in field 61, subfield 4 or 5 in field 66A, subfield 5 or 6 in field 26C, subfield 1 or 2 in fields 26A or 26B has improper content.','MsgAttributes.NackReason','T25' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Subfield 7 or 8 in field 61, subfield 4 or 5 in field 66A, subfield 5 or 6 in field 26C, subfield 1 or 2 in fields 26A or 26B has improper content.','MsgAttributes.NackReason','T26' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('BIC incorrectly formatted or invalid.','MsgAttributes.NackReason','T27' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('SWIFT BIC is not a valid destination.','MsgAttributes.NackReason','T28' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('SWIFT BIC contains an invalid branch code.','MsgAttributes.NackReason','T29' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Excessive lines, subfields, or components were found in this field.','MsgAttributes.NackReason','T30' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The line, subfield, or component separator or delimiter is missing or incorrect.','MsgAttributes.NackReason','T31' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('An expected subfield, component, or component separator was not found.','MsgAttributes.NackReason','T32' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The length of the field is too long, or, the component consists of one or more hidden characters, or, the component consists of one or more imbedded characters which are inconsistent with the defined field format, or wrong character set.','MsgAttributes.NackReason','T33' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The length of the field, line, subfield, or component contents is too short.','MsgAttributes.NackReason','T34' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in subfield 1, field 26C.','MsgAttributes.NackReason','T35' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T36' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T37' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Illogical time specified.','MsgAttributes.NackReason','T38' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Time of UTC Indicator HHMM] is not in the valid range.','MsgAttributes.NackReason','T39' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Missing amount/number or incorrect amount/number first character.','MsgAttributes.NackReason','T40' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in subfield 3, field 66A.','MsgAttributes.NackReason','T41' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in subfield 3, field 35U.','MsgAttributes.NackReason','T42' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The decimal separator in the amount/number subfield or component is missing, is not a valid character, or more than one separator is present.','MsgAttributes.NackReason','T43' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The SWIFT BIC exists but it is not enabled for FIN, or the BIC is active but it is not published in the current BIC directory, or it is not cutover.','MsgAttributes.NackReason','T44' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Invalid non-SWIFT BIC.','MsgAttributes.NackReason','T45' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('A Test-and-Training destination must not be used in a LIVE message.','MsgAttributes.NackReason','T46' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In an ERI field the data part of a code word /OCMT/, or /CHGS/ was being validated but the ending separator. This error is also a code word error that applies to:','MsgAttributes.NackReason','T47' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T48' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('(Available).','MsgAttributes.NackReason','T49' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Date error. Either Invalid Date subfield (this check applies to all MTs with a Date subfield) OR Invalid year in a Value Date subfield of the MTs that are candidate for the Value Date Ordering process.','MsgAttributes.NackReason','T50' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word  C , D , RC , RD , EC , ED  error.','MsgAttributes.NackReason','T51' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Invalid currency code or price code  PCT , REN , or  YLD .','MsgAttributes.NackReason','T52' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in subfield 6, component 1 of field 61.','MsgAttributes.NackReason','T53' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The format of the first line of Field 50F (Party Identifier) is invalid.','MsgAttributes.NackReason','T54' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error. This check applies to Subfield 1, component 1:','MsgAttributes.NackReason','T55' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error. This check applies to Subfield 2, component 1:','MsgAttributes.NackReason','T56' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in subfield 2 of fields 31H, 31J, or 31X.','MsgAttributes.NackReason','T57' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T58' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('(Available).','MsgAttributes.NackReason','T59' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T60' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word  D  or  M  error.','MsgAttributes.NackReason','T61' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Either the first subfield DATE2[HHMM] or the second subfield 7!a but not both must be present. If optional subfield 1 is used, component 1 DATE2 of this subfield must be present.','MsgAttributes.NackReason','T62' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Error in component 2 of field 22C or subfield 2, component 2, of field 22. When the last character of this component is zero  0  and the preceding character is not one  1  then the entire component must consist of zeros.','MsgAttributes.NackReason','T63' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T64' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('(Available).','MsgAttributes.NackReason','T65' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T66' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T67' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T68' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('(Available).','MsgAttributes.NackReason','T69' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Either the Account number, the Place, or both must be present.','MsgAttributes.NackReason','T70' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T71' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T72' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Invalid country code. Please refer to the BIC Directory General Information -Country Codes-.','MsgAttributes.NackReason','T73' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The currency code must be the same for each indicated subfield in the field.','MsgAttributes.NackReason','T74' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In MTs 405, n92, n95, n96:','MsgAttributes.NackReason','T75' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The first character in the first line of this field must be a  / , and there must be at least another line, but not more than 5 lines. This check applies to field 50H.','MsgAttributes.NackReason','T76' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If the first character of the first line of this component or sub-component is a  / , then there must be at least another line, but not more than 5 lines. Otherwise, no more than 4 lines are allowed.','MsgAttributes.NackReason','T77' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Invalid or duplicated code word, or a mandatory code word is missing.','MsgAttributes.NackReason','T78' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('(Available).','MsgAttributes.NackReason','T79' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Field 72 Reject/Return or Field 79 Reject Return code word error, or mandatory code word missing, or code word not in proper sequence.','MsgAttributes.NackReason','T80' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Format of Field 72 Reject/Return is not allowed in this message.','MsgAttributes.NackReason','T81' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ERI format is not allowed in this message. Field 72, MT102_STP,103_STP.','MsgAttributes.NackReason','T82' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('(Available).','MsgAttributes.NackReason','T83' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('(Available).','MsgAttributes.NackReason','T84' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error. This check applies to Field 23G, subfield 2.','MsgAttributes.NackReason','T85' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T86' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In a generic field the colon  :  delimiter is not present at the expected position.','MsgAttributes.NackReason','T87' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Field 12 in MT570 may only consist of 571,572,573,577.','MsgAttributes.NackReason','T88' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In a generic field either the qualifier is invalid, the qualifier is duplicated, a mandatory qualifier is missing, or the qualifier format is not valid.','MsgAttributes.NackReason','T89' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In a generic field either the issuer code format is invalid, the mandatory issuer code is missing, or the generic field format is invalid.','MsgAttributes.NackReason','T90' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In a generic field the slash  /  delimiter is not present at the expected position.','MsgAttributes.NackReason','T91' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T92' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T93' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In field 22, subfield 2, or in field 22C, the components 1 and 3, the values  0  and  1  are not permitted in LC1 and LC2.','MsgAttributes.NackReason','T94' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In field 22, subfield 2, or in field 22C, the components 1 and 3 do not contain the bank code and location code of the message sender, and/or the bank code and location code of the message receiver.','MsgAttributes.NackReason','T95' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In field 22, subfield 2, or in field 22C, the components 1 and 3 are not in alphabetical sequence.','MsgAttributes.NackReason','T96' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error.','MsgAttributes.NackReason','T97' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('(Available).','MsgAttributes.NackReason','T98' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('A special function has been declared in the validation syntax that is not recognized.','MsgAttributes.NackReason','T99' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('AU/PDS: in MT100,103,202, the letter option of the selected field is not A or D.','MsgAttributes.NackReason','G01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('AU/PDS: in MT100,103,202, the format of the selected field option A is not valid.','MsgAttributes.NackReason','G02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('AU/PDS: in MT100,103,202, the format of the selected field option D is not valid.','MsgAttributes.NackReason','G03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('AU/PDS: the selected field is missing. At least one of the following fields must be present: MT100,103: fields 56a, 57a.','MsgAttributes.NackReason','G04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('LVTS: if 2 LVTS members and the first 6 characters of their destination ID are different, exchange a SWIFT message type 100,103,205, and if the currency code used in tag 32A is CAD then the tag 103 must be present','MsgAttributes.NackReason','G05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('REMIT: in a SWIFT message MT103, the field 77T and the tag 119 with the code word REMIT (in the User Header) must either both be present or absent.','MsgAttributes.NackReason','G06' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CLS: in an MT300 eligible for the FIN-Copy service CLS or CLT, any field 53 present in sequence B must be used with the letter option A.','MsgAttributes.NackReason','G07' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CLS: in an MT300 eligible for the FIN-Copy service CLS or CLT, both fields 57 in sequences B1 and B2 (index 20,24) must be used with the letter option A, field 57a: of subsequence B1 must contain the CLSB BIC bank code.','MsgAttributes.NackReason','G08' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CLS: in an MT300 eligible for the FIN-Copy service CLS or CLT, if the tag 17U is used it must contain the value N.','MsgAttributes.NackReason','G09' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CLS: in an MT300 eligible for the FIN-Copy service CLS or CLT, any field 56 present in sequence B must be used with the letter option A.','MsgAttributes.NackReason','G10' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CLS: in an MT300 eligible for the FIN-Copy service CLS or CLT, if field 82 is present in sequence A it must be used with letter option A.','MsgAttributes.NackReason','G11' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CLS: in an MT300 eligible for the FIN-Copy service CLS or CLT, if field 87 is present in sequence A it must be used with letter option A.','MsgAttributes.NackReason','G12' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CLS: in an MT304 sent to the CLSB server, field 94A must contain the code ASET.','MsgAttributes.NackReason','G13' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CLS: in an MT304 sent to the CLSB server, field 82 in sequence A must be used with letter option A.','MsgAttributes.NackReason','G14' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CLS: in an MT304 sent to the CLSB server, field 87 in sequence A must be used with letter option A.','MsgAttributes.NackReason','G15' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CLS: in an MT304 sent to the CLSB server, any field 53 present in sequence B must be used with the letter option A.','MsgAttributes.NackReason','G16' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CLS: in an MT304 sent to the CLSB server, both fields 57 in sequence B must be used with letter option A and must contain the CLSB BIC bank code.','MsgAttributes.NackReason','G17' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('AU/PDS: in MT103 the format of the selected field letter option C is invalid.','MsgAttributes.NackReason','G18' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In MT 305 eligible for the FIN-Copy service CLS or CLT, field 53a must be used with option A.','MsgAttributes.NackReason','G19' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In MT 305 eligible for the FIN-Copy service CLS or CLT, field 56a must be used with option A.','MsgAttributes.NackReason','G20' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In MT 305 eligible for the FIN-Copy service CLS or CLT, field 57A must be present.','MsgAttributes.NackReason','G21' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In MT 305 eligible for the FIN-Copy service CLS (or CLT,) when the emitter and receiver are both CLS (or CLT) members, then field 57A must contain CLSB.','MsgAttributes.NackReason','G22' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In MT 305 eligible for the FIN-Copy service CLS (or CLT), when the emitter is CLS (or CLT) member and receiver is not, and field 34R is present, then field 57A must contain CLSB.','MsgAttributes.NackReason','G23' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In MT 305 eligible for the FIN-Copy service CLS (or CLT), both fields 56A and 57A must not contain the CLSB BIC bank code at the same time.','MsgAttributes.NackReason','G24' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('PAC Trailer used for non-Premium service message. Message has PAC trailer but sender or receiver, or both, are not members of Premium service.','MsgAttributes.NackReason','B01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('(Available)','MsgAttributes.NackReason','B02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('103:LCH present in the message, but sender, receiver, or both are not members of LCH, or the message type is not allowed for LCH, or, 103:TPS present in the message','MsgAttributes.NackReason','B03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('(Available)','MsgAttributes.NackReason','B04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('A system error has occurred. The user should contact their local Customer Service Center for further information.','MsgAttributes.NackReason','B05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Not Used.�','MsgAttributes.NackReason','C00' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('For MT 102_not_STP, 104, 10, if field 19 is present in sequence C, then it must equal the sum of the amounts in all occurrences of field 32B in sequence B.�','MsgAttributes.NackReason','C01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The currency code must be the same for all occurrences of indicated fields in the entire message. See the SWIFT Standards Category volumes for the indicated fields in each message.�','MsgAttributes.NackReason','C02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The number of decimal digits in the amount component is checked against the maximum allowed for the corresponding currency. This check is mostly applied to fields containing both the amount and the currency code components.�','MsgAttributes.NackReason','C03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 503, 504, 506: In sequence B, if field :19B::TEXA is not present, then field :19B::TCRL is mandatory; otherwise field :19B::TCRL is optional.�','MsgAttributes.NackReason','C04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The BIC must not be a BEI. That is, it must not be of subtype BEID, TRCO, MCCO, or SMDP. This error code applies to all types of BICs referenced in a FIN message, including SWIFT BICs, Non-SWIFT BICs, Masters, Synonyms, Live destinations and Test and�','MsgAttributes.NackReason','C05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 210: Either field 50a or field 52a, but not both, must be present in a repetitive sequence.�','MsgAttributes.NackReason','C06' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 516: Either field 35A or 35N must be present.�','MsgAttributes.NackReason','C07' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Available.�','MsgAttributes.NackReason','C08' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 430: In each occurrence of sequence A, if field 33a is present, then field 32a must be present.�','MsgAttributes.NackReason','C09' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 422: At least one of the fields 72, 75 or 76 must be present.�','MsgAttributes.NackReason','C10' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT400: If field 57a is present, fields 53a and 54a must be present.�','MsgAttributes.NackReason','C11' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 707, 747: When field 32B or 33B is present, field 34B must be present. Conversely, when field 34B is present, either field 32B or field 33B must be present.�','MsgAttributes.NackReason','C12' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 750: If any of fields 33B, 71B or 73 is present, field 34B must be present.�','MsgAttributes.NackReason','C13' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 559, 582, 754: Either field 53a or 57a, but not both, may be present.�','MsgAttributes.NackReason','C14' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 747: At least one of the fields 31E, 32B, 33B, 34B, 39A, 39B, 39C, 72 or 77A must be present.�','MsgAttributes.NackReason','C15' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 707: If field 23 is present, field 52a must be present.�','MsgAttributes.NackReason','C16' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 734: If field 73 is present, field 33a must be present.�','MsgAttributes.NackReason','C17' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 752: If fields 32B and 71B are present, field 33a must be present.�','MsgAttributes.NackReason','C18' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 754: Either field 72 or field 77A, but not both, may be present.�','MsgAttributes.NackReason','C19' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 601: Field 53a may be present only if field 34P is present.�','MsgAttributes.NackReason','C20' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT506: If sequence C is not present, then sequence D is mandatory. If one or more occurrence of sequence C is/are present, then sequence D is optional.(Error code(s): C21).�','MsgAttributes.NackReason','C21' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 920: If field 12 contains 942, field 34F must be present in the same repetitive sequence.�','MsgAttributes.NackReason','C22' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 940, 942: When only one field 34F is present, subfield 2 must not be used. When both fields 34F are present, subfield 2 of the first 34F must contain D, and subfield 2 of the second 34F must contain C.�','MsgAttributes.NackReason','C23' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 940: If field 86 is present in any occurrence of the repetitive sequence, it must be preceded by a field 61.�','MsgAttributes.NackReason','C24' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT n92:Field 79 or a copy of at least any fields (*) of the original message or both must be present.�','MsgAttributes.NackReason','C25' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 430:At least one of the optional fields 32a or 74 must be present.�','MsgAttributes.NackReason','C26' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 940, 941, 942, 950, 970, 972:The first two characters of the three-character currency code in fields 60F, 60M, 62F, 62M, 64, 65, 90C and 90D, in MTs 940, 941, 942, 950, 970 and 972, and field 34F in MT 942 must be the same for all occurrences of t�','MsgAttributes.NackReason','C27' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 544, 545, 546, 547:A value date should only be provided with an effective settlement amount, that is, in any occurrence of subsequence E3, if value date field :98a::VALU is present, then settled amount field :19A::ESTT must be present in the same �','MsgAttributes.NackReason','C28' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 645:Either field 71B in sequence A or field 71C in sequence C must be present, if sequence B is not present.�','MsgAttributes.NackReason','C29' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 707:At least one of the fields 31E, 32B, 33B, 34B, 39A, 39B, 39C, 44A, 44B, 44C, 44D, 44E, 44F, 79 or 72 must be present.�','MsgAttributes.NackReason','C30' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT n95, n96:Either field 79 or a copy of any field(s) of the original message to which this message relates, but not both, may be present.�','MsgAttributes.NackReason','C31' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 300, 303, 304, 306, 320, 330, 340, 350, 360, 361, 362, 363, 364, 365, 405, 582, 600, 643, 645, 813:An optional sequence of fields was used. However, a field that is required (that is, indicated by an \OR\) or a field that is mandatory (that is, �','MsgAttributes.NackReason','C32' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 768, 769:If field 71B is present, field 32a must be present.�','MsgAttributes.NackReason','C33' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 308:In each occurrence of Seq. B, either sequence B3 or sequence B4 must be present, but not both.�','MsgAttributes.NackReason','C34' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 643, 644, 645, 646, 649:Either field 21 or 29B must be present.�','MsgAttributes.NackReason','C35' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 643, 646:Subfield 2 (DATE2) of field 31F must be present in each occurrence of sequence B.�','MsgAttributes.NackReason','C36' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 577:Subfield 2 (DATE2) of field 67A must not be present.�','MsgAttributes.NackReason','C37' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 645:Subfield 3 (that is, 35x) of field 31F must not be present.�','MsgAttributes.NackReason','C38' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 813:Either sequence A or B must be present.�','MsgAttributes.NackReason','C39' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 920:The currency code must be the same for each occurrence of the indicated fields within each repetitive sequence.�','MsgAttributes.NackReason','C40' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 813:If field 34B or field 73 is present, field 32A must be present.�','MsgAttributes.NackReason','C41' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 820, 821, 823, 824:The currency code in each of the fields 68A of a sequence of fields 68A preceding a field 19 must be the same.�','MsgAttributes.NackReason','C42' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 646:Either field 32N or 33N must be present.�','MsgAttributes.NackReason','C43' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 646:If fields 32N and 33N are present in sequence C, field 34a must be present in sequence C.�','MsgAttributes.NackReason','C44' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 646:If field 23 contains REPRINC or PREPRINC, field 32N must be present in sequence C.�','MsgAttributes.NackReason','C45' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 646:If field 23 contains INT, field 33N must be present in sequence C.�','MsgAttributes.NackReason','C46' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 643:If field 23 contains LOAN/DRAWDOWN or FINARR/DRAWDOWN, sequence B must not be present.�','MsgAttributes.NackReason','C47' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 643:If field 23 contains LOAN/RENEWAL or FINARR/RENEWAL, sequence B must be present.�','MsgAttributes.NackReason','C48' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 456:If field 71B is present, the values in fields 32a and 33D must be different.�','MsgAttributes.NackReason','C49' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 540, 541, 541, 543:If field :36B::PAIR is present in a minimum of one occurrence of sequence A1, then the type of settlement transaction must be a pair-off (that is, sequence E field :22F::SETR//PAIR must be present and DSS must be absent).�','MsgAttributes.NackReason','C50' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 643:If field 23 contains LOAN/DRAWDOWN or LOAN/RENEWAL, field 31R must be present.�','MsgAttributes.NackReason','C51' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Available.MT 643:�','MsgAttributes.NackReason','C52' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 643:If field 71C is present in any sequence B, field 34a must be present in the same sequence.�','MsgAttributes.NackReason','C53' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 644:Either field 36 or field 37(A-F) must be present in any sequence B.�','MsgAttributes.NackReason','C54' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 644:In any sequence B, the currency code in fields 33B and 34a must be the same.�','MsgAttributes.NackReason','C55' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Available.MT 646:�','MsgAttributes.NackReason','C56' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 646:If field 34N is present in any sequence B, field 31F in the same sequence B and field 33N in sequence C must be present.�','MsgAttributes.NackReason','C57' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 300:In sequence A, if field 77D is present and if the first six(6) characters of the first line are equal to /VALD/ then the next eight(8) characters must contain a date expressed as YYYYMMDD and followed by the \end_of_line\ code (that is, \CRLF\�','MsgAttributes.NackReason','C58' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 300:In sequence A, if field 77D is present and if the first six (6) characters of the first line are equal to /VALD/, then the second line must be present and contain SETC.','MsgAttributes.NackReason','C59' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 307:In sequence A, the presence of field :22H::APER and the presence of field :22H::NEGR depend on the field :22H::CRTR as follows:�','MsgAttributes.NackReason','C60' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 307:In sequence A, the presence of field :22H::PAFI depends on field :22H::APER as follows:�','MsgAttributes.NackReason','C61' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 307:The presence of sequence C depends on field :22H::APER as follows:�','MsgAttributes.NackReason','C62' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In sequence A, the presence of the qualifier UNKN in field :22H::NEGR//UNKN depends on the content of field :22H::CRTR, of field :22H::APER and of field :22H::PAFI as follows:MT 307:�','MsgAttributes.NackReason','C63' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The presence of sequence D depends on the value of field 22H as follows:If Sequence A, field ::22H::CRTR is ASET and :22H::NEGR is NETC, then Sequence D is optional.�','MsgAttributes.NackReason','C64' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 567:In Sequence A, if field ::23G:01 is CAST, then in every occurrence of sequence A2 the field ::25D must be CPRC. If field ::23G:01 is INST, then in every occurrence of sequence A2 the field ::25D must be IPRC or ESTA. If field ::23G:01 is EVST,�','MsgAttributes.NackReason','C65' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 643:The number of occurrences of sequence C must be equal to or greater than the number of occurrences of sequence B.�','MsgAttributes.NackReason','C66' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 516:In sequence A, either field 83C or 87a, but not both, may be present.�','MsgAttributes.NackReason','C67' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 202_COV, 205_COV:In sequence B, if field 56a is present, then field 57a must also be present.�','MsgAttributes.NackReason','C68' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 507:In each occurrence of sequence B, the presence of sub-sequences B1a and B1b depend upon the value with sequence B field :22H::COLL//Status. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','C69' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 507:In each occurrence of sequence B, the presence of sub-sequence B1 depends upon the values of fields :25D::COLL//Status and :22H::COLL//Indicator. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','C70' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 528, 529:In sequence. B, field 36B::SETT cannot appear more than twice (maximum 2 occurrences). When repeated, one occurrence must have Quantity Type Code FAMT and the other occurrence must have Quantity Type Code AMOR.�','MsgAttributes.NackReason','C71' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 537:In each occurrence of sub-sequence C2, field 36B::PSTA cannot appear more than twice (maximum of 2 occurrences). When repeated, one occurrence must have Quantity Type Code FAMT and the other occurrence must have Quantity Type Code AMOR.�','MsgAttributes.NackReason','C72' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 536:A reference to the previously received message must be specified for each transaction reported (that is, in each occurrence of sub-sequence B1a Transaction, field 20C::RELA must be present in one and only one occurrence of sub-sequence B1a1 Li�','MsgAttributes.NackReason','C73' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 537:A reference to the previously received message must be specified for each transaction reported (that is, in each occurrence of sequence C Transaction, field 20C::RELA must be present in one and only one occurrence of sub-sequence C1 Linkages. �','MsgAttributes.NackReason','C74' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 104:The presence of field 23E in sequence B depends upon on the presence and content of field 23E in sequence A. (See the SWIFT User Handbook for more details.�','MsgAttributes.NackReason','C75' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 104:Field 50a (option A or K) must be present either in sequence A or in each occurrence of sequence B, but must never be present in both sequences.�','MsgAttributes.NackReason','C76' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 730, 768, 769:Either field 25 or field 57a, but not both, may be present.�','MsgAttributes.NackReason','C77' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 730, 768, 769:Either field 32D or field 57a, but not both, may be present.�','MsgAttributes.NackReason','C78' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 305, 601:Field 31C may be present only if subfield 3 or field 23 contains A.�','MsgAttributes.NackReason','C79' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 608:The metal code must be the same for all occurrences of the indicated fields in the entire message.�','MsgAttributes.NackReason','C80' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 103_not_STP, 103_STP, 202, 202_COV (Sequence A), 203, 205, 205_COV (Sequence A), and 582:If field 56a is present, then field 57a must also be present.�','MsgAttributes.NackReason','C81' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 104, 107:In sequence A, if field 23E is present and contains RTND, then field 72 must be present. In all other cases, field 72 is not allowed.�','MsgAttributes.NackReason','C82' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 935:Either field 23 or field 25, but not both, must be present in any repetitive sequence.�','MsgAttributes.NackReason','C83' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 303:In sequence A, if field 22A is AMNA, AMND, or CANC, then field 21 is mandatory. If field 22A is DUPL or NEWT, then field 21 is optional.�','MsgAttributes.NackReason','C84' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 609:Field 68B must be present when the immediately preceding field 23 contains SPOTS or FORWARDS.�','MsgAttributes.NackReason','C85' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 609:Field 68C must be present when the immediately preceding field 23 contains OPTIONS.�','MsgAttributes.NackReason','C86' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 601, 605, 606, 607, 608, 609:Subfield 1 of field 26C must not be present.�','MsgAttributes.NackReason','C87' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 305:The currency code in subfield 4 of field 23 must be the same as the currency code in field 32B.�','MsgAttributes.NackReason','C88' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 600, 601, 604, 605, 606, 607, 608, 609:A maximum of 6 decimal digits is permitted in the following: field 32F in MTs 600, 601, 604, 605, 606 and 607; fields 60F, 60M, 61, 62F, 62M, 64 and 65 in MT 608; and subfield 6 of fields 68B and 68C in MT 60�','MsgAttributes.NackReason','C89' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 700, 710, 720, 740:If field 42a is used, the only combinations that are allowed are field 42M (on its own) or field 42P (on its own) or both fields 42C and 42(A or D).�','MsgAttributes.NackReason','C90' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 608:Subfield 4 of field 61 must not be present.�','MsgAttributes.NackReason','C91' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 303:Sequences B and C are mutually exclusive. If Sequence A field 94A is FORX then sequence B is mandatory and sequence C is not permitted. If Sequence A field 94A is FXOP, then sequence C is mandatory and sequence B is not allowed.�','MsgAttributes.NackReason','C92' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 600:Either sequence B or C, but not both, must be present.�','MsgAttributes.NackReason','C93' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 104:If field 23E in sequence A is present and contains RFDD, then field 119 of the User Header must be present and contain RFDD. If field 23E in sequence A is not present or does not contain RFDD, then field 119 of the User Header must not be pres�','MsgAttributes.NackReason','C94' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 303:In sequence C, if field 23B is CLAM or PTAM then field 30X is mandatory. If field 23B is CLEU or PTEU, then field 30X is not allowed.�','MsgAttributes.NackReason','C95' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 104:The presence and contents of sequence B and C depend on the values within sequence A. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','C96' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 303:If sequence A, field 22A is AMNA, AMND, DUPL, or NEWT, then sequence D is mandatory. If sequence A, field 22A is CANC, then sequence D is optional.�','MsgAttributes.NackReason','C97' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT306:In sequence I, field 15I may not be the only field; if field 15I is present then at least one other field in sequence I must be present.�','MsgAttributes.NackReason','C98' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 303:If sequence A field 94A is FORX then sub-sequence D3 is not allowed. If sequence A field 94A is FXOP, then sub-sequence D3 is mandatory.�','MsgAttributes.NackReason','C99' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Not used.�','MsgAttributes.NackReason','D00' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 303:If subfield 1 of field 39P contains CURR, the number of decimal digits in subfield 3 is checked against the maximum allowed for the corresponding currency in subfield 2.�','MsgAttributes.NackReason','D01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 304, 306, 340, 341, 360, 361, 364, 365:In sequence A, the presence of field 21 depends on the value of field 22A. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','D02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 304:In sequence A, if field 94A is ASET, then fields 17O is and 17N are not allowed. If field 94A is AFWD, the fields 17O and 17N are mandatory.�','MsgAttributes.NackReason','D03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 304:In sequence A, if field 17O is Y or not present, then field 17F is not allowed. If field 17O is N, then field 17F is mandatory.�','MsgAttributes.NackReason','D04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 535:In each occurrence of Subsequence B1b, if field :93B::AVAI or/and :93B::NAVL is/are present, then :field :93B::AGGR must be present in the same occurrence of Subsequence B1b.�','MsgAttributes.NackReason','D05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Either field 44C or 44D, but not both, may be present.MT 601:�','MsgAttributes.NackReason','D06' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 601:If subfield 1 of field 77H contains \ISDA\, then (Date) and (Version) are mandatory.�','MsgAttributes.NackReason','D07' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Available.Available.�','MsgAttributes.NackReason','D08' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Available.Available.�','MsgAttributes.NackReason','D09' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Available.Available.�','MsgAttributes.NackReason','D10' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Available.Available.�','MsgAttributes.NackReason','D11' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Available.MT 503, 504, 506:�','MsgAttributes.NackReason','D12' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 503, 504, 506:In sub-sequence B1, fields 16R and 16S may not be the only fields present. If both fields 16R and 16S are present, then at least one other field of the same sub-sequence must be present.�','MsgAttributes.NackReason','D13' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Available.Available.�','MsgAttributes.NackReason','D14' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Available.MT 306:�','MsgAttributes.NackReason','D15' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 306:The presence of subsequence B1 and of sequence C depends on the values of Type of Event (subfield 1 of field 22K) in sequence A. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','D16' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 102_not_STP, 102_STP:Field 50a must be present either in sequence A or in each occurrence of sequence B, but it must never be present in both sequences, nor be absent from both sequences.�','MsgAttributes.NackReason','D17' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 102_not_STP:If a field 52a, 26T or 77B is present in sequence A, then that field must not be present in any occurrence of sequence B. When a field 52a, 26T or 77B is present in any occurrence of sequence B, that field must not be present in sequen','MsgAttributes.NackReason','D18' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 102_STP, 103_STP:The presence and contents of fields in sequence B depend upon the presence of the country code of the senders and receivers BICs within D19_CC. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','D19' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 102_not_STP, 102_STP.Field 71A must be present either in sequence A or in each occurrence of sequence B, but it must never be present in both sequences, nor be absent from both sequences.�','MsgAttributes.NackReason','D20' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 104, 107:In each occurrence of sequence B, if field 33B is present, then the currency code or the amount, or both, must be different between fields 33B and 32B.�','MsgAttributes.NackReason','D21' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 102_not_STP, 102_STP:Field 36 (sequence A or sequence B) must be present in the message if there is any sequence B which contains a field 33B with a currency code different from the currency code in field 32B; in all other cases field 36 is not al','MsgAttributes.NackReason','D22' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 304:If sequence A field 17O is Y or not present, then sequence D is not allowed. If sequence A field 17O is N, then sequence D is mandatory.�','MsgAttributes.NackReason','D23' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 306:In sequence A, if field 12F contains VANI, then at least field 17A or field 17F must contain Y. Both fields may contain Y.�','MsgAttributes.NackReason','D24' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 306:In sequence B, the presence of field 84a, depends on the value of fields 12F, 17A and 17F in sequence A. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','D25' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 306:In sequence A, the values allowed for field 12E depend on the value of field 12F. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','D26' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 306:In sequence A, the allowed values for subfield 1 of field 22K depend on fields 12F and 17A. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','D27' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 306:In sequence A, if subfield 1 of field 22K is CONF or CLST, then fields 30U and 29H are not allowed. If it is any other value, field 30U is mandatory and 29H is Optional.�','MsgAttributes.NackReason','D28' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('12,6666666666667The present of sequence E depends of field 17F and 17N. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','D29' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 306:If sequence A field 12F is VANI, then sequence D is mandatory and sequence G is not allowed. If field 12F is not VANI, then sequence D is not allowed and sequence G is mandatory.�','MsgAttributes.NackReason','D30' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 306:If sequence D is present, that is if field 12F in sequence A contains VANI (see Error Code D30), then the presence of fields 30P and 30Q depends on the value of field 12E in sequence A. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','D31' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 306:The presence of sequence E depends on the values of field 12F and subfield 1 of field 22K in sequence A. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','D32' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 306:If sequence A field 12F is VANI and field 17F is Y, then sequence D field 26F must be NETCASH. If sequence A field 12F VANI and field 17F is N, the sequence D field 26F must be NETCASH or PRINCIPAL�','MsgAttributes.NackReason','D33' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 306:In sequence E, if present, the presence of field 30H depends on the value of Type of Event (subfield 1 of field 22K) and on the Expiration Style (field 12E) in sequence A. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','D34' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 360, 361:In sequence A, if field 14A contains OTHER, field 77D must be present.�','MsgAttributes.NackReason','D35' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 306, 360, 361:In sequence A, if subfield 1 of field 77H is OTHER, then field 77D is mandatory. Otherwise, field 77D is optional.�','MsgAttributes.NackReason','D36' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 340:If sub-sequence B2 field 14D is OTHER, then sequence E is mandatory and sequence E field 72 is mandatory. Otherwise sequence E and sequence E field 72 are optional.�','MsgAttributes.NackReason','D37' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 360, 361:In sequences C and F, if field 14F contains OTHER, field 37N must be present in the respective sequence.�','MsgAttributes.NackReason','D38' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 360, 361:In sequences C and F, if field 14J contains OTHER, field 37N must be present in the respective sequence.�','MsgAttributes.NackReason','D39' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 360, 361:In sequences C and F, if subfield 1 of field 14G contains O, field 37N must be present in the respective sequence.�','MsgAttributes.NackReason','D40' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 360, 361:In sequences C and F, if subfield 2 of field 38E contains O, field 37N must be present in the respective sequence.�','MsgAttributes.NackReason','D41' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 340:If the second subcomponent of subfield 1 in sub-sequence B2 field 38G is O, then sequence E and sequence E field 72 are mandatory. Otherwise, they are optional.�','MsgAttributes.NackReason','D42' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 306:If sequence A field 17A is Y then sequence F is mandatory. If field 17A is N then sequence F is not allowed.�','MsgAttributes.NackReason','D43' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 306:In sequence F, if field 22G is SKIN or SKOT then field 37L is not allowed. If field 22G is DKIN or DKOT, then field 37L is mandatory.�','MsgAttributes.NackReason','D44' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 360, 361:If sub-sequence B1 is present, the presence of fields 32M, 17F, and 14D depends on field 37U in sequence B. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','D45' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 306:In sequence G, if field 22J is SITR then field 37P is not allowed. If field 22J is DBTR, then field 37P is mandatory.�','MsgAttributes.NackReason','D46' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 306:If sequence A, field 17F is Y, then sequence H is mandatory. If field 17F is N, then sequence H is not allowed.�','MsgAttributes.NackReason','D47' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 360, 361:If in sequence L or M, field 57a if present, then in the same sequence, fields 53a and 56a are optional. If field 57a is not present, then fields 53a and 56a are not allowed.�','MsgAttributes.NackReason','D48' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 102_not_STP, 102_STP:If the country codes of both the Senders and the Receivers BIC belong to the D49_CC list, then field 33B is mandatory in each occurrence of sequence B, otherwise field 33B is optional. (See the SWIFT User Handbook for more d','MsgAttributes.NackReason','D49' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 102_not_STP, 102_STP:If field 71A in sequence A contains SHA, then fields 71F are optional and field 71G is not allowed in any occurrence of sequence B. If field 71A in sequence B contains SHA, then fields 71F are optional and field 71G is not all','MsgAttributes.NackReason','D50' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 102_not_STP, 102_STP:If either field 71F (at least one occurrence) or field 71G is present in an occurrence of sequence B, then field 33B is mandatory in the same occurrence of sequence B.�','MsgAttributes.NackReason','D51' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 507:Field :13a::LINK must be present in one and only one occurrence of sub-sequence A2.�','MsgAttributes.NackReason','D52' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 507:Field :20C::RELA must be present in the same occurrence of sub-sequence A2 where field :13a::LINK is present.�','MsgAttributes.NackReason','D53' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 101:If field 36 is present, then field 21F must be present.�','MsgAttributes.NackReason','D54' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 360, 361:In sequences B, C, E and F, if field 14A contains OTHER, field 37N must be present in the respective sequence.�','MsgAttributes.NackReason','D55' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 320:The presence of fields 32H and 30X in sequence B depends on the value of field 22B in sequence A. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','D56' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 102_not_STP, 102_STP, 104, 107:In sequence C, in field 71G, Amount must not equal \0\.�','MsgAttributes.NackReason','D57' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 360:Depending on the contents of subfield 1 of field 23A in sequence A, only certain combinations of optional sequences B, C, E, and F are allowed. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','D58' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 360, 361:If sub-sequence E1 is present, the presence of fields 32M (in each occurrence of the internal loop), 17F and 14D, depends on field 37U in sequence E. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','D59' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 101:In each occurrence of Sequence B, if field 33B is present and \amount\ in field 32B is not equal to zero, then field 36 must be present, otherwise field 36 is not allowed.�','MsgAttributes.NackReason','D60' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 101:If there is only one debit account, the ordering customer must be identified in field 50a (option F, G or H) in sequence A. Conversely, if multiple debit accounts are used, they must be identified for every transaction in field 50a (option F, ','MsgAttributes.NackReason','D61' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 101:Field 50a (option C or L) may be present in either sequence A or each occurrence of sequence B, but must not be present in both sequences A and B.�','MsgAttributes.NackReason','D62' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 101, 102_not_STP, 103_not_STP, 104, 107, 405, 416:Field 51A is only valid in FileAct. This special error code is required to indicate to FileAct users that they have included a field in a FIN message that is reserved for FileAct.�','MsgAttributes.NackReason','D63' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 101, 206:Field 52a must not be present in both sequences A and B.�','MsgAttributes.NackReason','D64' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 101, 207:In each occurrence of sequence B, if field 56a is present then field 57a must be present.�','MsgAttributes.NackReason','D65' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 101:Subfield 2 of field 23E is allowed only when subfield 1 of this field consists of CMTO, PHON, OTHR or REPA.�','MsgAttributes.NackReason','D66' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 101:In each occurrence of sequence B, when field 23E is used more than once, certain combinations are not allowed. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','D67' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 101:For each occurrence of sequence B, if field 33B is present in sequence B, its currency code must be different from the currency code in field 32B of the same occurrence of sequence B.�','MsgAttributes.NackReason','D68' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 320, 620:If field 22B in sequence A contains MATU, then field 30F in sequence B is not allowed; otherwise field 30F is optional.�','MsgAttributes.NackReason','D69' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 300:In sequence A, the presence of field 21 depends on the value of field 22A. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','D70' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 502, 514, 518:If field :22F::DBNM//VEND is present in sequence C, then it is mandatory to specify a vendor: that is, one occurrence of sequence D Other Parties must contain a party field :95a::VEND.�','MsgAttributes.NackReason','D71' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 320, 620:In sequence A, if field 94A is present and contains AGNT, then field 21N in sequence A is mandatory; otherwise it is optional.�','MsgAttributes.NackReason','D72' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 104, 107:When present in sequence A, fields 21E, 26T, 77B, 71A, 52a and 50a (option C or L) must, independently of each other, not be present in any occurrence of sequence B. When present in one or more occurrences of sequence B, fields 21E, 26T, ','MsgAttributes.NackReason','D73' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 300:The presence of sequence C and fields 88a and 71F depends on field 94A. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','D74' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 103_not_STP, 103_STP:If field 33B is present and the currency code is different from that of field 32A, then field 36 must be present; otherwise field 36 is not allowed.�','MsgAttributes.NackReason','D75' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 300:If sequence A field 17U is N or Not present, then sequence D is not allowed. If field 17U is Y, then sequence D is mandatory.�','MsgAttributes.NackReason','D76' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 104:If field 21E is present in sequence A, then field 50a (option A or K) must also be present in sequence A. In each occurrence of sequence B, if field 21E is present, then field 50a (option A or K) must also be present in the same occurrence.�','MsgAttributes.NackReason','D77' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 416:Field 23E must be present either in sequence A or in each occurrence of sequence B but not in both.�','MsgAttributes.NackReason','D78' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 102_not_STP, 102_STP:If field 71G is present in one or more occurrences of sequence B, then field 71G is mandatory in sequence C.�','MsgAttributes.NackReason','D79' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 104:If sequence C is present and if the amount in field 32B of sequence C is equal to the sum of amounts of fields 32B of sequence B, then field 19 must not be present; otherwise, field 19 must be present.�','MsgAttributes.NackReason','D80' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 104, 107, 206, 256, 416:Subfield 2 of field 23E is allowed only when subfield 1 of this field consists of \OTHR\.�','MsgAttributes.NackReason','D81' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 104, 107, 207:The first component in line 1 of field 72 must consist either /RETN/ or /REJT/.�','MsgAttributes.NackReason','D82' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 416:When present in sequence A, fields 71F and 77A must, independently of each other, not be present in any occurrence of sequence B. Conversely, when not present in sequence A, fields 71F and 77A are, independently of each other, optional in any ','MsgAttributes.NackReason','D83' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 740:Either field 58a or 59, but not both, may be present.�','MsgAttributes.NackReason','D84' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 330:In sequence B, if field 30X is present, then field 34E is mandatory; otherwise field 34E is not allowed.�','MsgAttributes.NackReason','D85' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 107:Fields 23E and 50a (option A or K) must, independently of each other, be present either in sequence A or in each occurrence of sequence B but not in both.�','MsgAttributes.NackReason','D86' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 405:When present in sequence A, fields 26T, 77B, 71A, 50L and 52a must, independently of each other, not be present in any occurrence of sequence B. Conversely, when not present in sequence A, fields 26T, 77B, 71A, 50L and 52a are, independently o','MsgAttributes.NackReason','D87' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 405:Independently of each other, if fields 71F and 71G are present in one or more occurrence of sequence B, then they must also be present in sequence C. Conversely, if fields 71F and 71G are not present in any occurrence of sequence B, then they ','MsgAttributes.NackReason','D88' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 405:If sequence C is present and the sum of the fields 32a in sequence B equals the amount indicated in field 32a in sequence C, then field 19 must not be present in sequence C. If sequence C is present and the sum of the fields 32a in sequence B ','MsgAttributes.NackReason','D89' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 405:The presence of sub-sequences A1 and B1 is dependent on the presence and the content of subfield 1 of field 23E in the same sequence A and B respectively. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','D90' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 405:If field 71A contains either SHA or BEN, field 17A must be used. If field 71A contains OUR, field 17A must not be used. If field 71A is not present, field 17A is optional.�','MsgAttributes.NackReason','D91' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 530:In each occurrence of Sequence B, all Orders of field 20C are Optional, but at least one Order (any one) must be present.�','MsgAttributes.NackReason','D92' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 102_not_STP:If field 23 contains CHQB, then subfield 1 must not be present in field 59a. In all other cases, it is mandatory.�','MsgAttributes.NackReason','D93' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 405:The presence of fields 22D and 22E is dependent on the presence and the content of subfield 1 of field 23E. (See the SWIFT User Handbook for more details.)�','MsgAttributes.NackReason','D94' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 405:In sequences A and B, depending on the content of field 23E, only certain code word combinations may be used in fields 22D and 22E.�','MsgAttributes.NackReason','D95' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 300:If sequence D is present, field 16A must equal the number of internal repetitions in sequence D (that is block of fields: 17A - 58a).�','MsgAttributes.NackReason','D96' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 103_not_STP:Subfield 2 of field 23E is allowed only when subfield 1 consists of PHON, PHOB, PHOI, TELE, TELB, TELI, HOLD, or REPA.�','MsgAttributes.NackReason','D97' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 101:If field 21R is present in sequence A, then in each occurrence of sequence B, the currency code in fields 32B must be the same.�','MsgAttributes.NackReason','D98' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 564:If field :70E::NAME is used in sequence D, then field :22F::CAEV//CHAN must be present in sequence A, and field :22F::CHAN//NAME must be present in sequence D.�','MsgAttributes.NackReason','D99' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Not used..','MsgAttributes.NackReason','E00' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 23B contains SPRI, field 23E can contain only SDVA, TELB, PHOB, or INTC...','MsgAttributes.NackReason','E01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 23B contains SSTD or SPAY, field 23E must not be used...','MsgAttributes.NackReason','E02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 23B contains SPRI, SSTD or SPAY, field 53a must not be used with option D...','MsgAttributes.NackReason','E03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 23B contains SPRI, SSTD or SPAY and field 53a is present with option B, subfield 1, Party Identifier must be present in field 53B.','MsgAttributes.NackReason','E04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 23B contains SPRI, SSTD or SPAY, field 54a can be used with option A only...','MsgAttributes.NackReason','E05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 55a is present, then both fields 53a and 54a must also be present...','MsgAttributes.NackReason','E06' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 23B contains SPRI, SSTD or SPAY, field 55a can be used with option A only...','MsgAttributes.NackReason','E07' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If the message is a cancellation (that is, the Function of the Message, field 23G, is CANC), then sub-sequence A1 Linkages must be present at least once, and a reference to the previous message must be specified in the Linkage section (that is, field','MsgAttributes.NackReason','E08' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 23B contains SPRI, SSTD or SPAY, field 57a can be used with option A, option C or option D. In addition, in option D, subfield 1, Party Identifier  must be present.','MsgAttributes.NackReason','E09' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 23B contains SPRI, SSTD or SPAY, subfield 1, Account, in field 59a is mandatory...','MsgAttributes.NackReason','E10' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If the message is an additional business process (:23G::ADDB) then sequence D Corporate Action Details is mandatory, and in sequence D, field :22F::ADDB is Mandatory, only one occurrence is allowed, and it must contain the code word CLAI ','MsgAttributes.NackReason','E11' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Either field 70 or 77T, but not both, may be present...','MsgAttributes.NackReason','E12' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 71A in sequence A contains OUR, then field 71F is not allowed and field 71G is optional in any occurrence of sequence B. If field 71A in sequence B contains OUR, then field 71F is not allowed and field 71G is optional in the same occurrence ','MsgAttributes.NackReason','E13' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field :22F::FXCX//FXNO or FXYE is present in sequence C, then the message must be a cancellation, that is, Function of the Message in sequence A (field 23G) is CANC. If field :22F::FXCX//SINO is present in sequence C, then the message must be new,','MsgAttributes.NackReason','E14' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 71A in sequence A contains BEN, then at least one occurrence of field 71F is mandatory in each occurrence of sequence B and field 71G is not allowed...','MsgAttributes.NackReason','E15' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 23B contains SPRI, field 56a must not be used...','MsgAttributes.NackReason','E16' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 23B contains SSTD or SPAY, field 56a can be used with either option A or option C. If option C is used, it must contain a clearing code...','MsgAttributes.NackReason','E17' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If any field 23E contains CHQB, subfield 1, Account, in field 59a is not allowed...','MsgAttributes.NackReason','E18' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Available...','MsgAttributes.NackReason','E19' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Available...','MsgAttributes.NackReason','E20' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Available...','MsgAttributes.NackReason','E21' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Available...','MsgAttributes.NackReason','E22' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Available...','MsgAttributes.NackReason','E23' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 256:..','MsgAttributes.NackReason','E24' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 37J is present, then field 71G must also be present...','MsgAttributes.NackReason','E25' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 71L is present in sequence C, then the amount specified in field 71L must be equal to the sum of all occurrences of field 71F in sequence B...','MsgAttributes.NackReason','E26' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 71J is present in sequence C, then the amount specified in field 71J must be equal to the sum of all occurrences of field 71G in sequence B...','MsgAttributes.NackReason','E27' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Field 21 must be present either in sequence A or in each occurrence of sequence B but not in both...','MsgAttributes.NackReason','E28' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 71F is present in any occurrence of sequence B, then field 71L must be present in sequence C, and vice versa if field 71F is absent from all occurrences of sequence B, then field 71L is not allowed in sequence C...','MsgAttributes.NackReason','E29' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 71G is present in any occurrence of sequence B, then field 71J must be present in sequence C, and vice versa if field 71G is absent from all occurrences of sequence B, then field 71J is not allowed in sequence C...','MsgAttributes.NackReason','E30' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 71H is present in any occurrence of sequence B, then field 71K must be present in sequence C, and vice versa if field 71H is absent from all occurrences of sequence B, then field 71K is not allowed in sequence C...','MsgAttributes.NackReason','E31' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 71K is present in sequence C, then the amount specified in field 71K must be equal to the sum of all occurrences of field 71H in sequence B...','MsgAttributes.NackReason','E32' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The presence of sequences B and E depends on subfield 1 of field 23A in sequence A. (See the SWIFT User Handbook for more details.)..','MsgAttributes.NackReason','E33' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In sequence A, the presence of fields 32G and 22D and, in sequences B and E, the presence of field 37P depend on field 22B in sequence A. (See the SWIFT User Handbook for more details.)..','MsgAttributes.NackReason','E34' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In sequences C, E and J, if field 56a is not present, then field 86a in the same sequence C, E or J is not allowed; otherwise field 86a is optional...','MsgAttributes.NackReason','E35' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In sequence A, if field 22D contains OTHR, field 37N must be present...','MsgAttributes.NackReason','E36' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Within each occurrence of subsequence A2a, the qualifier in field 24B must be the same as the code word (Status Code) used with the appropriate qualifier in field 25D of its surrounding subsequence A2. (See the SWIFT User Handbook for more details.).','MsgAttributes.NackReason','E37' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The currency code of the fields 33F and 32H in sequence B must be the same. The currency codes of the fields 33F and 32H in sequence D must be the same...','MsgAttributes.NackReason','E38' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In sequences B and D, the presence of fields 37J and 37L depends on subfield 1 of field 23A in sequence A. (See the SWIFT User Handbook for more details.)..','MsgAttributes.NackReason','E39' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In sequence A, the presence of field 14C depends on the value of subfield 1 of field 77H. (See the SWIFT User Handbook for more details.)..','MsgAttributes.NackReason','E40' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In sequence B, the presence of sub-sequence B1 depends on the value of subfield 1 of field 77H in sequence A. (See the SWIFT User Handbook for more details.)..','MsgAttributes.NackReason','E41' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In sequences C and F, the presence of fields 37J and 37L depends on subfield 1 of field 23A in sequence A. (See the SWIFT User Handbook for more details.)..','MsgAttributes.NackReason','E42' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Depending on the value in subfield 1 of field 23A in sequence A, only the certain combinations of the optional sequences B, C, E and F are allowed. (See the SWIFT User Handbook for more details...','MsgAttributes.NackReason','E43' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 56a is not present, no field 23E may contain TELI or PHOI...','MsgAttributes.NackReason','E44' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 57a is not present, no field 23E may contain TELE or PHON...','MsgAttributes.NackReason','E45' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In each occurrence of sequence B, if field 23E is repeated, it must not contain the same code more than once, with the exception of OTHR. OTHR may be repeated...','MsgAttributes.NackReason','E46' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If sequence D is present, at least one of the sub-sequences D1 or D2 must be present...','MsgAttributes.NackReason','E47' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('At least one of the sequences C or E must be present...','MsgAttributes.NackReason','E48' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('When subfield 2 of field 23A contains NET, either sequence C or E must be present, but not both...','MsgAttributes.NackReason','E49' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('When subfield 2 of field 23A contains NET, fields 30F to 57a in sequence C or E must occur only once...','MsgAttributes.NackReason','E50' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('When subfield 2 of field 23A contains GROSS, fields 30F to 57a in sequence C and E cannot occur more than three times...','MsgAttributes.NackReason','E51' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In sub-sequence C1, if field :95a::PSET is present, then field :97a::SAFE is not allowed in the same sub-sequence...','MsgAttributes.NackReason','E52' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In sequence B, if field :22H::BUSE//SWIT is present, then sub-sequence A1 is mandatory, and field :20C::PREV must be present in a minimum of one occurrence of sub-sequence A1...','MsgAttributes.NackReason','E53' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In each occurrence of Sequence B, the presence of fields 33B and 21F is dependent on the presence and value of fields 32B and 23E. (See the SWIFT User Handbook for more details.)..','MsgAttributes.NackReason','E54' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If in Sequence A, field :12E:: contains Euro, then field 30F of sequence B is mandatory and if 12E is not Euro, then field 30F of sequence B is optional...','MsgAttributes.NackReason','E55' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If in sequence A, field :17B::CONS contains Y, then in every occurrence of sequence B, field :97a::SAFE and field :17B::ACTI are mandatory. This error code applies only when sequence B is present as per Error Code E66, that is, in sequence A, field :','MsgAttributes.NackReason','E56' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('The BIC must be a BEI, that is, it must be of sub-type BEID, TRCO, MCCO or SMDP...','MsgAttributes.NackReason','E57' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In sequence B, either field :36B::ORDR or field :19A::ORDR must be present, but not both...','MsgAttributes.NackReason','E58' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 23G does not contain CANC, then field 13A must be present and contain 515 in minimum one occurrence of sub-sequence A1...','MsgAttributes.NackReason','E59' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In each occurrence of sub-sequence D1, the presence of field :70C::RATS depends on the presence of field :94B::RATS. (See the SWIFT User Handbook for more details.)..','MsgAttributes.NackReason','E60' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('When field :22F::PRIC is present, field :90a::DEAL must also be present...','MsgAttributes.NackReason','E61' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In each sub-sequence C3, if field :92B::EXCH is present, the corresponding field :19A::RESU must be present. If field :92B::EXCH is not present, then field :19A::RESU is not allowed...','MsgAttributes.NackReason','E62' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In Sequence B, it is mandatory to provide an Issue Date/Time (:98a::ISSU) OR a Release Date/Time (:98a::RELD). Both dates may be provided...','MsgAttributes.NackReason','E63' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If the Function of the Message (field :23G:) is CANC and the Ordered Quantity (field :36B::ORDR) is present, then the Quantity to Cancel (field :36B::CANC) must be present in the order details sequence. If the Function of the Message (field :23G:) is','MsgAttributes.NackReason','E64' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If Sequence A field :22a::COLA// is other than SLEB and sequence B is present, then field :19A::TRAA must be present...','MsgAttributes.NackReason','E65' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field :17B::ACTI in sequence A contains N, then sequence B must not be present; otherwise, sequence B is mandatory...','MsgAttributes.NackReason','E66' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 17B::ACTI//Y is present (see Rule C1, Error Code E66), and if field :22F::STTY//ACCT is present, then at least one occurrence of subsequence B1 is required...','MsgAttributes.NackReason','E67' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In sequence A, if field :20C::SCTR is not present, then field :20C::RCTR is mandatory; otherwise field :20C::RCTR is optional...','MsgAttributes.NackReason','E68' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field :17B::ACTI in sequence B contains N, then sub-sequence B1 must not be present. In all other cases, sub-sequence B1 is mandatory...','MsgAttributes.NackReason','E69' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field :22F::DBNM is present in sequence C and field :22H::REDE//DELI is present in sequence B, then one occurrence of subsequence C1 must contain :95a::BUYR. If field :22F::DBNM is present in sequence C and field :22H::REDE//RECE is present in seq','MsgAttributes.NackReason','E70' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In each occurrence of sub-sequence A1, if field :22F::AGRE is not present, then field :70C::AGRE is mandatory; otherwise field :70C::AGRE is optional...','MsgAttributes.NackReason','E71' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In each occurrence of sub-sequence C3, if field :22H::BCOL//LCOL is present, then field :98B::EXPI//OPEN is not allowed; otherwise field :98B::EXPI//OPEN is optional...','MsgAttributes.NackReason','E72' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field :19A::SETT is present in sequence C, it must not be present in any occurrence of sub-sequence D3...','MsgAttributes.NackReason','E73' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In sequence B, field :22F::TOOR and/or field :90a::LIMI must be present...','MsgAttributes.NackReason','E74' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field 19A::SETT is specified in both sequences B and C3, it must contain the same value, that is Sign, Currency and Amount must be identical...','MsgAttributes.NackReason','E75' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 564:..','MsgAttributes.NackReason','E76' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In sequence D, field :92a::, the qualifier TAXC may only be repeated with letter option/s E or/and J; and the qualifiers GRSS and NETT may only be repeated with letter option J...','MsgAttributes.NackReason','E77' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In sequence D:..','MsgAttributes.NackReason','E78' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In sequence A, field :98a::STAT and field :69a::STAT are mutually exclusive...','MsgAttributes.NackReason','E79' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field :22F::DBNM is NOT present in sequence C, then it is mandatory to specify a place of settlement: one occurrence of subsequence C1 Settlement Parties must contain party field :95a::PSET...','MsgAttributes.NackReason','E80' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In sequence B, the third component of field :93A::FROM must be different from the third component in field :93A::TOBA...','MsgAttributes.NackReason','E81' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In each occurrence of subsequence B1, if NO subsequence B1b is present, then both fields Price (field :90a:) and Holding Value (field :19A::HOLD) must be specified...','MsgAttributes.NackReason','E82' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Certain fields cannot appear more than once in the message. (See the SWIFT User Handbook for more details.)..','MsgAttributes.NackReason','E83' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In each occurrence of Seq. B3, the following party fields cannot appear more than once: :95a::CDEA, :95a::INTE, :95a::ACCW, :95a::BENM...','MsgAttributes.NackReason','E84' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In each occurrence of sub-sequence C2, the presence of field :98A::TERM depends on the value of field :22H::DEPO//Indicator. (See the SWIFT User Handbook for more details.)..','MsgAttributes.NackReason','E85' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Certain amount fields cannot appear in more than one occurrence of the amounts sub-sequence E3. (See the SWIFT User Handbook for more details.)..','MsgAttributes.NackReason','E86' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 540, 541, 542, 543:..','MsgAttributes.NackReason','E87' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If sequence C is present once, field :19A::SETT must not be present in sequence C...','MsgAttributes.NackReason','E88' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MT 307:..','MsgAttributes.NackReason','E89' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Repetitive subsequence B3 must be present exactly twice in the message...','MsgAttributes.NackReason','E90' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In each occurrence of Seq. B3, the presence of the repetitive subsequence B3a depends on the content of :22H::NEGR. (See the SWIFT User Handbook for more details.)..','MsgAttributes.NackReason','E91' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Taking into account rule 291: in each occurrence of Sequence B3, the presence of field 95a in Sequence B3a depends on the content of field 19B in sequence B3. (See the SWIFT User Handbook for more details.)..','MsgAttributes.NackReason','E92' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('It is mandatory to specify a Receiving Agent for sub-sequence B1a1. In each occurrence of sequence B if present, if sub-sequence B1a1 is present, then field :95a::REAG must be present in one and only one occurrence of sub-sequence B1a1 within the sam','MsgAttributes.NackReason','E93' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field :97C::SAFE//GENR is present in any occurrence of sub-sequence B2, then sub-sequence B2 must not be repeated in the message, field 93a must not be present in sub-sequence B2, field 36B must not be present in subsequence E1, and field 19B must','MsgAttributes.NackReason','E94' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Within each occurrence of sequence B1, if field :17B::ACTI contains N, then sub-sequence B1a within that sub-sequence B1 is not allowed. If field 17B::ACTI contains Y, then sub-sequence B1a is mandatory...','MsgAttributes.NackReason','E95' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Within sub-sequence B1a, sub-sequence B1a2 and sub-sequence B1a3 are mutually exclusive...','MsgAttributes.NackReason','E96' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In sequence B, the presence of field :95a::EXPP depends on the value of field :22H::COAL//Indicator. (See the SWIFT User Handbook for more details.)..','MsgAttributes.NackReason','E97' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If field :17B::PRER contains Y, sequence C must also be present. If field :17B::PRER contains N, sequence C must not be present...','MsgAttributes.NackReason','E98' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('In sequence A, if field :99B::TORE or :99B::TODE is present, field :99B::TOSE must also be present...','MsgAttributes.NackReason','E99' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K00' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K06' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K07' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K08' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K09' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K10' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K11' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K12' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K13' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K14' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K15' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K16' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K17' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K18' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K19' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K20' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K21' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K22' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K23' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K24' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K25' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K26' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K27' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K28' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K29' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K30' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K31' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K32' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K33' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K34' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K35' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K36' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K37' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K38' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K39' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K40' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K41' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K42' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K43' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K44' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K45' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K46' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K47' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K48' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K49' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K50' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K51' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K52' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K53' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K54' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K55' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K56' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K57' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K58' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K59' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K60' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K61' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K62' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K63' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K64' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K65' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K66' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K67' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K68' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K69' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K70' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K71' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K72' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K73' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K74' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K75' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K76' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K77' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K78' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K79' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K80' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K81' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K82' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K83' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K84' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K85' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K86' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K87' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K88' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K89' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K90' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K91' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K92' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K93' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K94' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K95' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K96' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K97' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K98' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Code word error in a generic field.','MsgAttributes.NackReason','K99' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Bad block 3 format','MsgAttributes.NackReason','U00' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Bad bank priority','MsgAttributes.NackReason','U01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Bad MUR','MsgAttributes.NackReason','U02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Neither bank priority nor MUR present','MsgAttributes.NackReason','U03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('User Header not permitted for user-to-system messages (that is, message type less than 100)','MsgAttributes.NackReason','U07' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Tag 119 is not correct','MsgAttributes.NackReason','U08' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Tag 119 present for a message type other than 102, 103, 104, 503, 504, 505, 506, 507, 521, 523, and 574.','MsgAttributes.NackReason','U09' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('FXAveragingForward ReportStyle','productTypeReportStyle','FXAveragingForward' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Filters total number modelCalibration dates to the default value','domainName','FilterModelCalibration' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Default value','FilterModelCalibration','30' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Product TripartyExposure Static Data Filter criteria','sdFilterCriterion.Factory','TripartyExposure' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'Bond.RoundingRuleAttributes','CA Interest Amount' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Round final accrual rate that used to compute accrual','Bond.RoundingRuleAttributes','Accrual Rate' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'Bond.RoundingRuleAttributes','Discount' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'Bond.RoundingRuleAttributes','Principal Amount' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','IsShowCollarForInflationIndex' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (' Whether to show Collar for InflationIndexed CappedSwap ','IsShowCollarForInflationIndex','False' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','MultiQuoteMappingProduct' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (' Bond Product','MultiQuoteMappingProduct','Bond' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (' Equity Product','MultiQuoteMappingProduct','Equity' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('binomial Pricer for single equity Asian options - using Ju 2002 basket approximation - can do forward start price','EquityStructuredOption.Pricer','PricerBlack1FJuAnalyticAsian' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('analytic Pricer for single asset digital option, by call-spread replication','EquityStructuredOption.Pricer','PricerBlack1FReplicatingDigital' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Monte Carlo Pricer for single asset option with script payoff - stochastic volatility with our without jump','EquityStructuredOption.Pricer','PricerSVJMonteCarloExotic' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('To identify a FX trade whose spot risk is to be transfered from main book','systemKeyword','SpotRiskFromMainBook' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('To identify a PositionSplitTrade','systemKeyword','IsPositionSplitTrade' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Position split currency','systemKeyword','PositionSplitTradeSplitCcy' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('A loose reference back to the position that was split','systemKeyword','PositionSplitReference' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Edit External Trade Context','function','EditExternalTradeContext' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Default Super User Pricer Measure','DeferredPL.PricerMeasure','TAX_LN_AM' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('domainName','bookAttribute.SpotRiskFromMainBook' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('If set to true explicitly, Trade Date checks for non business day.','domainName','SundayEarlyNYFXDayChangeRule' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Return Status Reason','MsgAttributes','ReturnStatusReason' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Additional information if Return Status Reason is NARR','MsgAttributes','ReturnAdditionalInformation' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('AbortedClearingTimeout','ExternalStatusReason1Code','AB01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('AbortedClearingFatalError','ExternalStatusReason1Code','AB02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('AbortedSettlementTimeout','ExternalStatusReason1Code','AB03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('AbortedSettlementFatalError','ExternalStatusReason1Code','AB04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('TimeoutCreditorAgent','ExternalStatusReason1Code','AB05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('TimeoutInstructedAgent','ExternalStatusReason1Code','AB06' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('OfflineAgent','ExternalStatusReason1Code','AB07' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('OfflineCreditorAgent','ExternalStatusReason1Code','AB08' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ErrorCreditorAgent','ExternalStatusReason1Code','AB09' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ErrorInstructedAgent','ExternalStatusReason1Code','AB10' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('IncorrectAccountNumber','ExternalStatusReason1Code','AC01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidDebtorAccountNumber','ExternalStatusReason1Code','AC02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidCreditorAccountNumber','ExternalStatusReason1Code','AC03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ClosedAccountNumber','ExternalStatusReason1Code','AC04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ClosedDebtorAccountNumber','ExternalStatusReason1Code','AC05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('BlockedAccount','ExternalStatusReason1Code','AC06' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ClosedCreditorAccountNumber','ExternalStatusReason1Code','AC07' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidBranchCode','ExternalStatusReason1Code','AC08' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidAccountCurrency','ExternalStatusReason1Code','AC09' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidDebtorAccountCurrency','ExternalStatusReason1Code','AC10' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidCreditorAccountCurrency','ExternalStatusReason1Code','AC11' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidAccountType','ExternalStatusReason1Code','AC12' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidDebtorAccountType','ExternalStatusReason1Code','AC13' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidCreditorAccountType','ExternalStatusReason1Code','AC14' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('AccountDetailsChanged','ExternalStatusReason1Code','AC15' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('TransactionForbidden','ExternalStatusReason1Code','AG01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidBankOperationCode','ExternalStatusReason1Code','AG02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('TransactionNotSupported','ExternalStatusReason1Code','AG03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidAgentCountry','ExternalStatusReason1Code','AG04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidDebtorAgentCountry','ExternalStatusReason1Code','AG05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidCreditorAgentCountry','ExternalStatusReason1Code','AG06' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('UnsuccesfulDirectDebit','ExternalStatusReason1Code','AG07' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidAccessRights','ExternalStatusReason1Code','AG08' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('PaymentNotReceived','ExternalStatusReason1Code','AG09' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('AgentSuspended','ExternalStatusReason1Code','AG10' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CreditorAgentSuspended','ExternalStatusReason1Code','AG11' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('IncorrectAgent','ExternalStatusReason1Code','AGNT' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ZeroAmount','ExternalStatusReason1Code','AM01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('NotAllowedAmount','ExternalStatusReason1Code','AM02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('NotAllowedCurrency','ExternalStatusReason1Code','AM03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InsufficientFunds','ExternalStatusReason1Code','AM04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Duplication','ExternalStatusReason1Code','AM05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('TooLowAmount','ExternalStatusReason1Code','AM06' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('BlockedAmount','ExternalStatusReason1Code','AM07' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('WrongAmount','ExternalStatusReason1Code','AM09' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidControlSum','ExternalStatusReason1Code','AM10' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidTransactionCurrency','ExternalStatusReason1Code','AM11' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidAmount','ExternalStatusReason1Code','AM12' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('AmountExceedsClearingSystemLimit','ExternalStatusReason1Code','AM13' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('AmountExceedsAgreedLimit','ExternalStatusReason1Code','AM14' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('AmountBelowClearingSystemMinimum','ExternalStatusReason1Code','AM15' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidGroupControlSum','ExternalStatusReason1Code','AM16' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidPaymentInfoControlSum','ExternalStatusReason1Code','AM17' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidNumberOfTransactions','ExternalStatusReason1Code','AM18' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidGroupNumberOfTransactions','ExternalStatusReason1Code','AM19' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidPaymentInfoNumberOfTransactions','ExternalStatusReason1Code','AM20' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('LimitExceeded','ExternalStatusReason1Code','AM21' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ZeroAmountNotApplied','ExternalStatusReason1Code','AM22' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('AmountExceedsSettlementLimit','ExternalStatusReason1Code','AM23' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InconsistenWithEndCustomer','ExternalStatusReason1Code','BE01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MissingCreditorAddress','ExternalStatusReason1Code','BE04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('UnrecognisedInitiatingParty','ExternalStatusReason1Code','BE05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('UnknownEndCustomer','ExternalStatusReason1Code','BE06' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MissingDebtorAddress','ExternalStatusReason1Code','BE07' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MissingDebtorName','ExternalStatusReason1Code','BE08' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidCountry','ExternalStatusReason1Code','BE09' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidDebtorCountry','ExternalStatusReason1Code','BE10' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidCreditorCountry','ExternalStatusReason1Code','BE11' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidCountryOfResidence','ExternalStatusReason1Code','BE12' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidDebtorCountryOfResidence','ExternalStatusReason1Code','BE13' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidCreditorCountryOfResidence','ExternalStatusReason1Code','BE14' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidIdentificationCode','ExternalStatusReason1Code','BE15' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidDebtorIdentificationCode','ExternalStatusReason1Code','BE16' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidCreditorIdentificationCode','ExternalStatusReason1Code','BE17' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidContactDetails','ExternalStatusReason1Code','BE18' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidChargeBearerCode','ExternalStatusReason1Code','BE19' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidNameLength','ExternalStatusReason1Code','BE20' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MissingName','ExternalStatusReason1Code','BE21' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MissingCreditorName','ExternalStatusReason1Code','BE22' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CheckERI','ExternalStatusReason1Code','CERI' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('RequestedExecutionDateOrRequestedCollectionDateTooFarInFuture','ExternalStatusReason1Code','CH03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('RequestedExecutionDateOrRequestedCollectionDateTooFarInPast','ExternalStatusReason1Code','CH04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ElementIsNotToBeUsedAtB-andC-Level','ExternalStatusReason1Code','CH07' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MandateChangesNotAllowed','ExternalStatusReason1Code','CH09' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InformationOnMandateChangesMissing','ExternalStatusReason1Code','CH10' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CreditorIdentifierIncorrect','ExternalStatusReason1Code','CH11' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CreditorIdentifierNotUnambiguouslyAtTransaction-Level','ExternalStatusReason1Code','CH12' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('OriginalDebtorAccountIsNotToBeUsed','ExternalStatusReason1Code','CH13' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('OriginalDebtorAgentIsNotToBeUsed','ExternalStatusReason1Code','CH14' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ElementContentIncludesMoreThan140Characters','ExternalStatusReason1Code','CH15' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ElementContentFormallyIncorrect','ExternalStatusReason1Code','CH16' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ElementNotAdmitted','ExternalStatusReason1Code','CH17' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ValuesWillBeSetToNextTARGETday','ExternalStatusReason1Code','CH19' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('DecimalPointsNotCompatibleWithCurrency','ExternalStatusReason1Code','CH20' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('RequiredCompulsoryElementMissing ','ExternalStatusReason1Code','CH21' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('COREandB2BwithinOnemessage ','ExternalStatusReason1Code','CH22' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Creditor bank is not registered ','ExternalStatusReason1Code','CNOR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('IncorrectCurrency','ExternalStatusReason1Code','CURR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('RequestedByCustomer','ExternalStatusReason1Code','CUST' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Debtor bank is not registered','ExternalStatusReason1Code','DNOR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ElectronicSignaturesCorrect','ExternalStatusReason1Code','DS01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('OrderCancelled','ExternalStatusReason1Code','DS02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('OrderNotCancelled','ExternalStatusReason1Code','DS03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('OrderRejected','ExternalStatusReason1Code','DS04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('OrderForwardedForPostprocessing','ExternalStatusReason1Code','DS05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('TransferOrder','ExternalStatusReason1Code','DS06' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ProcessingOK','ExternalStatusReason1Code','DS07' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('DecompressionError','ExternalStatusReason1Code','DS08' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('DecryptionError','ExternalStatusReason1Code','DS09' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('DataSignRequested','ExternalStatusReason1Code','DS0A' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('UnknownDataSignFormat','ExternalStatusReason1Code','DS0B' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('SignerCertificateRevoked','ExternalStatusReason1Code','DS0C' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('SignerCertificateNotValid','ExternalStatusReason1Code','DS0D' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('IncorrectSignerCertificate','ExternalStatusReason1Code','DS0E' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('SignerCertificationAuthoritySignerNotValid','ExternalStatusReason1Code','DS0F' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('NotAllowedPayment','ExternalStatusReason1Code','DS0G' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('NotAllowedAccount','ExternalStatusReason1Code','DS0H' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('NotAllowedNumberOfTransaction','ExternalStatusReason1Code','DS0K' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Signer1CertificateRevoked','ExternalStatusReason1Code','DS10' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Signer1CertificateNotValid','ExternalStatusReason1Code','DS11' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('IncorrectSigner1Certificate','ExternalStatusReason1Code','DS12' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('SignerCertificationAuthoritySigner1NotValid','ExternalStatusReason1Code','DS13' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('UserDoesNotExist','ExternalStatusReason1Code','DS14' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('IdenticalSignatureFound','ExternalStatusReason1Code','DS15' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('PublicKeyVersionIncorrect','ExternalStatusReason1Code','DS16' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('DifferentOrderDataInSignatures','ExternalStatusReason1Code','DS17' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('RepeatOrder','ExternalStatusReason1Code','DS18' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ElectronicSignatureRightsInsufficient','ExternalStatusReason1Code','DS19' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Signer2CertificateRevoked','ExternalStatusReason1Code','DS20' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Signer2CertificateNotValid','ExternalStatusReason1Code','DS21' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('IncorrectSigner2Certificate','ExternalStatusReason1Code','DS22' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('SignerCertificationAuthoritySigner2NotValid','ExternalStatusReason1Code','DS23' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('WaitingTimeExpired','ExternalStatusReason1Code','DS24' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('OrderFileDeleted','ExternalStatusReason1Code','DS25' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('UserSignedMultipleTimes','ExternalStatusReason1Code','DS26' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('UserNotYetActivated','ExternalStatusReason1Code','DS27' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidDate','ExternalStatusReason1Code','DT01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidCreationDate','ExternalStatusReason1Code','DT02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidNonProcessingDate','ExternalStatusReason1Code','DT03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('FutureDateNotSupported','ExternalStatusReason1Code','DT04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidCutOffDate','ExternalStatusReason1Code','DT05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ExecutionDateChanged','ExternalStatusReason1Code','DT06' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('DuplicateMessageID','ExternalStatusReason1Code','DU01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('DuplicatePaymentInformationID','ExternalStatusReason1Code','DU02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('DuplicateTransaction','ExternalStatusReason1Code','DU03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('DuplicateEndToEndID','ExternalStatusReason1Code','DU04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('DuplicateInstructionID','ExternalStatusReason1Code','DU05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('DuplicatePayment','ExternalStatusReason1Code','DUPL' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CorrespondentBankNotPossible','ExternalStatusReason1Code','ED01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('BalanceInfoRequest','ExternalStatusReason1Code','ED03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('SettlementFailed','ExternalStatusReason1Code','ED05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('SettlementSystemNotAvailable','ExternalStatusReason1Code','ED06' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ERIOptionNotSupported','ExternalStatusReason1Code','ERIN' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Invalid File Format','ExternalStatusReason1Code','FF01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('SyntaxError','ExternalStatusReason1Code','FF02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidPaymentTypeInformation','ExternalStatusReason1Code','FF03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidServiceLevelCode','ExternalStatusReason1Code','FF04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidLocalInstrumentCode','ExternalStatusReason1Code','FF05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidCategoryPurposeCode','ExternalStatusReason1Code','FF06' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidPurpose','ExternalStatusReason1Code','FF07' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidEndToEndId','ExternalStatusReason1Code','FF08' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidChequeNumber','ExternalStatusReason1Code','FF09' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('BankSystemProcessingError','ExternalStatusReason1Code','FF10' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ClearingRequestAborted','ExternalStatusReason1Code','FF11' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('PaymentTransferredAndTracked','ExternalStatusReason1Code','G000' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('PaymentTransferredAndNotTracked','ExternalStatusReason1Code','G001' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CreditDebitNotConfirmed','ExternalStatusReason1Code','G002' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CreditPendingDocuments','ExternalStatusReason1Code','G003' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CreditPendingFunds','ExternalStatusReason1Code','G004' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('DeliveredWithServiceLevel','ExternalStatusReason1Code','G005' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('DeliveredWIthoutServiceLevel','ExternalStatusReason1Code','G006' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CorrespondingOriginalFileStillNotSent','ExternalStatusReason1Code','ID01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('NoMandate','ExternalStatusReason1Code','MD01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MissingMandatoryInformationIn Mandate','ExternalStatusReason1Code','MD02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('CollectionNotDue','ExternalStatusReason1Code','MD05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('RefundRequestByEndCustomer','ExternalStatusReason1Code','MD06' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('EndCustomerDeceased','ExternalStatusReason1Code','MD07' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('NotSpecifiedReasonCustomer Generated','ExternalStatusReason1Code','MS02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('NotSpecifiedReasonAgent  Generated','ExternalStatusReason1Code','MS03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Narrative','ExternalStatusReason1Code','NARR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('NoERI','ExternalStatusReason1Code','NERI' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('BankIdentifierIncorrect','ExternalStatusReason1Code','RC01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidBankIdentifier','ExternalStatusReason1Code','RC02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidDebtorBankIdentifier','ExternalStatusReason1Code','RC03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidCreditorBankIdentifier','ExternalStatusReason1Code','RC04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidBICIdentifier','ExternalStatusReason1Code','RC05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidDebtorBICIdentifier','ExternalStatusReason1Code','RC06' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidCreditorBICIdentifier','ExternalStatusReason1Code','RC07' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidClearingSystemMemberIdentifier','ExternalStatusReason1Code','RC08' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidDebtorClearingSystemMemberIdentifier','ExternalStatusReason1Code','RC09' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidCreditorClearingSystemMemberIdentifier','ExternalStatusReason1Code','RC10' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidIntermediaryAgent','ExternalStatusReason1Code','RC11' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MissingCreditorSchemeId','ExternalStatusReason1Code','RC12' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('R-MessageConflict','ExternalStatusReason1Code','RCON' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ReceiverCustomerInformation','ExternalStatusReason1Code','RECI' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('NotUniqueTransactionReference','ExternalStatusReason1Code','RF01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Missing Debtor Account or Identification','ExternalStatusReason1Code','RR01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Missing Debtor Name or Address','ExternalStatusReason1Code','RR02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Missing Creditor Name or Address','ExternalStatusReason1Code','RR03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('RegulatoryReason ','ExternalStatusReason1Code','RR04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('RegulatoryInformationInvalid','ExternalStatusReason1Code','RR05' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('TaxInformationInvalid','ExternalStatusReason1Code','RR06' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('RemittanceInformationInvalid','ExternalStatusReason1Code','RR07' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('RemittanceInformationTruncated','ExternalStatusReason1Code','RR08' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidStructuredCreditorReference','ExternalStatusReason1Code','RR09' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidCharacterSet','ExternalStatusReason1Code','RR10' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidDebtorAgentServiceID','ExternalStatusReason1Code','RR11' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidPartyID','ExternalStatusReason1Code','RR12' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ValidRequestForCancellationAcknowledged','ExternalStatusReason1Code','S000' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('UETRFlaggedForCancellation','ExternalStatusReason1Code','S001' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('NetworkStopOfUETR','ExternalStatusReason1Code','S002' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('RequestForCancellationForwarded','ExternalStatusReason1Code','S003' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('RequestForCancellationDeliveryAcknowledgement','ExternalStatusReason1Code','S004' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Specific Service offered by Debtor Agent','ExternalStatusReason1Code','SL01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Specific Service offered by Creditor Agent','ExternalStatusReason1Code','SL02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ServiceofClearingSystem','ExternalStatusReason1Code','SL03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Creditor not on Whitelist of Debtor','ExternalStatusReason1Code','SL11' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Creditor on Blacklist of Debtor','ExternalStatusReason1Code','SL12' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Maximum number of Direct Debit Transactions exceeded','ExternalStatusReason1Code','SL13' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Maximum Direct Debit Transaction Amount exceeded','ExternalStatusReason1Code','SL14' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('TransmissonAborted','ExternalStatusReason1Code','TA01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('NoDataAvailable','ExternalStatusReason1Code','TD01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('FileNonReadable','ExternalStatusReason1Code','TD02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('IncorrectFileStructure','ExternalStatusReason1Code','TD03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('TokenInvalid','ExternalStatusReason1Code','TK01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('SenderTokenNotFound','ExternalStatusReason1Code','TK02' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('ReceiverTokenNotFound','ExternalStatusReason1Code','TK03' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('TokenMissing','ExternalStatusReason1Code','TK09' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('TokenCounterpartyMismatch','ExternalStatusReason1Code','TKCM' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('TokenSingleUse','ExternalStatusReason1Code','TKSG' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('TokenSuspended','ExternalStatusReason1Code','TKSP' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('TokenValueLimitExceeded','ExternalStatusReason1Code','TKVE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('TokenExpired','ExternalStatusReason1Code','TKXP' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('InvalidCutOffTime. Formerly:  CutOffTime','ExternalStatusReason1Code','TM01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('TransmissionSuccessful','ExternalStatusReason1Code','TS01' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('TransferToSignByHand','ExternalStatusReason1Code','TS04' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','AccrualFeeType' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','OtherFeeType' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Configuration for engines','engineParam','adapterConfig' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'HedgeRelationshipDefinitionType','Portfolio Fair Value Hedge' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('OrderBundle Static Data Filter criteria','sdFilterCriterion.Factory','OrderBundle' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Enables SDFilter Simulate function for OrderBundle','SDFilterSimulateSubjectTypes','OrderBundle' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleAMOrder','CheckLimit' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleAMBlockOrder','SetKeywords' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','Order Id' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','Order Bundle Id' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('No Record','CsvReportContent','EmptyReportRecord' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Precious Metal Units Domain','domainName','PreciousMetalUnits.XAU' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Precious Metal Unit - Ounces','PreciousMetalUnits.XAU','Ounces' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Precious Metal Unit - Grams','PreciousMetalUnits.XAU','Grams' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','postingAttributes' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'postingAttributes','Hedging Trade Id' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'creAttribute','Hedging Trade Id' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('This Scheduled Task applies the quote mapping configurations to Bond Products','scheduledTask','APPLY_BOND_QUOTE_MAPPING' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('This Scheduled Task applies the quote mapping configurations to Equity Products','scheduledTask','APPLY_EQUITY_QUOTE_MAPPING' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Portfolio Swap Contract Attributes','domainName','PortfolioSwapContractAttributes' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (' Shows whether the contract spread changes have been propagated to applicable trades ','PortfolioSwapContractAttributes','RERATE_SPREAD_PROPAGATED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'PDF.Templates','DraftCheque.html' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'PDF.Templates','DraftChequeCAD.html' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes','DraftCheque' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes','MT111Tag75' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes.UPDATE_XFER_ATTR.Editable','MT111Tag75' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes.UPDATE_XFER_ATTR.Editable','RemittanceInfo' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes.UPDATE_XFER_ATTR.Editable','SenderInfo' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes.UPDATE_XFER_ATTR.RemittanceInfo','MT111Tag75' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes.UPDATE_XFER_ATTR.SenderInfo','MT111Tag75' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'PropagateTradeKeyword','DraftCheque' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','DraftCheque' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'PanelMainKeywords','DraftCheque' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'FX.keywords','DraftCheque' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('UNKNOWN PARTY','ManualPartyName','Beneficiary' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Advice of Cheque','SWIFT.Templates','MT110' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Request for Stop Payment of a Cheque','SWIFT.Templates','MT111' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MESSAGE.Templates','DraftCheque.html' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MESSAGE.Templates','DraftChequeCAD.html' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'transferAction','UPDATE_XFER_ATTR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','OrderBundleStatus' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleStatus','PENDING' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleStatus','PARTIAL_EXEC' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleStatus','NONE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleStatus','LIMIT_VIOLATION' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleStatus','SENT' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleStatus','EXECUTED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleStatus','CREATED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleStatus','CANCELED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleStatus','REJECTED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleStatus','LIMIT_CHECK' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','workflowRuleOrderBundle' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleOrderBundle','TriggerChildrenWorkflow' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleOrderBundle','CheckLimit' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleOrderBundle','SetKeywords' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','OrderBundleAttributes' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAttributes','LIMIT_CHECKED_PERFORMED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAttributes','LIMIT_IN_BREACH' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAttributes','LIMIT_IN_VIOLATION' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAttributes','LIMIT_IN_WARNING' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAttributes','LIMIT_VIOLATION_COMMENT' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAttributes','LIMIT_VIOLATION_IDS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','OrderBundleAction' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAction','UPDATE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAction','SEND_TO_MARKET' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAction','SEND' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAction','REJECT' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAction','PARTIAL_EXECUTE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAction','NEW' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAction','MANUAL_SEND' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAction','MANUAL_AUTHORIZE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAction','EXECUTE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAction','CANCEL' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAction','AUTHORIZE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAction','ASSIGN' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAction','AMEND' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OrderBundleAction','ACK' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'AMOrderAction','BUNDLE_CANCEL' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleAMOrder','TriggerParentWorkflow' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleAMOrder','SetKeywords' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Domain to specify date roll to overide CA for intex bonds','domainName','ABS_MBS_CA_Date_Roll' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('User updates the RateIndex of a trade. Typical result status: RATEINDEX_UPDATED or TERMINATED','tradeAction','RATEINDEX_UPDATE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeStatus','RATEINDEX_UPDATED' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Margin Calculator Config','domainName','MarginCalculator' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MarginCalculator','HEDGE_TRADES_SAVE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MarginCalculator','HEDGE_TRADES_BOOK_NAME' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MarginCalculator','HEDGE_TRADES_COUNTERPARTY_NAME' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Margin OTC CalculationSet','domainName','Margin.OTC.CalculationSet' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','IA_ACCOUNT' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('MFM Multiplier Report','REPORT.Types','MFMMultiplier' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Product class for Schedule','domainName','MarginInput.SCHEDULE.ProductClass' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('messageType','INC_PACS009' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('messageType','INC_PACS008' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('INC_PACS008','incomingType','PACS008' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('INC_PACS009','incomingType','PACS009' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('ExternalMessageField.MessageMapper','PACS009' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('ExternalMessageField.MessageMapper','PACS008' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','PaymentCOVMX.selector' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','PaymentCOVMXT2.selector' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','PaymentCOVMXSIX.selector' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','PaymentCOVMXCBPR.selector' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','PaymentCOVMXCHAPS.selector' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('06','MX.Versions','pacs.008.001' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('06','MX.Versions','pacs.009.001' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('08','MX.Versions','pacs.008.001.T2' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('08','MX.Versions','pacs.008.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('08','MX.Versions','pacs.009.001.T2' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('08','MX.Versions','pacs.009.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('05','MX.Versions','camt.050.001.T2' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('09','MX.Versions','pacs.004.001.T2' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('09','MX.Versions','pacs.004.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('03','MX.Versions','pacs.010.001.T2' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleTransfer','CheckTarget2Valid' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'leAttributeType','SIXClrSysID_Code' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'leAttributeType','SIXMmbId_ID' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'sdiAttribute','SIXInstructionToRTGS' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates.COV','pacs.009.001.COV.T2' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates.COV','pacs.009.001.COV.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates.COV','pacs.009.001.COV.CHAPS' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','pacs.008.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','pacs.004.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','pacs.009.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('XferAttributes','LinkedMessageIdentifier' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('XferAttributes','LinkedMessageType' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('XferAttributes','LinkedInstructionId' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('XferAttributes','LinkedEndToEndId' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('XferAttributes','LinkedUETR' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('XferAttributes','LinkedInterbankSettleAmount' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('XferAttributes','LinkedInterbankSettleDate' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('XferAttributes','ReturnInstructingAgentBIC' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('XferAttributes','ReturnInstructedAgentBIC' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('XferAttributes','ReturnReason' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('XferAttributes','ReturnAdditionalInformation' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('tradeKeyword','LinkedMessageIdentifier' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('tradeKeyword','LinkedMessageType' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('tradeKeyword','LinkedInstructionId' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('tradeKeyword','LinkedEndToEndId' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('tradeKeyword','LinkedUETR' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('tradeKeyword','LinkedInterbankSettleAmount' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('tradeKeyword','LinkedInterbankSettleDate' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('tradeKeyword','ReturnInstructingAgentBIC' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('tradeKeyword','ReturnInstructedAgentBIC' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('tradeKeyword','ReturnReason' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('tradeKeyword','ReturnAdditionalInformation' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('PropagateTradeKeyword','LinkedMessageIdentifier' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('PropagateTradeKeyword','LinkedMessageType' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('PropagateTradeKeyword','LinkedInstructionId' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('PropagateTradeKeyword','LinkedEndToEndId' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('PropagateTradeKeyword','LinkedUETR' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('PropagateTradeKeyword','LinkedInterbankSettleAmount' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('PropagateTradeKeyword','LinkedInterbankSettleDate' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('PropagateTradeKeyword','ReturnInstructingAgentBIC' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('PropagateTradeKeyword','ReturnInstructedAgentBIC' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('PropagateTradeKeyword','ReturnReason' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('PropagateTradeKeyword','ReturnAdditionalInformation' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('02','MX.BAH.Versions','pacs.008.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('02','MX.BAH.Versions','pacs.004.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('02','MX.BAH.Versions','pacs.009.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.Templates.GPI','pacs.008.001.T2' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.Templates.GPI','pacs.009.001.T2' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.Templates.GPI','pacs.009.001.COV.T2' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.Templates.GPI','pacs.008.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.Templates.GPI','pacs.009.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.Templates.GPI','pacs.009.001.COV.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('10','MX.Versions','pacs.002.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('02','MX.BAH.Versions','pacs.002.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','pacs.002.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to create and modify value date control config','function','AddModifyValueDateControl' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Access permission to remove value date control config','function','RemoveValueDateControl' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','MessageIdentifier' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'messageType','INC_PACS004' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'messageType','INC_PACS002' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('INC_PACS004','incomingType','PACS004' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('INC_PACS002','incomingType','PACS002' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ExternalMessageField.MessageMapper','PACS004' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'ExternalMessageField.MessageMapper','PACS002' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','BusinessMessageIdentifier' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','LinkedOriginalMsgId' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','LinkedMessageType' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','LinkedInstructionId' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','LinkedEndToEndId' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','LinkedUETR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','LinkedSettlementAmount' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','LinkedSettlementAmountCcy' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','LinkedSettlementDate' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','ReturnedAmount' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','ReturnedAmountCcy' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','ReturnSettlementDate' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','InstructingAgentBIC' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','InstructedAgentBIC' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','ReturnReasonCode' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','ReturnReasonCodeDescription' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','AdditionalInformation' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','TransactionStatus' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','StatusReasonInformation' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','ClearingSystemReference' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MsgAttributes','EffectiveInterbankSettlementDate' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MX.Templates','pacs.009.001.T2' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MX.Templates','pacs.008.001.T2' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'MX.Templates','pacs.004.001.T2' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleTransfer','RemoveXferAttributes' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleTransfer','AddRecallDateAttribute' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleTransfer','AddRequestDateAttribute' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleMessage','PACS002Rejection' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'transferAction','RETURN' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes','ReturnTransfer' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes','PACS004Direction' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes','ReturnedXferId' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes','MessageIdentifier' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes','MessageType' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes','InstructionId' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes','EndToEndId' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes','UETR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes','InterbankSettleAmount' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes','InterbankSettleDate' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes','InstructingAgentBIC' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes','InstructedAgentBIC' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'XferAttributes','ReturnedTransfer' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'SimpleTransfer.subtype','RETURN' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('06','MX.Versions','camt.057.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('02','MX.BAH.Versions','camt.057.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','camt.057.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('08','MX.Versions','pacs.008.001.CHAPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('02','MX.BAH.Versions','pacs.008.001.CHAPS' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','pacs.008.001.CHAPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleMessage','HandleMXReceipt' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('08','MX.Versions','pacs.009.001.CHAPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('02','MX.BAH.Versions','pacs.009.001.CHAPS' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','pacs.009.001.CHAPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('09','MX.Versions','pacs.004.001.CHAPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('02','MX.BAH.Versions','pacs.004.001.CHAPS' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','pacs.004.001.CHAPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'leAttributeType','CHAPSClrSysID_Code' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'leAttributeType','CHAPSMmbId_ID' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('messageType','INC_CAMT054' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('INC_CAMT054','incomingType','CAMT054' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('ExternalMessageField.MessageMapper','CAMT054' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','camt.054.001.CBPR' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','camt.054.001.T2' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','camt.054.001.SIX' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','PaymentCOVMXMEPS.selector' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','pacs.009.001.MEPS' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates.COV','pacs.009.001.COV.MEPS' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.Templates.GPI','pacs.009.001.MEPS' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.Templates.GPI','pacs.009.001.COV.MEPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('08','MX.Versions','pacs.009.001.MEPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('02','MX.BAH.Versions','pacs.009.001.MEPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('01','MX.BAH.Versions','pacs.004.001.SIX' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','pacs.004.001.SIX' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('messageType','INC_PACS010' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('INC_PACS010','incomingType','PACS010' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('ExternalMessageField.MessageMapper','PACS010' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('01','MX.BAH.BusinessService.Versions','pacs.009.001.CHAPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('01','MX.BAH.BusinessService.Versions','pacs.008.001.CHAPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('01','MX.BAH.BusinessService.Versions','pacs.004.001.CHAPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('03.ch.01','MX.Versions','camt.050.001.SIX' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('02.ch.02','MX.Versions','pacs.004.001.SIX' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('02.ch.02','MX.Versions','pacs.008.001.SIX' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('02.ch.02','MX.Versions','pacs.009.001.SIX' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','camt.050.001.SIX' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('MX.Templates','pacs.008.001.MEPS' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('SWIFT.Templates.GPI','pacs.008.001.COV.MEPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('08','MX.Versions','pacs.008.001.MEPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('02','MX.BAH.Versions','pacs.008.001.MEPS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Core service role','function','CORE_SERVICE_MANAGERRole' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Core service role','function','CORE_SERVICE_USERRole' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','UploadSenderConfig' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','SkipWorkflowCheck' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','UploadReceiverConfig' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','OISDiscountingMethodEXPCurrencies' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','CDSNettingKeys' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','IRDNettingKeys' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','UseFlexNettingCpty' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'OISDiscountingMethodEXPCurrencies','BRL' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleTrade','UpdateUndoRoll' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleTrade','PlatformModAffirm' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'AllocationKeywords','TransitionTo' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'AllocationKeywords','TransitionFrom' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'AllocationKeywords','TransitionReason' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','PlatformTransitionTradeId' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','PlatformTransitionReason' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','PlatformTransitionTradeIdType' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','TransitionTo' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','TransitionFrom' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','TransitionReason' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Configuration for Exercise action, all allowed Exercise actions need to specified here','domainName','UploadAllowedExerciseActions' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'UploadMessageFormatTypes','FCM' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Calypso mapping for uploader Interface types','domainName','UploaderCalypsoMapping.Types' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Calypso mapping for uploader Interface types','CalypsoMapping.Interfaces','Uploader' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Calypso mapping for uploader Interface types','CalypsoMapping.Interfaces','UBS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Calypso mapping for uploader Interface types','UploaderCalypsoMapping.Types','MappingsTranslator' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'UploaderCalypsoMapping.Types','BloombergRequestProducts' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'UploaderCalypsoMapping.Types','UBSFieldMapping' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'UBSCalypsoMapping.Types','Account' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'UBSCalypsoMapping.Types','AvgPriceB' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'UBSCalypsoMapping.Types','ClearingExchangeTicker' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'UBSCalypsoMapping.Types','ClientAccount' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'UBSCalypsoMapping.Types','Currency' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'UBSCalypsoMapping.Types','FieldMapping' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'UBSCalypsoMapping.Types','LegalEntity' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'UBSCalypsoMapping.Types','OptionType' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'UBSCalypsoMapping.Types','TradeAction' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'UBSCalypsoMapping.Types','TradeKeywords' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'UBSCalypsoMapping.Types','TradeType' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'UBSCalypsoMapping.Types','Translator' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('All the fees will be removed from the trade for the product types present in this domain if in the uploader file no fees are given.','domainName','UploaderRemoveFeesForProduct' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Source values for platform','domainName','PlatformMessageSourceTypes' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Source and supported file type values','domainName','UploadMessageFileTypes' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Interfaces Source value to be enabled in WebUI','domainName','UploadMessageSourceWebUI' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'UploadMessageSourceWebUI','Uploader' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('XML,FCM','UploadMessageSourceTypes','UBS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Configuration for Skipping Spot Date Validation','domainName','UploadSkipSpotDateValidation' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Configuration to add takeup keywords on child trade','domainName','UploadTakeupKeywords' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','UploadBOMessageModeSource' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','UploadAddUndoTakeUpKeywords' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'domainName','UploadAddUndoTakeUpAction' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleCollateral','CheckPosition' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleCollateral','Release' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleCollateral','CheckFullExecution' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleCollateral','AccommodationCharge' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'workflowRuleCollateral','UpdateTripartyExposureTrade' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'measuresForAdjustment','PM_SIMM' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'measuresForAdjustment','PM_SCHEDULE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('SubTypes for CoverDistribution trades','domainName','CoverDistribution.subType' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('SubTypes for CoverDistribution trades','CoverDistribution.subType','CoverDistribution' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'InventoryAggregations','CollateralPool-NettingConfig' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'classAuthMode','CollateralInventoryPool' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'classAuthMode','CollateralSource' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('tk.marketdata','classAuthMode','MarginCallCreditRatingConfiguration' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'classAuthMode','CollateralConfig' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Risk Currency','mccAdditionalField','RISK_CCY' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Stress Loss Margin','mccAdditionalField','SLM' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('domainName','mccAdditionalField.SLM' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('mccAdditionalField.SLM','True' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('mccAdditionalField.SLM','False' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('CollateralContext','POSITION_AGGREGATION_LEVEL' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('domainName','CollateralContext.POSITION_AGGREGATION_LEVEL' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('CollateralContext.POSITION_AGGREGATION_LEVEL','Book' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('CollateralContext.POSITION_AGGREGATION_LEVEL','Global' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('CollateralContext','RECOMPUTE_FINAL_CALL' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('domainName','CollateralContext.RECOMPUTE_FINAL_CALL' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('CollateralContext.RECOMPUTE_FINAL_CALL','true' )
/

    INSERT 
    INTO
        domain_values
        ( name, value ) 
    VALUES
        ('CollateralContext.RECOMPUTE_FINAL_CALL','false' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'Allocation.AutoAdjustType','Return & New Margin' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Max number of MarginCallEntry allowed','userAccessPermAttributes','Max.MarginCallEntry' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Max number of MarginCallDetailEntry allowed','userAccessPermAttributes','Max.MarginCallDetailEntry' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Max number of MarginCallAllocation allowed','userAccessPermAttributes','Max.MarginCallAllocation' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Max number of MarginCallPosition allowed','userAccessPermAttributes','Max.MarginCallPosition' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'FpMLCalypsoMapping.Types','SettlementMatrix' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'FpMLCalypsoMapping.Types','Seniority' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'FpMLCalypsoMapping.Types','ProductType' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'FpMLCalypsoMapping.Types','OISIndex' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Treasury Fund Transfer Pricing Product type','productType','FTPProduct' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Treasury FTP Product sub type for Bond','FTPProduct.subType','Bond' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Treasury FTP Product sub type for StructuredFlows','FTPProduct.subType','StructuredFlows' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Treasury FTP COLL_LIQUIDITY_PREMIUM cost type from FtpCostComponentNames domain values','FTPProduct.extendedType','COLL_LIQUIDITY_PREMIUM' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Treasury FTP LIQUIDITY_PREMIUM cost type from FtpCostComponentNames domain values','FTPProduct.extendedType','LIQUIDITY_PREMIUM' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Treasury FTP BASIS_COST cost type from FtpCostComponentNames domain values','FTPProduct.extendedType','BASIS_COST' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Treasury FTP SWAP_COST cost type from FtpCostComponentNames domain values','FTPProduct.extendedType','SWAP_COST' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Treasury FTPProduct ReportStyle','productTypeReportStyle','FTPProduct' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Treasury Pricers for FTPProduct','domainName','FTPProduct.Pricer' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Treasury Pricer for FTPProduct','FTPProduct.Pricer','PricerFTPProduct' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Treasury Pricer for FTPProduct filtering terminated legs','FTPProduct.Pricer','PricerFTPProductFilterTerminated' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Treasury FTP Funding trades generation','scheduledTask','FTP_TRADE_GENERATION' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Action applied on trades processed and saved by the FTP engine','tradeAction','FTP_TRADE_CANCEL' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('Action applied on trades processed and saved by the FTP engine','tradeAction','FTP_TRADE_MATURE`' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','FTP_TRADE_TYPE' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','FTP_TRADE_ERROR' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'tradeKeyword','FTP_TRADE_STATUS' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        ('filter based on Engine name and product types/sub types','eventFilter','ProductEventFilter' )
/

    INSERT 
    INTO
        domain_values
        ( description, name, value ) 
    VALUES
        (null,'FtpEngineProcessingStatus','MATURED' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_comment, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.SecFinancePricerMeasure','Bond Coupon Delayed payment at Repo Maturity.',606,'SEC_FIN_DELAYED_COUPON' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_comment, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.SecFinancePricerMeasure',null,607,'SEC_FIN_LIABILITY_PRINCIPAL' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_comment, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.SecFinancePricerMeasure',null,608,'SEC_FIN_LIABILITY_ACCRUAL' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_comment, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.SecFinancePricerMeasure','Sum of all future Cash Flows (type Principal)',534,'SEC_FIN_FUTURE_PRINCIPAL_FLOWS' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureTAX_LN_AM',535,'TAX_LN_AM' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.core.PricerMeasure',536,'PV01_DISC' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureMTM_BASE',497,'MTM_BASE' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureMTM_CCY',498,'MTM_CCY' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureFX_PL',535,'FX_PL' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.calculators.PricerMeasureBond',920,'DIRTY_PRICE_SCALED' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.calculators.PricerMeasureBond',921,'TRADE_DIRTY_PRICE_SCALED' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureACCRUAL_TERM_REAL',526,'ACCRUAL_TERM_REAL' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureACCRUAL_TERM_REAL_PAY',527,'ACCRUAL_TERM_REAL_PAY' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureACCRUAL_TERM_REAL_REC',528,'ACCRUAL_TERM_REAL_REC' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureACCRUAL_REAL_TD',529,'ACCRUAL_REAL_TD' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureACCRUAL_REAL_TD_PAY',530,'ACCRUAL_REAL_TD_PAY' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureACCRUAL_REAL_TD_REC',531,'ACCRUAL_REAL_TD_REC' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureCA_PV_NET_COST',929,'CA_PV_NET_COST' )
/

    INSERT 
    INTO
        pricer_measure
        ( measure_class_name, measure_id, measure_name ) 
    VALUES
        ('tk.pricer.PricerMeasureCA_PV_NET_COST_AM',930,'CA_PV_NET_COST_AM' )
/

    INSERT 
    INTO
        referring_object
        ( ref_obj_id, rfg_obj_class_name, rfg_obj_desc, rfg_obj_id, rfg_obj_window, rfg_tbl_join_cols, rfg_tbl_name, rfg_tbl_sel_cols, rfg_tbl_sel_types ) 
    VALUES
        (1,'ConcentrationLimit','ConcentrationLimit - Rule Definition - Securities Filter',801,'apps.refdata.concentration.ConcentrationRuleWindow','sd_filter','concentration_limit','rule_id','1' )
/

    INSERT 
    INTO
        referring_object
        ( ref_obj_id, rfg_obj_class_name, rfg_obj_desc, rfg_obj_id, rfg_obj_window, rfg_tbl_join_cols, rfg_tbl_name, rfg_tbl_sel_cols, rfg_tbl_sel_types ) 
    VALUES
        (1,'MarginCallConfig','Collateral Eligible Books Filter',802,'apps.refdata.BOMarginCallConfigWindow','value','eligible_books_kv','id','1' )
/

    INSERT 
    INTO
        book_attribute
        ( attribute_name, comments ) 
    VALUES
        ('Include WHT In OPL','Include Effect of WithholdingTax in OPL.' )
/


/* Applying Schema Statements - end */



/* Applying xtra statements - start */


    update
        calypso_database_module_audit 
    set
        version='4.2.00' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='acadia'
/

    insert 
    into
        calypso_database_module_audit
        (name,version,createdts) 
    values
        ('acc-pl-reconciliation','16.1.0.71',CURRENT_TIMESTAMP)
/

    insert 
    into
        calypso_database_module_audit
        (name,version,createdts) 
    values
        ('audit-service','1.0.4',CURRENT_TIMESTAMP)
/

    update
        calypso_database_module_audit 
    set
        version='1.15.0' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='bo-messaging-core'
/

    insert 
    into
        calypso_database_module_audit
        (name,version,createdts) 
    values
        ('bo-messaging-mx-cash','1.20.1',CURRENT_TIMESTAMP)
/

    update
        calypso_database_module_audit 
    set
        version='1.15.0' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='bo-messaging-mx-colr'
/

    update
        calypso_database_module_audit 
    set
        version='1.15.0' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='bo-messaging-mx-core'
/

    update
        calypso_database_module_audit 
    set
        version='1.15.0' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='bo-messaging-mx-fxtr'
/

    update
        calypso_database_module_audit 
    set
        version='1.15.0' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='bo-messaging-mx-jd'
/

    update
        calypso_database_module_audit 
    set
        version='1.15.0' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='bo-messaging-mx-sese'
/

    update
        calypso_database_module_audit 
    set
        version='5.6.1' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='collateral'
/

    insert 
    into
        calypso_database_module_audit
        (name,version,createdts) 
    values
        ('core-data-srvc','4.7.1',CURRENT_TIMESTAMP)
/

    update
        calypso_database_module_audit 
    set
        version='16.1.0.71' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='core'
/

    update
        calypso_database_module_audit 
    set
        version='5.3.0' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='datauploader'
/

    insert 
    into
        calypso_database_module_audit
        (name,version,createdts) 
    values
        ('integration-services','1.0.0',CURRENT_TIMESTAMP)
/

    update
        calypso_database_module_audit 
    set
        version='16.1.0.71' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='liquidity'
/

    update
        calypso_database_module_audit 
    set
        version='8.6.3' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='margin-calculator-unrestricted'
/

    insert 
    into
        calypso_database_module_audit
        (name,version,createdts) 
    values
        ('margin-manager','5.0.0',CURRENT_TIMESTAMP)
/

    insert 
    into
        calypso_database_module_audit
        (name,version,createdts) 
    values
        ('margin-simm','7.0.0',CURRENT_TIMESTAMP)
/

    update
        calypso_database_module_audit 
    set
        version='2.9.35' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='matching'
/

    update
        calypso_database_module_audit 
    set
        version='16.1.0.71' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='middleofficeam'
/

    insert 
    into
        calypso_database_module_audit
        (name,version,createdts) 
    values
        ('security-finance','16.1.0.71',CURRENT_TIMESTAMP)
/

    insert 
    into
        calypso_database_module_audit
        (name,version,createdts) 
    values
        ('objectstorage-service','2.6.0',CURRENT_TIMESTAMP)
/

    insert 
    into
        calypso_database_module_audit
        (name,version,createdts) 
    values
        ('security-finance','16.1.0.71',CURRENT_TIMESTAMP)
/

    update
        calypso_database_module_audit 
    set
        version='1.4.24' ,
        createdts=CURRENT_TIMESTAMP 
    where
        name='swift-mt-core'
/

    insert 
    into
        calypso_database_module_audit
        (name,version,createdts) 
    values
        ('treasury','16.1.0.71',CURRENT_TIMESTAMP)
/

    insert 
    into
        calypso_database_module_audit
        (name,version,createdts) 
    values
        ('user-preferences-service','1.5.16',CURRENT_TIMESTAMP)
/


/* Applying xtra statements - end */



/* one time install statements - start */



/* one time install statements - end */



/* Applying Stored Procedures - start */

CREATE OR REPLACE FUNCTION custom_rule_discriminator (name IN varchar2) RETURN varchar2
IS
BEGIN
IF instr(name,'MessageRule') <> 0 THEN
RETURN 'MessageRule';
ELSIF instr(name,'TradeRule') <> 0 THEN
RETURN 'TradeRule';
ELSIF instr(name,'TransferRule') <> 0 THEN
RETURN 'TransferRule';
ELSIF instr(name,'WorkflowRule') <> 0 THEN
RETURN 'WorkflowRule';
ELSE
RETURN 'error';
END IF;
END custom_rule_discriminator;
/
CREATE OR REPLACE PROCEDURE drop_function ( proc_name IN user_tab_columns.table_name%TYPE) AS
 x number;
BEGIN
   BEGIN
   SELECT count(*) into x FROM user_objects WHERE object_name=UPPER(proc_name) and object_type= 'FUNCTION';
   exception
        when NO_DATA_FOUND THEN
        x:=0;
        when others then
        null;
    end;
    IF x > 0 THEN
       EXECUTE IMMEDIATE 'drop function '|| proc_name;
    END IF;
END drop_function;
/
begin
 drop_function ('rate_index_string_value');
end;
/
create or replace view rate_index_string_value as select rate_index_id,
replace(substr(quote_name, instr(quote_name, '.', 1, 1) + 1), '.', '/') string_value
from rate_index
/
create or replace procedure sp_trunc_temp_tables
as
begin
execute immediate 'truncate table TRADE_FILTER_PAGE' ;
execute immediate 'truncate table TF_TEMP_TABLE' ;
end;
/
CREATE OR REPLACE PROCEDURE sp_analysis_out_permp (arg_id   IN NUMBER )
AS BEGIN
UPDATE analysis_output_perm_pages p1 
SET page_number = ( SELECT rnum FROM ( SELECT page_id, row_number() 
OVER (ORDER BY page_id) -1 rnum 
FROM analysis_output_perm_pages 
WHERE id = arg_id AND page_number<>-1) 
p2 WHERE p1.page_id = p2.page_id ) 
where p1.id = arg_id AND p1.page_number <> -1;
END;
/
CREATE OR REPLACE PROCEDURE SP_INSERT_OFFICIAL_PL_BUCKET
     ( 
        p_PL_BUCKET_ID        IN  OFFICIAL_PL_BUCKET.PL_BUCKET_ID%TYPE,                
        p_LEG                 IN  OFFICIAL_PL_BUCKET.LEG%TYPE,                  
        p_LOCATION            IN  OFFICIAL_PL_BUCKET.LOCATION%TYPE, 
        p_STRIP_DATE          IN  OFFICIAL_PL_BUCKET.STRIP_DATE%TYPE, 
        p_SUBPRODUCT_ID       IN  OFFICIAL_PL_BUCKET.SUBPRODUCT_ID%TYPE, 
        p_SUBPRODUCT_TYPE     IN  OFFICIAL_PL_BUCKET.SUBPRODUCT_TYPE%TYPE,                
        p_SUBPRODUCT_SUB_TYPE IN  OFFICIAL_PL_BUCKET.SUBPRODUCT_SUB_TYPE%TYPE,                
        p_SUBPRODUCT_EXTENDED_TYPE IN  OFFICIAL_PL_BUCKET.SUBPRODUCT_EXTENDED_TYPE%TYPE,
        p_EXISTING_PL_BUCKET_ID OUT OFFICIAL_PL_BUCKET.PL_BUCKET_ID%TYPE
     )
AS 
BEGIN  
	
	INSERT INTO OFFICIAL_PL_BUCKET 
		(PL_BUCKET_ID,LEG,LOCATION,STRIP_DATE,
		SUBPRODUCT_ID,SUBPRODUCT_TYPE,SUBPRODUCT_SUB_TYPE,SUBPRODUCT_EXTENDED_TYPE) 
	VALUES 
		(p_PL_BUCKET_ID,p_LEG,p_LOCATION,p_STRIP_DATE,
		p_SUBPRODUCT_ID,p_SUBPRODUCT_TYPE,p_SUBPRODUCT_SUB_TYPE,p_SUBPRODUCT_EXTENDED_TYPE) ;
	
	COMMIT;
	
	p_EXISTING_PL_BUCKET_ID := p_PL_BUCKET_ID;
	RETURN;
	
EXCEPTION 
        WHEN DUP_VAL_ON_INDEX THEN
			SELECT  
			      PL_BUCKET_ID
			INTO
			      p_EXISTING_PL_BUCKET_ID
			FROM   	OFFICIAL_PL_BUCKET
			WHERE (LEG = p_LEG OR ((LEG IS NULL) AND (p_LEG IS NULL)))
			AND		(LOCATION = p_LOCATION OR ((LOCATION IS NULL) AND (p_LOCATION IS NULL)))
			AND		(STRIP_DATE = p_STRIP_DATE OR ((STRIP_DATE IS NULL) AND (p_STRIP_DATE IS NULL)))
			AND		(SUBPRODUCT_ID = p_SUBPRODUCT_ID OR ((SUBPRODUCT_ID IS NULL) AND (p_SUBPRODUCT_ID IS NULL)))
			AND		(SUBPRODUCT_TYPE = p_SUBPRODUCT_TYPE OR ((SUBPRODUCT_TYPE IS NULL) AND (p_SUBPRODUCT_TYPE IS NULL)))
			AND		(SUBPRODUCT_SUB_TYPE = p_SUBPRODUCT_SUB_TYPE OR ((SUBPRODUCT_SUB_TYPE IS NULL) AND (p_SUBPRODUCT_SUB_TYPE IS NULL)))
			AND		(SUBPRODUCT_EXTENDED_TYPE = p_SUBPRODUCT_EXTENDED_TYPE OR ((SUBPRODUCT_EXTENDED_TYPE IS NULL) AND (p_SUBPRODUCT_EXTENDED_TYPE IS NULL)));
  
			RETURN;
        WHEN OTHERS THEN
             RAISE_APPLICATION_ERROR (-20001, 
                                     'Error while inserting new plBucket.  PL_BUCKET_ID=' 
                                     || p_PL_BUCKET_ID || ':$:' || SQLERRM, TRUE) ; 
END SP_INSERT_OFFICIAL_PL_BUCKET ;
/
CREATE OR REPLACE PROCEDURE SP_INSERT_OFFICIAL_PL_UNIT
     ( 
        p_PL_UNIT_ID          IN  OFFICIAL_PL_UNIT.PL_UNIT_ID%TYPE,                
        p_BOOK_ID             IN  OFFICIAL_PL_UNIT.BOOK_ID%TYPE,                  
        p_STRATEGY            IN  OFFICIAL_PL_UNIT.STRATEGY%TYPE, 
        p_TRADER              IN  OFFICIAL_PL_UNIT.TRADER%TYPE, 
        p_DESK                IN  OFFICIAL_PL_UNIT.DESK%TYPE, 
        p_CURRENCY            IN  OFFICIAL_PL_UNIT.CURRENCY%TYPE,                
        p_CURRENCY_PAIR       IN  OFFICIAL_PL_UNIT.CURRENCY_PAIR%TYPE,                
        p_PO_ID               IN  OFFICIAL_PL_UNIT.PO_ID%TYPE,                
        p_IS_BY_TRADE         IN  OFFICIAL_PL_UNIT.IS_BY_TRADE%TYPE,
        p_EXISTING_PL_UNIT_ID OUT OFFICIAL_PL_UNIT.PL_UNIT_ID%TYPE
     )
AS 
BEGIN  
	
	INSERT INTO OFFICIAL_PL_UNIT 
		(PL_UNIT_ID,BOOK_ID,STRATEGY,TRADER,DESK,
		CURRENCY,CURRENCY_PAIR,PO_ID,IS_BY_TRADE) 
	VALUES 
		(p_PL_UNIT_ID,p_BOOK_ID,p_STRATEGY,p_TRADER,p_DESK,
		p_CURRENCY,p_CURRENCY_PAIR,p_PO_ID,p_IS_BY_TRADE);
	
	COMMIT;
	
	p_EXISTING_PL_UNIT_ID := p_PL_UNIT_ID;
	RETURN ;
EXCEPTION 
        WHEN DUP_VAL_ON_INDEX THEN
          SELECT  
              PL_UNIT_ID
          INTO
                p_EXISTING_PL_UNIT_ID
          FROM   	OFFICIAL_PL_UNIT
          WHERE 	(BOOK_ID = p_BOOK_ID OR ((BOOK_ID IS NULL) AND (p_BOOK_ID IS NULL)))
          AND		(STRATEGY = p_STRATEGY OR ((STRATEGY IS NULL) AND (p_STRATEGY IS NULL)))
          AND		(TRADER = p_TRADER OR ((TRADER IS NULL) AND (p_TRADER IS NULL)))
          AND		(DESK = p_DESK OR ((DESK IS NULL) AND (p_DESK IS NULL)))
          AND  		CURRENCY = p_CURRENCY
          AND		(CURRENCY_PAIR = p_CURRENCY_PAIR OR ((CURRENCY_PAIR IS NULL) AND (p_CURRENCY_PAIR IS NULL)))
          AND		PO_ID = p_PO_ID
          AND		IS_BY_TRADE = p_IS_BY_TRADE;
          
          RETURN;
        WHEN OTHERS THEN
             RAISE_APPLICATION_ERROR (-20001, 
                                     'Error while inserting new plUnit.  PL_UNIT_ID=' 
                                     || p_PL_UNIT_ID || ':$:' || SQLERRM, TRUE) ; 
END SP_INSERT_OFFICIAL_PL_UNIT ;
/
CREATE OR REPLACE PROCEDURE SP_INS_OFFICIAL_PL_AGGREGATE
     ( 
        p_AGG_ID              IN  OFFICIAL_PL_AGGREGATE.AGG_ID%TYPE,                
        p_PL_CONFIG_ID        IN  OFFICIAL_PL_AGGREGATE.PL_CONFIG_ID%TYPE, 
        p_BOOK_ID             IN  OFFICIAL_PL_AGGREGATE.BOOK_ID%TYPE,                  
        p_PL_UNIT_ID          IN  OFFICIAL_PL_AGGREGATE.PL_UNIT_ID%TYPE, 
        p_ACTION_DATETIME     IN  OFFICIAL_PL_AGGREGATE.ACTION_DATETIME%TYPE, 
        p_EFFECTIVE_PRODUCT_TYPE  IN  OFFICIAL_PL_AGGREGATE.EFFECTIVE_PRODUCT_TYPE%TYPE,
        p_STRATEGY_ID         IN  OFFICIAL_PL_AGGREGATE.STRATEGY_ID%TYPE, 
        p_EXISTING_AGG_ID OUT OFFICIAL_PL_AGGREGATE.AGG_ID%TYPE
     )
AS 
BEGIN  
	
	INSERT INTO OFFICIAL_PL_AGGREGATE 
		(AGG_ID,PL_CONFIG_ID,BOOK_ID,PL_UNIT_ID,ACTION_DATETIME,
		EFFECTIVE_PRODUCT_TYPE,STRATEGY_ID) 
	VALUES 
		(p_AGG_ID,p_PL_CONFIG_ID,p_BOOK_ID,p_PL_UNIT_ID,p_ACTION_DATETIME,
		p_EFFECTIVE_PRODUCT_TYPE,p_STRATEGY_ID);
	
	COMMIT;
	
	p_EXISTING_AGG_ID := p_AGG_ID;
	RETURN ;
EXCEPTION 
        WHEN DUP_VAL_ON_INDEX THEN
          SELECT  
              AGG_ID
          INTO
                p_EXISTING_AGG_ID
          FROM   	OFFICIAL_PL_AGGREGATE
          WHERE PL_CONFIG_ID = p_PL_CONFIG_ID 	
          AND		BOOK_ID = p_BOOK_ID
          AND		PL_UNIT_ID = p_PL_UNIT_ID
          AND  	EFFECTIVE_PRODUCT_TYPE = p_EFFECTIVE_PRODUCT_TYPE
          AND	STRATEGY_ID = p_STRATEGY_ID;
          
          RETURN;
        WHEN OTHERS THEN
             RAISE_APPLICATION_ERROR (-20001, 
                                     'Error while inserting new opl aggregate.  AGG_ID=' 
                                     || p_AGG_ID || ':$:' || SQLERRM, TRUE) ; 
END SP_INS_OFFICIAL_PL_AGGREGATE ;
/
/* add all new stored procs above this line. The following will compile all invalid objects */

DECLARE
begin
  FOR c1_rec IN (SELECT 'ALTER ' || decode(a.object_type,   'PACKAGE BODY',   'PACKAGE',   'TYPE BODY',   'TYPE', a.object_type) 
  || ' ' || a.object_name || decode(a.object_type,   'JAVA CLASS',   ' RESOLVE',   ' COMPILE') 
  || decode(a.object_type, 'PACKAGE BODY',' BODY', 'TYPE BODY','BODY') FullSql
          FROM user_objects a,(SELECT MAX(LEVEL) mylevel, object_id
             FROM public_dependency START WITH object_id IN
				(SELECT object_id FROM user_objects WHERE status = 'INVALID' and    object_type <> 'SYNONYM' )
				CONNECT BY object_id = PRIOR referenced_object_id
				GROUP BY object_id)b
			WHERE a.object_id = b.object_id(+) 
			AND a.status = 'INVALID'
			AND object_type <> 'SYNONYM' ORDER BY b.mylevel DESC,a.object_name ASC )
  LOOP
  begin
    execute immediate c1_rec.FullSql;
    exception
		when others then
					null;
  end;    
  end LOOP;
end;
/
begin
   execute immediate 'drop procedure sp_mcc_housekeeping';
exception when others then
   if sqlcode != -4043 then
      raise;
   end if;
end;
/


/* Applying Stored Procedures - end */

