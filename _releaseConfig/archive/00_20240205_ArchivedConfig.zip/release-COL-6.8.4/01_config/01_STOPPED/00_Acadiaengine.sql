delete from CALYPSO.ENGINE_CONFIG where ENGINE_NAME = 'ACADIAMessageEngine';
delete from CALYPSO.ENGINE_CONFIG where ENGINE_NAME = 'SenderEngineAcadia';

select * from CALYPSO.ENGINE_CONFIG where ENGINE_NAME = 'ACADIAMessageEngine';
select * from CALYPSO.ENGINE_CONFIG where ENGINE_NAME = 'SenderEngineAcadia';

delete from CALYPSO.ENGINE_PARAM where ENGINE_NAME = 'ACADIAMessageEngine';
delete from CALYPSO.ENGINE_PARAM where ENGINE_NAME = 'SenderEngineAcadia';

delete from PS_EVENT_CONFIG where ENGINE_NAME = 'ACADIAMessageEngine';
delete from PS_EVENT_CONFIG where ENGINE_NAME = 'SenderEngineAcadia';

delete from PS_EVENT_FILTER where ENGINE_NAME = 'ACADIAMessageEngine';
delete from PS_EVENT_FILTER where ENGINE_NAME = 'SenderEngineAcadia';


Insert into CALYPSO.ENGINE_CONFIG (ENGINE_ID,ENGINE_NAME,ENGINE_COMMENT,VERSION_NUM) values ((select max(ENGINE_ID)+1 from CALYPSO.ENGINE_CONFIG),'ACADIAMessageEngine','Starts and stops AcadiaMessageEngine','500');
Insert into CALYPSO.ENGINE_CONFIG (ENGINE_ID,ENGINE_NAME,ENGINE_COMMENT,VERSION_NUM) values ((select max(ENGINE_ID)+1 from CALYPSO.ENGINE_CONFIG),'SenderEngineAcadia','Send messages Acadia','501');

Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('ACADIAMessageEngine','DISPLAY_NAME','ACADIAMessageEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('ACADIAMessageEngine','CLASS_NAME','com.calypso.engine.ACADIAMessageEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('ACADIAMessageEngine','STARTUP','true');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('ACADIAMessageEngine','INSTANCE_NAME','gen_engineserver');

Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SenderEngineAcadia','DISPLAY_NAME','SenderEngineAcadia');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SenderEngineAcadia','CLASS_NAME','com.calypso.engine.advice.SenderEngine');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SenderEngineAcadia','STARTUP','true');
Insert into CALYPSO.ENGINE_PARAM (ENGINE_NAME,PARAM_NAME,PARAM_VALUE) values ('SenderEngineAcadia','INSTANCE_NAME','gen_engineserver');

INSERT INTO PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventMessage','SenderEngineAcadia');
INSERT INTO PS_EVENT_CONFIG (EVENT_CONFIG_NAME,EVENT_CLASS,ENGINE_NAME) VALUES ('Back-Office','PSEventProcessMessage','SenderEngineAcadia');

INSERT INTO PS_EVENT_FILTER (EVENT_CONFIG_NAME,ENGINE_NAME,EVENT_FILTER) VALUES ('Back-Office','SenderEngineAcadia','AcadiaSenderEventFilter');
